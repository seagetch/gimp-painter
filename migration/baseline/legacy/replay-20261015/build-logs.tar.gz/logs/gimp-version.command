/workspace/scratch/5b5281e79681/legacy-filter-positive-20261015/build/prefix/bin/gimp-2.8 --version 
