source /workspace/shared/gimp-build-deps/env.sh
export LEGACY_BUILD_ROOT=/workspace/shared/gimp-legacy-build
export PATH=$LEGACY_BUILD_ROOT/bin:$PATH
export autom4te_perllibdir=$GIMP_DEPS_ROOT/usr/share/autoconf
export AC_MACRODIR=$GIMP_DEPS_ROOT/usr/share/autoconf
export AUTOM4TE=$GIMP_DEPS_ROOT/usr/bin/autom4te
export M4=$GIMP_DEPS_ROOT/usr/bin/m4
export PERL5LIB=$GIMP_DEPS_ROOT/usr/share/automake-1.17:$GIMP_DEPS_ROOT/usr/share/perl5${PERL5LIB:+:$PERL5LIB}
export AUTOMAKE_LIBDIR=$GIMP_DEPS_ROOT/usr/share/automake-1.17
export ACLOCAL_PATH=$GIMP_DEPS_ROOT/usr/share/aclocal
export _lt_pkgdatadir=$GIMP_DEPS_ROOT/usr/share/libtool
export AUTOMAKE=automake
export ACLOCAL=aclocal
export ACLOCAL_FLAGS="-I $GIMP_DEPS_ROOT/usr/share/aclocal"
export PKG_CONFIG_PATH=$LEGACY_BUILD_ROOT/prefix/lib/pkgconfig:$PKG_CONFIG_PATH
export LD_LIBRARY_PATH=$LEGACY_BUILD_ROOT/prefix/lib:$LD_LIBRARY_PATH
export CPPFLAGS="-I$GIMP_DEPS_ROOT/usr/include"
export LDFLAGS="-L$GIMP_DEPS_ROOT/usr/lib/x86_64-linux-gnu -Wl,-rpath,$GIMP_DEPS_ROOT/usr/lib/x86_64-linux-gnu"
export AUTOM4TE_CFG=$LEGACY_BUILD_ROOT/autom4te.cfg
export AUTOCONF=$GIMP_DEPS_ROOT/usr/bin/autoconf
export AUTOHEADER=$GIMP_DEPS_ROOT/usr/bin/autoheader
unset _lt_pkgdatadir
export AUTOCONF=$LEGACY_BUILD_ROOT/bin/autoconf
export gettext_datadir=$GIMP_DEPS_ROOT/usr/share/gettext
export LDFLAGS="-L$LEGACY_BUILD_ROOT/prefix/lib -L$GIMP_DEPS_ROOT/usr/lib/x86_64-linux-gnu -Wl,-rpath,$LEGACY_BUILD_ROOT/prefix/lib -Wl,-rpath,$GIMP_DEPS_ROOT/usr/lib/x86_64-linux-gnu"
export BABL_PATH=$LEGACY_BUILD_ROOT/prefix/lib/babl-0.1
export PERL5LIB=$GIMP_DEPS_ROOT/usr/lib/x86_64-linux-gnu/perl5/5.40:$PERL5LIB
export CPPFLAGS="-I$GIMP_DEPS_ROOT/usr/include -I$GIMP_DEPS_ROOT/usr/include/x86_64-linux-gnu"
