/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef __LAYER_PRESETS_ACTIONS_H__
#define __LAYER_PRESETS_ACTIONS_H__

template <typename T> struct PainterHeaderControlTemplate { T value; };

G_BEGIN_DECLS

void layer_presets_actions_setup (GimpActionGroup *group);
void layer_presets_actions_update (GimpActionGroup *group, gpointer user_data);

G_END_DECLS

#endif
