/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef __LAYER_PRESETS_ACTIONS_H__
#define __LAYER_PRESETS_ACTIONS_H__

G_BEGIN_DECLS

void layer_presets_actions_setup (GimpActionGroup *group);
void layer_presets_actions_update (GimpActionGroup *group, gpointer user_data);

void painter_header_control_reserved (int class);

G_END_DECLS

#endif
