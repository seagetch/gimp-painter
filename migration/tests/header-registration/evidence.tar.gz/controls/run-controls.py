#!/usr/bin/env python3
import copy, hashlib, json, os, shlex, shutil, subprocess, sys
from pathlib import Path
BASE=Path('/workspace/scratch/5b5281e79681')
SRC=BASE/'gimp-painter-port-active'
OUT=BASE/'header-04014-controls/final-current'
NATIVE=BASE/'gimp-native-restore-20261008'
GEN=Path('app/painter/tests/headers/generate-probes.py')
SNAP=OUT/'source-snapshot'
TARGET='app/actions/layer-presets-actions.h'
results=[]
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name, cmd, cwd=OUT, expected=0, contains=None, detail=None):
    d=OUT/name; d.mkdir(parents=True,exist_ok=True)
    (d/'command.json').write_text(json.dumps({'argv':list(map(str,cmd)),'cwd':str(cwd),'environment_script':str(NATIVE/'env-main.sh')},indent=2)+'\n')
    (d/'command.sh').write_text('#!/usr/bin/env bash\nsource '+shlex.quote(str(NATIVE/'env-main.sh'))+'\ncd '+shlex.quote(str(cwd))+'\n'+shlex.join(list(map(str,cmd)))+'\n')
    p=subprocess.run(cmd,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (d/'stdout.log').write_text(p.stdout); (d/'stderr.log').write_text(p.stderr)
    valid=(p.returncode==0 if expected==0 else p.returncode!=0) and (not contains or contains in p.stderr+p.stdout)
    result={'name':name,'returncode':p.returncode,'expected_success':expected==0,'observed_expected_result':valid,'expected_diagnostic':contains,'detail':detail}
    results.append(result)
    print(name, 'expected-result' if valid else 'UNEXPECTED', p.returncode,flush=True)
    return result
# Copy the reviewed source inputs and all production application C headers so the
# boundary scan sees a complete, isolated production-header tree.
initial=OUT/'original-generated'; initial.mkdir(exist_ok=True)
run('generate-original', [sys.executable,SRC/GEN,'--output-dir',initial])
manifest=json.loads((initial/'header-probes.json').read_text())
paths=set(manifest['source_sha256']) | {str(p.relative_to(SRC)) for p in (SRC/'app').rglob('*.h')} | {str(p.relative_to(SRC)) for p in (SRC/'app').rglob('*.hpp')}
paths.add(str(GEN))
for rel in sorted(paths):
    dest=SNAP/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(SRC/rel,dest)
(OUT/'source-snapshot-hashes.json').write_text(json.dumps({p:digest(SNAP/p) for p in sorted(paths)},indent=2)+'\n')
scope_path=SNAP/'migration/inventory/c-header-linkage.json'; scope=json.loads(scope_path.read_text())

def metadata(name, mutate, expected, diagnostic=None):
    data=copy.deepcopy(scope); detail=mutate(data); scope_path.write_text(json.dumps(data,indent=2)+'\n')
    case=OUT/name;case.mkdir(exist_ok=True);shutil.copy2(scope_path,case/'c-header-linkage.json')
    run(name,[sys.executable,SNAP/GEN,'--root',SNAP,'--list'],expected=expected,contains=diagnostic,detail=detail)
    scope_path.write_text(json.dumps(scope,indent=2)+'\n')

def missing_unique(d):
    row=d['routes'].pop(0);return {'removed_route':row['route'],'removed_target':row['target']}
def duplicate(d):
    d['routes'][-1]=copy.deepcopy(d['routes'][0]);return {'duplicated_route':d['routes'][0]['route']}
def cpp_route(d):
    d['routes'][0]['target']='app/painter/resources.hpp';return {'replaced_target':'app/painter/resources.hpp'}
def missing_shared(d):
    row=next(x for x in d['routes'] if x['route']=='libgimpwidgets/gimpframe.h');d['routes'].remove(row);return {'removed_route':row['route'],'retained_shared_target':row['target']}
metadata('missing-unique-route',missing_unique,1,'missing or additional reviewed C-header route')
metadata('duplicate-route',duplicate,1,'duplicate C-header route')
metadata('hpp-c-route',cpp_route,1,'review the C-header boundary')
metadata('missing-shared-route',missing_shared,1,'missing or additional reviewed C-header route')
def reassign_shared(d):
    row=next(x for x in d['routes'] if x['route']=='libgimpwidgets/gimpframe.h');row['route']='libgimpwidgets/control-unreviewed-frame.h';return {'reassigned_route':row['route'],'retained_target':row['target'],'retained_work_ids':row['work_ids']}
metadata('reassigned-shared-route',reassign_shared,1,'reviewed legacy header source duties are missing or reassigned')
# Restore byte-exact metadata before stale-report controls.
shutil.copy2(SRC/'migration/inventory/c-header-linkage.json',scope_path)
run('generate-snapshot',[sys.executable,SNAP/GEN,'--root',SNAP,'--output-dir',OUT/'snapshot-generated'])
# Compiler commands come directly from native Meson's compile database. Only the
# source, object/depfile destinations, diagnostic colour, and overlay include
# search path change; no target object or executable is ever executed.
cc=json.loads((NATIVE/'build-default/compile_commands.json').read_text())
selected={p['language']:p for p in manifest['probes'] if p['label']=='public-header' and p['header']==TARGET}
def compile_case(name, source_language, compiler_language, header_text=None, expected=0, diagnostic=None):
    d=OUT/name;d.mkdir(exist_ok=True)
    probe=selected[source_language]
    tu=d/probe['name'];shutil.copy2(initial/probe['name'],tu)
    overlay=d/'overlay'
    if header_text is not None:
        p=overlay/TARGET;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(header_text)
    command_row=next(row for row in cc if Path(row['file']).name==selected[compiler_language]['name'])
    argv=shlex.split(command_row['command']); args=[];i=0
    while i<len(argv):
        a=argv[i]
        if a in ('-MQ','-MF','-o'):
            i+=2;continue
        if a=='-MD':i+=1;continue
        if a=='-c':i+=2;continue
        if a.startswith('-I'):
            p=Path(a[2:]);a='-I'+str((Path(command_row['directory'])/p).resolve()) if not p.is_absolute() else a
        if a.startswith('-fdiagnostics-color='): a='-fdiagnostics-color=never'
        args.append(a);i+=1
    args[1:1]=['-I'+str(overlay)]
    args+=['-x','c++' if compiler_language=='cpp' else 'c','-o',str(d/'probe.o'),'-c',str(tu)]
    return run(name,args,expected=expected,contains=diagnostic,detail={'header':TARGET,'source_language':source_language,'compiler_language':compiler_language,'native_compile_command':command_row,'source_sha256':digest(tu),'overlay_header_sha256':digest(overlay/TARGET) if header_text is not None else None})
original=(SRC/TARGET).read_text()
compile_case('baseline-c','c','c')
compile_case('baseline-cpp','cpp','cpp')
template=original.replace('G_BEGIN_DECLS','template <typename T> struct PainterHeaderControlTemplate { T value; };\n\nG_BEGIN_DECLS',1)
compile_case('template-leak-c','c','c',template,1,'template')
compile_case('template-control-cpp','cpp','cpp',template)
reserved=original.replace('G_END_DECLS','void painter_header_control_reserved (int class);\n\nG_END_DECLS',1)
compile_case('reserved-control-c','c','c',reserved)
compile_case('reserved-identifier-cpp','cpp','cpp',reserved,1,'class')
structure=original+'\nstruct PainterHeaderControlUnguarded { int value; };\n'
compile_case('double-include-c','c','c',structure,1,'redefinition')
compile_case('double-include-cpp','cpp','cpp',structure,1,'redefinition')
compile_case('c-probe-as-cpp','c','cpp',expected=1,diagnostic='C compiler required')
compile_case('cpp-probe-as-c','cpp','c',expected=1,diagnostic='C++ compiler required')
# Stale generation is refused before archive presence is considered.
p=SNAP/TARGET;p.write_text(original+'\n/* stale-source control */\n')
run('stale-source-metadata',[sys.executable,SNAP/GEN,'--root',SNAP,'--verify-build',OUT/'snapshot-generated'],expected=1,contains='header probe inputs changed')
shutil.copy2(SRC/TARGET,p)
# Record the exact selected environment and compiler identification without
# dumping unrelated environment values or credentials.
env={k:os.environ.get(k) for k in ['PATH','CPATH','CPLUS_INCLUDE_PATH','LIBRARY_PATH','LD_LIBRARY_PATH','PKG_CONFIG_PATH','GIMP_DEPS_DIRECTORY','GIMP_DEPS_ROOT','GIMP_BUILD_PREFIX','CCACHE_DISABLE','LC_ALL']}
for compiler in ['cc','c++']:
    env[compiler]={'path':shutil.which(compiler),'version':subprocess.run([compiler,'--version'],text=True,stdout=subprocess.PIPE).stdout}
(OUT/'selected-environment.json').write_text(json.dumps(env,indent=2)+'\n')
report={'source':str(SRC),'native_build_read_only':str(NATIVE/'build-default'),'source_snapshot':str(SNAP),'no_target_execution':True,'results':results}
(OUT/'controls-result.json').write_text(json.dumps(report,indent=2)+'\n')
print('REPORT',OUT/'controls-result.json',flush=True)
