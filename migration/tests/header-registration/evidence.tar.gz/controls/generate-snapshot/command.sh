#!/usr/bin/env bash
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261008/env-main.sh
cd /workspace/scratch/5b5281e79681/header-04014-controls/final-current
/usr/bin/python3 /workspace/scratch/5b5281e79681/header-04014-controls/final-current/source-snapshot/app/painter/tests/headers/generate-probes.py --root /workspace/scratch/5b5281e79681/header-04014-controls/final-current/source-snapshot --output-dir /workspace/scratch/5b5281e79681/header-04014-controls/final-current/snapshot-generated
