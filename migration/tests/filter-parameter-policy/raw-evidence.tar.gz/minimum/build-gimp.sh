#!/bin/bash
set -euo pipefail
source /workspace/scratch/5b5281e79681/filter-policy-minimum/env.sh
cd "$MINIMUM_ROOT"
python3 run-command.py gimp-setup meson setup --clearcache --reconfigure build/gimp src/gimp --prefix="$MINIMUM_ROOT/prefix" --libdir=lib/x86_64-linux-gnu --native-file=python312-native.ini -Dauto_features=disabled -Dlibunwind=false -Dpainter-http=enabled "-Dc_link_args=-Wl,-rpath-link,$MINIMUM_ROOT/library-view" "-Dcpp_link_args=-Wl,-rpath-link,$MINIMUM_ROOT/library-view"
python3 run-command.py strict-link-configure meson configure --clearcache build/gimp "-Dpkg_config_path=['$MINIMUM_ROOT/pkgconfig-view','/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/pkgconfig']" "-Dbuild.pkg_config_path=['$MINIMUM_ROOT/pkgconfig-view','/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/pkgconfig']" "-Dc_link_args=-Wl,-rpath-link,$MINIMUM_ROOT/library-view" "-Dcpp_link_args=-Wl,-rpath-link,$MINIMUM_ROOT/library-view"
python3 run-command.py gimp-build env "LDFLAGS=-L$MINIMUM_ROOT/build/gimp/libgimpmath -lgimpmath-3.0 -Wl,-rpath-link,$MINIMUM_ROOT/library-view" meson compile -C build/gimp -j4
bash validate-build.sh
