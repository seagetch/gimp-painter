#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json,datetime,time
root=Path(__file__).resolve().parent
label=sys.argv[1]; argv=sys.argv[2:]
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
t=time.monotonic()
with (root/'logs'/f'{label}.log').open('w') as output:
 result=subprocess.run(argv,stdout=output,stderr=subprocess.STDOUT,check=False)
with (root/'evidence/command-history.jsonl').open('a') as output:
 output.write(json.dumps({'label':label,'argv':argv,'cwd':str(Path.cwd()),'started_utc':started,'duration_seconds':round(time.monotonic()-t,3),'exit':result.returncode,'log':f'logs/{label}.log'})+'\n')
print(f'{label}: exit {result.returncode}',flush=True)
raise SystemExit(result.returncode)
