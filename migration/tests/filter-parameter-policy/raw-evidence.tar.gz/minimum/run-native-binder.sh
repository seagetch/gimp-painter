#!/bin/bash
set -euo pipefail
source /workspace/scratch/5b5281e79681/filter-policy-minimum/env.sh
cd "$MINIMUM_ROOT"
flock /workspace/shared/gimp-painter-build.lock python3 run-native-binder.py
