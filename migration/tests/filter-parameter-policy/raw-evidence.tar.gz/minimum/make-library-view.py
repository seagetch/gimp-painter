from pathlib import Path
import re,json
base=Path(__file__).resolve().parent
roots=[Path('/workspace/scratch/5b5281e79681/.deps-debian13/root/usr'),base/'bookworm-root/usr',base/'prefix']
view=base/'library-view'; pcs=base/'pkgconfig-view'; headers=base/'header-view'
view.mkdir(exist_ok=True);pcs.mkdir(exist_ok=True);headers.mkdir(exist_ok=True)
selected={}
for root in roots:
 for source in (root/'include').iterdir():
  target=headers/source.name
  if target.is_symlink():target.unlink()
  if target.exists():raise RuntimeError('Unmanaged header staging entry: '+str(target))
  target.symlink_to(source,target_is_directory=source.is_dir())
 libdir=root/'lib/x86_64-linux-gnu'
 for source in libdir.iterdir():
  if source.name=='pkgconfig':continue
  target=view/source.name
  if target.is_symlink():target.unlink()
  if target.exists():raise RuntimeError('Unmanaged staging entry: '+str(target))
  target.symlink_to(source,target_is_directory=source.is_dir())
  selected[source.name]=str(source)
 for directory in (root/'lib/x86_64-linux-gnu/pkgconfig',root/'lib/pkgconfig',root/'share/pkgconfig'):
  if not directory.is_dir():continue
  for source in directory.glob('*.pc'):
   content=source.read_text()
   # The library view unifies real files. Requirements and versions are untouched.
   content=re.sub(r'^libdir=.*$', 'libdir='+str(view), content, flags=re.M)
   content=re.sub(r'^includedir=.*$', 'includedir='+str(headers), content, flags=re.M)
   for original in roots:
    content=content.replace(str(original/'lib/x86_64-linux-gnu'),str(view))
    content=content.replace(str(original/'include'),str(headers))
   (pcs/source.name).write_text(content)
(base/'evidence/library-view-provenance.json').write_text(json.dumps(selected,indent=2)+'\n')
print('Created a precedence-preserving library view and relocated pkg-config copies')
