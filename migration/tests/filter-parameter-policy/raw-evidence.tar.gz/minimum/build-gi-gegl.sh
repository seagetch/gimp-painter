#!/bin/bash
set -euo pipefail
source /workspace/scratch/5b5281e79681/filter-policy-minimum/env.sh
cd "$MINIMUM_ROOT"
minimum_runtime_path="$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH="$MINIMUM_ROOT/build/gi/girepository:$LD_LIBRARY_PATH"
python3 run-command.py gi-build meson compile -C build/gi -j4
python3 run-command.py gi-install meson install -C build/gi
export LD_LIBRARY_PATH="$minimum_runtime_path"
python3 run-command.py gegl-setup meson setup build/gegl src/gegl-0.4.62 --prefix="$MINIMUM_ROOT/prefix" --libdir=lib/x86_64-linux-gnu -Dauto_features=disabled -Ddocs=false -Dintrospection=true -Dgdk-pixbuf=enabled -Dlcms=enabled -Dcairo=enabled -Dpango=enabled -Dpangocairo=enabled
python3 run-command.py gegl-build meson compile -C build/gegl -j4
python3 run-command.py gegl-install meson install -C build/gegl
pkg-config --modversion glib-2.0 gobject-introspection-1.0 gegl-0.4
