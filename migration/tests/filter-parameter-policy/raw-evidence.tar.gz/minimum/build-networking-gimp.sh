#!/bin/bash
set -euo pipefail
source /workspace/scratch/5b5281e79681/filter-policy-minimum/env.sh
cd "$MINIMUM_ROOT"
python3 run-command.py glib-networking-setup meson setup build/glib-networking src/glib-networking-2.70.0 --prefix="$MINIMUM_ROOT/prefix" --libdir=lib/x86_64-linux-gnu -Dgnutls=enabled -Dlibproxy=disabled -Dgnome_proxy=disabled -Dinstalled_tests=false
python3 run-command.py glib-networking-build meson compile -C build/glib-networking -j4
python3 run-command.py glib-networking-install meson install -C build/glib-networking
python3 run-command.py gimp-setup meson setup build/gimp src/gimp --prefix="$MINIMUM_ROOT/prefix" --libdir=lib/x86_64-linux-gnu --native-file=python312-native.ini -Dauto_features=disabled -Dlibunwind=false -Dpainter-http=enabled
python3 run-command.py gimp-build meson compile -C build/gimp -j4
