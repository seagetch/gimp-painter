from pathlib import Path
import subprocess,os,hashlib,json,re,concurrent.futures
base=Path(__file__).resolve().parent
env=dict(os.environ,APT_CONFIG=str(base/'apt/apt.conf'))
names='libpoppler-glib-dev libpoppler-glib8 libpoppler-dev libpoppler126 gir1.2-poppler-0.18 liblcms2-dev liblcms2-2 flex bison m4 libfl2 libfl-dev libpango1.0-dev libpango-1.0-0 libpangocairo-1.0-0 libpangoft2-1.0-0 libpangoxft-1.0-0 gir1.2-pango-1.0 libjson-glib-dev libjson-glib-1.0-0 gir1.2-json-1.0 libgdk-pixbuf-2.0-dev libgdk-pixbuf-2.0-0 gir1.2-gdkpixbuf-2.0 libsoup-3.0-dev libsoup-3.0-0 gir1.2-soup-3.0 libgexiv2-dev libgexiv2-2 gir1.2-gexiv2-0.10 libexiv2-dev libexiv2-27 libatk1.0-dev libatk1.0-0 gir1.2-atk-1.0 libatk-bridge2.0-dev libatk-bridge2.0-0 libatspi2.0-dev libatspi2.0-0 gir1.2-atspi-2.0 libappstream-dev libappstream4 gir1.2-appstream-1.0 libcolord2 libdconf1'.split()
packages=[]
for name in names:
 s=subprocess.run(['apt-cache','show',name],env=env,capture_output=True,text=True,check=True).stdout
 fields={l.split(': ',1)[0]:l.split(': ',1)[1] for l in s.split('\n\n')[0].splitlines() if ': ' in l and not l.startswith(' ')}
 packages.append({k:fields[k] for k in ('Package','Version','Filename','SHA256','Depends') if k in fields})
(base/'evidence/bookworm-package-lock.json').write_text(json.dumps(packages,indent=2)+'\n')
def fetch(p):
 dest=base/'apt/archives'/Path(p['Filename']).name
 if not dest.exists():
  subprocess.run(['curl','--silent','--show-error','--fail','--location','--connect-timeout','20','--max-time','120','--output',str(dest),'https://deb.debian.org/debian/'+p['Filename']],check=True)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==p['SHA256'],str(dest)
 return dest
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool: archives=list(pool.map(fetch,packages))
root=base/'bookworm-root'
for archive in archives:subprocess.run(['dpkg-deb','-x',str(archive),str(root)],check=True)
system_prefix=re.compile(r'(?:(?<![\w/.-])|(?<=-L)|(?<=-I))/usr(?=/|\s|$)')
for pc in root.rglob('*.pc'):
 pc.write_text(system_prefix.sub(str(root/'usr'),pc.read_text()))
print(f'Verified and extracted {len(archives)} official signed-index packages')
