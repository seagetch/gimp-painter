#!/bin/bash
set -euo pipefail
source /workspace/scratch/5b5281e79681/filter-policy-minimum/env.sh
cd "$MINIMUM_ROOT"
python3 run-command.py pygobject-setup meson setup build/pygobject src/pygobject-3.46.0 --prefix="$MINIMUM_ROOT/prefix" --libdir=lib/x86_64-linux-gnu --native-file=python312-native.ini -Dtests=false -Dpycairo=disabled
python3 run-command.py pygobject-build meson compile -C build/pygobject -j4
python3 run-command.py pygobject-install meson install -C build/pygobject
python3 run-command.py gimp-setup meson setup build/gimp src/gimp --prefix="$MINIMUM_ROOT/prefix" --libdir=lib/x86_64-linux-gnu --native-file=python312-native.ini -Dauto_features=disabled -Dlibunwind=false -Dpainter-http=enabled
python3 run-command.py gimp-build meson compile -C build/gimp -j4
