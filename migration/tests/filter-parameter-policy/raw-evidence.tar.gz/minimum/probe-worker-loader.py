from pathlib import Path
import os,subprocess,json,importlib.util
r=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('loader_audit',r/'loader-audit.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
traces=r/'logs/worker-loader-relative';traces.mkdir(exist_ok=True)
env=dict(os.environ,LD_DEBUG='libs',LD_DEBUG_OUTPUT=str(traces/'loader'))
exe=r/'build/gimp/app/gimp-painter-filter-worker'
with (r/'logs/worker-loader-probe.log').open('w') as out:
 p=subprocess.run([str(exe.relative_to(r/'build/gimp'))],cwd=r/'build/gimp',env=env,stdout=out,stderr=subprocess.STDOUT,timeout=30)
audit=mod.audit_loader(r,traces,exe,program_cwd=r/'build/gimp')
audit.update({'exit':p.returncode,'expected_exit':125,'reason':'Worker rejects missing private protocol arguments after the ELF loader initializes all libraries'})
(r/'evidence/worker-loader-runtime.json').write_text(json.dumps(audit,indent=2)+'\n')
print('worker_expected_exit=',p.returncode==125,' actual_minimum_loader_audit=',audit['complete_native_library_audit'])
assert p.returncode==125 and audit['complete_native_library_audit'],audit
