# Actual GLib 2.70.0 minimum-build receipt

**Passed:** the complete configured default GIMP 3.0.9 build, 216 executable ELF checks, test-eevl (16/16), and five selected native groups on actual GLib/GObject/GIO 2.70.0.

The source is base `c7b5f74bf520dbaeb46e93a6ce4424e1a08295ca` plus the 12-file frozen overlay in `evidence/gimp-source-overlay.json`; it matches the active source. The separate archive snapshot has no `.git`, so GIMP's git-describe display is explicitly “unknown (unsupported)”.

Configuration uses `auto_features=disabled`, `libunwind=false`, `painter-http=enabled`, an isolated prefix/build, and C++14. Both `b_lundef` and `b_asneeded` remain true. All default targets completed; two explicitly non-default executable targets were skipped. No undefined-symbol suppression was used.

Actual compile/runtime version checks report GLib 2.70.0/2.70.0, GEGL 0.4.62/0.4.62, gexiv2 0.14.0/0.14.0, and exiv2 0.27.6. GI is 1.72.0. Worker symbol and strict dynamic-closure checks pass. Its three canonical GLib-family files and hashes are recorded, and a real worker loader probe confirms their initialization; its expected exit 125 rejects missing private protocol arguments, so this probe is a loader check rather than filter execution.

The four binder groups and Clone retained-item lifetime group each have exit 0, an exact selected TAP path and `1..1` plan. Per-process loader traces prove the frozen 2.70 GLib/GObject/GIO libraries initialized in all six native processes (including Clone's subprocess). Only relevant executable/core-library lines and hashes are retained in publication excerpts. The earlier sampling audit captured no processes and was correctly rejected; its report remains separate.

Isolation needed compatible official dependencies, a common header/library view, explicit Meson host/build pkg-config paths, and strict `-rpath-link` search. All 220 relocated pkg-config files retain their original Version/Requires fields. GI 1.72's temporary GimpUi introspection link additionally receives the matching built libgimpmath explicitly via LDFLAGS; its exact order is in `evidence/gir-link-recipe.txt`.

The full receipt, commands/exits, configuration exclusions, source/dependency hashes, library identities, corrected failures and selected native results are in `evidence/verification.json`. `evidence/publication-allowlist.json` defines the compact evidence bundle.

This does not claim every optional feature, a repeated historical pixel corpus or sanitizer run on the minimum stack, or a GIMP installation/package/deployment. Compatible newer third-party versions such as GTK 3.24.49 and Cairo 1.18.4 remain explicitly recorded. The normal-stack corpus/sanitizer acceptance is separate.
