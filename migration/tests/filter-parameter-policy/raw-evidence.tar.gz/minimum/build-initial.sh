#!/bin/bash
set -euo pipefail
source /workspace/scratch/5b5281e79681/filter-policy-minimum/env.sh
cd "$MINIMUM_ROOT"
sha256sum downloads/glib-2.70.0.tar.xz downloads/pcre-8.45.tar.bz2 > evidence/source-sha256.txt
tar -xf downloads/pcre-8.45.tar.bz2 -C src
mkdir -p build/pcre
cd build/pcre
../../src/pcre-8.45/configure --prefix="$MINIMUM_ROOT/prefix" --libdir="$MINIMUM_ROOT/prefix/lib/x86_64-linux-gnu" --enable-unicode-properties --enable-utf --disable-cpp > "$MINIMUM_ROOT/logs/pcre-configure.log" 2>&1
make -j4 > "$MINIMUM_ROOT/logs/pcre-build.log" 2>&1
make install > "$MINIMUM_ROOT/logs/pcre-install.log" 2>&1
cd "$MINIMUM_ROOT"
meson setup build/glib src/glib-2.70.0 --prefix="$MINIMUM_ROOT/prefix" --libdir=lib/x86_64-linux-gnu -Dtests=false -Dinstalled_tests=false -Dgtk_doc=false -Dman=false -Dselinux=disabled -Dlibmount=disabled -Dlibelf=disabled > logs/glib-setup.log 2>&1
meson compile -C build/glib -j4 > logs/glib-build.log 2>&1
meson install -C build/glib > logs/glib-install.log 2>&1
pkg-config --modversion glib-2.0 gio-2.0 gobject-2.0
