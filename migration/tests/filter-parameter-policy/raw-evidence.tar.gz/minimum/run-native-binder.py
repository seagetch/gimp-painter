from pathlib import Path
import json,os,subprocess,time,hashlib,re,signal,tempfile,importlib.util
root=Path(__file__).resolve().parent
build=root/'build/gimp'
frozen=json.loads((root/'evidence/frozen-native-inputs.json').read_text())
for name,digest in frozen.items():
 if isinstance(digest,str):assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
spec=importlib.util.spec_from_file_location('loader_audit',root/'loader-audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
tests=json.loads(subprocess.check_output(['meson','introspect','--tests',str(build)],text=True))
selections=[('gimp-filter-layer',case) for case in ('parameter_suffix_reordering','parameter_metadata_rejections','parameter_assignment_validation','parameter_object_lifetime')]
selections.append(('gimp-clone-layer','retained_item_gimp_lifetime'))
trace_parent=root/'logs/native-loader';trace_parent.mkdir(exist_ok=True)
trace_root=Path(tempfile.mkdtemp(prefix='run-',dir=trace_parent))
results=[]
for target,case in selections:
 test=next(x for x in tests if x['name']==target)
 environment=dict(os.environ,**test['env'])
 meson_dirs=test['env'].get('LD_LIBRARY_PATH','')
 assert all(Path(x).is_relative_to(build) for x in meson_dirs.split(':') if x),meson_dirs
 environment['LD_LIBRARY_PATH']=':'.join(x for x in (meson_dirs,os.environ.get('LD_LIBRARY_PATH','')) if x)
 assert str(root/'library-view') in environment['LD_LIBRARY_PATH']
 trace_dir=trace_root/case;trace_dir.mkdir()
 environment.update(LD_DEBUG='libs',LD_DEBUG_OUTPUT=str(trace_dir/'loader'))
 workdir=Path(test.get('workdir') or str(build))
 command=[str((workdir/arg).resolve()) if not Path(arg).is_absolute() and Path(arg).name==target else arg for arg in test['cmd']]+['-p','/'+target+'/'+case]
 started=time.monotonic();log=root/'logs'/('native-'+case+'.log')
 with log.open('w') as output:
  proc=subprocess.Popen(command,cwd=workdir,env=environment,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=proc.wait(timeout=180)
  except subprocess.TimeoutExpired:
   os.killpg(proc.pid,signal.SIGKILL);proc.wait();raise RuntimeError('Native test exceeded180 seconds: '+case)
 text=log.read_text();selected_path='/'+target+'/'+case
 tap_ok=bool(re.search(r'^ok\s+\d+\s+'+re.escape(selected_path)+r'\s*$',text,re.M))
 tap_plan=bool(re.search(r'^1\.\.1\s*$',text,re.M))
 library_audit=audit.audit_loader(root,trace_dir,build/'app/tests'/target,program_cwd=workdir)
 record={'target':target,'case':case,'exit':code,'seconds':round(time.monotonic()-started,3),'command':command,'log':str(log.relative_to(root)),'selected_tap_ok':tap_ok,'one_case_tap_plan':tap_plan,'library_search_order':environment['LD_LIBRARY_PATH'].split(':'),**library_audit}
 results.append(record)
 (root/'evidence/native-binder-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(target+'/'+case+': exit '+str(code)+'; TAP='+str(tap_ok and tap_plan)+'; minimum-loader-proof='+str(library_audit['complete_native_library_audit']),flush=True)
 if code or not tap_ok or not tap_plan or not library_audit['complete_native_library_audit']:raise SystemExit(1)
for item in frozen['core_libraries']:
 assert hashlib.sha256(Path(item['canonical_path']).read_bytes()).hexdigest()==item['sha256'],item['canonical_path']
