#include <glib.h>
#include <glib-object.h>
#include <gio/gio.h>
#include <stdio.h>
int main(void) {
  GObject *object=(GObject *)g_object_new(G_TYPE_OBJECT,NULL);
  printf("headers=%d.%d.%d runtime=%u.%u.%u object=%s\n", GLIB_MAJOR_VERSION, GLIB_MINOR_VERSION, GLIB_MICRO_VERSION, glib_major_version, glib_minor_version, glib_micro_version, G_OBJECT_TYPE_NAME(object));
  g_object_unref(object);
  return !(glib_major_version==2 && glib_minor_version==70 && glib_micro_version==0);
}
