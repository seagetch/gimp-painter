#include <glib.h>
#include <gegl.h>
#include <girepository.h>
#include <stdio.h>
int main(void) {
  gint major,minor,micro;
  gegl_get_version(&major,&minor,&micro);
  printf("GLib headers=%d.%d.%d runtime=%u.%u.%u\n", GLIB_MAJOR_VERSION,GLIB_MINOR_VERSION,GLIB_MICRO_VERSION,glib_major_version,glib_minor_version,glib_micro_version);
  printf("GEGL headers=%d.%d.%d runtime=%d.%d.%d\n", GEGL_MAJOR_VERSION,GEGL_MINOR_VERSION,GEGL_MICRO_VERSION,major,minor,micro);
  printf("GI runtime=%u.%u.%u\n",gi_get_major_version(),gi_get_minor_version(),gi_get_micro_version());
  return !(glib_major_version==2 && glib_minor_version==70 && glib_micro_version==0);
}
