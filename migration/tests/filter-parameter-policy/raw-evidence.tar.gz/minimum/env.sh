source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source /workspace/scratch/5b5281e79681/.deps-debian13/env.sh
export MINIMUM_ROOT=/workspace/scratch/5b5281e79681/filter-policy-minimum
export GIMP_BUILD_PREFIX="$MINIMUM_ROOT/prefix"
export PATH="$MINIMUM_ROOT/prefix/bin:$MINIMUM_ROOT/bookworm-root/usr/bin:$PATH"
export PKG_CONFIG_PATH="$MINIMUM_ROOT/prefix/lib/x86_64-linux-gnu/pkgconfig:$MINIMUM_ROOT/prefix/lib/pkgconfig:$MINIMUM_ROOT/prefix/share/pkgconfig:$MINIMUM_ROOT/bookworm-root/usr/lib/x86_64-linux-gnu/pkgconfig:$MINIMUM_ROOT/bookworm-root/usr/share/pkgconfig:/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/pkgconfig:$PKG_CONFIG_PATH"
export LD_LIBRARY_PATH="$MINIMUM_ROOT/prefix/lib/x86_64-linux-gnu:$MINIMUM_ROOT/prefix/lib:$MINIMUM_ROOT/bookworm-root/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
export LIBRARY_PATH="$MINIMUM_ROOT/prefix/lib/x86_64-linux-gnu:$MINIMUM_ROOT/prefix/lib:$MINIMUM_ROOT/bookworm-root/usr/lib/x86_64-linux-gnu:$LIBRARY_PATH"
export CPATH="$MINIMUM_ROOT/bookworm-root/usr/include:$MINIMUM_ROOT/bookworm-root/usr/include/x86_64-linux-gnu:$CPATH"
export GI_TYPELIB_PATH="$MINIMUM_ROOT/prefix/lib/x86_64-linux-gnu/girepository-1.0:$MINIMUM_ROOT/prefix/lib/girepository-1.0:$MINIMUM_ROOT/bookworm-root/usr/lib/x86_64-linux-gnu/girepository-1.0:$GI_TYPELIB_PATH"
export XDG_DATA_DIRS="$MINIMUM_ROOT/prefix/share:$MINIMUM_ROOT/bookworm-root/usr/share:$XDG_DATA_DIRS"
export BABL_PATH="$GIMP_DEPS_ROOT/usr/lib/x86_64-linux-gnu/babl-0.1"
export GEGL_PATH="$MINIMUM_ROOT/prefix/lib/x86_64-linux-gnu/gegl-0.4"
export BISON_PKGDATADIR="$MINIMUM_ROOT/bookworm-root/usr/share/bison"
export M4="$MINIMUM_ROOT/bookworm-root/usr/bin/m4"
export PYTHONPATH="$MINIMUM_ROOT/python-compat:$PYTHONPATH"
# GI 1.72's generated launcher uses /usr/bin/env python3 regardless of -Dpython.
export PATH="/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin:$PATH"
export PYTHONPATH="$MINIMUM_ROOT/prefix/lib/python3.12/site-packages:$PYTHONPATH"
export CC=gcc
export CXX=g++
# A common library view prevents transitive pkg-config -L ordering from selecting
# a newer copy of a dependency whose metadata and headers selected version 2.70.
export PKG_CONFIG_PATH="$MINIMUM_ROOT/pkgconfig-view:/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/pkgconfig"
export PKG_CONFIG_ALLOW_SYSTEM_LIBS=1
export PKG_CONFIG_ALLOW_SYSTEM_CFLAGS=1
export LD_LIBRARY_PATH="$MINIMUM_ROOT/library-view:$LD_LIBRARY_PATH"
export LIBRARY_PATH="$MINIMUM_ROOT/library-view:$LIBRARY_PATH"
