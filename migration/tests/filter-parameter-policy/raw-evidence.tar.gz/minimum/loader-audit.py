from pathlib import Path
import hashlib,re,json
CORE=('libglib-2.0.so.0','libgobject-2.0.so.0','libgio-2.0.so.0')
def audit_loader(root,trace_dir,executable,program_cwd=None):
 root=Path(root);executable=Path(executable).resolve();records=[];errors=[]
 program_cwd=Path(program_cwd) if program_cwd is not None else root
 resolve_program=lambda name:(Path(name) if Path(name).is_absolute() else program_cwd/Path(name)).resolve()
 expected={name:(root/'prefix/lib/x86_64-linux-gnu'/name).resolve() for name in CORE}
 frozen=json.loads((root/'evidence/frozen-native-inputs.json').read_text())
 expected_hashes={item['soname']:item['sha256'] for item in frozen['core_libraries']}
 for trace in sorted(Path(trace_dir).glob('loader.*')):
  text=trace.read_text(errors='replace')
  programs=re.findall(r'initialize program:\s*(\S+)',text)
  if not any(resolve_program(name)==executable for name in programs):continue
  libraries={}
  for value in re.findall(r'calling init:\s*(\S+)',text):
   path=Path(value)
   for name,wanted in expected.items():
    if not path.name.startswith(name):continue
    canonical=path.resolve();digest=hashlib.sha256(canonical.read_bytes()).hexdigest()
    libraries[name]={'loader_path':value,'canonical_path':str(canonical),'sha256':digest}
    if canonical!=wanted or digest!=expected_hashes[name]:errors.append({'trace':str(trace),'library':name,**libraries[name]})
  record={'pid':trace.name.split('.')[-1],'executable':str(executable),'executable_sha256':hashlib.sha256(executable.read_bytes()).hexdigest(),'trace':str(trace.relative_to(root)),'initialized_program':True,'transferred_control':any(resolve_program(name)==executable for name in re.findall(r'transferring control:\s*(\S+)',text)),'libraries':libraries}
  record['raw_trace_sha256']=hashlib.sha256(trace.read_bytes()).hexdigest()
  excerpt=trace.with_name('native-evidence-'+trace.name.split('.')[-1]+'.txt')
  kept=[line for line in text.splitlines() if ('initialize program:' in line or 'transferring control:' in line) or ('calling init:' in line and any(name in line for name in CORE))]
  excerpt.write_text('Raw native loader trace SHA256: '+record['raw_trace_sha256']+'\n'+'\n'.join(kept)+'\n')
  record['filtered_trace']=str(excerpt.relative_to(root))
  records.append(record)
 complete=bool(records) and all(set(CORE)<=set(x['libraries']) and x['transferred_control'] for x in records)
 return {'audit_mode':'glibc LD_DEBUG=libs per-process initialization trace','native_loader_records':records,'wrong_library_loads':errors,'complete_native_library_audit':complete and not errors}
