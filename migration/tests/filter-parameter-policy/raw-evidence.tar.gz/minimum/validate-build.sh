#!/bin/bash
set -euo pipefail
source /workspace/scratch/5b5281e79681/filter-policy-minimum/env.sh
cd "$MINIMUM_ROOT"
python3 run-command.py executable-check python3 src/gimp/tools/verify_build_executables.py build/gimp --report evidence/gimp-executable-check.json
python3 run-command.py minimum-test-eevl build/gimp/libgimpwidgets/test-eevl
python3 run-command.py runtime-probe-compile gcc src/runtime-versions.c -o build/runtime-versions $(pkg-config --cflags --libs glib-2.0 gegl-0.4 gobject-introspection-1.0)
python3 run-command.py runtime-versions build/runtime-versions
python3 run-command.py gimp-runtime-version build/gimp/app/gimp-console-3.0 --version --verbose
python3 run-command.py worker-library-closure ldd -r build/gimp/app/gimp-painter-filter-worker
python3 run-command.py worker-undefined-symbols nm -D --undefined-only build/gimp/app/gimp-painter-filter-worker
python3 - <<'PY'
from pathlib import Path
import json,subprocess,hashlib,shlex
root=Path.cwd(); build=root/'build/gimp'
libs=[root/'prefix/lib/x86_64-linux-gnu'/name for name in ('libglib-2.0.so','libgobject-2.0.so','libgio-2.0.so','libgmodule-2.0.so','libgirepository-1.0.so')]
exports=set()
for lib in libs:
 out=subprocess.check_output(['nm','-D','--defined-only',str(lib)],text=True)
 exports.update(line.split()[-1].split('@')[0] for line in out.splitlines() if line.split())
imports={line.split()[-1].split('@')[0] for line in (root/'logs/worker-undefined-symbols.log').read_text().splitlines() if line.split()}
gimports=sorted(s for s in imports if s.startswith(('g_','glib_')))
missing=sorted(set(gimports)-exports)
closure=(root/'logs/worker-library-closure.log').read_text()
errors=[x for x in closure.splitlines() if 'not found' in x or 'undefined symbol' in x]
actual_glib=[x.strip() for x in closure.splitlines() if 'libglib-2.0.so.0 =>' in x]
assert len(actual_glib)==1,actual_glib
loaded_glib_path=Path(actual_glib[0].split('=>',1)[1].split(' (',1)[0].strip())
assert loaded_glib_path.resolve()==(root/'prefix/lib/x86_64-linux-gnu/libglib-2.0.so.0').resolve(),actual_glib
assert not missing,missing
assert not errors,errors
sources=json.loads((root/'evidence/gimp-source-overlay.json').read_text())
for record in sources:
 assert hashlib.sha256((root/'src/gimp'/record['path']).read_bytes()).hexdigest()==record['sha256'],record['path']
commands=json.loads((build/'compile_commands.json').read_text())
selected=[x for x in commands if x['file'].endswith(('painter-filter-worker.cpp','gimpfilterprocedure-arguments.cpp','gimpfilterlayer.cpp','gimpfilterprocedure.cpp'))]
(root/'evidence/minimum-compile-commands.json').write_text(json.dumps(selected,indent=2)+'\n')
for command in selected:
 include_paths=[Path(x[2:]) for x in shlex.split(command['command']) if x.startswith('-I') and len(x)>2]
 assert any(x.resolve()==(root/'prefix/include/glib-2.0').resolve() for x in include_paths),command['file']
loaded_core=[]
for stem in ('libglib-2.0.so.0','libgobject-2.0.so.0','libgio-2.0.so.0'):
 line=next(x for x in closure.splitlines() if stem+' =>' in x)
 loaded=Path(line.split('=>',1)[1].split(' (',1)[0].strip()).resolve()
 expected=(root/'prefix/lib/x86_64-linux-gnu'/stem).resolve()
 assert loaded==expected,(loaded,expected)
 loaded_core.append({'soname':stem,'canonical_path':str(loaded),'sha256':hashlib.sha256(loaded.read_bytes()).hexdigest()})
result={'loaded_core_libraries':loaded_core,'glib_import_count':len(gimports),'glib_imports':gimports,'missing_from_270_and_gi172':missing,'undefined_dynamic_symbols':errors,'loaded_glib':actual_glib,'worker_sha256':hashlib.sha256((build/'app/gimp-painter-filter-worker').read_bytes()).hexdigest(),'source_overlay_hashes_verified':True}
(root/'evidence/worker-runtime-closure.json').write_text(json.dumps(result,indent=2)+'\n')
print('Actual minimum headers, worker GLib imports and dynamic closure verified')
PY
