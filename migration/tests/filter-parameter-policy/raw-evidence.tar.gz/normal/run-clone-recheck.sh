#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
policy_evidence=/workspace/scratch/5b5281e79681/filter-policy-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$policy_evidence/clone-session-exit.txt"' EXIT
printf 'RUNNING\n' > "$policy_evidence/clone-session-exit.txt"
ulimit -c 0
flock "$GIMP_PAINTER_BUILD_LOCK" ninja -C build-installed-filter -j3 app/tests/gimp-clone-layer > "$policy_evidence/build-clone-fixture.log" 2>&1
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$policy_evidence/run-clone-flag.py" > "$policy_evidence/clone-subprocess-flag-driver.log" 2>&1
