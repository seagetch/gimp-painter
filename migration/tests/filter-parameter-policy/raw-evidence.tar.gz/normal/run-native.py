import hashlib,json,os,subprocess,sys,re
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter-installed-filter')
build=root/'build-installed-filter';out=root.parent/'filter-policy-evidence'
sanitized='--sanitized' in sys.argv
cases=['parameter_suffix_reordering','parameter_metadata_rejections','parameter_assignment_validation','parameter_object_lifetime',
       'blinds_saved_argument_policy','small_tiles_invalid_domains_keep_cache','retinex_invalid_domains_keep_cache',
       'convolution_invalid_arrays_keep_cache','convolution_ignored_legacy_tail','convolution_native_failure_keeps_cache']
if not sanitized:cases += ['blinds_actual_old_context','small_tiles_actual_old_live','retinex_actual_old_live','convolution_actual_old_live',
                           'progress_real_workers','progress_worker_cancel_replace_close']
test=next(x for x in json.loads((build/'meson-info/intro-tests.json').read_text()) if x['name']=='gimp-filter-layer')
env=os.environ.copy();old=env.get('LD_LIBRARY_PATH','');env.update(test.get('env',{}))
if 'LD_LIBRARY_PATH' in test.get('env',{}):env['LD_LIBRARY_PATH'] += ':'+old
env['GIMP3_CACHEDIR']=str(build/'filter-spill-cache')
if sanitized:env.update(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
binary=out/'sanitizers/gimp-filter-layer' if sanitized else build/'app/tests/gimp-filter-layer'
cmd=['python3','-B',str(root/'migration/tests/run_filter_owner_context_fixture_test.py'),'--',str(binary)]
for case in cases:cmd += ['-p','/gimp-filter-layer/'+case]
result=subprocess.run(cmd,cwd=build,env=env,capture_output=True,text=True,timeout=600)
name='sanitized-native' if sanitized else 'normal-native'
(out/(name+'.log')).write_text(result.stdout+result.stderr)
actual=set(re.findall(r'^ok \d+ /gimp-filter-layer/(\S+)$',result.stdout,re.M))
receipt=dict(command=cmd,exit_code=result.returncode,selected=cases,executed=sorted(actual),pass_all=result.returncode==0 and actual==set(cases),
             binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
(out/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
sys.exit(0 if receipt['pass_all'] else 1)
