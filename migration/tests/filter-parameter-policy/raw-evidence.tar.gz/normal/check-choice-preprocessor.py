import difflib,fcntl,hashlib,json,shlex,subprocess
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter-installed-filter');build=root/'build-installed-filter';out=root.parent/'filter-policy-evidence'
name='libgimpbase/gimpchoice.c'
before=subprocess.check_output(['git','show','c7b5f74bf520dbaeb46e93a6ce4424e1a08295ca:'+name],cwd=root,text=True)
after=(root/name).read_text()
old_lines=before.splitlines(keepends=True);new_lines=after.splitlines(keepends=True)
# Normalize only diagnostic source locations. Inserted guards/comments have no
# executable tokens on >=2.74; unchanged source blocks keep baseline line IDs.
normalized=''
for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(a=old_lines,b=new_lines,autojunk=False).get_opcodes():
 if tag in ('replace','delete'):raise RuntimeError('Expected insertion-only compatibility guards')
 normalized+=f'#line {i1+1} "../{name}"\n'+''.join(new_lines[j1:j2])
entry=next(e for e in json.loads((build/'compile_commands.json').read_text()) if e['file']=='../'+name)
original=shlex.split(entry['command']);command=[];i=0
while i<len(original):
 arg=original[i]
 if arg in ('-o','-MF','-MQ','-MT'):i+=2;continue
 if arg in ('-MD','-MMD','-c') or arg==entry['file']:i+=1;continue
 command.append(arg);i+=1
command+=['-E','-P','-x','c','-']
results=[]
with Path('/workspace/shared/gimp-painter-build.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for label,text in [('before',f'#line 1 "../{name}"\n'+before),('after',normalized)]:
  result=subprocess.run(command,cwd=build,input=text,capture_output=True,text=True)
  (out/f'choice-{label}.preprocessed.c').write_text(result.stdout)
  (out/f'choice-{label}.preprocessor.log').write_text(result.stderr)
  results.append(result)
receipt={'scope':'Installed GLib2.84 preprocessing only; baseline diagnostic file/line IDs are normalized with #line, no value/type tokens are changed',
 'source':name,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'after_sha256':hashlib.sha256(after.encode()).hexdigest(),
 'command':command,'directory':str(build),'exit_codes':[r.returncode for r in results],
 'preprocessed_sha256':[hashlib.sha256(r.stdout.encode()).hexdigest() for r in results],
 'tokens_equal':results[0].stdout==results[1].stdout}
receipt['pass']=all(r.returncode==0 for r in results) and receipt['tokens_equal']
(out/'choice-preprocessor.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));raise SystemExit(0 if receipt['pass'] else 1)
