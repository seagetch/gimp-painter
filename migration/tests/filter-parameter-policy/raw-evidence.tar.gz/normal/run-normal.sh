#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
policy_evidence=/workspace/scratch/5b5281e79681/filter-policy-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$policy_evidence/normal-session-exit.txt"' EXIT
printf 'RUNNING\n' > "$policy_evidence/normal-session-exit.txt"
ulimit -c 0
flock "$GIMP_PAINTER_BUILD_LOCK" ninja -C build-installed-filter -j3 app/tests/gimp-filter-layer > "$policy_evidence/build-fixture.log" 2>&1
flock "$GIMP_PAINTER_BUILD_LOCK" meson test -C build-installed-filter --no-rebuild --num-processes 1 --print-errorlogs painter-filter-procedure painter-filter-convolution painter-filter-wire painter-filter-process > "$policy_evidence/normal-helpers.log" 2>&1
cp build-installed-filter/meson-logs/testlog.json "$policy_evidence/normal-helpers.json"
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$policy_evidence/run-native.py" > "$policy_evidence/normal-native-driver.log" 2>&1
