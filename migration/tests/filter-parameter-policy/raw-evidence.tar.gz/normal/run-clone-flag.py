import hashlib,json,os,re,subprocess,sys
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter-installed-filter');build=root/'build-installed-filter';out=root.parent/'filter-policy-evidence'
spec=next(x for x in json.loads((build/'meson-info/intro-tests.json').read_text()) if x['name']=='gimp-clone-layer')
env=os.environ.copy();old=env.get('LD_LIBRARY_PATH','');env.update(spec.get('env',{}))
if 'LD_LIBRARY_PATH' in spec.get('env',{}):env['LD_LIBRARY_PATH']+=':'+old
case='/gimp-clone-layer/retained_item_gimp_lifetime';binary=build/'app/tests/gimp-clone-layer';command=[str(binary),'-p',case]
result=subprocess.run(command,cwd=build,env=env,capture_output=True,text=True,timeout=90)
(out/'clone-subprocess-flag.log').write_text(result.stdout+result.stderr)
actual=re.findall(r'^ok \d+ (\S+)$',result.stdout,re.M)
receipt={'command':command,'exit_code':result.returncode,'executed':actual,'pass':result.returncode==0 and actual==[case],
 'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256((root/'app/tests/test-gimp-clone-layer.c').read_bytes()).hexdigest()}
(out/'clone-subprocess-flag.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));sys.exit(0 if receipt['pass'] else 1)
