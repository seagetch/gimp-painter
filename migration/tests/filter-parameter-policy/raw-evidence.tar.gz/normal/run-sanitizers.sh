#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
policy_evidence=/workspace/scratch/5b5281e79681/filter-policy-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$policy_evidence/sanitized-session-exit.txt"' EXIT
printf 'RUNNING\n' > "$policy_evidence/sanitized-session-exit.txt"
ulimit -c 0
python3 -B migration/tests/run_filter_process_sanitizers.py --build build-installed-filter --output "$policy_evidence/sanitizers" --lock "$GIMP_PAINTER_BUILD_LOCK" > "$policy_evidence/sanitizer-build-driver.log" 2>&1
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$policy_evidence/run-native.py" --sanitized > "$policy_evidence/sanitized-native-driver.log" 2>&1
