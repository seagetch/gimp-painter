/* SPDX-License-Identifier: GPL-3.0-or-later
 * Independent FilterLayer. The GEGL source is only the last committed buffer;
 * neither graph evaluation nor the pickable path starts a job or waits for one.
 */
#include "config.h"
#include <gegl.h>
#include <gio/gio.h>
#include <gdk-pixbuf/gdk-pixbuf.h>
extern "C" {
#include "libgimpbase/gimpbase.h"
#include "libgimpmath/gimpmath.h"
#include "core-types.h"
#include "gimpfilterlayer.h"
#include "gimpcontainer.h"
#include "gimpfilterstack.h"
#include "gimpimage.h"
#include "gimpchannel.h"
#include "gimpcontext.h"
#include "gimp.h"
#include "gimpimage-undo.h"
#include "gimpitemundo.h"
#include "gimpundostack.h"
#include "gimppickable.h"
#include "gimpprogress.h"
#include "gimpprojectable.h"
#include "gegl/gimp-babl.h"
}
#include "gimp-painter-type-traits.hpp"
#include "gimpfilterlayer-arguments.hpp"
#include "gimpfilterparametereditor.hpp"
#include "gimpfilterpaths.hpp"
#include "gimpfiltercontext.hpp"
#include "painter/binding-store.hpp"
#include "painter/connection.hpp"
#include "painter/filter-scheduler.hpp"
#include "config/gimppainterfilterconfig.hpp"
#include "painter/fair-dispatcher.hpp"
#include "painter/filter-edge.hpp"
#include "painter/filter-gauss.hpp"
#include "painter/filter-sharpen-shadow.hpp"
#include "painter/filter-sobel.hpp"
#include "painter/filter-point-shadow.hpp"
#include "painter/filter-raster-kernels.hpp"
#include "painter/filter-native-kernels.hpp"
#include "painter/filter-process.hpp"
#include "painter/gimp-painter-binding.h"
#include "painter/source.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <functional>
#include <memory>
#include <limits>
#include <set>
#include <string>
#include <utility>
#include <vector>
using namespace GimpPainter;
static void gimp_filter_layer_pickable_init (GimpPickableInterface *iface);
static void gimp_filter_layer_progress_init (GimpProgressInterface *iface);
G_DEFINE_TYPE_WITH_CODE (GimpFilterLayer, gimp_filter_layer, GIMP_TYPE_LAYER,
                        G_IMPLEMENT_INTERFACE (GIMP_TYPE_PICKABLE, gimp_filter_layer_pickable_init)
                        G_IMPLEMENT_INTERFACE (GIMP_TYPE_PROGRESS, gimp_filter_layer_progress_init))
struct GimpFilterLayerUndo { GimpItemUndo parent_instance; gboolean binding_failed; };
struct GimpFilterLayerUndoClass { GimpItemUndoClass parent_class; };
static GType gimp_filter_layer_undo_get_type ();
G_DEFINE_TYPE (GimpFilterLayerUndo, gimp_filter_layer_undo, GIMP_TYPE_ITEM_UNDO)
namespace GimpPainter {
template<> struct TypeTraits<GimpFilterLayerUndo>
{ static GType type () noexcept { return gimp_filter_layer_undo_get_type (); } };
}
namespace {
struct FilterImpl;
struct FilterSlot : SlotSpec<GimpFilterLayer, FilterImpl> {};
struct BytesFree { void operator() (GBytes *p) const noexcept { if (p) g_bytes_unref (p); } };
struct ArgsFree { void operator() (GimpValueArray *p) const noexcept { if (p) gimp_value_array_unref (p); } };
using BytesRef = std::unique_ptr<GBytes, BytesFree>;
using ArgsRef = std::unique_ptr<GimpValueArray, ArgsFree>;
struct CloneReferenceFree
{ void operator() (GimpCloneLayerReference *p) const noexcept { gimp_clone_layer_reference_free (p); } };
using CloneReference = std::unique_ptr<GimpCloneLayerReference, CloneReferenceFree>;
struct Callback
{
  explicit Callback (GimpFilterLayer *layer)
    : owner (ObjectRef<GObject>::retain (G_OBJECT (layer))),
      generation (BindingStore::require (G_OBJECT (layer)).generation ()) {}
  WeakRef<GObject> owner;
  std::uint64_t generation;
};
void free_callback (gpointer p, GClosure *) { delete static_cast<Callback *> (p); }
template<class F> void visit (gpointer data, F function) noexcept
{
  boundary_void (nullptr, [&] {
    auto *c = static_cast<Callback *> (data);
    auto owner = c->owner.lock ();
    if (!owner) return;
    auto *store = BindingStore::find (owner.get ());
    if (store && store->accepts (c->generation)) store->with<FilterSlot> (function);
  });
}
void topology_changed (GimpContainer *, GimpObject *, gpointer);
void reordered (GimpContainer *, GimpObject *, gint, gint, gpointer);
void dependency_update (GimpDrawable *, gint, gint, gint, gint, gpointer);
void dependency_active (GimpFilter *, gpointer);
void dependency_status (GimpFilterLayer *, gpointer);
void graph_status (GimpFilterLayer *, gpointer);
void graph_update (GimpDrawable *, gint, gint, gint, gint, gpointer);
void owner_ancestry (GimpViewable *, gpointer);
void owner_removed (GimpItem *, gpointer);
void owner_size (GimpViewable *, gpointer);
void owner_offset (GObject *, GParamSpec *, gpointer);
void owner_active (GimpFilter *, gpointer);
void owner_image_changed (GObject *, GParamSpec *, gpointer);
void owner_format_changed (GimpDrawable *, gpointer);
void image_profile_changed (GObject *, gpointer);
void filter_budget_changed (GObject *, GParamSpec *, gpointer);
void image_disconnected (GimpObject *, gpointer);
void selection_invalidated (GimpImage *, gpointer);

struct FilterImpl
{
  explicit FilterImpl (GimpFilterLayer *owner) : owner (owner) {}
  ~FilterImpl () noexcept = default;
  void close () noexcept
  {
    native_context.reset ();
    scheduler.close ();
    progress.active = progress.cancellable = FALSE;
    pending.close ();
    dependencies.clear ();
    graph_connections.clear ();
    graph_filters.clear ();
    graph_clones.clear ();
    graph_nodes.clear ();
    own_connections.clear ();
    selection_connection.close ();
    context_selection.reset ();
    image_connection.close ();
    profile_connection.close ();
    config_connection.close ();
    staged.reset ();
    stack.reset ();
    lower_objects.clear ();
  }
  Connection connect (GObject *object, const char *signal, GCallback function)
  {
    std::unique_ptr<Callback> c (new Callback (owner));
    auto result = Connection::connect (ObjectRef<GObject>::retain (object), signal,
                                       function, c.get (), free_callback);
    c.release ();
    return result;
  }
  void attach ()
  {
    if (!own_connections.empty ()) return;
    own_connections.push_back (connect (G_OBJECT (owner), "ancestry-changed", G_CALLBACK (owner_ancestry)));
    own_connections.push_back (connect (G_OBJECT (owner), "removed", G_CALLBACK (owner_removed)));
    own_connections.push_back (connect (G_OBJECT (owner), "size-changed", G_CALLBACK (owner_size)));
    own_connections.push_back (connect (G_OBJECT (owner), "notify::offset-x", G_CALLBACK (owner_offset)));
    own_connections.push_back (connect (G_OBJECT (owner), "notify::offset-y", G_CALLBACK (owner_offset)));
    own_connections.push_back (connect (G_OBJECT (owner), "active-changed", G_CALLBACK (owner_active)));
    own_connections.push_back (connect (G_OBJECT (owner), "notify::image", G_CALLBACK (owner_image_changed)));
    own_connections.push_back (connect (G_OBJECT (owner), "format-changed", G_CALLBACK (owner_format_changed)));
    watch_image ();
    refresh_connections ();
  }
  void watch_image ()
  {
    selection_connection.close ();
    context_selection.reset ();
    native_context.reset ();
    image_connection.close ();
    profile_connection.close ();
    config_connection.close ();
    if (GimpImage *image = gimp_item_get_image (GIMP_ITEM (owner)))
      {
        image_connection = connect (G_OBJECT (image), "disconnect", G_CALLBACK (image_disconnected));
        selection_connection = connect (G_OBJECT (image), "selection-invalidate", G_CALLBACK (selection_invalidated));
        profile_connection = connect (G_OBJECT (image), "profile-changed", G_CALLBACK (image_profile_changed));
        config_connection = connect (G_OBJECT (image->gimp->config), "notify::painter-filter-spill-size", G_CALLBACK (filter_budget_changed));
      }
  }
  void refresh_context_selection ()
  {
    auto *image = gimp_item_get_image (GIMP_ITEM (owner));
    if (!image) throw std::runtime_error ("Filter selection image was closed");
    auto *selection = G_OBJECT (gimp_image_get_mask (image));
    if (context_selection.lock ().get () != selection)
      {
        /* XCF replaces the selection object after loading layers, without
         * notifying the layer's image property. Identity is an owner epoch,
         * not a Filter input generation and never restarts a clean Filter. */
        context_selection = WeakRef<GObject> (ObjectRef<GObject>::retain (selection));
        native_context.selection_changed ();
      }
  }
  GimpContainer *current_stack ()
  {
    GimpContainer *result = gimp_item_get_container (GIMP_ITEM (owner));
    if (!result)
      {
        GimpImage *image = gimp_item_get_image (GIMP_ITEM (owner));
        if (image) result = gimp_image_get_layers (image);
      }
    return result;
  }
  void watch_descendant_status (GimpObject *object)
  {
    if (GIMP_IS_FILTER_LAYER (object))
      dependencies.push_back (connect (G_OBJECT (object), "filter-state-changed", G_CALLBACK (dependency_status)));
    if (GimpContainer *children = gimp_viewable_get_children (GIMP_VIEWABLE (object)))
      {
        dependencies.push_back (connect (G_OBJECT (children), "add", G_CALLBACK (topology_changed)));
        dependencies.push_back (connect (G_OBJECT (children), "remove", G_CALLBACK (topology_changed)));
        dependencies.push_back (connect (G_OBJECT (children), "reorder", G_CALLBACK (reordered)));
        for (int i = 0; i < gimp_container_get_n_children (children); ++i)
          watch_descendant_status (gimp_container_get_child_by_index (children, i));
      }
  }
  void refresh_connections ()
  {
    if (scheduler.state () == FilterScheduler::State::closed) return;
    const auto revision = ++connections_revision;
    graph_valid = false;
    dependencies.clear ();
    /* invalidate() emits synchronously. Keep the old stack alive until its
     * interrupted refresh returns, even if the callback reparents the owner. */
    auto container_lease = ObjectRef<GObject>::retain (G_OBJECT (current_stack ()));
    auto *container = reinterpret_cast<GimpContainer *> (container_lease.get ());
    stack = WeakRef<GObject> (ObjectRef<GObject>::retain (G_OBJECT (container)));
    topology_dirty = false;
    std::vector<WeakRef<GObject>> current_lower;
    bool different = false;
    if (container)
      {
        const auto self = gimp_container_get_child_index (container, GIMP_OBJECT (owner));
        if (self >= 0)
          for (int i = self + 1; i < gimp_container_get_n_children (container); ++i)
            {
              auto *object = G_OBJECT (gimp_container_get_child_by_index (container, i));
              if (current_lower.size () >= lower_objects.size () ||
                  lower_objects[current_lower.size ()].lock ().get () != object) different = true;
              current_lower.emplace_back (ObjectRef<GObject>::retain (object));
            }
      }
    if (current_lower.size () != lower_objects.size ()) different = true;
    lower_objects = std::move (current_lower);
    if (different) invalidate ();
    /* Close must be terminal, and a nested refresh owns the new registrations.
     * Never append stale handlers after it has replaced our dependency list. */
    if (scheduler.state () == FilterScheduler::State::closed ||
        revision != connections_revision || current_stack () != container) return;
    if (!container) return;
    dependencies.push_back (connect (G_OBJECT (container), "add", G_CALLBACK (topology_changed)));
    dependencies.push_back (connect (G_OBJECT (container), "remove", G_CALLBACK (topology_changed)));
    dependencies.push_back (connect (G_OBJECT (container), "reorder", G_CALLBACK (reordered)));
    const auto n = gimp_container_get_n_children (container);
    for (int i = 0; i < n; ++i)
      {
        GimpObject *child = gimp_container_get_child_by_index (container, i);
        if (child == GIMP_OBJECT (owner)) continue;
        dependencies.push_back (connect (G_OBJECT (child), "update", G_CALLBACK (dependency_update)));
        dependencies.push_back (connect (G_OBJECT (child), "active-changed", G_CALLBACK (dependency_active)));
        if (below (GIMP_ITEM (child))) watch_descendant_status (child);
      }
  }
  bool below (GimpItem *item)
  {
    auto container = stack.lock ();
    if (!container || item == GIMP_ITEM (owner)) return false;
    while (gimp_item_get_parent (item) && gimp_item_get_container (item) != GIMP_CONTAINER (container.get ()))
      item = gimp_item_get_parent (item);
    const auto self = gimp_container_get_child_index (GIMP_CONTAINER (container.get ()), GIMP_OBJECT (owner));
    const auto index = gimp_container_get_child_index (GIMP_CONTAINER (container.get ()), GIMP_OBJECT (item));
    return self >= 0 && index > self;
  }
  void invalidate ()
  {
    graph_valid = false;
    read_budget = 1024;
    native_context.reset ();
    scheduler.invalidate ();
    staged.reset ();
    schedule ();
    g_signal_emit_by_name (owner, "filter-state-changed");
  }
  void dependency_dirty ()
  {
    /* A waiting generation has captured no input. Repeated paths through a
     * dependency DAG must not emit another WAITING signal and recursively
     * amplify the same edit across every ancestor. */
    if (scheduler.state () == FilterScheduler::State::waiting)
      { graph_valid = false; read_budget = 1024; schedule (); }
    else
      invalidate ();
  }
  void structure_changed ()
  { refresh_connections (); schedule (); }
  void definition_installed ()
  {
    if (definition_revision == std::numeric_limits<std::uint64_t>::max ())
      throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter definition revision exhausted");
    ++definition_revision;
  }
  bool definition_current (std::uint64_t binding_token, std::uint64_t revision) const
  {
    auto *store = BindingStore::find (G_OBJECT (owner));
    return store && store->accepts (binding_token) && definition_revision == revision;
  }
  struct PreparedConfiguration
  {
    FilterScheduler::Request request;
    std::shared_ptr<FilterProcedureRequest> procedure;
    std::shared_ptr<FilterProcessOptions> process_options;
    std::shared_ptr<FilterProcedureResult> outcome;
    std::shared_ptr<FilterSelectionRegion> kernel_region;
    std::function<void ()> kernel_validate;
    bool projection_input = false;
  };
  bool publish_definition (GeglBuffer *restore_buffer = nullptr, bool cache_complete = true,
                           PreparedConfiguration *prepared = nullptr)
  {
    auto& store = BindingStore::require (G_OBJECT (owner));
    const auto token = store.generation (), revision = definition_revision;
    if (prepared) apply_configuration (std::move (*prepared));
    else configure ();
    if (!definition_current (token, revision)) return false;
    if (restore_buffer)
      {
        /* Undo owns the old committed pixels, not a claim about current lower
         * content. Keep them visible, but only a successful rerun certifies
         * freshness. In particular, an opaque model must never inherit the
         * newer procedure's pixels or be marked complete/current by Undo. */
        native_context.reset ();
        scheduler.restore_cache ({1, 0, cache_complete});
        staged.reset (); schedule ();
        publish_buffer (restore_buffer, scheduler.generation (), false);
        if (!definition_current (token, revision)) return false;
      }
    for (const char *property : {"filter-procedure", "filter-arguments", "filter-original-definition", "filter-opaque-arguments"})
      {
        g_object_notify (G_OBJECT (owner), property);
        if (!definition_current (token, revision)) return false;
      }
    return true;
  }
  void configure ()
  {
    auto prepared = prepare_configuration (procedure, args);
    schedule ();
    apply_configuration (std::move (prepared));
  }
  PreparedConfiguration prepare_configuration (const std::string& procedure,
                                                const std::shared_ptr<const FilterArguments>& args)
  {
    /* Allocate callable captures and native execution state privately. A
     * rejected definition must not publish its model or retire current work.
     * Unsupported definitions still produce the same empty request, preserving
     * their stored values and the executor's existing failure diagnostics. */
    PreparedConfiguration prepared;
    auto& request = prepared.request;
    const auto channel = std::make_shared<FilterProgress> ();
    request.progress = channel;
    request.width = gimp_item_get_width (GIMP_ITEM (owner));
    request.height = gimp_item_get_height (GIMP_ITEM (owner));
    const bool real = real_samples ();
    request.bytes_per_pixel = real ? 32 : 4;
    const bool spill = request.height && request.width > (4 * 1024 * 1024 / request.bytes_per_pixel) / request.height;
    if (spill)
      {
        /* Independent queues + transpose/coefficient bookkeeping + worst IIR
         * line state. GEGL input/staging tiles use the host shared cache/swap
         * budget; no full input or result vector is allocated by this route. */
        const std::uint64_t peak = (real ? 16 : 8) * 1024 * 1024 + std::uint64_t (std::max (request.width, request.height)) * (real ? 128 : 72);
        request.peak_bytes = std::size_t (std::min (peak, std::uint64_t (std::numeric_limits<std::size_t>::max ())));
      }
    else if (request.height && request.width <= FilterScheduler::maximum_pixels / request.height)
      {
        /* Input/result/staging plus maximum Gaussian IIR line buffers. The
         * 2 MiB allowance covers bounded RLE coefficients and native chunks.
         * Existing completed GEGL caches remain the host's own swap policy. */
        const std::uint64_t peak = std::uint64_t (request.width) * request.height * (real ? 128 : 12) +
                                  std::uint64_t (std::max (request.width, request.height)) * (real ? 128 : 72) + 2 * 1024 * 1024;
        request.peak_bytes = std::size_t (std::min (peak, std::uint64_t (std::numeric_limits<std::size_t>::max ())));
      }
    if (procedure == "plug-in-sharpen" && !real && args && args->size () == 4 &&
        (gimp_drawable_get_base_type (GIMP_DRAWABLE (owner)) == GIMP_RGB || gray ()) &&
        G_VALUE_HOLDS_INT (args->at (0)) && G_VALUE_HOLDS_INT (args->at (1)) &&
        G_VALUE_HOLDS_INT (args->at (2)) && G_VALUE_HOLDS_INT (args->at (3)) &&
        g_value_get_int (args->at (3)) >= 100 - std::numeric_limits<std::int32_t>::max ())
      {
        /* Sharpen has no isolated PDB descriptor or wire-protocol route. The
         * worker sees only this plain captured region, sealed before launch.
         * A later generation cannot write it until the old worker is gone. */
        const auto region = std::make_shared<FilterSelectionRegion> ();
        const auto outcome = std::make_shared<FilterProcedureResult> ();
        const SharpenOptions options { g_value_get_int (args->at (3)) };
        const auto width = request.width, height = request.height;
        if (width && height && width <= std::size_t (std::numeric_limits<std::int32_t>::max () / 4) &&
            height <= std::size_t (std::numeric_limits<std::int32_t>::max ()) &&
            std::uint64_t (width) <= (std::numeric_limits<std::uint64_t>::max () - 4 * 1024 * 1024) / 17 / height)
          {
            /* Charge original native snapshot, final mask and private native
             * staging in both storage classes. Vector input/raw result add two
             * RGBA rasters; spill uses two files and six bounded transport
             * chunks. The allowance covers strip/LUT scratch and owner merge
             * chunks. GEGL's shared cache/swap policy is not a total-RSS bound. */
            const auto pixels = std::uint64_t (width) * height;
            const auto owner_bytes = pixels * (gray () ? 5u : 9u);
            const auto peak = owner_bytes + (spill ?
              std::uint64_t (FilterScheduler::pixel_budget) * 4 * 6 : pixels * 8) + 2 * 1024 * 1024;
            request.peak_bytes = std::size_t (std::min (peak,
              std::uint64_t (std::numeric_limits<std::size_t>::max ())));
            if (spill) request.peak_spill_bytes = pixels * 8 + owner_bytes;
            request.process = [width, height, region, options, channel, outcome]
              (const FilterScheduler::Bytes& input, std::atomic<bool>& cancel, FilterScheduler::Bytes& output) {
                const auto result = filter_sharpen_shadow_vector (input, width, height, *region, options,
                  cancel, output, channel);
                if (result == FilterSharpenShadowOutcome::cancelled) return false;
                outcome->publish (result == FilterSharpenShadowOutcome::shadow ?
                  FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                return true;
              };
            if (spill)
              request.raster_process = [width, height, region, options, channel, outcome]
                (FilterRaster& input, FilterRaster& output, std::atomic<bool>& cancel, const FilterRasterFactory&) {
                  const auto result = filter_sharpen_shadow_raster (input, width, height, *region, options,
                    cancel, output, channel);
                  if (result == FilterSharpenShadowOutcome::cancelled) return false;
                  outcome->publish (result == FilterSharpenShadowOutcome::shadow ?
                    FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                  return true;
                };
            prepared.kernel_region = region;
            prepared.kernel_validate = [width, height, region, options] {
              filter_sharpen_shadow_validate (width, height, *region, options);
            };
            prepared.outcome = outcome;
          }
      }
    else if (procedure == "plug-in-sobel" && !real)
      {
        /* This is the independent old Sobel procedure, never Edge's Sobel
         * mode. Claim the literal byte route before strict argument admission;
         * no malformed definition may fall through to another executor. */
        if (args && args->size () == 6 &&
            (gimp_drawable_get_base_type (GIMP_DRAWABLE (owner)) == GIMP_RGB || gray ()) &&
            G_VALUE_HOLDS_INT (args->at (0)) && G_VALUE_HOLDS_INT (args->at (1)) &&
            G_VALUE_HOLDS_INT (args->at (2)) && G_VALUE_HOLDS_INT (args->at (3)) &&
            G_VALUE_HOLDS_INT (args->at (4)) && G_VALUE_HOLDS_INT (args->at (5)))
          {
            const auto width = request.width, height = request.height;
            constexpr auto maximum = std::numeric_limits<std::int32_t>::max ();
            /* Full storage/reservation bounds precede admission. The Sobel
             * validator applies its own captured ROI row-width bound later;
             * neither Sharpen's tiny minima nor Threshold's area limit apply. */
            if (width && height && width <= std::size_t (maximum) && height <= std::size_t (maximum) &&
                std::uint64_t (width) <= std::uint64_t (std::numeric_limits<std::int64_t>::max ()) / 4 / height &&
                std::uint64_t (width) <= (std::numeric_limits<std::uint64_t>::max () - 2 * 1024 * 1024) / 17 / height)
              {
                const auto region = std::make_shared<FilterSelectionRegion> ();
                const auto outcome = std::make_shared<FilterProcedureResult> ();
                const SobelOptions options { g_value_get_int (args->at (3)),
                  g_value_get_int (args->at (4)), g_value_get_int (args->at (5)) };
                const auto pixels = std::uint64_t (width) * height;
                const auto owner_bytes = pixels * (gray () ? 5u : 9u);
                /* Native input, final mask and private staging: 5/9 Bpp.
                 * Two private RGBA vectors/files: 8 Bpp. The conservative
                 * shared 304-KiB allowance covers bounded owner merge/capture
                 * and Sobel's fixed 32,792-byte scratch. Spill additionally
                 * charges six RGBA transport chunks. These logical admission
                 * reservations are not a process-RSS or GEGL-cache limit. */
                const auto bounded = std::uint64_t (FilterScheduler::pixel_budget) * 8 + 48 * 1024;
                const auto peak = owner_bytes + bounded + (spill ?
                  std::uint64_t (FilterScheduler::pixel_budget) * 4 * 6 : pixels * 8);
                request.peak_bytes = std::size_t (std::min (peak,
                  std::uint64_t (std::numeric_limits<std::size_t>::max ())));
                if (spill) request.peak_spill_bytes = pixels * 8 + owner_bytes;
                request.process = [width, height, region, options, channel, outcome]
                  (const FilterScheduler::Bytes& input, std::atomic<bool>& cancel, FilterScheduler::Bytes& output) {
                    const auto result = filter_sobel_shadow_vector (input, width, height, *region,
                      options, cancel, output, channel);
                    if (result == FilterSobelShadowOutcome::cancelled) return false;
                    outcome->publish (result == FilterSobelShadowOutcome::shadow ?
                      FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                    return true;
                  };
                if (spill)
                  request.raster_process = [width, height, region, options, channel, outcome]
                    (FilterRaster& input, FilterRaster& output, std::atomic<bool>& cancel, const FilterRasterFactory&) {
                      const auto result = filter_sobel_shadow_raster (input, width, height, *region,
                        options, cancel, output, channel);
                      if (result == FilterSobelShadowOutcome::cancelled) return false;
                      outcome->publish (result == FilterSobelShadowOutcome::shadow ?
                        FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                      return true;
                    };
                prepared.kernel_region = region;
                prepared.kernel_validate = [width, height, region, options] {
                  filter_sobel_shadow_validate (width, height, *region, options);
                };
                prepared.outcome = outcome;
                prepared.projection_input = true;
              }
          }
      }
    else if (procedure == "plug-in-threshold-alpha" && !real)
      {
        /* Claim this literal name even for malformed byte definitions. Falling
         * through to the historical point route would bypass owner context.
         * Other encodings retain that route's existing typed compatibility. */
        if (args && args->size () == 4 &&
            (gimp_drawable_get_base_type (GIMP_DRAWABLE (owner)) == GIMP_RGB || gray ()) &&
            G_VALUE_HOLDS_INT (args->at (0)) && G_VALUE_HOLDS_INT (args->at (1)) &&
            G_VALUE_HOLDS_INT (args->at (2)) && G_VALUE_HOLDS_INT (args->at (3)))
          {
            const auto width = request.width, height = request.height;
            constexpr auto maximum = std::numeric_limits<std::int32_t>::max ();
            /* Full logical storage and the fixed bound below must fit before
             * admission. The smaller legacy selected-area limit is checked
             * after owner capture, before any point kernel can run. */
            if (width && height && width <= std::size_t (maximum) && height <= std::size_t (maximum) &&
                std::uint64_t (width) <= std::uint64_t (std::numeric_limits<std::int64_t>::max ()) / 4 / height &&
                std::uint64_t (width) <= (std::numeric_limits<std::uint64_t>::max () - 2 * 1024 * 1024) / 17 / height)
              {
                const auto region = std::make_shared<FilterSelectionRegion> ();
                const auto outcome = std::make_shared<FilterProcedureResult> ();
                const std::int32_t threshold = g_value_get_int (args->at (3));
                const auto pixels = std::uint64_t (width) * height;
                const auto owner_bytes = pixels * (gray () ? 5u : 9u);
                /* Native input + final mask + private native staging: 5/9 Bpp.
                 * Two RGBA vectors or files: 8 Bpp. Bounded owner capture/merge
                 * needs at most eight bytes per transport pixel, and the raw
                 * wrapper/kernel retain 16 + 32 KiB stack pixel arrays. Spill
                 * additionally charges the established six RGBA queue chunks.
                 * These are logical reservations, not process-RSS limits. */
                const auto bounded = std::uint64_t (FilterScheduler::pixel_budget) * 8 + 48 * 1024;
                const auto peak = owner_bytes + bounded + (spill ?
                  std::uint64_t (FilterScheduler::pixel_budget) * 4 * 6 : pixels * 8);
                request.peak_bytes = std::size_t (std::min (peak,
                  std::uint64_t (std::numeric_limits<std::size_t>::max ())));
                if (spill) request.peak_spill_bytes = pixels * 8 + owner_bytes;
                request.process = [width, height, region, threshold, channel, outcome]
                  (const FilterScheduler::Bytes& input, std::atomic<bool>& cancel, FilterScheduler::Bytes& output) {
                    const auto result = filter_point_shadow_vector (input, width, height, *region,
                      threshold, cancel, output, channel);
                    if (result == FilterPointShadowOutcome::cancelled) return false;
                    outcome->publish (result == FilterPointShadowOutcome::shadow ?
                      FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                    return true;
                  };
                if (spill)
                  request.raster_process = [width, height, region, threshold, channel, outcome]
                    (FilterRaster& input, FilterRaster& output, std::atomic<bool>& cancel, const FilterRasterFactory&) {
                      const auto result = filter_point_shadow_raster (input, width, height, *region,
                        threshold, cancel, output, channel);
                      if (result == FilterPointShadowOutcome::cancelled) return false;
                      outcome->publish (result == FilterPointShadowOutcome::shadow ?
                        FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                      return true;
                    };
                prepared.kernel_region = region;
                prepared.kernel_validate = [width, height, region] {
                  filter_point_shadow_validate (width, height, *region);
                };
                prepared.outcome = outcome;
                prepared.projection_input = true;
              }
          }
      }
    else if (procedure == "plug-in-red-eye-removal")
      {
        /* New literal compatibility route, not a GEGL name substitution.
         * Claim malformed/unsupported definitions too: only nonlinear U8 RGB
         * is admitted, never a silent precision conversion or generic fallback.
         * Old execution replaces the first three saved scalar context slots. */
        if (!real && args && args->size () == 4 &&
            gimp_drawable_get_base_type (GIMP_DRAWABLE (owner)) == GIMP_RGB &&
            G_VALUE_HOLDS_INT (args->at (0)) && G_VALUE_HOLDS_INT (args->at (1)) &&
            G_VALUE_HOLDS_INT (args->at (2)) && G_VALUE_HOLDS_INT (args->at (3)) &&
            filter_red_eye_threshold_valid (g_value_get_int (args->at (3))))
          {
            const auto width = request.width, height = request.height;
            constexpr auto maximum = std::numeric_limits<std::int32_t>::max ();
            /* Full logical storage and the fixed bound below must fit before
             * admission. The smaller legacy selected-area limit is checked
             * after owner capture, before any point kernel can run. */
            if (width && height && width <= std::size_t (maximum) && height <= std::size_t (maximum) &&
                std::uint64_t (width) <= std::uint64_t (std::numeric_limits<std::int64_t>::max ()) / 4 / height &&
                std::uint64_t (width) <= (std::numeric_limits<std::uint64_t>::max () - 2 * 1024 * 1024) / 17 / height)
              {
                const auto region = std::make_shared<FilterSelectionRegion> ();
                const auto outcome = std::make_shared<FilterProcedureResult> ();
                const std::int32_t mode = g_value_get_int (args->at (3));
                const auto pixels = std::uint64_t (width) * height;
                const auto owner_bytes = pixels * 9u;
                /* Native input + final mask + private native staging: 9 Bpp.
                 * Two RGBA vectors or files: 8 Bpp. Bounded owner capture/merge
                 * needs at most eight bytes per transport pixel, and the raw
                 * wrapper/kernel retain 16 + 32 KiB stack pixel arrays. Spill
                 * additionally charges the established six RGBA queue chunks.
                 * These are logical reservations, not process-RSS limits. */
                const auto bounded = std::uint64_t (FilterScheduler::pixel_budget) * 8 + 48 * 1024;
                const auto peak = owner_bytes + bounded + (spill ?
                  std::uint64_t (FilterScheduler::pixel_budget) * 4 * 6 : pixels * 8);
                request.peak_bytes = std::size_t (std::min (peak,
                  std::uint64_t (std::numeric_limits<std::size_t>::max ())));
                if (spill) request.peak_spill_bytes = pixels * 8 + owner_bytes;
                request.process = [width, height, region, mode, channel, outcome]
                  (const FilterScheduler::Bytes& input, std::atomic<bool>& cancel, FilterScheduler::Bytes& output) {
                    const auto result = filter_point_shadow_vector (input, width, height, *region,
                      FilterPointShadowOperation::red_eye, mode, cancel, output, channel);
                    if (result == FilterPointShadowOutcome::cancelled) return false;
                    outcome->publish (result == FilterPointShadowOutcome::shadow ?
                      FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                    return true;
                  };
                if (spill)
                  request.raster_process = [width, height, region, mode, channel, outcome]
                    (FilterRaster& input, FilterRaster& output, std::atomic<bool>& cancel, const FilterRasterFactory&) {
                      const auto result = filter_point_shadow_raster (input, width, height, *region,
                        FilterPointShadowOperation::red_eye, mode, cancel, output, channel);
                      if (result == FilterPointShadowOutcome::cancelled) return false;
                      outcome->publish (result == FilterPointShadowOutcome::shadow ?
                        FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                      return true;
                    };
                prepared.kernel_region = region;
                prepared.kernel_validate = [width, height, region] {
                  filter_point_shadow_validate (width, height, *region);
                };
                prepared.outcome = outcome;
                prepared.projection_input = true;
              }
          }
      }
    else if (procedure == "plug-in-max-rgb" && !real)
      {
        /* Claim this literal name even for malformed byte definitions. Falling
         * through to the historical point route would bypass owner context.
         * Gray is unsupported; other encodings retain the historical route's
         * existing typed compatibility and context-free behavior. */
        if (args && args->size () == 4 &&
            gimp_drawable_get_base_type (GIMP_DRAWABLE (owner)) == GIMP_RGB &&
            G_VALUE_HOLDS_INT (args->at (0)) && G_VALUE_HOLDS_INT (args->at (1)) &&
            G_VALUE_HOLDS_INT (args->at (2)) && G_VALUE_HOLDS_INT (args->at (3)))
          {
            const auto width = request.width, height = request.height;
            constexpr auto maximum = std::numeric_limits<std::int32_t>::max ();
            /* Full logical storage and the fixed bound below must fit before
             * admission. The smaller legacy selected-area limit is checked
             * after owner capture, before any point kernel can run. */
            if (width && height && width <= std::size_t (maximum) && height <= std::size_t (maximum) &&
                std::uint64_t (width) <= std::uint64_t (std::numeric_limits<std::int64_t>::max ()) / 4 / height &&
                std::uint64_t (width) <= (std::numeric_limits<std::uint64_t>::max () - 2 * 1024 * 1024) / 17 / height)
              {
                const auto region = std::make_shared<FilterSelectionRegion> ();
                const auto outcome = std::make_shared<FilterProcedureResult> ();
                const std::int32_t mode = g_value_get_int (args->at (3));
                const auto pixels = std::uint64_t (width) * height;
                const auto owner_bytes = pixels * 9u;
                /* Native input + final mask + private native staging: 9 Bpp.
                 * Two RGBA vectors or files: 8 Bpp. Bounded owner capture/merge
                 * needs at most eight bytes per transport pixel, and the raw
                 * wrapper/kernel retain 16 + 32 KiB stack pixel arrays. Spill
                 * additionally charges the established six RGBA queue chunks.
                 * These are logical reservations, not process-RSS limits. */
                const auto bounded = std::uint64_t (FilterScheduler::pixel_budget) * 8 + 48 * 1024;
                const auto peak = owner_bytes + bounded + (spill ?
                  std::uint64_t (FilterScheduler::pixel_budget) * 4 * 6 : pixels * 8);
                request.peak_bytes = std::size_t (std::min (peak,
                  std::uint64_t (std::numeric_limits<std::size_t>::max ())));
                if (spill) request.peak_spill_bytes = pixels * 8 + owner_bytes;
                request.process = [width, height, region, mode, channel, outcome]
                  (const FilterScheduler::Bytes& input, std::atomic<bool>& cancel, FilterScheduler::Bytes& output) {
                    const auto result = filter_point_shadow_vector (input, width, height, *region,
                      FilterPointShadowOperation::max_rgb, mode, cancel, output, channel);
                    if (result == FilterPointShadowOutcome::cancelled) return false;
                    outcome->publish (result == FilterPointShadowOutcome::shadow ?
                      FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                    return true;
                  };
                if (spill)
                  request.raster_process = [width, height, region, mode, channel, outcome]
                    (FilterRaster& input, FilterRaster& output, std::atomic<bool>& cancel, const FilterRasterFactory&) {
                      const auto result = filter_point_shadow_raster (input, width, height, *region,
                        FilterPointShadowOperation::max_rgb, mode, cancel, output, channel);
                      if (result == FilterPointShadowOutcome::cancelled) return false;
                      outcome->publish (result == FilterPointShadowOutcome::shadow ?
                        FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                      return true;
                    };
                prepared.kernel_region = region;
                prepared.kernel_validate = [width, height, region] {
                  filter_point_shadow_validate (width, height, *region);
                };
                prepared.outcome = outcome;
                prepared.projection_input = true;
              }
          }
      }
    else if (procedure == "plug-in-vinvert" && !real)
      {
        /* Value Invert has exactly the three saved context slots: no mode or
         * operation parameter. Claim its literal name even when malformed. Falling
         * through to the historical point route would bypass owner context.
         * Gray is unsupported; other encodings retain the historical route's
         * existing typed compatibility and context-free behavior. */
        if (args && args->size () == 3 &&
            gimp_drawable_get_base_type (GIMP_DRAWABLE (owner)) == GIMP_RGB &&
            G_VALUE_HOLDS_INT (args->at (0)) && G_VALUE_HOLDS_INT (args->at (1)) &&
            G_VALUE_HOLDS_INT (args->at (2)))
          {
            const auto width = request.width, height = request.height;
            constexpr auto maximum = std::numeric_limits<std::int32_t>::max ();
            /* Full logical storage and the fixed bound below must fit before
             * admission. The smaller legacy selected-area limit is checked
             * after owner capture, before any point kernel can run. */
            if (width && height && width <= std::size_t (maximum) && height <= std::size_t (maximum) &&
                std::uint64_t (width) <= std::uint64_t (std::numeric_limits<std::int64_t>::max ()) / 4 / height &&
                std::uint64_t (width) <= (std::numeric_limits<std::uint64_t>::max () - 2 * 1024 * 1024) / 17 / height)
              {
                const auto region = std::make_shared<FilterSelectionRegion> ();
                const auto outcome = std::make_shared<FilterProcedureResult> ();
                const auto pixels = std::uint64_t (width) * height;
                const auto owner_bytes = pixels * 9u;
                /* Native input + final mask + private native staging: 9 Bpp.
                 * Two RGBA vectors or files: 8 Bpp. Bounded owner capture/merge
                 * needs at most eight bytes per transport pixel, and the raw
                 * wrapper/kernel retain 16 + 32 KiB stack pixel arrays. Spill
                 * additionally charges the established six RGBA queue chunks.
                 * These are logical reservations, not process-RSS limits. */
                const auto bounded = std::uint64_t (FilterScheduler::pixel_budget) * 8 + 48 * 1024;
                const auto peak = owner_bytes + bounded + (spill ?
                  std::uint64_t (FilterScheduler::pixel_budget) * 4 * 6 : pixels * 8);
                request.peak_bytes = std::size_t (std::min (peak,
                  std::uint64_t (std::numeric_limits<std::size_t>::max ())));
                if (spill) request.peak_spill_bytes = pixels * 8 + owner_bytes;
                request.process = [width, height, region, channel, outcome]
                  (const FilterScheduler::Bytes& input, std::atomic<bool>& cancel, FilterScheduler::Bytes& output) {
                    const auto result = filter_point_shadow_vector (input, width, height, *region,
                      FilterPointShadowOperation::value_invert, 0, cancel, output, channel);
                    if (result == FilterPointShadowOutcome::cancelled) return false;
                    outcome->publish (result == FilterPointShadowOutcome::shadow ?
                      FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                    return true;
                  };
                if (spill)
                  request.raster_process = [width, height, region, channel, outcome]
                    (FilterRaster& input, FilterRaster& output, std::atomic<bool>& cancel, const FilterRasterFactory&) {
                      const auto result = filter_point_shadow_raster (input, width, height, *region,
                        FilterPointShadowOperation::value_invert, 0, cancel, output, channel);
                      if (result == FilterPointShadowOutcome::cancelled) return false;
                      outcome->publish (result == FilterPointShadowOutcome::shadow ?
                        FilterProcedureDisposition::shadow : FilterProcedureDisposition::no_merge);
                      return true;
                    };
                prepared.kernel_region = region;
                prepared.kernel_validate = [width, height, region] {
                  filter_point_shadow_validate (width, height, *region);
                };
                prepared.outcome = outcome;
                prepared.projection_input = true;
              }
          }
      }
    else if (procedure == "plug-in-edge" && args &&
        (args->size () == 5 || args->size () == 6))
      {
        const GValue *amount = args->at (3);
        const GValue *wrap = args->at (4);
        const GValue *edge = args->size () == 6 ? args->at (5) : nullptr;
        /* The original first three slots remain saved verbatim. Execution uses
         * our owned snapshot, never stale image/drawable IDs from the file. */
        if ((G_VALUE_HOLDS_DOUBLE (amount) || G_VALUE_HOLDS_FLOAT (amount)) &&
            G_VALUE_HOLDS_INT (wrap) && (!edge || G_VALUE_HOLDS_INT (edge)))
          {
            EdgeOptions options { G_VALUE_HOLDS_DOUBLE (amount) ? g_value_get_double (amount) : g_value_get_float (amount),
                                  g_value_get_int (wrap), edge ? g_value_get_int (edge) : 0 };
            if (std::isfinite (options.amount) && options.wrapmode >= 1 && options.wrapmode <= 3 &&
                options.edgemode >= 0 && options.edgemode <= 5)
              {
                auto width = request.width, height = request.height;
                request.process = [width, height, options, channel] (const FilterScheduler::Bytes& input,
                                                            std::atomic<bool>& cancel,
                                                            FilterScheduler::Bytes& output) {
                  return filter_edge (input, width, height, options, cancel, output, channel);
                };
                if (spill)
                  request.raster_process = [width, height, options, channel] (FilterRaster& input, FilterRaster& output,
                    std::atomic<bool>& cancel, const FilterRasterFactory&) {
                    return filter_edge_raster (input, width, height, options, cancel, output, channel);
                  };
                if (real)
                  {
                    FilterNativeProcess process = [width,height,options,channel] (FilterRaster& input, FilterRaster& output,
                      std::atomic<bool>& cancel, const FilterRasterFactory&) {
                      return filter_edge_real_raster (input,output,width,height,options,cancel,channel);
                    };
                    request.process = [process] (const FilterScheduler::Bytes& input, std::atomic<bool>& cancel,
                                                  FilterScheduler::Bytes& output) {
                      return filter_native_vector (input,cancel,output,process);
                    };
                    if (spill) request.raster_process = std::move (process);
                  }
              }
          }
      }
    else if (args && (procedure == "plug-in-gauss" || procedure == "plug-in-gauss-iir" ||
                      procedure == "plug-in-gauss-rle" || procedure == "plug-in-gauss-iir2" ||
                      procedure == "plug-in-gauss-rle2"))
      {
        const bool flags = procedure == "plug-in-gauss-iir" || procedure == "plug-in-gauss-rle";
        const bool canonical = procedure == "plug-in-gauss";
        const auto floating = [] (const GValue *value) { return G_VALUE_HOLDS_DOUBLE (value) || G_VALUE_HOLDS_FLOAT (value); };
        const auto argument_real = [] (const GValue *value) { return G_VALUE_HOLDS_DOUBLE (value) ? g_value_get_double (value) : g_value_get_float (value); };
        if (args->size () == (flags || canonical ? 6 : 5))
          {
            const GValue *a = args->at (3), *b = args->at (4), *c = args->size () == 6 ? args->at (5) : nullptr;
            GaussOptions options;
            bool valid = floating (a);
            if (flags)
              {
                valid = valid && G_VALUE_HOLDS_INT (b) && G_VALUE_HOLDS_INT (c);
                if (valid)
                  {
                    const auto radius = argument_real (a);
                    valid = std::isfinite (radius) && radius > 0;
                    options.horizontal = g_value_get_int (b) ? radius : 0;
                    options.vertical = g_value_get_int (c) ? radius : 0;
                  }
              }
            else
              {
                valid = valid && floating (b) && (!canonical || G_VALUE_HOLDS_INT (c));
                if (valid)
                  {
                    options.horizontal = argument_real (a); options.vertical = argument_real (b);
                    valid = std::isfinite (options.horizontal) && std::isfinite (options.vertical) &&
                            (options.horizontal > 0 || options.vertical > 0);
                  }
              }
            if (valid)
              {
                options.method = canonical ? g_value_get_int (c) :
                  (procedure == "plug-in-gauss-rle" || procedure == "plug-in-gauss-rle2" ? 1 : 0);
                valid = options.method >= 0 && options.method <= 1;
              }
            if (valid)
              {
                const bool identity = flags && options.horizontal == 0 && options.vertical == 0;
                if (spill) {
                  const std::uint64_t multiplier = request.bytes_per_pixel * (options.vertical > 0 ? 3 : 2);
                  if (std::uint64_t (request.width) > std::numeric_limits<std::uint64_t>::max () / multiplier / request.height)
                    throw std::invalid_argument ("Gaussian spill reservation exceeds64-bit accounting");
                  request.peak_spill_bytes = std::uint64_t (request.width) * request.height * multiplier;
                }
                const auto width = request.width, height = request.height;
                request.process = [width, height, options, identity, channel] (const FilterScheduler::Bytes& input,
                                                                      std::atomic<bool>& cancel,
                                                                      FilterScheduler::Bytes& output) {
                  if (!identity) return filter_gauss (input, width, height, options, cancel, output, channel);
                  if (cancel.load (std::memory_order_relaxed)) return false;
                  FilterScheduler::Bytes copy (input);
                  if (cancel.load (std::memory_order_relaxed)) return false;
                  output.swap (copy); channel->set_value (1.0); return true;
                };
                if (spill)
                  request.raster_process = [width, height, options, identity, channel] (FilterRaster& input, FilterRaster& output,
                    std::atomic<bool>& cancel, const FilterRasterFactory& scratch) {
                    if (!identity) return filter_gauss_raster (input, width, height, options, cancel, output, scratch, channel);
                    FilterScheduler::Bytes chunk (FilterScheduler::pixel_budget * 4);
                    for (std::uint64_t offset = 0; offset < input.size ();)
                      {
                        if (cancel.load (std::memory_order_relaxed)) return false;
                        const auto count = std::size_t (std::min (std::uint64_t (chunk.size ()),input.size () - offset));
                        input.read (offset,count,chunk.data ()); output.write (offset,count,chunk.data ()); offset += count;
                        channel->set_value (double (offset) / double (input.size ()));
                      }
                    output.flush (); return !cancel.load (std::memory_order_relaxed);
                  };
                if (real && !identity)
                  {
                    FilterNativeProcess process = [width,height,options,channel] (FilterRaster& input, FilterRaster& output,
                      std::atomic<bool>& cancel, const FilterRasterFactory& scratch) {
                      return filter_gauss_real_raster (input,output,width,height,options,cancel,scratch,channel);
                    };
                    request.process = [process] (const FilterScheduler::Bytes& input, std::atomic<bool>& cancel,
                                                  FilterScheduler::Bytes& output) {
                      return filter_native_vector (input,cancel,output,process);
                    };
                    if (spill) request.raster_process = std::move (process);
                  }
              }
          }
      }
    else if (args &&
             ((procedure == "plug-in-vinvert" && args->size () == 3 && !gray ()) ||
              (procedure == "plug-in-max-rgb" && args->size () == 4 && !gray () && G_VALUE_HOLDS_INT (args->at (3))) ||
              (procedure == "plug-in-threshold-alpha" && args->size () == 4 && G_VALUE_HOLDS_INT (args->at (3)))))
      {
        const auto operation = procedure == "plug-in-vinvert" ? FilterPoint::value_invert :
          procedure == "plug-in-max-rgb" ? FilterPoint::max_rgb : FilterPoint::threshold_alpha;
        const auto argument = args->size () == 4 ? g_value_get_int (args->at (3)) : 0;
        const auto width = request.width, height = request.height;
        FilterNativeProcess process = [width,height,operation,argument,real,channel] (FilterRaster& input, FilterRaster& output,
          std::atomic<bool>& cancel, const FilterRasterFactory&) {
          return filter_point_raster (input,output,width,height,operation,argument,real,cancel,channel);
        };
        request.process = [process] (const FilterScheduler::Bytes& input, std::atomic<bool>& cancel,
                                      FilterScheduler::Bytes& output) {
          return filter_native_vector (input,cancel,output,process);
        };
        if (spill) request.raster_process = std::move (process);
      }
    else if (procedure == FilterLegacy::convolution.saved && args && FilterLegacy::convolution_saved_count (args->size ()))
      {
        /* The old handler also accepted and ignored a twelfth argument. Keep
         * its typed value in the definition, never in native plugin options. */
        const auto integer = [&] (unsigned i) { return G_VALUE_HOLDS_INT (args->at (i)); };
        const bool types = integer (0) && integer (1) && integer (2) && integer (3) && integer (5) &&
          integer (8) && integer (10) && G_VALUE_HOLDS (args->at (4), GIMP_TYPE_DOUBLE_ARRAY) &&
          G_VALUE_HOLDS_DOUBLE (args->at (6)) && G_VALUE_HOLDS_DOUBLE (args->at (7)) &&
          G_VALUE_HOLDS (args->at (9), GIMP_TYPE_INT32_ARRAY);
        if (types && g_value_get_int (args->at (3)) == FilterLegacy::matrix_count &&
            g_value_get_int (args->at (8)) == FilterLegacy::channel_count)
          {
            const auto *matrix = static_cast<const GimpArray *> (g_value_get_boxed (args->at (4)));
            const auto *channels = static_cast<const GimpArray *> (g_value_get_boxed (args->at (9)));
            /* A matching boxed type alone does not prove element count or even
             * a whole element. Check raw byte lengths before any typed read. */
            if (matrix && matrix->data && matrix->length == FilterLegacy::matrix_count * sizeof (double) &&
                channels && channels->data && channels->length == FilterLegacy::channel_count * sizeof (gint32))
              {
                auto descriptor = std::make_shared<FilterProcedureRequest> ();
                descriptor->procedure = FilterProcedure::convolution;
                descriptor->width = request.width; descriptor->height = request.height;
                descriptor->gray = gray (); descriptor->storage_channels = gray () ? 2 : 4;
                const auto trc = gimp_drawable_get_trc (GIMP_DRAWABLE (owner));
                descriptor->sample_mode = !real ? 0 : trc == GIMP_TRC_LINEAR ? 1 :
                  trc == GIMP_TRC_NON_LINEAR ? 2 : 3;
                std::memcpy (descriptor->matrix.data (), matrix->data, matrix->length);
                std::memcpy (descriptor->channels.data (), channels->data, channels->length);
                descriptor->alpha_alg = g_value_get_int (args->at (5));
                descriptor->divisor = g_value_get_double (args->at (6));
                descriptor->offset = g_value_get_double (args->at (7));
                descriptor->border = g_value_get_int (args->at (10));
                bool valid = true;
                try { descriptor->bytes (); }
                catch (const std::invalid_argument&) { valid = false; }
                if (valid) configure_native (prepared, std::move (descriptor));
              }
          }
      }
    /* Blinds historically checks only payload slots 3..6. Unlike the other
     * routes, saved context slot types are not an execution admission rule. */
    else if (!real && args &&
             ((procedure == FilterLegacy::blinds.saved && args->size () == 7 &&
               G_VALUE_HOLDS_INT (args->at (3)) && G_VALUE_HOLDS_INT (args->at (4)) &&
               G_VALUE_HOLDS_INT (args->at (5)) && G_VALUE_HOLDS_INT (args->at (6))) ||
              (procedure == FilterLegacy::small_tiles.saved && args->size () == 4 &&
               G_VALUE_HOLDS_INT (args->at (0)) && G_VALUE_HOLDS_INT (args->at (1)) &&
               G_VALUE_HOLDS_INT (args->at (2)) && G_VALUE_HOLDS_INT (args->at (3))) ||
              (procedure == FilterLegacy::retinex.saved && !gray () && args->size () == 7 &&
               G_VALUE_HOLDS_INT (args->at (0)) && G_VALUE_HOLDS_INT (args->at (1)) &&
               G_VALUE_HOLDS_INT (args->at (2)) && G_VALUE_HOLDS_INT (args->at (3)) &&
               G_VALUE_HOLDS_INT (args->at (4)) && G_VALUE_HOLDS_INT (args->at (5)) &&
               G_VALUE_HOLDS_DOUBLE (args->at (6)))))
      {
        const bool tiles = procedure == FilterLegacy::small_tiles.saved;
        const bool retinex = procedure == FilterLegacy::retinex.saved;
        const auto angle = tiles || retinex ? FilterLegacy::angle.initial : g_value_get_int (args->at (3));
        const auto segments = tiles || retinex ? FilterLegacy::segments.initial : g_value_get_int (args->at (4));
        const auto factor = tiles ? g_value_get_int (args->at (3)) : FilterLegacy::tiles.initial;
        const auto scale = retinex ? g_value_get_int (args->at (3)) : FilterLegacy::scale.initial;
        const auto nscales = retinex ? g_value_get_int (args->at (4)) : FilterLegacy::nscales.initial;
        const auto scales_mode = retinex ? g_value_get_int (args->at (5)) : FilterLegacy::scales_mode.initial;
        const auto cvar = retinex ? g_value_get_double (args->at (6)) : FilterLegacy::cvar.initial;
        if (FilterLegacy::blinds_scalars (angle, segments) && FilterLegacy::tiles.accepts (factor) &&
            (!retinex || (FilterLegacy::retinex_owner_geometry (request.width, request.height) &&
              FilterLegacy::retinex_scalars (scale, nscales, scales_mode, cvar))))
          {
            auto descriptor = std::make_shared<FilterProcedureRequest> ();
            descriptor->width = request.width; descriptor->height = request.height;
            descriptor->angle = angle; descriptor->segments = segments;
            descriptor->procedure = retinex ? FilterProcedure::retinex :
                                    tiles ? FilterProcedure::small_tiles : FilterProcedure::blinds;
            descriptor->tiles = factor;
            descriptor->scale = scale; descriptor->nscales = nscales;
            descriptor->scales_mode = scales_mode; descriptor->cvar = cvar;
            descriptor->orientation = tiles || retinex ? FilterLegacy::orientation_default : g_value_get_int (args->at (5));
            descriptor->transparent = tiles || retinex ? FilterLegacy::transparent_default : g_value_get_int (args->at (6)); descriptor->gray = gray ();
            configure_native (prepared, std::move (descriptor));
          }
      }
    return prepared;
  }
  void apply_configuration (PreparedConfiguration prepared)
  {
    /* The caller has also scheduled the dispatcher before entering this
     * publication step. Moving the prepared request performs no C++ allocation. */
    graph_valid = false;
    read_budget = 1024;
    native_procedure = std::move (prepared.procedure);
    native_process_options = std::move (prepared.process_options);
    native_outcome = std::move (prepared.outcome);
    native_kernel_region = std::move (prepared.kernel_region);
    native_kernel_validate = std::move (prepared.kernel_validate);
    native_projection_input = prepared.projection_input;
    native_context.reset ();
    scheduler.set_request (std::move (prepared.request));
    staged.reset ();
    g_signal_emit_by_name (owner, "filter-state-changed");
  }
  void configure_native (PreparedConfiguration& prepared,
                         std::shared_ptr<FilterProcedureRequest> descriptor)
  {
    auto& request = prepared.request;
    auto options = std::make_shared<FilterProcessOptions> ();
    auto outcome = std::make_shared<FilterProcedureResult> ();
    /* Same isolated bridge and owner gates for every native route. Convolution
     * doubles retain their full native input and selection snapshots. Reserve
     * both logical storage classes conservatively, independently of GEGL's
     * shared tile-cache policy; this is not a total-RSS bound. */
    const auto raster = descriptor->bytes ();
    const auto sample = descriptor->sample_mode ? 8u : 1u;
    const auto owner_context_bytes = std::uint64_t (request.width) * request.height *
      (gray () ? 3u : 5u) * sample;
    const auto child_mask_bytes = std::uint64_t (request.width) * request.height * sample;
    request.peak_spill_bytes = raster * 5 + owner_context_bytes + child_mask_bytes;
    const auto peak = owner_context_bytes + std::uint64_t (256) * 1024 * 1024 + descriptor->scratch_bytes ();
    request.peak_bytes = std::size_t (std::min (peak, std::uint64_t (std::numeric_limits<std::size_t>::max ())));
    const auto channel = request.progress;
    request.raster_process = [descriptor,options,outcome,channel] (FilterRaster& input, FilterRaster& output,
      std::atomic<bool>& cancel, const FilterRasterFactory&) {
        auto resolved = *options;
        resolved.executable = filter_worker_path ();
        return filter_process (*descriptor, input, output, cancel, resolved, outcome, channel);
      };
    prepared.procedure = std::move (descriptor); prepared.process_options = std::move (options);
    prepared.outcome = std::move (outcome);
  }
  void schedule ()
  {
    if (scheduler.state () == FilterScheduler::State::closed) return;
    /* A single source rotates one bounded quantum across all layers/images.
     * Multiple ready images cannot form an unbounded same-priority timer batch. */
    static FairDispatcher dispatcher (nullptr, 2, 150);
    if (!pending.valid ())
      {
        auto callback = std::make_shared<Callback> (owner);
        pending = dispatcher.ticket ([callback] {
          bool again = false;
          visit (callback.get (), [&] (FilterImpl& impl) { again = impl.step (); });
          return again;
        });
      }
    pending.schedule ();
  }
  struct FilterDependency
  {
    WeakRef<GObject> object;
    std::uint64_t generation;
  };
  struct CloneDependency { WeakRef<GObject> object, source; bool had_source; };
  bool plan_graph_nodes ()
  {
    graph_nodes.clear (); graph_node_cursor = 0; graph_fish_cursor = 0;
    auto container = stack.lock ();
    if (!container || !GIMP_IS_LIST (container.get ())) return false;
    /* Node construction is the expensive part of the host stack's synchronous
     * get_graph(). Snapshot a child-before-parent plan without entering any
     * get_node vfunc or resolving Clone references during borrowed traversal.
     * Include active layers above us: the host links the entire stack. */
    struct Frame { GimpFilter *filter; GList *next = nullptr; bool entered = false; };
    std::vector<Frame> frames;
    std::set<GimpFilter *> visited;
    for (GList *root = GIMP_LIST (container.get ())->queue->head; root; root = root->next)
      {
        auto *filter = GIMP_FILTER (root->data);
        if (!gimp_filter_get_active (filter)) continue;
        frames.push_back ({filter});
        while (!frames.empty ())
          {
            Frame& frame = frames.back ();
            if (!frame.entered)
              {
                if (gimp_filter_peek_node (frame.filter)) { frames.pop_back (); continue; }
                if (!visited.insert (frame.filter).second || visited.size () > 4096) return false;
                frame.entered = true;
                if (auto *children = gimp_viewable_get_children (GIMP_VIEWABLE (frame.filter)))
                  {
                    if (!GIMP_IS_LIST (children)) return false;
                    frame.next = GIMP_LIST (children)->queue->head;
                  }
              }
            while (frame.next && !gimp_filter_get_active (GIMP_FILTER (frame.next->data))) frame.next = frame.next->next;
            if (frame.next)
              {
                auto *child = GIMP_FILTER (frame.next->data); frame.next = frame.next->next;
                frames.push_back ({child}); continue;
              }
            graph_nodes.emplace_back (ObjectRef<GObject>::retain (G_OBJECT (frame.filter)));
            frames.pop_back ();
          }
      }
    return true;
  }
  bool prepare_graph_quantum ()
  {
    /* The host layer-mode prepare eagerly creates all twelve conversion fishes
     * in one call. Prime the same immutable Babl cache entries cooperatively for
     * default and native image spaces; no pixels or graph state are evaluated.
     * This is a performance hint only: host nodes still prepare their own exact
     * formats, including any other space a custom operation requests. */
    const auto started = g_get_monotonic_time ();
    static const char *formats[] = {"RGBA float", "R~G~B~A float", "R'G'B'A float", "CIE Lab alpha float"};
    static const unsigned pairs[12][2] = {{0,1},{0,2},{0,3},{2,0},{1,0},{1,3},{2,3},{3,0},{3,1},{3,2},{1,2},{2,1}};
    while (graph_fish_cursor < 24)
      {
        const auto index = graph_fish_cursor++;
        const auto from = pairs[index % 12][0], to = pairs[index % 12][1];
        const Babl *space = index < 12 ? nullptr : babl_format_get_space (gimp_drawable_get_format (GIMP_DRAWABLE (owner)));
        babl_fish (babl_format_with_space (formats[from],space), babl_format_with_space (formats[to],space));
        if (g_get_monotonic_time () - started >= 2000) return true;
      }
    while (graph_node_cursor < graph_nodes.size ())
      {
        // Publish the cursor and end every vector borrow before callback entry.
        auto object = graph_nodes[graph_node_cursor++].lock ();
        if (!object) { graph_valid = false; return true; }
        if (gimp_filter_peek_node (GIMP_FILTER (object.get ()))) continue;
        auto image = ObjectRef<GObject>::retain (G_OBJECT (gimp_item_get_image (GIMP_ITEM (owner))));
        if (!image) { scheduler.close (); return false; }
        gimp_filter_get_node (GIMP_FILTER (object.get ()));
        // Reentry may clear the whole plan, invalidate dependencies or close.
        // Do not consult old plan indices/references or read pixels this turn.
        return true;
      }
    return false;
  }
  bool validate_graph ()
  {
    graph_connections.clear ();
    graph_filters.clear ();
    graph_clones.clear ();
    const auto invalid = [&] {
      graph_connections.clear (); graph_filters.clear (); graph_clones.clear (); graph_nodes.clear (); return false;
    };
    auto container = stack.lock ();
    if (!container || !GIMP_IS_LIST (container.get ())) return invalid ();
    GList *root = g_list_find (GIMP_LIST (container.get ())->queue->head, owner);
    if (!root) return invalid ();
    struct Frame { GimpLayer *layer; GList *next = nullptr; GimpLayer *source = nullptr; bool entered = false; };
    std::vector<Frame> frames;
    std::vector<CloneReference> clone_snapshots;
    std::set<GimpLayer *> path, complete;
    std::size_t visited = 0;
    for (root = root->next; root; root = root->next)
      {
        auto *layer = GIMP_LAYER (root->data);
        if (!gimp_item_get_visible (GIMP_ITEM (layer))) continue;
        frames.push_back ({layer});
        while (!frames.empty ())
          {
            Frame& frame = frames.back ();
            layer = frame.layer;
            if (!frame.entered)
              {
                if (complete.count (layer)) { frames.pop_back (); continue; }
                if (layer == GIMP_LAYER (owner) || !path.insert (layer).second || ++visited > 4096) return invalid ();
                frame.entered = true;
                if (GIMP_IS_CLONE_LAYER (layer))
                  {
                    CloneReference reference (gimp_clone_layer_dup_reference (GIMP_CLONE_LAYER (layer), nullptr));
                    if (!reference) return invalid ();
                    frame.source = reference->source;
                    graph_clones.push_back ({WeakRef<GObject> (ObjectRef<GObject>::retain (G_OBJECT (layer))),
                      WeakRef<GObject> (ObjectRef<GObject>::retain (G_OBJECT (frame.source))), frame.source != nullptr});
                    /* Also observe clones reached through another clone, whose
                     * referenced image may be outside our own layer stack. */
                    graph_connections.push_back (connect (G_OBJECT (layer), "update", G_CALLBACK (graph_update)));
                    clone_snapshots.push_back (std::move (reference));
                  }
                else if (GIMP_IS_FILTER_LAYER (layer))
                  {
                    graph_filters.push_back ({WeakRef<GObject> (ObjectRef<GObject>::retain (G_OBJECT (layer))),
                      gimp_filter_layer_get_generation (GIMP_FILTER_LAYER (layer))});
                    graph_connections.push_back (connect (G_OBJECT (layer), "filter-state-changed", G_CALLBACK (graph_status)));
                    auto *children = gimp_item_get_container (GIMP_ITEM (layer));
                    if (children && GIMP_IS_LIST (children))
                      {
                        GList *self = g_list_find (GIMP_LIST (children)->queue->head, layer);
                        frame.next = self ? self->next : nullptr;
                      }
                  }
                else if (auto *children = gimp_viewable_get_children (GIMP_VIEWABLE (layer)))
                  {
                    if (!GIMP_IS_LIST (children)) return invalid ();
                    frame.next = GIMP_LIST (children)->queue->head;
                  }
              }
            if (frame.source)
              {
                auto *source = frame.source;
                frame.source = nullptr;
                /* Clone renders its source even when that source is hidden. */
                frames.push_back ({source});
                continue;
              }
            while (frame.next && !gimp_item_get_visible (GIMP_ITEM (frame.next->data))) frame.next = frame.next->next;
            if (frame.next)
              {
                auto *child = GIMP_LAYER (frame.next->data);
                frame.next = frame.next->next;
                frames.push_back ({child});
                continue;
              }
            path.erase (layer);
            complete.insert (layer);
            frames.pop_back ();
          }
      }
    if (!plan_graph_nodes ()) return invalid ();
    graph_valid = true;
    return true;
  }
  bool ready (bool& failed)
  {
    if (!graph_valid && !validate_graph ()) { failed = true; return false; }
    /* Validation is cached, but not ownership or freshness. Weak endpoints,
     * live clone targets and Filter states/generations are checked at every
     * scheduling checkpoint, including a missed or manually suppressed signal. */
    bool changed = false, all_ready = true;
    for (const auto& entry : graph_clones)
      {
        auto object = entry.object.lock (), source = entry.source.lock ();
        CloneReference reference (object ? gimp_clone_layer_dup_reference (GIMP_CLONE_LAYER (object.get ()), nullptr) : nullptr);
        if (!reference || (entry.had_source && !source) || source.get () != G_OBJECT (reference->source))
          { changed = true; break; }
      }
    if (!changed)
      for (const auto& entry : graph_filters)
        {
          auto object = entry.object.lock ();
          if (!object) { changed = true; break; }
          auto *filter = GIMP_FILTER_LAYER (object.get ());
          const auto state = gimp_filter_layer_get_state (filter);
          if (state == GIMP_FILTER_LAYER_FAILED || state == GIMP_FILTER_LAYER_CLOSED) { failed = true; return false; }
          if (entry.generation != gimp_filter_layer_get_generation (filter)) { changed = true; break; }
          if (state != GIMP_FILTER_LAYER_CLEAN) all_ready = false;
        }
    if (changed)
      {
        /* All owned snapshots and iteration references above have ended.
         * Invalidation emits user callbacks: do not traverse again afterwards
         * in this quantum. A fresh scheduled turn checks owner/generation. */
        graph_recheck = true;
        invalidate ();
        return false;
      }
    return all_ready;
  }
  bool input_current (std::uint64_t generation)
  {
    if (generation != scheduler.generation () || scheduler.state () != FilterScheduler::State::preparing) return false;
    bool failed = false;
    const bool current = ready (failed);
    if (failed) scheduler.reject ("Filter dependency failed, is cyclic, or exceeds the graph limit");
    else if (!current && generation == scheduler.generation () && scheduler.state () == FilterScheduler::State::preparing)
      invalidate ();
    return current && generation == scheduler.generation () && scheduler.state () == FilterScheduler::State::preparing;
  }
  static void tune_budget (std::size_t count, gint64 elapsed, std::size_t& budget)
  {
    /* Cost depends on the lower graph, not just pixel count. Begin with a
     * small probe; only grow after a cheap measured sample, and damp changes.
     * This is cooperative latency control, not a hard real-time guarantee. */
    if (elapsed > 4000) budget = std::max (std::size_t (1024), count / 2);
    else if (elapsed < 2000) budget = std::min (std::size_t (FilterScheduler::pixel_budget), budget * 2);
  }
  bool gray () const
  { return gimp_drawable_get_base_type (GIMP_DRAWABLE (owner)) == GIMP_GRAY; }
  bool real_samples () const
  { return gimp_drawable_get_precision (GIMP_DRAWABLE (owner)) != GIMP_PRECISION_U8_NON_LINEAR; }
  const Babl *encoded_format () const
  {
    if (real_samples ())
      return gimp_babl_format (gray () ? GIMP_GRAY : GIMP_RGB,
        gimp_babl_precision (GIMP_COMPONENT_TYPE_DOUBLE, gimp_drawable_get_trc (GIMP_DRAWABLE (owner))), TRUE,
        babl_format_get_space (gimp_drawable_get_format (GIMP_DRAWABLE (owner))));
    /* Legacy plug-ins calculate on encoded native bytes, not a conversion to
     * default sRGB. Input and import must use the same drawable color space. */
    return babl_format_with_space (gray () ? "Y'A u8" : "R'G'B'A u8",
      babl_format_get_space (gimp_drawable_get_format (GIMP_DRAWABLE (owner))));
  }
  GeglRectangle rectangle (std::size_t offset, std::size_t count)
  {
    const int width = gimp_item_get_width (GIMP_ITEM (owner));
    const int x = offset % width, y = offset / width;
    return { x, y, int (count < std::size_t (width) ? count : width),
             int (count < std::size_t (width) ? 1 : count / width) };
  }
  void publish_buffer (GeglBuffer *completed, std::uint64_t token, bool flush)
  {
    if (token != scheduler.generation () || scheduler.state () == FilterScheduler::State::closed) return;
    /* Swap a fully imported buffer. No partial result is visible to the
     * drawable source, save code, projection, or an upper FilterLayer. */
    gimp_drawable_set_buffer_full (GIMP_DRAWABLE (owner), FALSE, nullptr, completed, nullptr, FALSE);
    /* Buffer notification may synchronously close the image or edit the
     * definition. Never publish a later drawable update for that token. */
    if (scheduler.state () == FilterScheduler::State::closed || token != scheduler.generation ()) return;
    gimp_drawable_update (GIMP_DRAWABLE (owner), 0, 0,
                          gimp_item_get_width (GIMP_ITEM (owner)), gimp_item_get_height (GIMP_ITEM (owner)));
    if (scheduler.state () == FilterScheduler::State::closed || token != scheduler.generation ()) return;
    /* Asynchronous completion also flushes the image, scheduling chunked
     * projection without waiting. Synchronous Undo uses its caller's flush. */
    if (flush)
      {
        auto image = ObjectRef<GObject>::retain (G_OBJECT (gimp_item_get_image (GIMP_ITEM (owner))));
        if (image) gimp_image_flush (GIMP_IMAGE (image.get ()));
      }
  }
  bool progress_current () const noexcept
  {
    return progress.active && progress_generation == scheduler.generation () &&
           scheduler.state () != FilterScheduler::State::closed;
  }
  void progress_changed ()
  { g_signal_emit_by_name (owner, "filter-progress-changed"); }
  void sync_progress ()
  {
    const auto token = scheduler.generation ();
    const auto phase = scheduler.state ();
    const bool active = phase == FilterScheduler::State::preparing ||
                        phase == FilterScheduler::State::running ||
                        phase == FilterScheduler::State::importing;
    if (!active)
      {
        if (progress.active)
          {
            progress.active = progress.cancellable = false;
            if (progress_generation == token && phase == FilterScheduler::State::clean)
              progress.value = 1.0;
            progress_changed ();
          }
        return;
      }
    const bool starting = !progress_current ();
    const auto now = g_get_monotonic_time ();
    if (!starting && phase == progress_phase && now < progress_next_update) return;
    if (starting)
      {
        progress = {};
        progress_generation = token;
        progress.active = progress.cancellable = true;
        FilterProgress::copy_text (progress.text, procedure.c_str ());
      }
    progress_phase = phase;
    progress_next_update = now + 100 * G_TIME_SPAN_MILLISECOND;
    FilterProgress::Snapshot worker;
    const bool sampled = scheduler.progress_snapshot (worker);
    if (sampled)
      {
        if (worker.text[0]) progress.text = worker.text;
        progress.pulses = worker.pulses;
        progress.message_revision = worker.message_revision;
        progress.message_text = worker.message_text;
        progress.message_domain = worker.message_domain;
        progress.message_severity = worker.message_severity;
      }
    // Preparation/import are real bounded copy work. The middle interval is
    // the native kernel or isolated PDB's own fraction, never elapsed time.
    const double fraction = phase == FilterScheduler::State::preparing ? 0.15 * scheduler.phase_fraction () :
      phase == FilterScheduler::State::importing ? 0.85 + 0.15 * scheduler.phase_fraction () :
      sampled ? 0.15 + 0.70 * worker.value : progress.value;
    progress.value = std::max (progress.value, fraction);
    progress_changed (); // one bounded snapshot notification; observers may reenter
  }
  bool step ()
  {
    if (dispatching) return scheduler.state () != FilterScheduler::State::closed;
    struct Guard { bool& flag; Guard (bool& flag) : flag (flag) { flag = true; } ~Guard () { flag = false; } } guard (dispatching);
    const auto token = scheduler.generation ();
    const auto started = g_get_monotonic_time ();
    bool again = step_work ();
    if (scheduler.state () != FilterScheduler::State::closed) sync_progress ();
    maximum_quantum_us = std::max (maximum_quantum_us, g_get_monotonic_time () - started);
    if (scheduler.state () == FilterScheduler::State::closed) return false;
    return again || token != scheduler.generation ();
  }
  bool step_work ()
  {
    /* Include every early return, callback and local destructor. Recording
     * before state-change emission hid synchronous observer/teardown cost. The
     * BindingStore borrow keeps this implementation alive through scope exit. */
    struct QuantumTimer
    {
      gint64& maximum;
      gint64 started = g_get_monotonic_time ();
      ~QuantumTimer () noexcept { maximum = std::max (maximum, g_get_monotonic_time () - started); }
    } timer { maximum_quantum_us };
    if (topology_dirty) refresh_connections ();
    if (!gimp_item_is_attached (GIMP_ITEM (owner)) || gimp_item_is_removed (GIMP_ITEM (owner)) ||
        !gimp_item_get_visible (GIMP_ITEM (owner)))
      {
        native_context.reset ();
        const bool again = scheduler.step (false, {}, {}, {});
        if (scheduler.state () != FilterScheduler::State::importing) staged.reset ();
        return again;
      }
    const auto previous = scheduler.state ();
    if ((previous == FilterScheduler::State::waiting || previous == FilterScheduler::State::cancelling) &&
        scheduler.uses_spool ())
      {
        /* This is the expanded, trusted application swap setting, not an XCF
         * path argument or an implicit /tmp (which may be RAM-backed). The
         * worker copies it at admission; no owner-side file I/O is performed. */
        gchar *directory = nullptr;
        g_object_get (gegl_config (), "swap", &directory, nullptr);
        std::unique_ptr<gchar, decltype (&g_free)> guard (directory, g_free);
        scheduler.set_spool_directory (directory ? directory : "");
        if (native_process_options)
          {
            preparing_process_directory = directory ? directory : "";
            if (!directory || !*directory || !g_path_is_absolute (directory))
              scheduler.reject ("Bundled PDB Filter execution requires configured file swap; definition and cache are retained");
          }
      }
    if (auto* image = gimp_item_get_image (GIMP_ITEM (owner))) {
      try { scheduler.set_admission (filter_admission_for_config (G_OBJECT (image->gimp->config))); }
      catch (const std::exception& error) {
        if (scheduler.state () != FilterScheduler::State::failed) scheduler.reject (error.what ());
        return scheduler.step (false, {}, {}, {});
      }
    }
    scheduler.set_pixel_budget (previous == FilterScheduler::State::importing ? import_budget : read_budget);
    /* Legacy RGB/Gray U8 nonlinear stays on the byte oracle. Other native
     * RGB/Gray precisions/TRCs use the documented double extension. Indexed
     * palette semantics cannot be represented by an independent RGBA cache. */
    if (previous != FilterScheduler::State::clean && previous != FilterScheduler::State::failed &&
        gimp_drawable_get_base_type (GIMP_DRAWABLE (owner)) != GIMP_RGB && !gray ())
      scheduler.reject ("Filter execution requires RGB or Gray; indexed definition and cache are retained");
    bool failed = false;
    graph_recheck = false;
    const bool dependencies_ready = ready (failed);
    if (scheduler.state () == FilterScheduler::State::closed) return false;
    if (failed) scheduler.reject ("Filter dependency failed, is cyclic, or exceeds the graph limit");
    if (dependencies_ready && scheduler.state () == FilterScheduler::State::waiting && scheduler.has_processor ())
      {
        const auto preparing_started = g_get_monotonic_time ();
        const bool prepared_one = prepare_graph_quantum ();
        maximum_graph_us = std::max (maximum_graph_us, g_get_monotonic_time () - preparing_started);
        if (prepared_one)
          {
            return scheduler.state () != FilterScheduler::State::closed;
          }
      }
    if (scheduler.state () == FilterScheduler::State::closed) return false;
    bool again = scheduler.step (dependencies_ready,
      [&] (std::size_t offset, std::size_t count, FilterScheduler::Bytes& input) {
        const auto read_started = g_get_monotonic_time ();
        const auto generation = scheduler.generation ();
        auto image = ObjectRef<GObject>::retain (G_OBJECT (gimp_item_get_image (GIMP_ITEM (owner))));
        if (!image) throw Error (GIMP_PAINTER_ERROR_CLOSED, "Layer image was closed");
        auto container = stack.lock ();
        if (!container) throw Error (GIMP_PAINTER_ERROR_CLOSED, "Layer stack was removed");
        /* Build the existing stack graph outside operator evaluation, then
         * sample only this layer's input proxy: precisely the lower stack. */
        gimp_filter_stack_get_graph (GIMP_FILTER_STACK (container.get ()));
        /* Node construction can emit callbacks or resolve a pending reference.
         * Do not evaluate a graph exposed by such a change until revalidated. */
        if (!input_current (generation)) return;
        GeglNode *node = gimp_filter_get_node (GIMP_FILTER (owner));
        if (!input_current (generation)) return;
        GeglNode *below_node = gegl_node_get_input_proxy (node, "input");
        const auto rect = rectangle (offset, count);
        /* Item offsets are gint but a later local chunk may move beyond that
         * domain. Keep the translated rectangle wide until projection clipping
         * has established whether any native read is needed. In particular, an
         * entirely off-parent chunk still carries its completed cache bytes. */
        const auto source_x = std::int64_t (rect.x) + gimp_item_get_offset_x (GIMP_ITEM (owner));
        const auto source_y = std::int64_t (rect.y) + gimp_item_get_offset_y (GIMP_ITEM (owner));
        const auto size = input.size ();
        const bool real = real_samples ();
        input.resize (size + count * (real ? 32 : 4));
        const auto blit_input = [&] (void *bytes, std::size_t stride) {
          if (!native_projection_input)
            {
              if (source_x < G_MININT || source_y < G_MININT ||
                  source_x + rect.width > G_MAXINT || source_y + rect.height > G_MAXINT)
                throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,
                             "Filter input exceeds the native coordinate range");
              const GeglRectangle source {int (source_x), int (source_y), rect.width, rect.height};
              gegl_node_blit (below_node, 1.0, &source, encoded_format (), bytes,
                              GEGL_AUTO_ROWSTRIDE, GEGL_BLIT_CACHE);
              return;
            }
          /* The old FilterLayer copied the parent projection into its existing
           * drawable tiles, leaving prior pixels outside the copied rectangle.
           * Prefill this already admitted native chunk from the completed cache
           * so loaded pixels and earlier off-canvas results survive there; then
           * overwrite only current lower-projection coverage. Reading the raw
           * GEGL proxy unrestricted would instead expose off-canvas source.
           * A group projection uses its own offset/extent, not the image canvas.
           * This policy belongs only to the nonlinear-U8 Threshold and Sobel
           * routes. Sobel's vertical halo may sample retained cache pixels. */
          const auto local = rectangle (offset, count);
          auto cache = ObjectRef<GObject>::retain (G_OBJECT (gimp_drawable_get_buffer (GIMP_DRAWABLE (owner))));
          gegl_buffer_get (GEGL_BUFFER (cache.get ()), &local, 1.0, encoded_format (),
                           bytes, GEGL_AUTO_ROWSTRIDE, GEGL_ABYSS_NONE);
          auto *parent = gimp_item_get_parent (GIMP_ITEM (owner));
          const std::int64_t x1 = parent ? gimp_item_get_offset_x (parent) : 0;
          const std::int64_t y1 = parent ? gimp_item_get_offset_y (parent) : 0;
          const auto x2 = x1 + (parent ? gimp_item_get_width (parent) :
            gimp_image_get_width (GIMP_IMAGE (image.get ())));
          const auto y2 = y1 + (parent ? gimp_item_get_height (parent) :
            gimp_image_get_height (GIMP_IMAGE (image.get ())));
          const auto left = std::max (source_x, x1);
          const auto top = std::max (source_y, y1);
          const auto right = std::min (source_x + rect.width, x2);
          const auto bottom = std::min (source_y + rect.height, y2);
          if (left >= right || top >= bottom) return;
          if (left < G_MININT || top < G_MININT || right > G_MAXINT || bottom > G_MAXINT)
            throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,
                         "Filter parent projection exceeds the native coordinate range");
          const GeglRectangle clipped {int (left), int (top), int (right-left), int (bottom-top)};
          const auto destination = (std::size_t (top-source_y) * rect.width + std::size_t (left-source_x)) * stride;
          gegl_node_blit (below_node, 1.0, &clipped, encoded_format (),
                          static_cast<std::uint8_t *> (bytes) + destination,
                          rect.width * stride, GEGL_BLIT_CACHE);
        };
        if (real)
          {
            /* Aligned staging avoids treating byte-vector storage as live
             * double objects. Gray channels are replicated without conversion. */
            std::vector<double> native (count * (gray () ? 2 : 4));
            blit_input (native.data (), (gray () ? 2 : 4) * sizeof (double));
            if (gray ())
              for (std::size_t i = 0; i < count; ++i)
                {
                  const double rgba[] = {native[i*2],native[i*2],native[i*2],native[i*2+1]};
                  std::memcpy (input.data ()+size+i*32,rgba,32);
                }
            else std::memcpy (input.data ()+size,native.data (),count*32);
          }
        else if (gray ())
          {
            /* Gray is one encoded channel, not RGB luminance. Replication lets
             * the channel-independent legacy kernels retain their exact byte
             * arithmetic without introducing an ICC RGB/Gray conversion. */
            std::vector<std::uint8_t> native (count * 2);
            blit_input (native.data (), 2);
            for (std::size_t i = 0; i < count; ++i)
              {
                input[size + i * 4] = input[size + i * 4 + 1] = input[size + i * 4 + 2] = native[i * 2];
                input[size + i * 4 + 3] = native[i * 2 + 1];
              }
          }
        else
          blit_input (input.data () + size, 4);
        if (!input_current (generation)) return;
        if (native_process_options && !offset)
          {
            /* The old worker is gone before first read. This is the exact
             * directory copied into this admitted spool, not a later setting. */
            native_process_options->temporary_directory = preparing_process_directory;
          }
        if (native_procedure || native_kernel_region)
          native_context.capture_input (GIMP_DRAWABLE (owner), offset, count, input.data () + size);
        maximum_read_us = std::max (maximum_read_us, g_get_monotonic_time () - read_started);
        tune_budget (count, g_get_monotonic_time () - read_started, read_budget);
      },
      [&] (std::size_t offset, std::size_t count, const std::uint8_t *pixels) {
        const auto import_started = g_get_monotonic_time ();
        std::vector<std::uint8_t> merged;
        if (native_procedure || native_kernel_region)
          { native_context.merge_chunk (offset, count, pixels, merged); pixels = merged.data (); }
        if (!offset)
          {
            GeglRectangle extent {0, 0, gimp_item_get_width (GIMP_ITEM (owner)), gimp_item_get_height (GIMP_ITEM (owner))};
            staged = ObjectRef<GObject>::adopt (G_OBJECT (gegl_buffer_new (&extent, gimp_drawable_get_format (GIMP_DRAWABLE (owner)))));
          }
        auto rect = rectangle (offset, count);
        if (real_samples ())
          {
            std::vector<double> native (count * (gray () ? 2 : 4));
            if (gray ())
              for (std::size_t i = 0; i < count; ++i)
                {
                  double rgba[4]; std::memcpy (rgba,pixels+i*32,32);
                  if (rgba[0] != rgba[1] || rgba[0] != rgba[2])
                    throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,"Native Gray executor returned unequal channels");
                  native[i*2]=rgba[0]; native[i*2+1]=rgba[3];
                }
            else std::memcpy (native.data (),pixels,count*32);
            gegl_buffer_set (GEGL_BUFFER (staged.get ()),&rect,0,encoded_format (),native.data (),GEGL_AUTO_ROWSTRIDE);
            const auto component = gimp_babl_component_type (gimp_drawable_get_precision (GIMP_DRAWABLE (owner)));
            if (native_procedure && native_procedure->procedure == FilterProcedure::convolution &&
                (component == GIMP_COMPONENT_TYPE_HALF || component == GIMP_COMPONENT_TYPE_FLOAT))
              {
                /* A finite double result can overflow HALF/FLOAT storage.
                 * Read only this private, bounded converted chunk; never let
                 * an infinity produced by native storage reach publication. */
                gegl_buffer_get (GEGL_BUFFER (staged.get ()), &rect, 1.0, encoded_format (),
                                 native.data (), GEGL_AUTO_ROWSTRIDE, GEGL_ABYSS_NONE);
                for (double sample : native)
                  if (!std::isfinite (sample))
                    throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,
                                 "Convolution result exceeds finite native storage");
              }
          }
        else if (gray ())
          {
            std::vector<std::uint8_t> native (count * 2);
            for (std::size_t i = 0; i < count; ++i)
              {
                if (pixels[i * 4] != pixels[i * 4 + 1] || pixels[i * 4] != pixels[i * 4 + 2])
                  throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Legacy Gray executor returned unequal channels");
                native[i * 2] = pixels[i * 4];
                native[i * 2 + 1] = pixels[i * 4 + 3];
              }
            gegl_buffer_set (GEGL_BUFFER (staged.get ()), &rect, 0, encoded_format (), native.data (), GEGL_AUTO_ROWSTRIDE);
          }
        else
          gegl_buffer_set (GEGL_BUFFER (staged.get ()), &rect, 0, encoded_format (), pixels, GEGL_AUTO_ROWSTRIDE);
        tune_budget (count, g_get_monotonic_time () - import_started, import_budget);
      },
      [&] (std::uint64_t token) {
        if (token != scheduler.generation ()) return;
        native_context.reset ();
        auto completed = std::move (staged);
        publish_buffer (GEGL_BUFFER (completed.get ()), token, true);
      },
      native_procedure || native_kernel_region ? FilterScheduler::Gate ([&] {
        refresh_context_selection ();
        if (native_kernel_region)
          {
            if (!native_context.before_process (GIMP_DRAWABLE (owner), *native_kernel_region, read_budget))
              return false;
            /* Each kernel owns its captured-crop domain. In particular,
             * Threshold Alpha and Sobel accept one-pixel intersections while Sharpen
             * retains the pinned kernel's unsafe tiny-crop rejection. */
            native_kernel_validate ();
            native_outcome->reset ();
            return true;
          }
        if (!native_context.before_process (GIMP_DRAWABLE (owner), *native_procedure, read_budget)) return false;
        /* Retinex's native entry rejects an outside or narrower-than-16 ROI.
         * Validate the captured start rectangle before launching any helper. */
        native_procedure->bytes ();
        native_outcome->reset ();
        return true;
      }) : FilterScheduler::Gate (),
      native_procedure || native_kernel_region ? FilterScheduler::Gate ([&] {
        refresh_context_selection ();
        return native_context.before_import (GIMP_DRAWABLE (owner), native_outcome->disposition (), import_budget);
      }) : FilterScheduler::Gate ());
    if (scheduler.state () == FilterScheduler::State::closed) return false;
    if (scheduler.state () != FilterScheduler::State::importing) staged.reset ();
    if (scheduler.state () == FilterScheduler::State::clean || scheduler.state () == FilterScheduler::State::failed)
      native_context.reset ();
    if (previous != scheduler.state ()) g_signal_emit_by_name (owner, "filter-state-changed");
    return again || graph_recheck;
  }
  GimpFilterLayer *owner;
  std::string procedure;
  BytesRef raw, opaque_arguments;
  std::shared_ptr<const FilterArguments> args;
  std::uint64_t definition_revision = 0;
  FilterScheduler scheduler;
  FilterProgress::Snapshot progress;
  std::uint64_t progress_generation = 0;
  FilterScheduler::State progress_phase = FilterScheduler::State::clean;
  gint64 progress_next_update = 0;
  bool dispatching = false;
  std::shared_ptr<FilterProcedureRequest> native_procedure;
  std::shared_ptr<FilterProcessOptions> native_process_options;
  std::shared_ptr<FilterProcedureResult> native_outcome;
  std::shared_ptr<FilterSelectionRegion> native_kernel_region;
  std::function<void ()> native_kernel_validate;
  bool native_projection_input = false;
  FilterOwnerContext native_context;
  std::string preparing_process_directory;
  FairDispatcher::Ticket pending;
  WeakRef<GObject> stack, context_selection;
  ObjectRef<GObject> staged;
  std::vector<Connection> own_connections, dependencies, graph_connections;
  std::vector<FilterDependency> graph_filters;
  std::vector<CloneDependency> graph_clones;
  std::vector<WeakRef<GObject>> graph_nodes;
  std::size_t graph_node_cursor = 0, graph_fish_cursor = 0;
  bool graph_valid = false, graph_recheck = false;
  Connection image_connection, profile_connection, config_connection, selection_connection;
  std::vector<WeakRef<GObject>> lower_objects;
  std::uint64_t connections_revision = 0;
  bool topology_dirty = false;
  gint64 maximum_quantum_us = 0, maximum_graph_us = 0, maximum_read_us = 0;
  std::size_t read_budget = 1024, import_budget = FilterScheduler::pixel_budget;
};
void topology_changed (GimpContainer *container, GimpObject *, gpointer data)
{ visit (data, [&] (FilterImpl& impl) {
    if (container != impl.current_stack ()) impl.invalidate ();
    impl.structure_changed ();
  }); }
void reordered (GimpContainer *container, GimpObject *, gint, gint, gpointer data)
{ topology_changed (container, nullptr, data); }
void dependency_update (GimpDrawable *source, gint, gint, gint, gint, gpointer data)
{ visit (data, [&] (FilterImpl& impl) { if (impl.below (GIMP_ITEM (source))) impl.dependency_dirty (); }); }
void dependency_active (GimpFilter *source, gpointer data)
{ visit (data, [&] (FilterImpl& impl) { if (impl.below (GIMP_ITEM (source))) impl.dependency_dirty (); }); }
void dependency_status (GimpFilterLayer *source, gpointer data)
{ visit (data, [&] (FilterImpl& impl) {
    if (impl.below (GIMP_ITEM (source)))
      {
        const auto state = gimp_filter_layer_get_state (source);
        if (state == GIMP_FILTER_LAYER_WAITING || state == GIMP_FILTER_LAYER_CANCELLING) impl.dependency_dirty ();
        else impl.schedule ();
      }
  }); }
void graph_status (GimpFilterLayer *source, gpointer data)
{ visit (data, [&] (FilterImpl& impl) {
    const auto state = gimp_filter_layer_get_state (source);
    if (state == GIMP_FILTER_LAYER_WAITING || state == GIMP_FILTER_LAYER_CANCELLING) impl.dependency_dirty ();
    else impl.schedule ();
  }); }
void graph_update (GimpDrawable *, gint, gint, gint, gint, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.dependency_dirty (); }); }
void owner_ancestry (GimpViewable *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.structure_changed (); }); }
void owner_removed (GimpItem *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.invalidate (); }); }
void owner_size (GimpViewable *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.configure (); }); }
void filter_budget_changed (GObject *, GParamSpec *, gpointer data)
{ visit (data, [] (FilterImpl& impl) {
    if (impl.scheduler.state () != FilterScheduler::State::clean) impl.invalidate ();
  }); }
void owner_offset (GObject *, GParamSpec *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.invalidate (); }); }
void owner_active (GimpFilter *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.invalidate (); }); }
void owner_image_changed (GObject *, GParamSpec *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.watch_image (); impl.structure_changed (); impl.invalidate (); }); }
void owner_format_changed (GimpDrawable *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.configure (); }); }
void image_profile_changed (GObject *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.invalidate (); }); }
void selection_invalidated (GimpImage *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { impl.native_context.selection_changed (); }); }
void image_disconnected (GimpObject *, gpointer data)
{ visit (data, [] (FilterImpl& impl) { gimp_painter_binding_close (G_OBJECT (impl.owner), nullptr); }); }
struct FilterUndoImpl
{
  ObjectRef<GObject> buffer;
  bool cache_complete = false;
  void close () noexcept { raw.reset (); opaque_arguments.reset (); args.reset (); buffer.reset (); }
  std::string procedure;
  BytesRef raw, opaque_arguments;
  std::shared_ptr<const FilterArguments> args;
};
struct FilterUndoSlot : SlotSpec<GimpFilterLayerUndo, FilterUndoImpl> {};
void undo_constructed (GObject *object)
{
  G_OBJECT_CLASS (gimp_filter_layer_undo_parent_class)->constructed (object);
  auto *undo = reinterpret_cast<GimpFilterLayerUndo *> (object);
  if (!undo->binding_failed)
    undo->binding_failed = !boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
      auto& store = BindingStore::require (object);
      store.initialize<FilterUndoSlot> ([&] (FilterUndoImpl& snapshot) {
        BindingStore::require (G_OBJECT (GIMP_ITEM_UNDO (object)->item)).read<FilterSlot> ([&] (const FilterImpl& impl) {
          snapshot.procedure = impl.procedure;
          snapshot.raw = BytesRef (impl.raw ? g_bytes_ref (impl.raw.get ()) : nullptr);
          snapshot.args = impl.args;
          snapshot.opaque_arguments = BytesRef (impl.opaque_arguments ? g_bytes_ref (impl.opaque_arguments.get ()) : nullptr);
          GeglBuffer *buffer = gimp_drawable_get_buffer (GIMP_DRAWABLE (impl.owner));
          if (!buffer) throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter has no committed cache");
          snapshot.buffer = ObjectRef<GObject>::adopt (G_OBJECT (gegl_buffer_dup (buffer)));
          snapshot.cache_complete = impl.scheduler.snapshot ().cache_complete;
        });
      });
      store.activate (); return TRUE;
    });
}
void undo_dispose (GObject *object)
{
  gimp_painter_binding_close (object, nullptr);
  G_OBJECT_CLASS (gimp_filter_layer_undo_parent_class)->dispose (object);
}
void undo_pop (GimpUndo *undo, GimpUndoMode mode, GimpUndoAccumulator *accum)
{
  GIMP_UNDO_CLASS (gimp_filter_layer_undo_parent_class)->pop (undo, mode, accum);
  boundary_void (nullptr, [&] {
    BindingStore::require (G_OBJECT (undo)).with<FilterUndoSlot> ([&] (FilterUndoImpl& snapshot) {
      BindingStore::require (G_OBJECT (GIMP_ITEM_UNDO (undo)->item)).with<FilterSlot> ([&] (FilterImpl& impl) {
        auto current = ObjectRef<GObject>::adopt (G_OBJECT (gegl_buffer_dup (gimp_drawable_get_buffer (GIMP_DRAWABLE (impl.owner)))));
        impl.definition_installed ();
        auto restored = std::move (snapshot.buffer);
        const bool complete = snapshot.cache_complete;
        snapshot.buffer = std::move (current);
        snapshot.cache_complete = impl.scheduler.snapshot ().cache_complete;
        impl.procedure.swap (snapshot.procedure);
        impl.raw.swap (snapshot.raw);
        impl.args.swap (snapshot.args);
        impl.opaque_arguments.swap (snapshot.opaque_arguments);
        impl.publish_definition (GEGL_BUFFER (restored.get ()), complete);
      });
    });
  });
}
gint64 undo_memsize (GimpObject *object, gint64 *gui)
{
  const auto retained = boundary<gint64> (nullptr, 0, [&] {
    auto *store = BindingStore::find (G_OBJECT (object));
    if (!store || store->state () != BindingStore::State::active) return gint64 (0);
    return store->read<FilterUndoSlot> ([] (const FilterUndoImpl& snapshot) {
      const std::uint64_t limit = G_MAXINT64;
      std::uint64_t size = sizeof (snapshot);
      const auto add = [&] (std::uint64_t bytes) { size = bytes > limit - size ? limit : size + bytes; };
      add (snapshot.procedure.capacity ());
      if (snapshot.raw) add (g_bytes_get_size (snapshot.raw.get ()));
      if (snapshot.opaque_arguments) add (g_bytes_get_size (snapshot.opaque_arguments.get ()));
      if (snapshot.buffer)
        {
          auto *buffer = GEGL_BUFFER (snapshot.buffer.get ());
          std::uint64_t area = gegl_buffer_get_width (buffer);
          const std::uint64_t height = gegl_buffer_get_height (buffer), bpp = babl_format_get_bytes_per_pixel (gegl_buffer_get_format (buffer));
          area = height && area > limit / height ? limit : area * height;
          add (bpp && area > limit / bpp ? limit : area * bpp);
        }
      return gint64 (size);
    });
  });
  const auto base = GIMP_OBJECT_CLASS (gimp_filter_layer_undo_parent_class)->get_memsize (object, gui);
  return retained > G_MAXINT64 - base ? G_MAXINT64 : retained + base;
}
void constructed (GObject *object)
{
  if (G_OBJECT_CLASS (gimp_filter_layer_parent_class)->constructed)
    G_OBJECT_CLASS (gimp_filter_layer_parent_class)->constructed (object);
  auto *layer = GIMP_FILTER_LAYER (object);
  if (!layer->binding_failed)
    layer->binding_failed = !boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
      auto& store = BindingStore::require (object);
      store.initialize<FilterSlot> ([] (FilterImpl&) {});
      store.activate ();
      return TRUE;
    });
  if (layer->binding_failed) gimp_painter_binding_close (object, nullptr);
}
void get_property (GObject *object, guint property_id, GValue *value, GParamSpec *spec)
{
  auto *layer = GIMP_FILTER_LAYER (object);
  switch (property_id)
    {
    case 1: g_value_set_boolean (value, layer->binding_failed); break;
    case 2:
    case 3:
    case 4:
    case 5:
      property_boundary (object, spec, "get", [&] {
        BindingStore::require (object).read<FilterSlot> ([&] (const FilterImpl& impl) {
          if (property_id == 2)
            g_value_take_string (value, g_strdup (impl.procedure.c_str ()));
          else if (property_id == 3)
            g_value_take_boxed (value, impl.args ? impl.args->copy_values () : nullptr);
          else if (property_id == 4)
            g_value_take_boxed (value, impl.raw ? g_bytes_ref (impl.raw.get ()) : nullptr);
          else
            g_value_take_boxed (value, impl.opaque_arguments ? g_bytes_ref (impl.opaque_arguments.get ()) : nullptr);
        });
      });
      break;
    default: G_OBJECT_WARN_INVALID_PROPERTY_ID (object, property_id, spec);
    }
}
void dispose (GObject *object)
{ gimp_painter_binding_close (object, nullptr); G_OBJECT_CLASS (gimp_filter_layer_parent_class)->dispose (object); }
GimpItem *duplicate (GimpItem *item, GType type)
{
  return boundary<GimpItem *> (nullptr, nullptr, [&] {
    GimpItem *copy = GIMP_ITEM_CLASS (gimp_filter_layer_parent_class)->duplicate (item, type);
    auto partial = ObjectRef<GObject>::adopt (G_OBJECT (copy));
    if (GIMP_IS_FILTER_LAYER (copy))
      BindingStore::require (G_OBJECT (item)).read<FilterSlot> ([&] (const FilterImpl& impl) {
        BindingStore::require (G_OBJECT (copy)).with<FilterSlot> ([&] (FilterImpl& duplicate_impl) {
          std::string name = impl.procedure;
          BytesRef raw (impl.raw ? g_bytes_ref (impl.raw.get ()) : nullptr);
          BytesRef opaque (impl.opaque_arguments ? g_bytes_ref (impl.opaque_arguments.get ()) : nullptr);
          auto arguments = impl.args;
          const auto token = BindingStore::require (G_OBJECT (copy)).generation ();
          const auto cache = impl.scheduler.snapshot ();
          duplicate_impl.definition_installed ();
          const auto revision = duplicate_impl.definition_revision;
          /* Publish all fields before retired payload deleters can reenter. */
          duplicate_impl.procedure.swap (name);
          duplicate_impl.raw.swap (raw);
          duplicate_impl.opaque_arguments.swap (opaque);
          duplicate_impl.args.swap (arguments);
          duplicate_impl.attach ();
          if (!duplicate_impl.definition_current (token, revision))
            throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter duplicate changed during attachment");
          duplicate_impl.configure ();
          if (!duplicate_impl.definition_current (token, revision))
            throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter duplicate changed during configuration");
          duplicate_impl.scheduler.restore_cache (cache);
        });
      });
    return GIMP_ITEM (partial.release ());
  });
}
/* The old Filter flip invalidated its derived result without transforming
 * the layer geometry or cached pixels. Other transforms retain native parent
 * behavior; an image-wide flip still transforms the lower ordinary layers. */
void flip (GimpItem *item, GimpContext *, GimpOrientationType, gdouble, gboolean)
{
  boundary_void (nullptr, [&] {
    BindingStore::require (G_OBJECT (item)).with<FilterSlot> ([] (FilterImpl& impl) {
      impl.invalidate ();
    });
  });
}
/* Legacy geometry wrappers invalidate after delegation even for no-op
 * geometry; property notifications alone cannot preserve that scheduling duty. */
void translate (GimpItem *item, gdouble offset_x, gdouble offset_y, gboolean push_undo)
{
  boundary_void (nullptr, [&] {
    auto owner_pin = ObjectRef<GObject>::retain (G_OBJECT (item));
    auto image_pin = ObjectRef<GObject>::retain (G_OBJECT (gimp_item_get_image (item)));
    auto *store = BindingStore::find (owner_pin.get ());
    if (!store) return;
    const auto token = store->generation ();
    if (!store->accepts (token)) return;
    GIMP_ITEM_CLASS (gimp_filter_layer_parent_class)->translate (
      item, offset_x, offset_y, push_undo);
    store = BindingStore::find (owner_pin.get ());
    if (store && store->accepts (token))
      store->with<FilterSlot> ([] (FilterImpl& impl) { impl.invalidate (); });
  });
}
void scale (GimpItem *item, gint new_width, gint new_height,
            gint new_offset_x, gint new_offset_y,
            GimpInterpolationType interpolation_type, GimpProgress *progress)
{
  boundary_void (nullptr, [&] {
    auto owner_pin = ObjectRef<GObject>::retain (G_OBJECT (item));
    auto image_pin = ObjectRef<GObject>::retain (G_OBJECT (gimp_item_get_image (item)));
    auto *store = BindingStore::find (owner_pin.get ());
    if (!store) return;
    const auto token = store->generation ();
    if (!store->accepts (token)) return;
    GIMP_ITEM_CLASS (gimp_filter_layer_parent_class)->scale (
      item, new_width, new_height, new_offset_x, new_offset_y,
      interpolation_type, progress);
    store = BindingStore::find (owner_pin.get ());
    if (store && store->accepts (token))
      store->with<FilterSlot> ([] (FilterImpl& impl) { impl.invalidate (); });
  });
}
void resize (GimpItem *item, GimpContext *context, GimpFillType fill_type,
             gint new_width, gint new_height, gint offset_x, gint offset_y)
{
  boundary_void (nullptr, [&] {
    auto owner_pin = ObjectRef<GObject>::retain (G_OBJECT (item));
    auto image_pin = ObjectRef<GObject>::retain (G_OBJECT (gimp_item_get_image (item)));
    auto *store = BindingStore::find (owner_pin.get ());
    if (!store) return;
    const auto token = store->generation ();
    if (!store->accepts (token)) return;
    GIMP_ITEM_CLASS (gimp_filter_layer_parent_class)->resize (
      item, context, fill_type, new_width, new_height, offset_x, offset_y);
    store = BindingStore::find (owner_pin.get ());
    if (store && store->accepts (token))
      store->with<FilterSlot> ([] (FilterImpl& impl) { impl.invalidate (); });
  });
}
/* Unlike flip, legacy rotate performs the native transform before invalidating
 * its derived cache. Same-extent rotations emit no size/offset/format change. */
void rotate (GimpItem *item, GimpContext *context, GimpRotationType rotate_type,
             gdouble center_x, gdouble center_y, gboolean clip_result)
{
  boundary_void (nullptr, [&] {
    auto owner_pin = ObjectRef<GObject>::retain (G_OBJECT (item));
    auto image_pin = ObjectRef<GObject>::retain (G_OBJECT (gimp_item_get_image (item)));
    auto *store = BindingStore::find (owner_pin.get ());
    if (!store) return;
    const auto token = store->generation ();
    if (!store->accepts (token)) return;
    /* No Impl borrow survives the native transform's synchronous callbacks. */
    GIMP_ITEM_CLASS (gimp_filter_layer_parent_class)->rotate (
      item, context, rotate_type, center_x, center_y, clip_result);
    store = BindingStore::find (owner_pin.get ());
    if (store && store->accepts (token))
      store->with<FilterSlot> ([] (FilterImpl& impl) { impl.invalidate (); });
  });
}
/* The legacy matrix transform also delegates before resetting derived output;
 * unchanged extents do not imply that native cache pixels stayed unchanged. */
void transform (GimpItem *item, GimpContext *context, const GimpMatrix3 *matrix,
                GimpTransformDirection direction,
                GimpInterpolationType interpolation_type,
                GimpTransformResize clip_result, GimpProgress *progress)
{
  boundary_void (nullptr, [&] {
    auto owner_pin = ObjectRef<GObject>::retain (G_OBJECT (item));
    auto image_pin = ObjectRef<GObject>::retain (G_OBJECT (gimp_item_get_image (item)));
    auto *store = BindingStore::find (owner_pin.get ());
    if (!store) return;
    const auto token = store->generation ();
    if (!store->accepts (token)) return;
    GIMP_ITEM_CLASS (gimp_filter_layer_parent_class)->transform (
      item, context, matrix, direction, interpolation_type, clip_result, progress);
    store = BindingStore::find (owner_pin.get ());
    if (store && store->accepts (token))
      store->with<FilterSlot> ([] (FilterImpl& impl) { impl.invalidate (); });
  });
}
gboolean content_locked (GimpItem *item, GimpItem **locked) { if (locked) *locked = item; return TRUE; }
gdouble opacity_at (GimpPickable *, gint, gint) { return 0.0; }
} // namespace
static void gimp_filter_layer_undo_class_init (GimpFilterLayerUndoClass *klass)
{
  G_OBJECT_CLASS (klass)->constructed = undo_constructed;
  G_OBJECT_CLASS (klass)->dispose = undo_dispose;
  GIMP_UNDO_CLASS (klass)->pop = undo_pop;
  GIMP_OBJECT_CLASS (klass)->get_memsize = undo_memsize;
}
static void gimp_filter_layer_undo_init (GimpFilterLayerUndo *undo)
{
  undo->binding_failed = !boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
    BindingStore::ensure (G_OBJECT (undo)).emplace<FilterUndoSlot> (); return TRUE;
  });
}
static void gimp_filter_layer_class_init (GimpFilterLayerClass *klass)
{
  auto *object = G_OBJECT_CLASS (klass);
  object->constructed = constructed;
  object->dispose = dispose;
  object->get_property = get_property;
  g_object_class_install_property (object, 1,
    g_param_spec_boolean ("binding-failed", "Binding failed", "C++ state construction failed; object is inert", FALSE, G_PARAM_READABLE));
  g_object_class_install_property (object, 2,
    g_param_spec_string ("filter-procedure", "Filter procedure", "Saved procedure name", nullptr, G_PARAM_READABLE));
  g_object_class_install_property (object, 3,
    g_param_spec_boxed ("filter-arguments", "Filter arguments", "Resolved copy of saved execution arguments", GIMP_TYPE_VALUE_ARRAY, G_PARAM_READABLE));
  g_object_class_install_property (object, 4,
    g_param_spec_boxed ("filter-original-definition", "Original definition", "Unmodified original serialized definition", G_TYPE_BYTES, G_PARAM_READABLE));
  g_object_class_install_property (object, 5,
    g_param_spec_boxed ("filter-opaque-arguments", "Opaque arguments", "Unavailable converted argument model, retained uninterpreted",
                        G_TYPE_BYTES, G_PARAM_READABLE));
  GIMP_ITEM_CLASS (klass)->duplicate = duplicate;
  GIMP_ITEM_CLASS (klass)->translate = translate;
  GIMP_ITEM_CLASS (klass)->scale = scale;
  GIMP_ITEM_CLASS (klass)->resize = resize;
  GIMP_ITEM_CLASS (klass)->flip = flip;
  GIMP_ITEM_CLASS (klass)->rotate = rotate;
  GIMP_ITEM_CLASS (klass)->transform = transform;
  GIMP_ITEM_CLASS (klass)->is_content_locked = content_locked;
  GIMP_VIEWABLE_CLASS (klass)->default_icon_name = "gimp-gegl";
  GIMP_VIEWABLE_CLASS (klass)->default_name = "Filter Layer";
  g_signal_new ("filter-progress-changed", G_TYPE_FROM_CLASS (klass), G_SIGNAL_RUN_LAST,
                0, nullptr, nullptr, nullptr, G_TYPE_NONE, 0);
  g_signal_new ("filter-state-changed", G_TYPE_FROM_CLASS (klass), G_SIGNAL_RUN_LAST,
                0, nullptr, nullptr, nullptr, G_TYPE_NONE, 0);
}
static void gimp_filter_layer_init (GimpFilterLayer *layer)
{
  layer->binding_failed = !boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
    BindingStore::ensure (G_OBJECT (layer)).emplace<FilterSlot> (layer); return TRUE;
  });
}
static void gimp_filter_layer_pickable_init (GimpPickableInterface *iface) { iface->get_opacity_at = opacity_at; }
namespace {
template<class Result, class F>
Result filter_progress_call (GimpProgress *value, Result fallback, F function) noexcept
{
  return boundary<Result> (nullptr, fallback, [&] {
    return BindingStore::require (G_OBJECT (value)).with<FilterSlot> (function);
  });
}
template<class F> void filter_progress_call (GimpProgress *value, F function) noexcept
{
  boundary_void (nullptr, [&] {
    BindingStore::require (G_OBJECT (value)).with<FilterSlot> (function);
  });
}
GimpProgress *filter_progress_start (GimpProgress *value, gboolean cancellable, const gchar *message) noexcept
{
  return filter_progress_call<GimpProgress *> (value, nullptr, [=] (FilterImpl& impl) -> GimpProgress * {
    if (impl.progress_current ()) return nullptr;
    const auto token = impl.scheduler.generation ();
    impl.progress = {};
    impl.progress_generation = token;
    impl.progress.active = true;
    impl.progress.cancellable = cancellable;
    FilterProgress::copy_text (impl.progress.text, message);
    impl.progress_changed ();
    return impl.progress_current () && impl.progress_generation == token ? value : nullptr;
  });
}
void filter_progress_end (GimpProgress *value) noexcept
{
  filter_progress_call (value, [] (FilterImpl& impl) {
    if (!impl.progress_current ()) return;
    impl.progress.active = impl.progress.cancellable = false;
    impl.progress_changed ();
  });
}
gboolean filter_progress_active (GimpProgress *value) noexcept
{
  return boundary<gboolean> (nullptr, FALSE, [&] {
    return BindingStore::require (G_OBJECT (value)).read<FilterSlot> ([] (const FilterImpl& impl) -> gboolean {
      return impl.progress_current ();
    });
  });
}
void filter_progress_text (GimpProgress *value, const gchar *text) noexcept
{
  filter_progress_call (value, [=] (FilterImpl& impl) {
    if (!impl.progress_current ()) return;
    FilterProgress::copy_text (impl.progress.text, text);
    impl.progress_changed ();
  });
}
void filter_progress_value (GimpProgress *value, gdouble fraction) noexcept
{
  if (!std::isfinite (fraction)) return;
  filter_progress_call (value, [=] (FilterImpl& impl) {
    if (!impl.progress_current ()) return;
    impl.progress.value = std::max (0.0, std::min (1.0, fraction));
    impl.progress_changed ();
  });
}
gdouble filter_progress_get_value (GimpProgress *value) noexcept
{
  return boundary<gdouble> (nullptr, 0.0, [&] {
    return BindingStore::require (G_OBJECT (value)).read<FilterSlot> ([] (const FilterImpl& impl) {
      return impl.progress_current () ? impl.progress.value : 0.0;
    });
  });
}
void filter_progress_pulse (GimpProgress *value) noexcept
{
  filter_progress_call (value, [] (FilterImpl& impl) {
    if (!impl.progress_current ()) return;
    if (impl.progress.pulses != G_MAXUINT64) ++impl.progress.pulses;
    impl.progress_changed ();
  });
}
gboolean filter_progress_message (GimpProgress *value, Gimp *, GimpMessageSeverity severity,
                                   const gchar *domain, const gchar *message) noexcept
{
  return filter_progress_call<gboolean> (value, FALSE, [=] (FilterImpl& impl) -> gboolean {
    if (!impl.progress_current () || severity < 0 || severity > GIMP_MESSAGE_BUG_CRITICAL) return FALSE;
    impl.progress.message_severity = severity;
    FilterProgress::copy_text (impl.progress.message_domain, domain);
    FilterProgress::copy_text (impl.progress.message_text, message);
    if (impl.progress.message_revision != G_MAXUINT64) ++impl.progress.message_revision;
    impl.progress_changed ();
    return TRUE;
  });
}
void filter_progress_cancel (GimpProgress *value) noexcept
{
  filter_progress_call (value, [] (FilterImpl& impl) {
    if (impl.progress_current () && impl.progress.cancellable)
      gimp_filter_layer_cancel_generation (impl.owner, impl.progress_generation);
  });
}
}
static void gimp_filter_layer_progress_init (GimpProgressInterface *iface)
{
  iface->start = filter_progress_start;
  iface->end = filter_progress_end;
  iface->is_active = filter_progress_active;
  iface->set_text = filter_progress_text;
  iface->set_value = filter_progress_value;
  iface->get_value = filter_progress_get_value;
  iface->pulse = filter_progress_pulse;
  iface->message = filter_progress_message;
  iface->cancel = filter_progress_cancel;
}
gboolean gimp_filter_layer_get_progress (GimpFilterLayer *layer, GimpFilterLayerProgress *result)
{
  if (!result) return FALSE;
  *result = {};
  return boundary<gboolean> (nullptr, FALSE, [&] {
    return BindingStore::require (G_OBJECT (layer)).read<FilterSlot> ([&] (const FilterImpl& impl) -> gboolean {
      result->generation = impl.progress_generation;
      result->active = impl.progress_current ();
      result->cancellable = result->active && impl.progress.cancellable;
      result->value = impl.progress.value;
      result->pulses = impl.progress.pulses;
      result->message_revision = impl.progress.message_revision;
      result->message_severity = impl.progress.message_severity;
      std::memcpy (result->text, impl.progress.text.data (), sizeof (result->text));
      std::memcpy (result->message_text, impl.progress.message_text.data (), sizeof (result->message_text));
      std::memcpy (result->message_domain, impl.progress.message_domain.data (), sizeof (result->message_domain));
      return TRUE;
    });
  });
}
GimpLayer *gimp_filter_layer_new (GimpImage *image, gint width, gint height, const gchar *name,
                                 gdouble opacity, GimpLayerMode mode)
{
  g_return_val_if_fail (GIMP_IS_IMAGE (image), nullptr);
  return boundary<GimpLayer *> (nullptr, nullptr, [&] {
    if (width <= 0) width = gimp_image_get_width (image);
    if (height <= 0) height = gimp_image_get_height (image);
    auto *layer = GIMP_FILTER_LAYER (gimp_drawable_new (GIMP_TYPE_FILTER_LAYER, image, name, 0, 0, width, height,
                                                       gimp_image_get_layer_format (image, TRUE)));
    if (!layer) return static_cast<GimpLayer *> (nullptr);
    auto partial = ObjectRef<GObject>::adopt (G_OBJECT (layer));
    if (layer->binding_failed) return static_cast<GimpLayer *> (nullptr);
    gimp_layer_set_opacity (GIMP_LAYER (layer), opacity, FALSE);
    gimp_layer_set_mode (GIMP_LAYER (layer), mode, FALSE);
    BindingStore::require (G_OBJECT (layer)).with<FilterSlot> ([] (FilterImpl& impl) { impl.attach (); });
    return GIMP_LAYER (partial.release ());
  });
}
static gboolean set_definition (GimpFilterLayer *layer, const gchar *procedure,
                                GBytes *raw, const GimpValueArray *args, bool push_undo, GError **error,
                                const std::shared_ptr<const FilterArguments> *imported = nullptr,
                                GBytes *opaque_arguments = nullptr,
                                const std::shared_ptr<const FilterArguments> *expected_arguments = nullptr,
                                guint64 expected_revision = 0,
                                gboolean (*check) (gpointer) = nullptr,
                                gpointer check_data = nullptr)
{
  return boundary<gboolean> (error, FALSE, [&] () -> gboolean {
    if (!GIMP_IS_FILTER_LAYER (layer)) throw Error (GIMP_PAINTER_ERROR_WRONG_TYPE, "Expected FilterLayer");
    auto owner_pin = ObjectRef<GObject>::retain (G_OBJECT (layer));
    auto image_pin = ObjectRef<GObject>::retain (G_OBJECT (gimp_item_get_image (GIMP_ITEM (layer))));
    std::string name = procedure ? procedure : "";
    BytesRef bytes (raw ? g_bytes_ref (raw) : nullptr);
    BytesRef opaque (opaque_arguments ? g_bytes_ref (opaque_arguments) : nullptr);
    std::shared_ptr<const FilterArguments> arguments = imported ? *imported :
                                                       args ? std::make_shared<FilterArguments> (args) : nullptr;
    BindingStore::require (G_OBJECT (layer)).with<FilterSlot> ([&] (FilterImpl& impl) {
      if (expected_arguments && (impl.args != *expected_arguments || impl.definition_revision != expected_revision))
        throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter definition changed; reload its saved parameters");
      const auto binding_token = BindingStore::require (G_OBJECT (layer)).generation ();
      const auto revision = impl.definition_revision;
      ObjectRef<GObject> pushed_undo;
      if (impl.definition_revision == std::numeric_limits<std::uint64_t>::max ())
        throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter definition revision exhausted");
      const auto current = [&] {
        return impl.definition_current (binding_token, revision) &&
          (!expected_arguments || (impl.args == *expected_arguments && impl.definition_revision == expected_revision));
      };
      const auto discard_own_undo = [&] {
        /* A failed private allocation/guard can follow Undo creation. Remove
         * only our own still-top item for an otherwise unchanged definition.
         * Dirty notifications and expired redo/old history remain the existing
         * separate image-history atomicity limitation. Never undo reentrant work. */
        if (!current () || !pushed_undo || !image_pin) return;
        auto *image = GIMP_IMAGE (image_pin.get ());
        auto *stack = gimp_image_get_undo_stack (image);
        auto *undo = GIMP_UNDO (pushed_undo.get ());
        if (gimp_undo_stack_peek (stack) != undo) return;
        auto stack_pin = ObjectRef<GObject>::retain (G_OBJECT (stack));
        if (gimp_container_remove (stack->undos, GIMP_OBJECT (undo)))
          {
            gimp_undo_free (undo, GIMP_UNDO_MODE_UNDO);
            gimp_image_undo_event (image, GIMP_UNDO_EVENT_UNDO_EXPIRED, undo);
            g_object_unref (undo); // Original stack-owned reference.
          }
      };
      FilterImpl::PreparedConfiguration prepared;
      try
        {
          if (push_undo && gimp_item_is_attached (GIMP_ITEM (layer)))
            {
              auto *undo = gimp_image_undo_push (gimp_item_get_image (GIMP_ITEM (layer)),
                                                gimp_filter_layer_undo_get_type (), GIMP_UNDO_FILTER_LAYER_DEFINITION,
                                                "Filter layer definition", GimpDirtyMask (GIMP_DIRTY_ITEM | GIMP_DIRTY_ITEM_META | GIMP_DIRTY_DRAWABLE),
                                                "item", layer, nullptr);
              pushed_undo = ObjectRef<GObject>::retain (G_OBJECT (undo));
              if (undo && reinterpret_cast<GimpFilterLayerUndo *> (undo)->binding_failed)
                throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter definition Undo construction failed");
            }
          /* Undo signals and the caller's guard may change dimensions, close
           * the target, or dispatch the old clean request in a nested loop. */
          if (!current ())
            throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter definition changed during Undo creation");
          impl.attach ();
          const bool precondition = !check || check (check_data);
          if (!precondition || !current ())
            throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter definition or editor metadata changed during Undo creation");
          /* Capture geometry and enqueue only after the final callback. No
           * callback/main-loop gap may consume this wakeup before publication. */
          prepared = impl.prepare_configuration (name, arguments);
          impl.schedule ();
        }
      catch (...)
        {
          discard_own_undo ();
          throw;
        }
      impl.definition_installed ();
      const auto installed_revision = impl.definition_revision;
      /* Byte payloads can have caller-supplied destruction callbacks. Keep
       * the retired definition alive until the whole replacement is published. */
      impl.procedure.swap (name); impl.raw.swap (bytes);
      impl.args.swap (arguments); impl.opaque_arguments.swap (opaque);
      if (!impl.definition_current (binding_token, installed_revision) ||
          !impl.publish_definition (nullptr, true, &prepared))
        throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter definition target changed during notification");
    });
    return TRUE;
  });
}
gboolean gimp_filter_layer_set_definition (GimpFilterLayer *layer, const gchar *procedure,
                                          GBytes *raw, const GimpValueArray *args, GError **error)
{ return set_definition (layer, procedure, raw, args, false, error); }
gboolean gimp_filter_layer_edit_definition (GimpFilterLayer *layer, const gchar *procedure,
                                           GBytes *raw, const GimpValueArray *args, GError **error)
{ return set_definition (layer, procedure, raw, args, true, error); }
namespace {
/* These three fixed legacy scalar layouts are not a general PDB binder.
 * Never copy/reference the caller's ignored image/drawable values. */
template<guint count, bool double_tail = false>
ArgsRef prepare_legacy_scalar_route (const GArray *arguments, const std::string& label)
{
  static_assert (count == 4 || count == 7, "Only reviewed legacy layouts are admitted");
  static_assert (!double_tail || count == 7, "Only Retinex has a double tail");
  std::array<Value, count - 2> staged;
  const bool supplied = arguments != nullptr;
  if (supplied)
    {
      if (g_array_get_element_size (const_cast<GArray *> (arguments)) != sizeof (GValue) ||
          arguments->len != count || !arguments->data)
        throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,
                     (label + " preparation requires exactly " + std::to_string (count) + " GValue arguments").c_str ());
      const auto *source = reinterpret_cast<const GValue *> (arguments->data);
      /* Exact scalar getters/setters cannot invoke a caller-defined boxed copy
       * or transform. Finish staging ALL consumed slots before the first
       * g_value_transform: its registered callback can reenter and change the
       * definition, provider, name or the caller's original argument values. */
      for (std::size_t i = 0; i < staged.size (); ++i)
        {
          const auto slot = i == 0 ? 0 : i + 2;
          const auto *value = &source[slot];
          const auto type = G_VALUE_TYPE (value);
          if (type != G_TYPE_INT && type != G_TYPE_BOOLEAN &&
              type != G_TYPE_FLOAT && type != G_TYPE_DOUBLE &&
              !(slot == 0 && type == GIMP_TYPE_RUN_MODE))
            throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,
                         (label + " preparation requires initialized supported scalar arguments").c_str ());
          if (type == G_TYPE_FLOAT || type == G_TYPE_DOUBLE)
            {
              const double number = type == G_TYPE_FLOAT ? g_value_get_float (value) : g_value_get_double (value);
              if (!std::isfinite (number) ||
                  (!(double_tail && slot == count - 1) &&
                   (number < double (std::numeric_limits<gint>::min ()) ||
                    number > double (std::numeric_limits<gint>::max ()))))
                throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,
                             (label + " preparation requires finite scalars within the destination range").c_str ());
            }
          staged[i] = Value (type);
          if (type == G_TYPE_INT) g_value_set_int (staged[i].get (), g_value_get_int (value));
          else if (type == G_TYPE_BOOLEAN) g_value_set_boolean (staged[i].get (), g_value_get_boolean (value));
          else if (type == G_TYPE_FLOAT) g_value_set_float (staged[i].get (), g_value_get_float (value));
          else if (type == G_TYPE_DOUBLE) g_value_set_double (staged[i].get (), g_value_get_double (value));
          else g_value_set_enum (staged[i].get (), g_value_get_enum (value));
        }
    }
  ArgsRef result (gimp_value_array_new (count));
  std::size_t next = 0;
  for (guint slot = 0; slot < count; ++slot)
    {
      const GType target = double_tail && slot == count - 1 ? G_TYPE_DOUBLE : G_TYPE_INT;
      Value value (target); // Typed zero, never a modern/legacy pspec default.
      if (supplied && slot != 1 && slot != 2)
        {
          if (!g_value_transform (staged[next++].get (), value.get ()) ||
              G_VALUE_TYPE (value.get ()) != target)
            throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,
                         (label + " scalar transformation did not produce its native destination type").c_str ());
        }
      gimp_value_array_append (result.get (), value.get ());
    }
  return result;
}

/* All pointers below are leased by the synchronous C entry. No Impl borrow or
 * caller-array address survives a transformation or provider check. */
struct LegacyScalarRouteGuard
{
  GimpFilterLayer *layer;
  GimpImage *image;
  Gimp *gimp;
  const FilterEditorSchema *schema;
  const std::shared_ptr<const FilterArguments> *arguments;
  guint64 binding_token, revision;

  bool owner_current () const
  {
    auto *store = BindingStore::find (G_OBJECT (layer));
    if (!store || !store->accepts (binding_token) ||
        gimp_item_get_image (GIMP_ITEM (layer)) != image || image->gimp != gimp)
      return false;
    return store->with<FilterSlot> ([&] (FilterImpl& impl) {
      return impl.args == *arguments && impl.definition_current (binding_token, revision);
    });
  }
  static gboolean current (gpointer data) noexcept
  {
    return boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
      const auto& guard = *static_cast<const LegacyScalarRouteGuard *> (data);
      return guard.owner_current () && guard.schema->current (guard.gimp) && guard.owner_current ();
    });
  }
};
}
gboolean gimp_filter_layer_set_legacy_procedure (GimpFilterLayer *layer, const gchar *procedure,
                                               const GArray *arguments, GError **error)
{
  return boundary<gboolean> (error, FALSE, [&] () -> gboolean {
    if (!GIMP_IS_FILTER_LAYER (layer))
      throw Error (GIMP_PAINTER_ERROR_WRONG_TYPE, "Expected FilterLayer");
    /* Retire the captured old model before dropping any owner lease. Release
     * the layer before its image, and the image before its owning Gimp. */
    ObjectRef<GObject> gimp_pin, image_pin, owner_pin;
    std::shared_ptr<const FilterArguments> original;
    guint64 revision = 0, binding_token = 0;
    /* Reject wrong-thread/closed/missing bindings before examining the image,
     * provider, procedure or supplied arguments. Read-only access is not enough. */
    BindingStore::require (G_OBJECT (layer)).with<FilterSlot> ([&] (FilterImpl& impl) {
      original = impl.args;
      revision = impl.definition_revision;
      binding_token = BindingStore::require (G_OBJECT (layer)).generation ();
    });
    owner_pin = ObjectRef<GObject>::retain (G_OBJECT (layer));
    if (!procedure || (std::strcmp (procedure, FilterLegacy::blinds.saved) &&
                       std::strcmp (procedure, FilterLegacy::small_tiles.saved) &&
                       std::strcmp (procedure, FilterLegacy::retinex.saved)))
      throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,
                   "Unsupported legacy preparation route; only plug-in-blinds, plug-in-small-tiles and plug-in-retinex are accepted");
    const std::string name (procedure);
    const bool tiles = name == FilterLegacy::small_tiles.saved;
    const bool retinex = name == FilterLegacy::retinex.saved;
    const std::string label = retinex ? "Legacy Retinex" : tiles ? "Legacy Small Tiles" : "Legacy Blinds";
    auto *image = gimp_item_get_image (GIMP_ITEM (layer));
    if (!GIMP_IS_IMAGE (image) || !GIMP_IS_GIMP (image->gimp))
      throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, (label + " preparation requires a live image and Gimp owner").c_str ());
    image_pin = ObjectRef<GObject>::retain (G_OBJECT (image));
    auto *gimp = image->gimp;
    gimp_pin = ObjectRef<GObject>::retain (G_OBJECT (gimp));
    try
      {
        FilterEditorSchema schema (gimp, retinex ? FilterProcedure::retinex : tiles ? FilterProcedure::small_tiles : FilterProcedure::blinds);
        LegacyScalarRouteGuard guard {layer, image, gimp, &schema, &original, binding_token, revision};
        ArgsRef prepared = retinex ? prepare_legacy_scalar_route<7, true> (arguments, label) :
                           tiles ? prepare_legacy_scalar_route<4> (arguments, label) :
                                   prepare_legacy_scalar_route<7> (arguments, label);
        if (!LegacyScalarRouteGuard::current (&guard))
          throw Error (GIMP_PAINTER_ERROR_INVALID_STATE,
                       (label + " owner, definition or trusted provider changed during preparation").c_str ());
        /* Carry the ORIGINAL model/revision into the final publication path;
         * capturing a new revision after conversion would overwrite reentry.
         * The final synchronous guard also rechecks owner/provider identity.
         * A later notification failure is intentionally not rolled back. */
        return set_definition (layer, name.c_str (), nullptr, prepared.get (), false, error,
                               nullptr, nullptr, &original, revision, LegacyScalarRouteGuard::current, &guard);
      }
    catch (const FilterEditorSchemaError& failure)
      {
        const std::string message = label + (failure.status () == FilterEditorSchemaStatus::unavailable ?
          " trusted provider is unavailable: " : " trusted provider is incompatible: ") + failure.what ();
        throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, message.c_str ());
      }
  });
}
gboolean gimp_filter_layer_set_definition_checked (GimpFilterLayer *layer, const gchar *procedure,
                                                   GBytes *raw, const GimpValueArray *args, gboolean push_undo,
                                                   gboolean (*check) (gpointer), gpointer check_data,
                                                   GError **error)
{
  return boundary<gboolean> (error, FALSE, [&] () -> gboolean {
    if (!GIMP_IS_FILTER_LAYER (layer) || (push_undo != FALSE && push_undo != TRUE))
      throw Error (GIMP_PAINTER_ERROR_WRONG_TYPE, "Expected FilterLayer and Boolean Undo option");
    auto owner_pin = ObjectRef<GObject>::retain (G_OBJECT (layer));
    std::shared_ptr<const FilterArguments> original;
    guint64 revision = 0;
    BindingStore::require (G_OBJECT (layer)).read<FilterSlot> ([&] (const FilterImpl& impl) {
      original = impl.args; revision = impl.definition_revision;
    });
    if (check && !check (check_data))
      throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter editor metadata changed before staging");
    return set_definition (layer, procedure, raw, args, push_undo, error,
                           nullptr, nullptr, &original, revision, check, check_data);
  });
}
gboolean gimp_filter_layer_set_definition_with_opaque_arguments (GimpFilterLayer *layer, const gchar *procedure,
                                                                GBytes *raw, GBytes *opaque, GError **error)
{ return set_definition (layer, procedure, raw, nullptr, false, error, nullptr, opaque); }
#define FILTER_READ(type, fallback, expression) \
  return boundary<type> (nullptr, fallback, [&] { \
    if (!GIMP_IS_FILTER_LAYER (layer)) return fallback; \
    return BindingStore::require (G_OBJECT (layer)).read<FilterSlot> ([&] (const FilterImpl& impl) -> type { return expression; }); \
  })
const gchar *gimp_filter_layer_get_procedure (GimpFilterLayer *layer)
{ FILTER_READ (const gchar *, static_cast<const gchar *> (nullptr), impl.procedure.c_str ()); }
gchar *gimp_filter_layer_dup_procedure (GimpFilterLayer *layer)
{ FILTER_READ (gchar *, static_cast<gchar *> (nullptr), g_strdup (impl.procedure.c_str ())); }
gchar *gimp_filter_layer_dup_procedure_prefix (GimpFilterLayer *layer, gsize max_bytes,
                                             gboolean *truncated)
{
  if (truncated) *truncated = FALSE;
  return boundary<gchar *> (nullptr, nullptr, [&] {
    if (!GIMP_IS_FILTER_LAYER (layer)) return static_cast<gchar *> (nullptr);
    return BindingStore::require (G_OBJECT (layer)).read<FilterSlot> ([&] (const FilterImpl& impl) {
      const gsize size = MIN (max_bytes, gsize (impl.procedure.size ()));
      if (truncated) *truncated = size < impl.procedure.size ();
      return g_strndup (impl.procedure.c_str (), size);
    });
  });
}
GBytes *gimp_filter_layer_ref_definition (GimpFilterLayer *layer)
{ FILTER_READ (GBytes *, static_cast<GBytes *> (nullptr), impl.raw ? g_bytes_ref (impl.raw.get ()) : nullptr); }
GBytes *gimp_filter_layer_ref_opaque_arguments (GimpFilterLayer *layer)
{ FILTER_READ (GBytes *, static_cast<GBytes *> (nullptr), impl.opaque_arguments ? g_bytes_ref (impl.opaque_arguments.get ()) : nullptr); }
GimpValueArray *gimp_filter_layer_dup_args (GimpFilterLayer *layer)
{ FILTER_READ (GimpValueArray *, static_cast<GimpValueArray *> (nullptr), impl.args ? impl.args->copy_values () : nullptr); }
GArray *gimp_filter_layer_get_procedure_args (GimpFilterLayer *layer)
{
  return boundary<GArray *> (nullptr, nullptr, [&] {
    /* Materialize through the existing reference-aware model. Never expose its
     * saved values or replace raw/opaque serialization with these values. */
    ArgsRef values (gimp_filter_layer_dup_args (layer));
    if (!values) return static_cast<GArray *> (nullptr);
    const gint count = gimp_value_array_length (values.get ());
    if (count < 0) throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Invalid Filter argument count");
    auto result = ArrayRef::adopt (g_array_sized_new (FALSE, TRUE, sizeof (GValue), count));
    g_array_set_clear_func (result.get (), [] (gpointer data) {
      auto *value = static_cast<GValue *> (data);
      if (G_IS_VALUE (value)) g_value_unset (value);
    });
    g_array_set_size (result.get (), count);
    for (gint i = 0; i < count; ++i)
      {
        const GValue *source = gimp_value_array_index (values.get (), i);
        if (!G_IS_VALUE (source))
          throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Invalid Filter argument value");
        GValue *destination = &g_array_index (result.get (), GValue, i);
        g_value_init (destination, G_VALUE_TYPE (source));
        g_value_copy (source, destination);
      }
    return result.release ();
  });
}
GimpFilterLayerState gimp_filter_layer_get_state (GimpFilterLayer *layer)
{ FILTER_READ (GimpFilterLayerState, GIMP_FILTER_LAYER_CLOSED, static_cast<GimpFilterLayerState> (impl.scheduler.state ())); }
gchar *gimp_filter_layer_dup_error (GimpFilterLayer *layer)
{ FILTER_READ (gchar *, static_cast<gchar *> (nullptr), g_strdup (impl.scheduler.error ().c_str ())); }
guint64 gimp_filter_layer_get_definition_revision (GimpFilterLayer *layer)
{ FILTER_READ (guint64, guint64 (0), impl.definition_revision); }
guint64 gimp_filter_layer_get_generation (GimpFilterLayer *layer)
{ FILTER_READ (guint64, guint64 (0), impl.scheduler.generation ()); }
guint64 gimp_filter_layer_get_cache_generation (GimpFilterLayer *layer)
{ FILTER_READ (guint64, guint64 (0), impl.scheduler.cache_generation ()); }
guint64 gimp_filter_layer_get_run_count (GimpFilterLayer *layer)
{ FILTER_READ (guint64, guint64 (0), impl.scheduler.starts ()); }
gint64 gimp_filter_layer_get_max_quantum_us (GimpFilterLayer *layer)
{ FILTER_READ (gint64, gint64 (0), impl.maximum_quantum_us); }
gint64 gimp_filter_layer_get_max_graph_quantum_us (GimpFilterLayer *layer)
{ FILTER_READ (gint64, gint64 (0), impl.maximum_graph_us); }
gint64 gimp_filter_layer_get_max_read_quantum_us (GimpFilterLayer *layer)
{ FILTER_READ (gint64, gint64 (0), impl.maximum_read_us); }
#undef FILTER_READ
void gimp_filter_layer_mark_as_loaded (GimpFilterLayer *layer)
{ boundary_void (nullptr, [&] { BindingStore::require (G_OBJECT (layer)).with<FilterSlot> ([] (FilterImpl& impl) {
    impl.native_context.reset (); impl.scheduler.mark_loaded (); impl.staged.reset (); }); }); }
void gimp_filter_layer_invalidate (GimpFilterLayer *layer)
{ boundary_void (nullptr, [&] { BindingStore::require (G_OBJECT (layer)).with<FilterSlot> ([] (FilterImpl& impl) { impl.invalidate (); }); }); }
gboolean gimp_filter_layer_cancel_generation (GimpFilterLayer *layer, guint64 generation)
{
  return boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
    if (!GIMP_IS_FILTER_LAYER (layer)) return FALSE;
    return BindingStore::require (G_OBJECT (layer)).with<FilterSlot> ([&] (FilterImpl& impl) -> gboolean {
      if (generation != impl.scheduler.generation ()) return FALSE;
      auto retired = std::move (impl.staged);
      impl.native_context.reset ();
      impl.scheduler.reject ("Filter execution cancelled");
      impl.schedule ();
      g_signal_emit_by_name (impl.owner, "filter-state-changed");
      // No further Impl access: notification/destruction may replace or close.
      return TRUE;
    });
  });
}
void gimp_filter_layer_cancel (GimpFilterLayer *layer)
{ gimp_filter_layer_cancel_generation (layer, gimp_filter_layer_get_generation (layer)); }

gboolean gimp_filter_layer_get_argument_reference (GimpFilterLayer *layer, guint argument, guint element,
                                                  GType *type, gint64 *id, gboolean *expired)
{
  return boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
    if (!GIMP_IS_FILTER_LAYER (layer)) return FALSE;
    return BindingStore::require (G_OBJECT (layer)).read<FilterSlot> ([&] (const FilterImpl& impl) -> gboolean {
      const auto *ref = impl.args ? impl.args->reference (argument, element) : nullptr;
      if (!ref) return FALSE;
      if (type) *type = ref->type;
      if (id) *id = ref->id;
      if (expired) *expired = ref->had_object && !ref->target.lock ();
      return TRUE;
    });
  });
}

gboolean gimp_filter_layer_get_snapshot_state (GimpFilterLayer *layer, GimpFilterLayerSnapshot *snapshot)
{
  return boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
    if (!GIMP_IS_FILTER_LAYER (layer) || !snapshot) return FALSE;
    return BindingStore::require (G_OBJECT (layer)).read<FilterSlot> ([&] (const FilterImpl& impl) -> gboolean {
      const auto saved = impl.scheduler.snapshot ();
      *snapshot = {1, saved.generation, saved.cache_generation, saved.cache_complete,
                   static_cast<GimpFilterLayerState> (impl.scheduler.state ())};
      return TRUE;
    });
  });
}
gboolean gimp_filter_layer_restore_snapshot_state (GimpFilterLayer *layer,
                                                   const GimpFilterLayerSnapshot *snapshot, GError **error)
{
  return boundary<gboolean> (error, FALSE, [&] () -> gboolean {
    if (!GIMP_IS_FILTER_LAYER (layer)) throw Error (GIMP_PAINTER_ERROR_WRONG_TYPE, "Expected FilterLayer");
    if (!snapshot || snapshot->version != 1 ||
        (snapshot->cache_complete != FALSE && snapshot->cache_complete != TRUE) ||
        snapshot->state < GIMP_FILTER_LAYER_CLEAN || snapshot->state > GIMP_FILTER_LAYER_CLOSED ||
        snapshot->cache_generation > snapshot->generation || snapshot->generation > G_MAXINT64)
      throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Invalid FilterLayer snapshot schema");
    BindingStore::require (G_OBJECT (layer)).with<FilterSlot> ([&] (FilterImpl& impl) {
      impl.native_context.reset ();
      impl.scheduler.restore_cache ({snapshot->generation, snapshot->cache_generation, bool (snapshot->cache_complete)});
      impl.staged.reset ();
      impl.schedule ();
      g_signal_emit_by_name (impl.owner, "filter-state-changed");
    });
    return TRUE;
  });
}

struct GIMP_PAINTER_PRIVATE _GimpFilterArgumentsSnapshot
{
  explicit _GimpFilterArgumentsSnapshot (std::shared_ptr<const FilterArguments> arguments)
    : arguments (std::move (arguments)) {}
  std::shared_ptr<const FilterArguments> arguments;
};
GimpFilterArgumentsSnapshot *gimp_filter_layer_snapshot_arguments (GimpFilterLayer *layer)
{
  return boundary<GimpFilterArgumentsSnapshot *> (nullptr, nullptr, [&] {
    if (!GIMP_IS_FILTER_LAYER (layer)) return static_cast<GimpFilterArgumentsSnapshot *> (nullptr);
    return BindingStore::require (G_OBJECT (layer)).read<FilterSlot> ([&] (const FilterImpl& impl) -> GimpFilterArgumentsSnapshot * {
      return impl.args ? new GimpFilterArgumentsSnapshot (impl.args) : nullptr;
    });
  });
}
gboolean gimp_filter_layer_edit_argument_patch (GimpFilterLayer *layer, guint64 expected_revision,
                                                const GimpFilterArgumentsSnapshot *snapshot,
                                                guint n_patches, const GimpFilterArgumentPatch *patches,
                                                gboolean (*check) (gpointer), gpointer check_data,
                                                GError **error)
{
  return boundary<gboolean> (error, FALSE, [&] () -> gboolean {
    if (!GIMP_IS_FILTER_LAYER (layer) || !snapshot || !snapshot->arguments)
      throw Error (GIMP_PAINTER_ERROR_WRONG_TYPE, "Expected FilterLayer and saved argument snapshot");
    if (n_patches > 512 || (n_patches && !patches))
      throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter argument edit exceeds structural limits");
    auto owner_pin = ObjectRef<GObject>::retain (G_OBJECT (layer));
    const auto original = snapshot->arguments;
    if (check && !check (check_data))
      throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter editor metadata changed before staging");
    std::shared_ptr<const FilterArguments> edited;
    std::string procedure;
    BytesRef raw, opaque;
    BindingStore::require (G_OBJECT (layer)).read<FilterSlot> ([&] (const FilterImpl& impl) {
      if (impl.args != original || impl.definition_revision != expected_revision)
        throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter definition changed; reload its saved parameters");
      if (!n_patches) return;
      if (impl.procedure.size () > 4096)
        throw Error (GIMP_PAINTER_ERROR_INVALID_STATE, "Filter procedure name exceeds the edit budget");
      edited = std::make_shared<FilterArguments> (original, n_patches, patches);
      procedure = impl.procedure;
      raw.reset (impl.raw ? g_bytes_ref (impl.raw.get ()) : nullptr);
      opaque.reset (impl.opaque_arguments ? g_bytes_ref (impl.opaque_arguments.get ()) : nullptr);
    });
    if (!n_patches) return TRUE;
    return set_definition (layer, procedure.c_str (), raw.get (), nullptr, true, error,
                           &edited, opaque.get (), &original, expected_revision, check, check_data);
  });
}
void gimp_filter_arguments_snapshot_free (GimpFilterArgumentsSnapshot *snapshot) { delete snapshot; }
guint gimp_filter_arguments_snapshot_count (const GimpFilterArgumentsSnapshot *snapshot)
{ return snapshot ? snapshot->arguments->size () : 0; }
GType gimp_filter_arguments_snapshot_type (const GimpFilterArgumentsSnapshot *snapshot, guint argument)
{
  return snapshot && argument < snapshot->arguments->size () ?
         G_VALUE_TYPE (snapshot->arguments->at (argument)) : G_TYPE_INVALID;
}
gboolean gimp_filter_arguments_snapshot_value (const GimpFilterArgumentsSnapshot *snapshot, guint argument, GValue *value)
{
  return boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
    if (!snapshot || !value || G_IS_VALUE (value) || argument >= snapshot->arguments->size () ||
        !snapshot->arguments->scalar (argument)) return FALSE;
    const GValue *source = snapshot->arguments->at (argument);
    g_value_init (value, G_VALUE_TYPE (source)); g_value_copy (source, value);
    return TRUE;
  });
}
const GValue *gimp_filter_arguments_snapshot_peek_value (const GimpFilterArgumentsSnapshot *snapshot, guint argument)
{
  return boundary<const GValue *> (nullptr, nullptr, [&] () -> const GValue * {
    if (!snapshot || argument >= snapshot->arguments->size () ||
        !snapshot->arguments->scalar (argument)) return nullptr;
    return snapshot->arguments->at (argument);
  });
}
guint gimp_filter_arguments_snapshot_reference_count (const GimpFilterArgumentsSnapshot *snapshot, guint argument)
{ return snapshot ? snapshot->arguments->reference_count (argument) : 0; }
gboolean gimp_filter_arguments_snapshot_reference (const GimpFilterArgumentsSnapshot *snapshot, guint argument,
                                                   guint element, GimpFilterArgumentReference *reference)
{
  return boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
    const auto *ref = snapshot ? snapshot->arguments->reference (argument, element) : nullptr;
    if (!ref || !reference) return FALSE;
    *reference = {ref->type, ref->id, ref->had_object, ref->had_object && !ref->target.lock ()};
    return TRUE;
  });
}
gboolean gimp_filter_arguments_snapshot_acquire_reference (const GimpFilterArgumentsSnapshot *snapshot, guint argument,
                                                           guint element, GimpFilterArgumentReference *reference,
                                                           GObject **target)
{
  return boundary<gboolean> (nullptr, FALSE, [&] () -> gboolean {
    if (!snapshot || !reference || !target) return FALSE;
    /* A weak-lock/toggle notification may reenter. Keep its backing model alive
     * and transfer this very lease instead of observing expiration twice. */
    auto arguments = snapshot->arguments;
    const auto *ref = arguments->reference (argument, element);
    if (!ref) return FALSE;
    auto lease = ref->target.lock ();
    *reference = {ref->type, ref->id, ref->had_object, ref->had_object && !lease};
    *target = lease.release ();
    return TRUE;
  });
}
GimpFilterArgumentsSnapshot *gimp_filter_arguments_snapshot_nested (const GimpFilterArgumentsSnapshot *snapshot, guint argument)
{
  return boundary<GimpFilterArgumentsSnapshot *> (nullptr, nullptr, [&] {
    auto nested = snapshot ? snapshot->arguments->nested (argument) : nullptr;
    return nested ? new GimpFilterArgumentsSnapshot (std::move (nested)) : nullptr;
  });
}

gboolean gimp_filter_arguments_snapshot_is_null (const GimpFilterArgumentsSnapshot *snapshot, guint argument)
{
  return snapshot && argument < snapshot->arguments->size () && snapshot->arguments->is_null (argument);
}

GimpFilterArgumentsSnapshot *gimp_filter_arguments_snapshot_import (guint count,
                                                                   const GimpFilterArgumentSpec *specs, GError **error)
{
  return boundary<GimpFilterArgumentsSnapshot *> (error, nullptr, [&] {
    std::size_t remaining = 65536;
    auto arguments = std::make_shared<FilterArguments> (count, specs, 0, remaining);
    return new GimpFilterArgumentsSnapshot (std::move (arguments));
  });
}
gboolean gimp_filter_layer_set_definition_with_snapshot (GimpFilterLayer *layer, const gchar *procedure,
                                                         GBytes *raw, const GimpFilterArgumentsSnapshot *snapshot, GError **error)
{
  std::shared_ptr<const FilterArguments> arguments = snapshot ? snapshot->arguments : nullptr;
  return set_definition (layer, procedure, raw, nullptr, false, error, &arguments);
}
