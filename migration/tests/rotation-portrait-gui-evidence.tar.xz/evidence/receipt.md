# Modern rotation portrait GUI smoke receipt

Outcome: PASS for this bounded smoke, with the runtime diagnostics listed below. This is not whole-task-25 or full-port acceptance.

## Exact source and runtime

- Published source commit: `22708f41d368c6c7c2e425d30ea2765b9d29158b`
- Source tree: `0a48c7e042ae2f2b46e6cfe828926470e1ace9ab`
- Source was clean before build, after build, and after GUI exit. No repository edits were made by this smoke.
- Full default `ninja -j4` build and `meson install --no-rebuild` succeeded from this exact source. The installed branch executable was launched directly.
- Build and installed executable ELF build ID: `143e3f68cd62eca3fcd22c2cc80a49961c5bfe99`.
- Build executable SHA-256: `9e36302917ed7def4d793694b545c7c3b72eae9919ef8f7bcc1ef01995e3fa09`.
- Installed executable SHA-256: `df0d4095b02d43c64b2e658ad2ec692c786396624c4aabf52d175d02128c2e2f`.
- Source, installed runtime, and executable before/after seals matched. Actual process executable and mapped-library snapshots accompany each live phase.

## Display and ordinary input

- Authenticated loopback TCP Xvfb: 1080 × 1920 × 24, display 127.0.0.1:91. Authenticated client accepted; empty-authority client rejected. Automatic TCP/Unix/local listeners were disabled, with only the inherited 127.0.0.1:6091 listener used.
- Fresh private profile with inherited Painter rotation defaults. Actual View → Painter Canvas Controls was enabled through its menu.
- The existing 720 × 1080 synthetic RGB study was centered at 70% zoom. Full artwork, top color/brush/layer controls, left tool controls, right layer tile, and statusbar were visible.
- Ordinary XTest input only; no batch, debugger, action injection, or internal state setters. Live inspected start (850,800), target (890,970). No geometry retry was needed.

## Same-drag visual observations

Each full raw capture was inspected before advancing. No crop, scaling, compositing, or annotation was applied to these primary screenshots.

1. `010-rotation-free.png`: Shift+middle drag displayed 28.43°.
2. `020-rotation-ctrl-snap.png`: Ctrl down and real motion to the same target displayed 30.00°.
3. `030-rotation-shift-released.png`: Shift up, Ctrl+middle retained, real motion displayed 30.00°.
4. `040-rotation-ctrl-unsnap.png`: Ctrl up and real motion restored 28.43° at the same target.
5. `050-rotation-released.png`: middle released, no held inputs, stable 28.43° and intact visible artwork/controls.

The uninterrupted five-phase sequence took approximately 39 seconds; maximum recorded event gap was 11.65 seconds, below the 120-second held-input limit. No idle safety release occurred. All 19 GUI request responses were `ok: true`.

## Save and reopen

- Saved through the normal Save Image dialog as `rotation-portrait-smoke.xcf`; no existing file was overwritten. `060-xcf-saved.png` records the completed save.
- Closed the image normally, selected and opened that same XCF through the normal Open Image dialog. `067-xcf-selected.png` shows its filename, 720 × 1080 dimensions, RGB, and 1 layer.
- `070-xcf-reopened.png`: original 70% geometry restored; upright artwork, layer appearance and on-canvas controls intact. The zero-degree status label is absent, consistent with the source contract. Rotation is view state and does not persist through XCF.
- XCF SHA-256 after save and after reopen: `01a1846108e57776bed5b132928f6524de81c7d936dfe2be4b7cb60616c5c931`.
- Read-only comparison of the visible rendered artwork rectangle [289,606,791,1361] at identical baseline/reopen geometry was byte-identical; region SHA-256 `4925f91b27039998a4b1fcf294df7349d2f11ce0a488f9cb3463df708c0448f7`. This is rendered-image evidence, not a numerical GIMP buffer proof. No cropped deliverable was created.
- One optional short post-reopen Shift+middle drag showed 28.43° again (`075-post-reopen-rotation.png`) and released all inputs. The saved XCF was preserved unchanged.

## Terminal state and diagnostics

- Normal Ctrl+Q quit. Application, driver, launcher, and Xvfb all returned 0. Driver reason: application_exit. No held buttons or keys and no cleanup errors remained.
- Display shutdown connection failed with errno 111 (connection refused). Final source/runtime/binary seals passed; shared lane released.
- Preserved runtime diagnostics: 112 unsupported fonts ignored; unavailable session bus; 47 dconf warnings reporting unavailable dbus-launch. No GIMP CRITICAL line was recorded. These did not prevent the observed smoke, but this is not a warning-free claim.
- No rotation/input failure or retry occurred. Initial main-window and file-dialog geometry adjustments are retained in the ordered requests and raw captures.

## Evidence scope

Archive includes raw full-root PNGs, synthetic input, saved XCF, ordered requests/responses, input events, executable/maps evidence, exact source/runtime inventories, helper sources/hashes, build/install/GIMP/Xvfb logs, display authentication/shutdown checks and this receipt. Private profile, Xauthority and authentication material are excluded.

No old runtime or new legacy capture was used. No physical device behavior, full numerical buffer correctness, full task 25 coverage, or full port acceptance is claimed.
