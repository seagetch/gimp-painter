# Prepared modern rotation portrait smoke

Status: PREPARED ONLY. This preparation did not run a build, install, application,
display, repository test, or shared-lane lock. The parent owns native launch and
interactive screenshot inspection. Everything created here is external to the
frozen source and build.

## Exact handshake before launch

Read-only preparation inspected:

- Source: `/workspace/shared/gimp-painter-clone-components`
- Commit B: `d975c1ba64895bcb61995c5a807d0b440509716b`
- Tree: `d3f8aa2072cf1c21c5a81fb3e58ecfaefa15b6a1`
- Clean Git status. No AGENTS.md was found in the inspected workspace ancestors
  or this source tree, and no repository-local `.agents` skill was found.
- Build: `/workspace/shared/gimp-clone-component-build`
- Installed prefix: `/workspace/shared/gimp-clone-component-prefix`, known older
  at preparation time. It is not valid evidence for B until rebuilt/installed.

The accepted final documentary descendant is not known. Do not substitute B for
the final published identity without an explicit parent commit/tree handshake.
First wait for the parent to release the frozen strict-gate lane and explicitly
grant the GUI lane. Only then may the parent run:

```sh
PREP=/workspace/shared/gimp-rotation-portrait-gui-prep
bash "$PREP/launch-gui.sh" ACCEPTED_COMMIT ACCEPTED_TREE \
  "$PREP/runs/run-001" --parent-gui-lane-granted
```

The launcher validates clean exact source identity, takes the shared lock
nonblocking, validates again, seals source, incrementally builds the full default
target, installs with `meson install --no-rebuild`, and checks source stayed fixed.
It verifies build/install ELF build IDs match, records both SHA-256 hashes, seals
installed bin/lib/libexec/share content, and starts the real installed GIMP using
a fresh private profile and authenticated loopback-only 1080×1920×24 Xvfb. It keeps
the lock through exit and final source/runtime/binary comparisons. Build/install
logs are retained even if a later step fails. No old runtime or legacy capture is
part of this smoke.

The driver has a 30-minute maximum lifetime; the Xvfb wrapper allows 31 minutes.
Held input idle timeout is 120 seconds. SIGTERM/SIGINT and ordinary errors release
buttons before modifiers; a forced SIGKILL cannot execute cleanup, so display
teardown is the backstop. Timeout or forced termination is not successful smoke.

## Actual source contract

The following are read-only findings at B, to recheck if code changes before the
final identity is supplied:

- `app/display/gimppainternavigation.c`: default middle action uses Shift for
  rotation and Shift+Ctrl for stepped rotation. Rotation uses a fixed initial
  bearing/angle anchor, and a live Ctrl bit-test snaps to 15-degree increments.
- `app/display/gimpdisplayshell-tool-events.c`: active inherited rotation rechecks
  Ctrl on pointer motion, including after Shift release. Therefore send real
  motion after toggling Ctrl. A bare key event is not the assertion.
- `app/display/gimpstatusbar.c:gimp_statusbar_shell_rotated`: the status angle is
  displayed to two decimals when nonzero and hidden at exactly zero. A missing
  zero-degree label is expected, not a rendering failure.
- `app/display/gimpdisplayshell-rotate.c`: `rotate_to` changes display-shell view
  state and retains the viewport center. `gimpdisplayshell.c` resets rotation to
  zero when the shell is emptied. No corresponding display-angle persistence was
  found in `app/xcf`. Save/reopen verifies the image document; record the observed
  reopen view angle separately. Do not require rotation to survive XCF or describe
  a view reset as image damage.

## Bounded interactive procedure

Use only ordinary XTest mouse/keyboard input. No GIMP batch commands, debugger,
injected actions, or internal state setters. The preserved 720×1080 synthetic RGB
study is the existing mountain/sun/wave artwork with distinct landmarks and color
patches. Its source hash is in `reviewed-inputs.sha256`.

1. Read an initial capture and window list. Focus/resize the actual GIMP window to
   fill the portrait display if needed. Choose coordinates only from live raw
   screenshots. Fit/center the artwork at a stable zoom that leaves rotation
   margin and meaningful visible image area. Keep the statusbar visible.
2. Enable View → Painter Canvas Controls through the actual menu. Capture the
   resulting on-canvas layer tile, color/tool controls, artwork and statusbar as
   `005-canvas-controls-baseline.png`. If a popup is opened to inspect a control,
   close it before rotation. Do not paint, change layer data, or configure an
   alternate pointer mapping. The fresh profile uses inherited Painter defaults.
3. Pick two safe canvas points at least 100 screen pixels apart and well away
   from the viewport center, dock overlays, layer tiles and controls. Prefer an
   arc yielding approximately 20–40 degrees of rotation, clearly away from a
   15-degree multiple. Generate inert request templates:

   ```sh
   python3 -B "$PREP/prepare.py" --output "$PREP/templates-run-001" \
     --start START_X START_Y --target TARGET_X TARGET_Y
   ```

   These coordinates are the full display coordinates, not image coordinates.
   The helper writes templates only. It never posts them to a live queue.
4. Copy one request at a time to the live `gui-queue`, using a temporary filename
   followed by rename to `*.request.json`. Wait for the matching response, confirm
   `ok: true`, and inspect each full raw capture before proceeding. Keep each held
   phase under 120 seconds. The five requests are:
   - 010: Shift down, middle down, 12 spaced motions to the target. Capture a
     nonzero non-stepped angle. Shift+middle stay held.
   - 020: Ctrl down, move one pixel and back to the exact same target. Capture a
     15-degree-multiple angle. All three inputs stay held.
   - 030: Shift up, move one pixel and back. Capture continued snapping with
     middle+Ctrl held; original anchor remains in effect.
   - 040: Ctrl up, move one pixel and back. Capture the original unsnapped angle
     at the same target, to the displayed 0.01-degree precision.
   - 050: Middle up, release-all safety check. Capture stable final artwork,
     nonzero status angle and on-canvas controls with no held inputs.

   If the free angle happens to be a 15-degree multiple, this does not establish
   snap/unsnap visually. Release everything, use the real View rotation UI to
   reset the view if needed, and prepare one new bounded attempt with a different
   target and unique request/capture names (`prepare.py --prefix retry-` with a
   fresh output directory). Preserve the first attempt as such.
5. Save through the ordinary UI as the fresh external path
   `RUN/rotation-portrait-smoke.xcf`. Do not overwrite an existing file. Wait until
   the save completes, capture `060-xcf-saved.png`, then immediately hash the XCF
   into `evidence/xcf-after-save.sha256`. Preserve this XCF unchanged afterward.
6. Close the image with normal UI, reopen that same XCF through File → Open, and
   restore the prior zoom/centering as needed. Capture `070-xcf-reopened.png` with
   artwork and on-canvas controls. Record image title/dimensions/layer appearance,
   whether rotation reset, and the visible angle or absence of its zero label.
   Confirm the XCF SHA-256 is unchanged. A view reset is expected by the reviewed
   contract and is not a failed round trip.
7. Optionally make one short post-reopen Shift+middle drag and release it to show
   controls still respond, retaining a final portrait screenshot. This must not
   become a larger validator. Quit normally with Ctrl+Q, and confirm app/driver
   exit, empty held input state, display shutdown, and seal comparisons.

At most one initial attempt, one geometry-adjustment retry if needed, and one
optional short post-reopen gesture. Stop and report an actual UI/input failure
instead of compensating with internal APIs or widening this task.

## Queue operation reference

Supported actions retain the reviewed click/move/key/text/focus/resize operations
and add explicit held input:

```json
{"actions":[{"op":"key_down","key":"Shift_L"},{"op":"button_down","button":2},{"op":"move","x":640,"y":1000},{"op":"button_up","button":2},{"op":"key_up","key":"Shift_L"}],"capture":"example-only.png","settle":0.5}
```

The example coordinates are explanatory, not a runnable live test plan. `key`
uses `keys: ["Control_L", "s"]` for a complete chord; it must not include an
already-held key. `release_all` releases this driver's tracked buttons then keys.
Every explicit input is recorded in `logs/input-events.jsonl`; request responses
record per-action timing, held states, window geometry, process executable/maps,
and raw capture SHA-256. Each screenshot is a direct full-root XGetImage encoding
at 1080×1920. Existing screenshot filenames are never overwritten. Do not crop,
rescale, annotate, or composite the primary evidence.

## Evidence and honest result

Keep raw screenshots, ordered request/response files, input events, synthetic PNG,
saved XCF and save/reopen hashes, source before/after inventories, installed
runtime before/after inventories, build/install executable hashes/build IDs,
process executable/maps, helper hashes, display auth/geometry/shutdown checks,
and raw GIMP/build/install/Xvfb logs. Include a concise inspected-results receipt
with the accepted published commit/tree, actual observed angles, screenshot names,
save/reopen observations, diagnostics, and any retry/failure. Exclude the private
profile, Xauthority, and all auth material from uploaded archives.

Success needs the parent's visual inspection plus input/identity evidence. A
zero driver exit alone is insufficient: every intended request must be `ok:true`,
no safety idle release may have interrupted the sequence, and all required
captures/XCF must exist. Do not claim warning-free unless logs establish it.

This establishes a small real modern portrait UI smoke. It is not full numerical
buffer proof, a physical mouse/tablet test, whole25 coverage, or a new legacy
capture. View-only rotation and XCF image preservation are distinct observations.

Preparation verification is limited to static source review, Python `ast.parse`,
and `bash -n`; see `static-review.json`. No runtime result is claimed here.
