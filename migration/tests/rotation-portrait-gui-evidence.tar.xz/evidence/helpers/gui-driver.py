#!/usr/bin/env python3
"""Drive the actual app through ordinary XTest input and preserve raw X screenshots."""
import argparse,ctypes as C,hashlib,json,os,signal,struct,subprocess,sys,time,zlib
from pathlib import Path
parser=argparse.ArgumentParser(); parser.add_argument('--run',required=True); parser.add_argument('--binary',required=True); parser.add_argument('--input',required=True); parser.add_argument('--max-seconds',type=int,default=1800); parser.add_argument('--hold-timeout',type=int,default=120); args=parser.parse_args()
if not (60 <= args.max_seconds <= 1800 and 10 <= args.hold_timeout <= 120): parser.error('Bounded runtime/held-input timeout required')
run=Path(args.run).resolve(); binary=Path(args.binary).resolve(); artwork=Path(args.input).resolve(); queue=run/'gui-queue'; queue.mkdir(exist_ok=True)
(run/'screenshots').mkdir(exist_ok=True); (run/'logs').mkdir(exist_ok=True)
x=C.CDLL('libX11.so.6'); t=C.CDLL('libXtst.so.6')
def sig(lib,name,args,rest):
 f=getattr(lib,name); f.argtypes=args;f.restype=rest;return f
P=C.c_void_p; U=C.c_ulong; I=C.c_int
sig(x,'XOpenDisplay',[C.c_char_p],P); d=x.XOpenDisplay(None)
if not d: raise RuntimeError('No authenticated display')
sig(x,'XDefaultRootWindow',[P],U); root=x.XDefaultRootWindow(d)
sig(x,'XFlush',[P],I);sig(x,'XSync',[P,I],I);sig(x,'XFree',[P],I);sig(x,'XCloseDisplay',[P],I)
sig(x,'XQueryTree',[P,U,C.POINTER(U),C.POINTER(U),C.POINTER(C.POINTER(U)),C.POINTER(C.c_uint)],I)
sig(x,'XFetchName',[P,U,C.POINTER(C.c_char_p)],I)
sig(x,'XGetGeometry',[P,U,C.POINTER(U),C.POINTER(I),C.POINTER(I),C.POINTER(C.c_uint),C.POINTER(C.c_uint),C.POINTER(C.c_uint),C.POINTER(C.c_uint)],I)
sig(x,'XTranslateCoordinates',[P,U,U,I,I,C.POINTER(I),C.POINTER(I),C.POINTER(U)],I)
sig(x,'XSetInputFocus',[P,U,I,U],I);sig(x,'XRaiseWindow',[P,U],I);sig(x,'XMoveResizeWindow',[P,U,I,I,C.c_uint,C.c_uint],I)
sig(x,'XStringToKeysym',[C.c_char_p],U);sig(x,'XKeysymToKeycode',[P,U],C.c_uint)
sig(t,'XTestFakeKeyEvent',[P,C.c_uint,I,U],I);sig(t,'XTestFakeButtonEvent',[P,C.c_uint,I,U],I);sig(t,'XTestFakeMotionEvent',[P,I,I,I,U],I)
class XImage(C.Structure):
 _fields_=[('width',I),('height',I),('xoffset',I),('format',I),('data',P),('byte_order',I),('bitmap_unit',I),('bitmap_bit_order',I),('bitmap_pad',I),('depth',I),('bytes_per_line',I),('bits_per_pixel',I),('red_mask',U),('green_mask',U),('blue_mask',U),('obdata',P)]
sig(x,'XGetImage',[P,U,I,I,C.c_uint,C.c_uint,U,I],C.POINTER(XImage));sig(x,'XDestroyImage',[C.POINTER(XImage)],I)
def window_info(w):
 name=C.c_char_p();x.XFetchName(d,w,C.byref(name)); n=name.value.decode(errors='replace') if name.value else '';x.XFree(name)
 rr=U();xx=I();yy=I();ww=C.c_uint();hh=C.c_uint();border=C.c_uint();depth=C.c_uint()
 x.XGetGeometry(d,w,C.byref(rr),C.byref(xx),C.byref(yy),C.byref(ww),C.byref(hh),C.byref(border),C.byref(depth))
 rx=I();ry=I();child=U();x.XTranslateCoordinates(d,w,root,0,0,C.byref(rx),C.byref(ry),C.byref(child))
 return {'id':w,'name':n,'x':rx.value,'y':ry.value,'width':ww.value,'height':hh.value,'depth':depth.value}
def windows():
 r=U();p=U();children=C.POINTER(U)();n=C.c_uint();x.XQueryTree(d,root,C.byref(r),C.byref(p),C.byref(children),C.byref(n))
 result=[window_info(children[i]) for i in range(n.value)];x.XFree(children);return result
def screenshot(path):
 x.XSync(d,False); image=x.XGetImage(d,root,0,0,1080,1920,0xffffffff,2)
 if not image: raise RuntimeError('XGetImage failed')
 try:
  info=image.contents
  if info.width != 1080 or info.height != 1920 or info.bits_per_pixel != 32 or info.byte_order != 0 or (info.red_mask,info.green_mask,info.blue_mask)!=(0xff0000,0xff00,0xff): raise RuntimeError('Unexpected X geometry/pixel layout')
  raw=C.string_at(info.data,info.bytes_per_line*info.height);lines=[]
  for y in range(info.height):
   line=raw[y*info.bytes_per_line:y*info.bytes_per_line+info.width*4]
   rgb=bytearray(info.width*3);rgb[0::3]=line[2::4];rgb[1::3]=line[1::4];rgb[2::3]=line[0::4];lines.append(b'\0'+rgb)
  def chunk(kind,data): return struct.pack('!I',len(data))+kind+data+struct.pack('!I',zlib.crc32(kind+data))
  png=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!IIBBBBB',1080,1920,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(lines),6))+chunk(b'IEND',b'')
  Path(path).write_bytes(png)
 finally:x.XDestroyImage(image)
held_keys={};held_buttons=set();last_input=time.monotonic()
def held():return {'keys':list(held_keys),'buttons':sorted(held_buttons)}
def audit(event,**fields):
 with (run/'logs/input-events.jsonl').open('a') as f:f.write(json.dumps({'time':time.time(),'event':event,'held':held(),**fields},sort_keys=True)+'\n')
def key(name,down):
 global last_input
 k=x.XKeysymToKeycode(d,x.XStringToKeysym(name.encode()))
 if not k:raise RuntimeError('Unknown key '+name)
 if bool(down)==(name in held_keys):raise RuntimeError('Key already in requested state: '+name)
 if not t.XTestFakeKeyEvent(d,k,down,0):raise RuntimeError('XTest key failed')
 if down:held_keys[name]=k
 else:del held_keys[name]
 x.XSync(d,False);last_input=time.monotonic();audit('key_down' if down else 'key_up',key=name,keycode=k)
def button(number,down):
 global last_input
 if not isinstance(number,int) or not 1 <= number <= 9:raise RuntimeError('Invalid button')
 if bool(down)==(number in held_buttons):raise RuntimeError('Button already in requested state: '+str(number))
 if not t.XTestFakeButtonEvent(d,number,down,0):raise RuntimeError('XTest button failed')
 if down:held_buttons.add(number)
 else:held_buttons.remove(number)
 x.XSync(d,False);last_input=time.monotonic();audit('button_down' if down else 'button_up',button=number)
def move(px,py):
 global last_input
 if not isinstance(px,int) or not isinstance(py,int) or not (0 <= px < 1080 and 0 <= py < 1920):raise RuntimeError('Motion must be within full portrait display')
 if not t.XTestFakeMotionEvent(d,0,px,py,0):raise RuntimeError('XTest motion failed')
 x.XSync(d,False);last_input=time.monotonic();audit('move',x=px,y=py)
def release_all(reason):
 before=held();errors=[]
 for number in sorted(held_buttons,reverse=True):
  try:button(number,0)
  except Exception as e:errors.append(repr(e))
 for name in reversed(list(held_keys)):
  try:key(name,0)
  except Exception as e:errors.append(repr(e))
 x.XSync(d,False);audit('release_all',reason=reason,before=before,errors=errors)
 return errors
def combo(parts):
 if not parts or len(parts)!=len(set(parts)):raise RuntimeError('Nonempty distinct keys required')
 if any(k in held_keys for k in parts):raise RuntimeError('Use explicit key_up/down when a combo key is already held')
 for k in parts:key(k,1)
 for k in reversed(parts):key(k,0)
 x.XSync(d,False);time.sleep(.15)
def type_text(text):
 shifted={'_':'minus',':':'semicolon','+':'equal','?':'slash','(':'9',')':'0','!':'1','@':'2','#':'3','$':'4','%':'5','^':'6','&':'7','*':'8','"':'apostrophe','<':'comma','>':'period'}
 normal={' ':'space','/':'slash','.':'period','-':'minus','=':'equal',';':'semicolon',"'":'apostrophe',',':'comma','\\':'backslash','[':'bracketleft',']':'bracketright','\n':'Return'}
 for c in text:
  if c.isupper() and c.isascii():combo(['Shift_L',c.lower()])
  elif c in shifted:combo(['Shift_L',shifted[c]])
  else:combo([normal.get(c,c)])
def stop(signum,frame):raise KeyboardInterrupt('Signal '+str(signum))
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
start=time.time();deadline=time.monotonic()+args.max_seconds;logfile=(run/'logs/gimp-gui-01.log').open('w');p=None;reason='deadline';status=124
try:
 p=subprocess.Popen([str(binary),'-n','--no-splash',str(artwork)],stdout=logfile,stderr=subprocess.STDOUT)
 (run/'gui-start.json').write_text(json.dumps({'pid':p.pid,'display':os.environ['DISPLAY'],'start':start,'requested_executable':str(binary),'executable_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'process_executable':os.readlink('/proc/%d/exe'%p.pid),'process_cmdline':Path('/proc/%d/cmdline'%p.pid).read_bytes().decode().split('\0')[:-1],'input':str(artwork),'input_sha256':hashlib.sha256(artwork.read_bytes()).hexdigest(),'max_seconds':args.max_seconds,'hold_timeout':args.hold_timeout},indent=2))
 while time.monotonic()<deadline:
  if p.poll() is not None:
   reason='application_exit';status=p.returncode;break
  if (held_keys or held_buttons) and time.monotonic()-last_input>args.hold_timeout:
   release_all('held_input_idle_timeout');raise RuntimeError('Held inputs exceeded safety timeout; smoke must be repeated')
  for path in sorted(queue.glob('*.request.json')):
   response=path.with_name(path.name.replace('.request.json','.response.json'))
   if response.exists():continue
   result={'request_path':str(path),'time':time.time(),'held_before':held(),'executed':[]}
   try:
    request=json.loads(path.read_text());result['request']=request
    if len(request.get('actions',[]))>1000:raise RuntimeError('Request action limit exceeded')
    for op in request.get('actions',[]):
     if time.monotonic()>=deadline:raise RuntimeError('GUI deadline reached during request')
     kind=op['op']
     result['executed'].append({'action':op,'time':time.time(),'held_before':held()})
     if kind=='wait':
      seconds=float(op.get('seconds',1))
      if not 0 <= seconds <= 15:raise RuntimeError('Wait must be 0..15 seconds')
      time.sleep(seconds)
     elif kind=='click':
      move(op['x'],op['y']);time.sleep(.1);button(op.get('button',1),1);time.sleep(.08);button(op.get('button',1),0);time.sleep(.2)
     elif kind=='move':move(op['x'],op['y']);time.sleep(.05)
     elif kind=='key':combo(op['keys'])
     elif kind in ('key_down','key_up'):key(op['key'],kind=='key_down');time.sleep(.08)
     elif kind in ('button_down','button_up'):button(op['button'],kind=='button_down');time.sleep(.08)
     elif kind=='release_all':release_all('requested')
     elif kind=='text':type_text(op['text'])
     elif kind=='focus':x.XRaiseWindow(d,op['window']);x.XSetInputFocus(d,op['window'],2,0);x.XSync(d,0)
     elif kind=='resize':x.XMoveResizeWindow(d,op['window'],op['x'],op['y'],op['width'],op['height']);x.XSync(d,0)
     else:raise RuntimeError('Unknown op '+kind)
     result['executed'][-1]['held_after']=held()
    settle=float(request.get('settle',.5))
    if not 0 <= settle <= 5:raise RuntimeError('Settle must be 0..5 seconds')
    time.sleep(settle);result['windows']=windows()
    # Read-only process snapshot ties the captured UI to its executable and
    # actually mapped libraries without injecting or evaluating application code.
    if p.poll() is None:
     result['process_executable']=os.readlink('/proc/%d/exe'%p.pid)
     maps=Path('/proc/%d/maps'%p.pid).read_text()
     maps_path=run/'logs'/(path.name.replace('.request.json','.maps.txt'))
     maps_path.write_text(maps);result['process_maps']=str(maps_path)
    if request.get('capture'):
     name=request['capture']
     if Path(name).name!=name or not name.endswith('.png'):raise RuntimeError('Capture must be a PNG basename')
     capture=run/'screenshots'/name
     if capture.exists():raise RuntimeError('Refusing to replace a raw screenshot')
     screenshot(capture);result['capture']=str(capture);result['capture_sha256']=hashlib.sha256(capture.read_bytes()).hexdigest()
    result['ok']=True
   except Exception as e:result['ok']=False;result['error']=repr(e);release_all('request_error')
   result['held_after']=held()
   response.write_text(json.dumps(result,indent=2))
  time.sleep(.2)
except KeyboardInterrupt as e:reason=str(e);status=130
except Exception as e:reason=repr(e);status=1;raise
finally:
 # SIGTERM/SIGINT and normal failures release buttons before modifiers. SIGKILL
 # cannot run cleanup; the enclosing bounded X server teardown remains the backstop.
 signal.signal(signal.SIGTERM,signal.SIG_IGN);signal.signal(signal.SIGINT,signal.SIG_IGN)
 cleanup_errors=release_all('driver_finally')
 if p is not None and p.poll() is None:
  p.terminate()
  try:p.wait(timeout=10)
  except subprocess.TimeoutExpired:p.kill();p.wait(timeout=5)
 (run/'gui-exit.json').write_text(json.dumps({'exit':p.returncode if p else None,'driver_status':status,'reason':reason,'time':time.time(),'held_after_cleanup':held(),'cleanup_errors':cleanup_errors},indent=2))
 x.XCloseDisplay(d);logfile.close();print('GUI_DRIVER_EXIT',status,reason,flush=True)
raise SystemExit(status)
