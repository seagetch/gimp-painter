#!/usr/bin/env python3
"""Read-only content seals for the exact source and runtime; output is external."""
import argparse,hashlib,json,os,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('kind',choices=['source','runtime']);p.add_argument('root');p.add_argument('output');a=p.parse_args();r=Path(a.root).resolve()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return h.hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(r),*args]).decode().strip()
if a.kind=='source':
 files=[r/os.fsdecode(x) for x in subprocess.check_output(['git','-C',str(r),'ls-files','--recurse-submodules','-z']).split(b'\0') if x]
 result={'commit':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain','--untracked-files=all'),'submodules':git('submodule','status','--recursive')}
else:
 files=sorted(x for base in [r/'bin',r/'lib',r/'libexec',r/'share'] if base.exists() for x in base.rglob('*') if x.is_file() or x.is_symlink());result={}
result.update(kind=a.kind,root=str(r),files=[])
for f in files:
 item={'path':str(f.relative_to(r))}
 if f.is_symlink():item.update(symlink=os.readlink(f))
 elif f.is_file():item.update(bytes=f.stat().st_size,sha256=sha(f))
 else:raise RuntimeError('Missing tracked path '+str(f))
 result['files'].append(item)
Path(a.output).write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
print(json.dumps({'kind':a.kind,'files':len(files),'output':a.output,'sha256':sha(Path(a.output))}))
