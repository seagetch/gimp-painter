#!/bin/bash
# PREPARED ONLY. Parent owns lane grant, final identity handshake, and launch.
set -euo pipefail
: "${1:?accepted published source commit required}"
: "${2:?accepted published source tree required}"
: "${3:?fresh external run directory required}"
[[ "${4:-}" == --parent-gui-lane-granted ]] || { echo 'Explicit parent GUI lane grant required'; exit 2; }
[[ "$1" =~ ^[a-f0-9]{40}$ && "$2" =~ ^[a-f0-9]{40}$ ]] || exit 2
SOURCE=/workspace/shared/gimp-painter-clone-components
BUILD=/workspace/shared/gimp-clone-component-build
PREFIX=/workspace/shared/gimp-clone-component-prefix
PREP=/workspace/shared/gimp-rotation-portrait-gui-prep
RUN="$3"
[[ "$RUN" == "$PREP"/runs/run-* && "$RUN" == "$(realpath -m -- "$RUN")" ]] || exit 2
[[ ! -e "$RUN" ]] || { echo 'Fresh run directory required'; exit 2; }
verify_source() {
  [[ $(git -C "$SOURCE" rev-parse HEAD) == "$1" ]]
  [[ $(git -C "$SOURCE" rev-parse 'HEAD^{tree}') == "$2" ]]
  [[ -z $(git -C "$SOURCE" status --porcelain --untracked-files=all) ]]
}
verify_source "$1" "$2"
exec 9>/workspace/shared/gimp-painter-build.lock
flock -n -x 9 || { echo 'Shared build/GUI lane busy'; exit 3; }
verify_source "$1" "$2"
mkdir -p "$RUN"/{profile/{home,config,cache,data,state,runtime,tmp},logs,screenshots,gui-queue,evidence}
chmod 700 "$RUN"/profile/{home,config,cache,data,state,runtime,tmp}
source /workspace/shared/gimp-portrait-deps/env.sh
export PATH="$PREFIX/bin:$PATH"
export LD_LIBRARY_PATH="$PREFIX/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
export GI_TYPELIB_PATH="$PREFIX/lib/x86_64-linux-gnu/girepository-1.0:$GI_TYPELIB_PATH"
export XDG_DATA_DIRS="$PREFIX/share:$XDG_DATA_DIRS"
export BABL_PATH="$GIMP_DEPS_ROOT/usr/lib/x86_64-linux-gnu/babl-0.1"
export GEGL_PATH="$GIMP_DEPS_ROOT/usr/lib/x86_64-linux-gnu/gegl-0.4"
export HOME="$RUN/profile/home" XDG_CONFIG_HOME="$RUN/profile/config" XDG_CACHE_HOME="$RUN/profile/cache"
export XDG_DATA_HOME="$RUN/profile/data" XDG_STATE_HOME="$RUN/profile/state" XDG_RUNTIME_DIR="$RUN/profile/runtime" TMPDIR="$RUN/profile/tmp"
export LANG=C.UTF-8 LC_ALL=C.UTF-8 PYTHONDONTWRITEBYTECODE=1 CCACHE_DISABLE=1 GIMP_GUI_RUN="$RUN"
unset GSETTINGS_BACKEND GIMP3_DATADIR
cp "$PREP/synthetic-u8-rgb-study.png" "$RUN/"
cp "$PREP/README.md" "$RUN/evidence/prepared-procedure.md"
sha256sum /workspace/shared/gimp-portrait-deps/env.sh > "$RUN/evidence/dependency-env.sha256"
sha256sum "$PREP"/*.py "$PREP"/*.sh "$PREP/synthetic-u8-rgb-study.png" > "$RUN/evidence/executed-helpers.sha256"
printf '%s\n' "$1" > "$RUN/accepted-source-commit.txt"
printf '%s\n' "$2" > "$RUN/accepted-source-tree.txt"
stage=initial
finish() {
  local status=$? seal_status=0
  trap - EXIT
  set +e
  printf '%s\n' "$stage" > "$RUN/final-stage.txt"
  python3 -B "$PREP/seal-files.py" source "$SOURCE" "$RUN/source-after.json" > "$RUN/logs/source-after-seal.log" 2>&1 || seal_status=1
  if [[ -f "$RUN/source-before.json" ]]; then
    cmp "$RUN/source-before.json" "$RUN/source-after.json" > "$RUN/logs/source-final-compare.log" 2>&1 || seal_status=1
  fi
  if [[ -f "$RUN/runtime-before.json" ]]; then
    python3 -B "$PREP/seal-files.py" runtime "$PREFIX" "$RUN/runtime-after.json" > "$RUN/logs/runtime-after-seal.log" 2>&1 || seal_status=1
    cmp "$RUN/runtime-before.json" "$RUN/runtime-after.json" > "$RUN/logs/runtime-final-compare.log" 2>&1 || seal_status=1
    sha256sum "$BUILD/app/gimp-3.0" "$PREFIX/bin/gimp-3.0" > "$RUN/binary-after.sha256" || seal_status=1
    cmp "$RUN/binary-before.sha256" "$RUN/binary-after.sha256" > "$RUN/logs/binary-final-compare.log" 2>&1 || seal_status=1
  fi
  printf '%s\n' "$seal_status" > "$RUN/final-seal-status.txt"
  [[ "$seal_status" == 0 ]] || status=1
  printf '%s\n' "$status" > "$RUN/launcher-status.txt"
  exit "$status"
}
trap finish EXIT
python3 -B "$PREP/seal-files.py" source "$SOURCE" "$RUN/source-before.json" > "$RUN/logs/source-before-seal.log"
stage=build
ninja -C "$BUILD" -j4 > "$RUN/logs/default-build.log" 2>&1
stage=install
meson install --no-rebuild -C "$BUILD" > "$RUN/logs/install.log" 2>&1
[[ -x "$PREFIX/bin/gimp-3.0" ]]
verify_source "$1" "$2"
python3 -B "$PREP/seal-files.py" source "$SOURCE" "$RUN/source-after-build.json" > "$RUN/logs/source-after-build-seal.log"
cmp "$RUN/source-before.json" "$RUN/source-after-build.json"
python3 -B "$PREP/seal-files.py" runtime "$PREFIX" "$RUN/runtime-before.json" > "$RUN/logs/runtime-before-seal.log"
sha256sum "$BUILD/app/gimp-3.0" "$PREFIX/bin/gimp-3.0" > "$RUN/binary-before.sha256"
readelf -n "$PREFIX/bin/gimp-3.0" > "$RUN/logs/installed-build-id.txt"
readelf -n "$BUILD/app/gimp-3.0" > "$RUN/logs/build-build-id.txt"
installed_id=$(sed -n 's/.*Build ID: //p' "$RUN/logs/installed-build-id.txt")
build_id=$(sed -n 's/.*Build ID: //p' "$RUN/logs/build-build-id.txt")
[[ -n "$installed_id" && "$installed_id" == "$build_id" ]] || { echo 'Build/install executable build IDs differ'; exit 1; }
stage=gui
python3 -B "$PREP/run-authenticated-xvfb.py" python3 -B "$PREP/gui-driver.py" --run "$RUN" --binary "$PREFIX/bin/gimp-3.0" --input "$RUN/synthetic-u8-rgb-study.png" > "$RUN/logs/launcher.log" 2>&1
stage=finished
