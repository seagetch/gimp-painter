#!/usr/bin/env python3
"""External bounded loopback-only authenticated portrait display for actual GUI."""
import json,os,signal,socket,subprocess,sys,tempfile,time
from pathlib import Path
run=Path(os.environ['GIMP_GUI_RUN'])
def stop(signum,frame):raise KeyboardInterrupt('Signal '+str(signum))
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
with tempfile.TemporaryDirectory(prefix='xvfb-auth-',dir=os.environ['TMPDIR']) as temp:
 auth=Path(temp)/'authority';auth.touch(mode=0o600)
 empty=Path(temp)/'empty';empty.touch(mode=0o600)
 listener=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
 for number in range(91,191):
  if Path(f'/tmp/.X{number}-lock').exists():continue
  try:listener.bind(('127.0.0.1',6000+number));break
  except OSError:continue
 else:raise RuntimeError('No free loopback display port')
 listener.listen(32);display=f'127.0.0.1:{number}'
 subprocess.run(['xauth','-f',str(auth),'add',display,'MIT-MAGIC-COOKIE-1',os.urandom(16).hex()],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 env=os.environ.copy();env.update(DISPLAY=display,XAUTHORITY=str(auth))
 launcher=f'import os; os.dup2({listener.fileno()},3,inheritable=True); os.environ.update(LISTEN_PID=str(os.getpid()),LISTEN_FDS="1"); os.execvp("Xvfb",["Xvfb"]+__import__("sys").argv[1:])'
 log=(run/'logs/xvfb.log').open('w')
 server=subprocess.Popen([sys.executable,'-c',launcher,f':{number}','-screen','0','1080x1920x24','-auth',str(auth),'-nolisten','tcp','-nolisten','unix','-nolisten','local','-noreset'],env=env,pass_fds=(listener.fileno(),),stdout=log,stderr=subprocess.STDOUT)
 probe='import ctypes; x=ctypes.CDLL("libX11.so.6"); x.XOpenDisplay.restype=ctypes.c_void_p; p=x.XOpenDisplay(None); x.XCloseDisplay.argtypes=[ctypes.c_void_p]; x.XCloseDisplay(p) if p else None; raise SystemExit(0 if p else 1)'
 command=None;status=1
 try:
  for _ in range(30):
   if server.poll() is not None:raise RuntimeError('Xvfb exited during startup')
   try:result=subprocess.run([sys.executable,'-c',probe],env=env,timeout=2,stderr=subprocess.DEVNULL)
   except subprocess.TimeoutExpired:time.sleep(.2);continue
   if result.returncode==0:break
   time.sleep(.2)
  else:raise RuntimeError('Authenticated X client failed')
  bad=env.copy();bad['XAUTHORITY']=str(empty)
  rejected=subprocess.run([sys.executable,'-c',probe],env=bad,timeout=5,stderr=subprocess.DEVNULL)
  if rejected.returncode==0:raise RuntimeError('Unauthenticated X client accepted')
  if listener.getsockname()!=('127.0.0.1',6000+number):raise RuntimeError('Unexpected listener')
  geometry=subprocess.check_output(['xdpyinfo'],env=env,stderr=subprocess.STDOUT).decode()
  (run/'logs/display-info.txt').write_text(geometry)
  if '1080x1920 pixels' not in geometry:raise RuntimeError('Display geometry differs')
  (run/'display-check.json').write_text(json.dumps({'display':display,'listener':['127.0.0.1',6000+number],'width':1080,'height':1920,'depth':24,'authenticated_client_accepted':True,'empty_authority_client_rejected':True,'inherited_systemd_socket':True,'automatic_tcp_unix_local_listeners_disabled':True},indent=2))
  print('AUTHENTICATED_PORTRAIT_DISPLAY_READY',display,flush=True)
  command=subprocess.Popen(sys.argv[1:],env=env,start_new_session=True)
  try:status=command.wait(timeout=1860)
  finally:
   try:os.killpg(command.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:command.wait(timeout=5)
   except subprocess.TimeoutExpired:pass
   time.sleep(.2)
   try:os.killpg(command.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   command.wait()
 finally:
  signal.signal(signal.SIGTERM,signal.SIG_IGN);signal.signal(signal.SIGINT,signal.SIG_IGN)
  server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait()
  listener.close();log.close()
  s=socket.socket();errno=s.connect_ex(('127.0.0.1',6000+number));s.close()
  (run/'display-exit.json').write_text(json.dumps({'command_status':status,'server_status':server.returncode,'shutdown_connect_errno':errno},indent=2))
 raise SystemExit(status)
