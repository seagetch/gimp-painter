#!/usr/bin/env python3
"""Write an inert five-frame drag plan from parent-inspected screen coordinates.

Does not launch GIMP/Xvfb, acquire the shared lane, or send any input. Copy each
request into a live run's gui-queue only when the parent is ready to inspect it.
"""
import argparse, json, math, re
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', required=True, help='Fresh directory inside this preparation directory; never a live gui-queue')
parser.add_argument('--start', nargs=2, required=True, type=int, metavar=('X', 'Y'))
parser.add_argument('--target', nargs=2, required=True, type=int, metavar=('X', 'Y'))
parser.add_argument('--prefix', default='', help='Optional unique attempt prefix for queue and capture basenames')
args = parser.parse_args()
if not re.fullmatch(r'[a-zA-Z0-9_-]{0,40}',args.prefix):
    parser.error('Prefix must contain at most 40 letters, digits, underscores or hyphens')
base = Path(__file__).resolve().parent
out = Path(args.output).resolve()
if base not in out.parents or out.exists() or 'gui-queue' in out.parts:
    parser.error('Use a fresh external template directory inside preparation, not gui-queue')
sx, sy = args.start
tx, ty = args.target
if not all(0 <= x < 1080 and 0 <= y < 1920 for x, y in [(sx, sy), (tx, ty)]):
    parser.error('Coordinates must lie inside 1080x1920')
if math.hypot(tx-sx, ty-sy) < 100:
    parser.error('Choose meaningfully separated safe canvas points, at least 100 screen pixels apart')
nx = tx+1 if tx < 1079 else tx-1
out.mkdir(parents=True)
def move(x, y):return {'op':'move','x':x,'y':y}
def write(number, name, actions, note):
    data = {'purpose':note,'actions':actions,'capture':f'{args.prefix}{number}-{name}.png','settle':.5}
    (out/f'{args.prefix}{number}-{name}.request.json').write_text(json.dumps(data,indent=2)+'\n')
points = [move(round(sx+(tx-sx)*i/12), round(sy+(ty-sy)*i/12)) for i in range(1,13)]
write('010','rotation-free',[
    move(sx,sy),{'op':'key_down','key':'Shift_L'},
    {'op':'button_down','button':2},*points],
    'Actual Shift+middle drag; retain Shift and middle across captures. Inspect nonzero non-15-degree angle and canvas controls.')
write('020','rotation-ctrl-snap',[
    {'op':'key_down','key':'Control_L'},move(nx,ty),move(tx,ty)],
    'Same drag and final pointer: add Ctrl, send genuine motion, inspect a 15-degree multiple. Key event alone is not the assertion.')
write('030','rotation-shift-released',[
    {'op':'key_up','key':'Shift_L'},move(nx,ty),move(tx,ty)],
    'Same drag: release Shift while middle+Ctrl remain. Inspect continued snapped rotation with unchanged anchor.')
write('040','rotation-ctrl-unsnap',[
    {'op':'key_up','key':'Control_L'},move(nx,ty),move(tx,ty)],
    'Same drag: release Ctrl, return to exact target. Inspect original free angle within displayed 0.01-degree precision.')
write('050','rotation-released',[
    {'op':'button_up','button':2},{'op':'release_all'}],
    'Release input; inspect nonzero final angle, complete canvas artwork, on-canvas controls and status. No crop or image compositing.')
(out/'plan.json').write_text(json.dumps({'prepared_only':True,'start':[sx,sy],'target':[tx,ty],'frames':5,'motion_events':19,'prefix':args.prefix,'note':'Parent must choose these coordinates from the live portrait screenshot, away from overlays, and copy requests one at a time. Idle held inputs are released after 120 seconds and invalidate the sequence.'},indent=2)+'\n')
print(str(out))
