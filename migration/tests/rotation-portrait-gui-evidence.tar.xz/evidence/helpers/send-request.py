#!/usr/bin/env python3
"""Submit one ordinary-input GUI request and wait for its recorded response."""
import json, pathlib, sys, time
queue = pathlib.Path(sys.argv[1]) / 'gui-queue'
name = sys.argv[2]
if pathlib.Path(name).name != name or not name.endswith('.request.json'):
    raise SystemExit('Invalid request basename')
target = queue / name
response = queue / name.replace('.request.json', '.response.json')
if target.exists() or response.exists():
    raise SystemExit('Refusing request replacement')
data = json.load(sys.stdin)
temp = queue / (name + '.tmp')
temp.write_text(json.dumps(data, indent=2)+'\n')
temp.rename(target)
deadline = time.monotonic() + 90
while not response.exists():
    if time.monotonic() > deadline:
        raise SystemExit('Response pending after 90 seconds; do not retry blindly')
    time.sleep(.1)
result = json.loads(response.read_text())
print(json.dumps(result, indent=2))
raise SystemExit(0 if result.get('ok') else 1)
