/* Scratch native regression, includes exact frozen production Options TU. */
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <new>
#include <string>
#include <execinfo.h>
namespace fault {
static thread_local bool armed=false;
static thread_local bool reached_observer=false;
static thread_local const std::uint64_t*revision=nullptr;
static thread_local std::uint64_t initial_revision=0;
static thread_local unsigned fail_at=1,attempts=0,hits=0;
static thread_local std::size_t failed_size=0;
static thread_local void*frames[48]{};
static thread_local int depth=0;
}
void*operator new(std::size_t size) {
  if(fault::armed&&(!fault::revision||*fault::revision!=fault::initial_revision)) {
    if(++fault::attempts==fault::fail_at) {
      fault::armed=false;++fault::hits;fault::failed_size=size;
      fault::depth=backtrace(fault::frames,48);throw std::bad_alloc();
    }
  }
  if(void*p=std::malloc(size?size:1))return p;throw std::bad_alloc();
}
void*operator new[](std::size_t size){return ::operator new(size);}
void operator delete(void*p)noexcept{std::free(p);}
void operator delete[](void*p)noexcept{std::free(p);}
void operator delete(void*p,std::size_t)noexcept{std::free(p);}
void operator delete[](void*p,std::size_t)noexcept{std::free(p);}
#include OPTIONS_SOURCE
extern "C" {
#include "widgets/widgets-types.h"
#include "tests/tests.h"
#include "tests/gimp-app-test-utils.h"
}
static void require(bool value,const char*what){if(!value){std::fprintf(stderr,"ASSERTION: %s\n",what);std::exit(2);}}
#include "verify-class.inc"
static Gimp*app;
static unsigned owners_created=0,owners_finalized=0;
static void owner_finalized(gpointer,GObject*){++owners_finalized;}
static void observer_entry(){if(fault::armed&&fault::revision){fault::armed=false;fault::reached_observer=true;}}
static bool fixed=false;
static bool report_scope=false;
static unsigned reports=0;
static void report_log(const gchar*domain,GLogLevelFlags level,const gchar*message,gpointer){
  if(report_scope&&(level&(G_LOG_LEVEL_WARNING|G_LOG_LEVEL_CRITICAL|G_LOG_LEVEL_MESSAGE)))++reports;
  g_log_default_handler(domain,level,message,nullptr);
}
struct State {std::string json,saved;std::uint64_t revision;GimpPainterMybrush*selected;bool dirty,conflict;};
static State snapshot(GimpPainterMybrushOptions*o){return store(o).read<OptionsSlot>([](const OptionsImpl&i){
  return State{i.draft.encode(),i.selected?PainterMybrushRef::retain(i.selected.get()).snapshot().encode():"",i.revision,i.selected.get(),i.dirty,i.conflict};});}
static void unchanged(const State&a,const State&b){require(a.json==b.json&&a.saved==b.saved&&a.revision==b.revision&&a.selected==b.selected&&a.dirty==b.dirty&&a.conflict==b.conflict,"rejected operation leaves model, saved source, revision, selection and flags unchanged");}
struct Observed {
  unsigned json=0,dirty=0,conflict=0,settings=0,requested=0;
  std::string seen_json;
  bool seen_dirty=false;
  static void notify(GObject*object,GParamSpec*spec,gpointer p){
    observer_entry();auto&s=*static_cast<Observed*>(p);
    if(!std::strcmp(spec->name,"painter-settings"))++s.json;
    if(!std::strcmp(spec->name,"painter-dirty"))++s.dirty;
    if(!std::strcmp(spec->name,"painter-conflict"))++s.conflict;
    if(!std::strcmp(spec->name,"stroke-opacity")||!std::strcmp(spec->name,"brushmark-name"))++s.requested;
    // Normal native retrieval, observes the actual committed draft.
    gchar*json=nullptr;gboolean dirty=FALSE;
    g_object_get(object,"painter-settings",&json,"painter-dirty",&dirty,nullptr);
    require(json!=nullptr,"observer can retrieve JSON");s.seen_json=json;s.seen_dirty=dirty;g_free(json);
  }
  static void settings_changed(GimpPainterMybrushOptions*o,gpointer p){observer_entry();auto&s=*static_cast<Observed*>(p);++s.settings;
    auto state=snapshot(o);s.seen_json=state.json;s.seen_dirty=state.dirty;}
  void connect(GimpPainterMybrushOptions*o){g_signal_connect(o,"notify",G_CALLBACK(notify),this);g_signal_connect(o,"settings-changed",G_CALLBACK(settings_changed),this);}
  void disconnect(GimpPainterMybrushOptions*o){g_signal_handlers_disconnect_by_data(o,this);}
  void clear(){json=dirty=conflict=settings=requested=0;seen_json.clear();seen_dirty=false;}
};
static GimpPainterMybrushOptions*options_new(){auto*o=GIMP_PAINTER_MYBRUSH_OPTIONS(g_object_new(GIMP_TYPE_PAINTER_MYBRUSH_OPTIONS,"gimp",app,nullptr));require(o&&!o->binding_failed,"actual Options constructed with active native binding");++owners_created;g_object_weak_ref(G_OBJECT(o),owner_finalized,nullptr);g_object_set(o,"name","Options native inherited property control",nullptr);gchar*name=nullptr;Gimp*got_app=nullptr;g_object_get(o,"name",&name,"gimp",&got_app,nullptr);require(g_strcmp0(name,"Options native inherited property control")==0&&got_app==app,"native inherited name and construct gimp property dispatch");g_free(name);g_clear_object(&got_app);return o;}
static void arm(GimpPainterMybrushOptions*o,bool after_commit,unsigned at=1){
  fault::revision=after_commit?store(o).read<OptionsSlot>([](const OptionsImpl&i){return &i.revision;}):nullptr;
  fault::initial_revision=fault::revision?*fault::revision:0;fault::attempts=fault::hits=0;fault::failed_size=0;fault::depth=0;fault::fail_at=at;fault::reached_observer=false;fault::armed=true;
}
static void disarm(const char*test){fault::armed=false;fault::revision=nullptr;
  std::printf("fault case=%s hits=%u attempts=%u allocation_size=%zu frames=%d reached_observer=%u\n",test,fault::hits,fault::attempts,fault::failed_size,fault::depth,fault::reached_observer);
  if(fault::depth)backtrace_symbols_fd(fault::frames,fault::depth,1);
}
static std::string candidate_json(){return "{\"version\":3,\"settings\":{\"stroke_opacity\":{\"base_value\":0.374,\"inputs\":{}}},\"switches\":{\"use_gimp_brushmark\":true,\"brushmark_specified\":true,\"use_gimp_texture\":true,\"texture_specified\":true},\"texts\":{\"brushmark_name\":\"a deliberately long native resource text allocation to probe\",\"texture_name\":\"another deliberately long missing native pattern name\"},\"fixture_unknown\":{\"preserve\":73}}";}
static void recover(GimpPainterMybrushOptions*o,Observed&seen){seen.clear();g_object_set(o,"stroke-opacity",0.627,nullptr);
  double value=0;g_object_get(o,"stroke-opacity",&value,nullptr);
  require(value==0.627&&seen.json==1&&seen.dirty==1&&seen.conflict==1&&seen.settings==1&&seen.requested==1,"follow-on native property edit recovers with full expected notification batch");
  require(seen.seen_json==snapshot(o).json&&seen.seen_dirty,"observers see recovered draft");}
static void postcommit(const char*path){
  auto*o=options_new();Observed seen;seen.connect(o);const auto before=snapshot(o);const auto input=candidate_json();const auto expected=Resource::decode(input).encode();GError*error=nullptr;
  report_scope=true;reports=0;arm(o,true);gboolean result=TRUE;
  if(!std::strcmp(path,"checked"))result=gimp_painter_mybrush_options_set_json(o,input.c_str(),&error);
  else if(!std::strcmp(path,"json-property"))g_object_set(o,"painter-settings",input.c_str(),nullptr);
  else g_object_set(o,"stroke-opacity",0.374,nullptr);
  disarm(path);report_scope=false;const auto after=snapshot(o);
  const bool changed=after.json!=before.json;
  std::printf("postcommit path=%s checked_return=%d error=%s changed=%u revision_delta=%llu dirty=%u json_notify=%u dirty_notify=%u conflict_notify=%u settings_changed=%u requested_notify=%u diagnostics=%u\n",path,result,error?error->message:"none",changed,(unsigned long long)(after.revision-before.revision),after.dirty,seen.json,seen.dirty,seen.conflict,seen.settings,seen.requested,reports);
  require(after.saved==before.saved&&after.selected==before.selected&&!after.conflict,"postcommit keeps saved source, selection and conflict coherent");
  if(!fixed){require(fault::hits==1&&changed&&after.dirty&&after.revision==before.revision+1,"baseline injected after real draft commit");
    require(seen.settings==0&&seen.dirty==0&&seen.conflict==0,"baseline loses explicit settings/state notification after commit");
    if(!std::strcmp(path,"checked"))require(!result&&error&&seen.json==0,"baseline checked API reports failure after committed change");
    else if(!std::strcmp(path,"json-property"))require(seen.json==1,"native implicit requested JSON notify remains after failure");
    else require(seen.requested==1&&seen.json==0,"native implicit requested numeric notify remains after failure");
  } else {
    // Test-owned native observers close the gate before allocating their own readback.
    require(!fault::hits&&fault::attempts==0&&fault::reached_observer,"no C++ allocation between actual commit and first native observer");
    require(result&&!error&&changed&&after.dirty,"fixed operation reports coherent committed success");
    require(seen.settings==1&&seen.json==1&&seen.dirty==1&&seen.conflict==1,"fixed committed draft emits complete settings and state notifications");
    require(seen.seen_json==after.json&&seen.seen_dirty,"fixed listeners observe committed state");
  }
  if(std::strcmp(path,"scalar-property"))require(after.json==expected,"JSON replacement preserves complete resource bytes");
  g_clear_error(&error);recover(o,seen);seen.disconnect(o);g_object_unref(o);
}
static void malformed(bool null_input){auto*o=options_new();Observed seen;seen.connect(o);auto before=snapshot(o);
  reports=0;report_scope=true;g_object_set(o,"painter-settings",null_input?nullptr:"{ malformed ",nullptr);report_scope=false;
  unchanged(before,snapshot(o));require(seen.json==1&&!seen.settings&&!seen.dirty&&!seen.conflict,"rejected JSON retains native automatic requested-property notify only");
  if(fixed)require(reports>0,"fixed invalid JSON has bounded diagnostic channel");
  std::printf("invalid_json null=%u unchanged=1 json_notify=%u settings_changed=%u diagnostics=%u\n",null_input,seen.json,seen.settings,reports);
  recover(o,seen);seen.disconnect(o);g_object_unref(o);}
static void precommit(bool text){auto*o=options_new();Observed seen;seen.connect(o);auto before=snapshot(o);
  reports=0;report_scope=true;arm(o,false);
  if(text)g_object_set(o,"brushmark-name","a long replacement text proving Resource copy failure is prior to mutation",nullptr);
  else g_object_set(o,"stroke-opacity",0.374,nullptr);
  disarm(text?"precommit-text":"precommit-numeric");report_scope=false;require(fault::hits==1,"precommit allocation gate hit");unchanged(before,snapshot(o));
  require(seen.requested==1&&!seen.settings&&!seen.json&&!seen.dirty&&!seen.conflict,"failed copy gets native requested-property notify only");
  if(fixed)require(reports>0,"fixed allocation failure has bounded diagnostic channel");
  std::printf("precommit text=%u unchanged=1 requested_notify=%u settings_changed=%u diagnostics=%u\n",text,seen.requested,seen.settings,reports);
  recover(o,seen);seen.disconnect(o);g_object_unref(o);}
static void getter(bool text,bool prefilled){auto*o=options_new();auto json=candidate_json();require(gimp_painter_mybrush_options_set_json(o,json.c_str(),nullptr),"long JSON seed");const auto before=snapshot(o);
  GValue value=G_VALUE_INIT;if(prefilled){g_value_init(&value,G_TYPE_STRING);g_value_set_string(&value,"native GLib must reset this prior owned string");}
  reports=0;report_scope=true;arm(o,false);g_object_get_property(G_OBJECT(o),text?"brushmark-name":"painter-settings",&value);disarm(text?"getter-text":"getter-json");report_scope=false;
  require(fault::hits==1,"getter real allocating path hit");require(G_VALUE_HOLDS_STRING(&value)&&g_value_get_string(&value)==nullptr,"native getter returns typed NULL, replacing prefilled value safely");g_value_unset(&value);unchanged(before,snapshot(o));
  if(fixed)require(reports>0,"fixed getter failure has bounded diagnostic channel");
  g_object_get_property(G_OBJECT(o),text?"brushmark-name":"painter-settings",&value);require(G_VALUE_HOLDS_STRING(&value)&&g_value_get_string(&value)!=nullptr,"getter succeeds after failed allocation");
  require(text?std::string(g_value_get_string(&value))=="a deliberately long native resource text allocation to probe":std::string(g_value_get_string(&value))==before.json,"successful getter exact content");g_value_unset(&value);
  std::printf("getter text=%u prefilled=%u typed_null=1 unchanged=1 recovery=1 diagnostics=%u\n",text,prefilled,reports);g_object_unref(o);}

struct Reentry {bool fired=false;unsigned calls=0;bool close=false;};
static void settings_reenter(GimpPainterMybrushOptions*o,gpointer p){auto&r=*static_cast<Reentry*>(p);++r.calls;if(r.fired)return;r.fired=true;
  if(r.close)require(gimp_painter_binding_close(G_OBJECT(o),nullptr),"settings observer closes binding");
  else g_object_set(o,"stroke-opacity",0.819,nullptr);
}
static void notify_closes(GObject*o,GParamSpec*,gpointer p){auto&r=*static_cast<Reentry*>(p);++r.calls;if(r.fired)return;r.fired=true;require(gimp_painter_binding_close(o,nullptr),"property observer closes binding");}
static void reentry(unsigned kind){auto*o=options_new();Observed seen;seen.connect(o);const auto before=snapshot(o);Reentry state;state.close=kind==1;
  if(kind<2)g_signal_connect(o,"settings-changed",G_CALLBACK(settings_reenter),&state);
  else g_signal_connect(o,"notify::opaque",G_CALLBACK(notify_closes),&state);
  const auto input=candidate_json();GError*error=nullptr;require(gimp_painter_mybrush_options_set_json(o,input.c_str(),&error)&&!error,"checked setter survives observer reentry");
  require(state.fired,"native observer reentered");const auto after=snapshot(o);
  if(kind==0){require(state.calls==2&&seen.settings==2&&after.revision==before.revision+2,"nested settings edit has two coherent committed revisions");double value=0;g_object_get(o,"stroke-opacity",&value,nullptr);require(value==0.819&&seen.seen_json==after.json,"nested edit owns final draft and observer state");}
  else {require(store(o).state()==BindingStore::State::closed,"reentrant close remains closed");require(after.revision==before.revision+1,"close retains exactly committed revision");
    if(kind==1)require(state.calls==1&&seen.settings==1,"settings close completes without repeat emission");
    else require(state.calls==1&&!seen.settings&&!seen.json&&!seen.dirty&&!seen.conflict,"generation check cancels stale notifications after property close");}
  std::printf("reentry kind=%s calls=%u settings_changed=%u revision_delta=%llu accepted=1\n",kind==0?"settings-edit":kind==1?"settings-close":"notify-close",state.calls,seen.settings,(unsigned long long)(after.revision-before.revision));
  g_signal_handlers_disconnect_by_data(o,&state);seen.disconnect(o);g_object_unref(o);
}

int main(int argc,char**argv){std::setvbuf(stdout,nullptr,_IONBF,0);fixed=argc>1&&!std::strcmp(argv[1],"fixed");
  gegl_init(nullptr,nullptr);g_log_set_default_handler(report_log,nullptr);require(g_getenv("GIMP3_DIRECTORY"),"isolated synthetic profile configured");app=gimp_init_for_testing();require(app,"native application setup");
  auto*klass=static_cast<GObjectClass*>(g_type_class_ref(GIMP_TYPE_PAINTER_MYBRUSH_OPTIONS));auto*parent=static_cast<GObjectClass*>(g_type_class_ref(GIMP_TYPE_PAINT_OPTIONS));guint parent_count=0;auto**listed=g_object_class_list_properties(parent,&parent_count);g_free(listed);
  verify_class(klass,GIMP_TYPE_PAINTER_MYBRUSH_OPTIONS,parent_count);GParamSpec*before_specs[PROP_CONFLICT+1];std::memcpy(before_specs,properties,sizeof before_specs);
  std::printf("fixture=Options mode=%s GLib=%u.%u.%u production_class=%s own_properties=%u\n",fixed?"fixed":"baseline",glib_major_version,glib_minor_version,glib_micro_version,G_OBJECT_CLASS_NAME(klass),PROP_CONFLICT);
  postcommit("checked");postcommit("json-property");postcommit("scalar-property");malformed(false);malformed(true);precommit(false);precommit(true);
  getter(false,false);getter(false,true);getter(true,false);getter(true,true);reentry(0);reentry(1);reentry(2);
  require(std::memcmp(before_specs,properties,sizeof before_specs)==0,"native property identities unchanged across failures");verify_class(klass,GIMP_TYPE_PAINTER_MYBRUSH_OPTIONS,parent_count);
  require(owners_created==owners_finalized,"all explicitly created Options finalize exactly once");std::printf("outcome=pass cases=14 class_metadata=unchanged inherited_properties=pass recovery=pass owners_created=%u owners_finalized=%u\n",owners_created,owners_finalized);g_type_class_unref(klass);g_type_class_unref(parent);gimp_exit(app,TRUE);return 0;}
