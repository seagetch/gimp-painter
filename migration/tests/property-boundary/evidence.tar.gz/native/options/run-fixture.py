from pathlib import Path
import json,os,subprocess,time,shutil,tempfile,sys,hashlib
out=Path(__file__).resolve().parent;root=out.parent;build=root/'gimp-native-restore-20261009/build-http'
test=next(t for t in json.loads((build/'meson-info/intro-tests.json').read_text()) if t['name']=='gimp-painter-options')
env=dict(os.environ,**test['env']);env['LD_LIBRARY_PATH']=test['env']['LD_LIBRARY_PATH']+':'+os.environ.get('LD_LIBRARY_PATH','')
env['ASAN_OPTIONS']='detect_leaks=0:abort_on_error=1';env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
results=[]
for variant in sys.argv[1:] or ['baseline']:
 binary=out/(variant+'-native' if (out/variant).is_dir() else variant)
 profile=Path(tempfile.mkdtemp(prefix=variant+'-profile-',dir=out));shutil.copytree(root/'gimp-painter-port-active/app/tests/gimpdir',profile,dirs_exist_ok=True)
 run_env=dict(env,GIMP3_DIRECTORY=str(profile));command=[str(binary),'fixed' if variant.startswith('fixed') else 'baseline'];start=time.monotonic()
 try:
  p=subprocess.run(command,cwd=build,env=run_env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90);text=p.stdout;code=p.returncode;timed_out=False
 except subprocess.TimeoutExpired as e:
  text=e.stdout or '';text=text.decode() if isinstance(text,bytes) else text;code=None;timed_out=True
 log=out/(variant+'.run.log');log.write_text(text)
 result={'variant':variant,'command':command,'exit_code':code,'timed_out':timed_out,'seconds':round(time.monotonic()-start,3),'profile':str(profile),'log':str(log),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'ASAN_OPTIONS':run_env['ASAN_OPTIONS'],'UBSAN_OPTIONS':run_env['UBSAN_OPTIONS']};results.append(result);(out/(variant+'-result.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);print(text[-3500:],flush=True)
 if code!=0:raise SystemExit(1)
