from pathlib import Path
import hashlib,json,re,subprocess
out=Path(__file__).resolve().parent
variants=[n for n in ('baseline','baseline-san','fixed','fixed-san') if (out/(n+'.run.log')).exists()]
summary=[]
for name in variants:
 binary=out/(name+'-native' if (out/name).is_dir() else name)
 log=(out/(name+'.run.log')).read_text();offsets=list(dict.fromkeys(re.findall(r'/'+re.escape(binary.name)+r'\(\+0x([0-9a-f]+)\)',log)))
 sym=out/(name+'-symbolized-sites.txt')
 with sym.open('w') as f:
  for offset in offsets:
   f.write('return offset 0x'+offset+'; symbolize preceding instruction\n')
   f.write(subprocess.check_output(['addr2line','-C','-f','-i','-e',str(binary),hex(int(offset,16)-1)],text=True))
 summary.append({'variant':name,'result':json.loads((out/(name+'-result.json')).read_text()),'results':[line for line in log.splitlines() if re.match(r'^(fixture=|postcommit |invalid_json |precommit |getter |reentry |outcome=)',line)],'build':json.loads((out/(name+'-commands.json')).read_text())})
(out/'summary.json').write_text(json.dumps({'variants':summary,'sanitizer_scope':'Options TU and harness instrumented; linked native Resource and dependency archives uninstrumented. LSan disabled due ptrace, vptr excluded for no-RTTI native code. Explicit Options weak-finalization counters are independent of sanitizers.','scope':'14 native Options cases; no tracked code edits, no signal dispatcher work, no entire migration completion claim.'},indent=2)+'\n')
files=[p for p in out.iterdir() if p.is_file() and p.name not in ('SHA256SUMS','property-options-evidence.zip') and p.suffix!='.o']
(out/'SHA256SUMS').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(files)))
print('sealed',len(files),'files;',len(variants),'variants')
