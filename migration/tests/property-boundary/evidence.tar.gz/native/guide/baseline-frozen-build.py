from pathlib import Path
import json,shlex,subprocess,hashlib,sys
out=Path(__file__).resolve().parent
base=out.parent;repo=base/'gimp-painter-port-active';build=base/'gimp-native-restore-20261009/build-http'
entry=next(x for x in json.loads((build/'compile_commands.json').read_text()) if x['file'].endswith('/gimp-painter-options.cpp'))
flags=shlex.split(entry['command'])[1:];flags=flags[:flags.index('-MD')]
s=(build/'build.ninja').read_text();start=s.index('build app/tests/gimp-painter-options:');block=s[start:s.index('\n\n',start)]
link=shlex.split(block.split(' LINK_ARGS = ',1)[1].strip().replace('$$','$'))
variant=sys.argv[1] if len(sys.argv)>1 else 'baseline'
san=['-fsanitize=address,undefined','-fno-sanitize=vptr','-fno-omit-frame-pointer'] if 'san' in variant else []
commands=[['c++',*flags,*san,'-o',str(out/(variant+'.o')),'-c',str(out/'native-guide.cpp')],['c++',*san,'-o',str(out/variant),str(out/(variant+'.o')),'app/tests/gimp-painter-options.p/tests.c.o',*link]]
(out/(variant+'-commands.json')).write_text(json.dumps(commands,indent=2)+'\n')
(out/(variant+'-guideundo.cpp')).write_bytes((repo/'app/core/gimpperspectiveguideundo.cpp').read_bytes())
for label,command in zip(['compile','link'],commands):
 with (out/(variant+'-'+label+'.log')).open('w') as f:r=subprocess.run(command,cwd=build,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
