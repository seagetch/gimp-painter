from pathlib import Path
import os,json,subprocess,hashlib,re,time
out=Path(__file__).resolve().parent;root=out.parent;build=root/'gimp-native-restore-20261009/build-http'
tests=json.loads((build/'meson-info/intro-tests.json').read_text());results=[]
for name in ['gimp-painter-options','painter-perspective','painter-mypaint-resource','gimp-painter-session']:
 t=next(t for t in tests if t['name']==name);env=dict(os.environ,**t['env'])
 env['LD_LIBRARY_PATH']=t['env'].get('LD_LIBRARY_PATH','')+':'+os.environ.get('LD_LIBRARY_PATH','')
 start=time.monotonic();r=subprocess.run(t['cmd'],cwd=build,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
 log=out/('native-'+name+'.log');log.write_text(r.stdout)
 row={'name':name,'command':t['cmd'],'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3),'passed':len(re.findall(r'^ok \d+',r.stdout,re.M)),'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(Path(t['cmd'][0]).read_bytes()).hexdigest()}
 results.append(row);(out/'native-tests.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
