#include "config.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <gegl.h>
#include <gtk/gtk.h>
extern "C" {
#include "libgimpbase/gimpbase.h"
#include "core/core-types.h"
#include "widgets/widgets-types.h"
#include "core/gimp.h"
#include "core/gimpimage.h"
#include "core/gimpfilterlayer.h"
#include "core/gimpclonelayer.h"
#include "core/gimpperspectiveguide.h"
#include "paint/gimpfillbrush.h"
#include "paint/gimppaintersmudge.h"
#include "paint/painter-mypaint-surface/gimp-painter-session.h"
#include "operations/gimpoperationmaskcomponents.h"
#include "painter/gimp-painter-binding.h"
#include "tests/tests.h"
#include "tests/gimp-app-test-utils.h"
}
static unsigned reports=0,requested=0,changed=0,finalized=0;
static GObject *release_on_report=nullptr;
static void log_report(const gchar*d,GLogLevelFlags l,const gchar*m,gpointer){
 if((l&G_LOG_LEVEL_WARNING)&&g_str_has_prefix(m,"Painter property "))++reports;
 if(release_on_report){auto *old=release_on_report;release_on_report=nullptr;g_object_unref(old);}
 g_log_default_handler(d,l,m,nullptr);
}
static void notified(GObject*,GParamSpec*,gpointer){++requested;}
static void modified(GObject*,gpointer){++changed;}
static void destroyed(gpointer,GObject*){++finalized;}
static void require(bool b,const char*m){if(!b){std::fprintf(stderr,"ASSERTION: %s\n",m);std::exit(2);}}
static void scalar(GType type,Gimp*app,const char*name,double first,double rejected,bool guide){
 auto*o=G_OBJECT(guide?g_object_new(type,nullptr):g_object_new(type,"gimp",app,nullptr));
 auto*klass=G_OBJECT_GET_CLASS(o);auto*spec=g_object_class_find_property(klass,name);
 require(spec!=nullptr,"real property registered");
 g_signal_connect(o,"notify",G_CALLBACK(notified),nullptr);
 if(guide)g_signal_connect(o,"changed",G_CALLBACK(modified),nullptr);
 requested=changed=reports=0;g_object_set(o,name,first,nullptr);double value=0;g_object_get(o,name,&value,nullptr);
 require(value==first&&requested==1&&(!guide||changed==1),"native scalar set and notifications");
 require(gimp_painter_binding_close(o,nullptr),"close native slot");requested=changed=reports=0;
 g_object_set(o,name,rejected,nullptr);g_object_get(o,name,&value,nullptr);
 require(value==first&&requested==1&&changed==0&&reports==1,"closed setter reports, preserves state, native implicit notify and readable value");
 require(g_object_class_find_property(klass,name)==spec,"property registration identity unchanged");
 std::printf("scalar type=%s property=%s normal=pass closed=pass reports=%u\n",g_type_name(type),name,reports);g_object_unref(o);
}
int main(){
 std::setvbuf(stdout,nullptr,_IONBF,0);gegl_init(nullptr,nullptr);g_log_set_default_handler(log_report,nullptr);
 auto*app=gimp_init_for_testing();
 scalar(GIMP_TYPE_FILL_BRUSH_OPTIONS,app,"rate",31,52,false);
 scalar(GIMP_TYPE_PAINTER_SMUDGE_OPTIONS,app,"rate",31,52,false);
 scalar(GIMP_TYPE_PERSPECTIVE_GUIDE,app,"angle",0.4,0.8,true);
 auto*lease_guide=gimp_perspective_guide_new(73);auto*weak_guide=lease_guide;
 g_object_add_weak_pointer(G_OBJECT(lease_guide),reinterpret_cast<gpointer*>(&weak_guide));
 gimp_painter_binding_close(G_OBJECT(lease_guide),nullptr);release_on_report=G_OBJECT(lease_guide);
 g_object_set(lease_guide,"angle",0.9,nullptr);require(!weak_guide&&!release_on_report,"diagnostic callback may drop last caller ref safely");
 std::puts("diagnostic owner release=pass");
 auto*options=GIMP_PAINTER_MYBRUSH_OPTIONS(g_object_new(GIMP_TYPE_PAINTER_MYBRUSH_OPTIONS,"gimp",app,nullptr));
 auto*session=gimp_painter_session_new(options,nullptr);require(session,"native session");
 GimpPainterMybrushOptions*returned=nullptr;gboolean active=TRUE;gchar*message=nullptr;
 g_object_get(session,"options",&returned,"active",&active,"error",&message,nullptr);
 require(returned==options&&!active&&!message,"retained construct options and session status getters");g_clear_object(&returned);g_free(message);
 g_object_unref(session);g_object_unref(options);std::puts("session properties=pass");
 auto*image=gimp_image_new(app,8,8,GIMP_RGB,GIMP_PRECISION_U8_NON_LINEAR);
 auto*clone=gimp_clone_layer_new(image,nullptr,8,8,"synthetic clone",1,GIMP_LAYER_MODE_NORMAL_LEGACY);if(g_object_is_floating(clone))g_object_ref_sink(clone);
 gboolean failed=TRUE;g_object_get(clone,"binding-failed",&failed,nullptr);require(!failed,"clone scalar getter");g_object_unref(clone);
 auto*operation=G_OBJECT(g_object_new(GIMP_TYPE_OPERATION_MASK_COMPONENTS,"alpha",0.375,nullptr));
 double alpha=0;g_object_get(operation,"alpha",&alpha,nullptr);require(alpha==0.375,"native operation double property");g_object_unref(operation);std::puts("native scalar adapters=pass");
 auto*filter=GIMP_FILTER_LAYER(gimp_filter_layer_new(image,8,8,"synthetic filter",1,GIMP_LAYER_MODE_NORMAL_LEGACY));if(g_object_is_floating(filter))g_object_ref_sink(filter);
 auto*object=G_OBJECT(g_object_new(G_TYPE_OBJECT,nullptr));g_object_weak_ref(object,destroyed,nullptr);
 GObject*array[]={G_OBJECT(image),object,nullptr};
 auto*args=gimp_value_array_new_from_types(nullptr,GIMP_TYPE_CORE_OBJECT_ARRAY,array,G_TYPE_NONE);
 auto*bytes=g_bytes_new_static("synthetic raw",13);
 require(gimp_filter_layer_set_definition(filter,"future-array-procedure",bytes,args,nullptr),"stored filter object array");gimp_value_array_unref(args);
 GValue value=G_VALUE_INIT;g_object_get_property(G_OBJECT(filter),"filter-arguments",&value);
 require(G_VALUE_HOLDS(&value,GIMP_TYPE_VALUE_ARRAY)&&g_value_get_boxed(&value),"owning array getter succeeds");g_value_unset(&value);
 g_object_unref(object);require(finalized==1,"getter leaves no retained object after unset");reports=0;
 g_value_init(&value,GIMP_TYPE_VALUE_ARRAY);g_object_get_property(G_OBJECT(filter),"filter-arguments",&value);
 require(G_VALUE_HOLDS(&value,GIMP_TYPE_VALUE_ARRAY)&&!g_value_get_boxed(&value)&&reports==1,"expired owning array getter typed NULL with diagnostic");g_value_unset(&value);
 GBytes*raw=nullptr;gchar*procedure=nullptr;g_object_get(filter,"filter-original-definition",&raw,"filter-procedure",&procedure,nullptr);
 require(raw&&g_bytes_equal(raw,bytes)&&g_strcmp0(procedure,"future-array-procedure")==0,"failure preserves raw definition and procedure");g_bytes_unref(raw);g_free(procedure);
 auto*recovery=gimp_value_array_new_from_types(nullptr,G_TYPE_INT,73,G_TYPE_NONE);
 require(gimp_filter_layer_set_definition(filter,"future-scalar-procedure",bytes,recovery,nullptr),"filter subsequent valid definition");gimp_value_array_unref(recovery);
 g_object_get_property(G_OBJECT(filter),"filter-arguments",&value);
 auto*copy=static_cast<GimpValueArray*>(g_value_get_boxed(&value));require(copy&&g_value_get_int(gimp_value_array_index(copy,0))==73,"owning getter recovery");g_value_unset(&value);
 g_bytes_unref(bytes);g_object_unref(filter);g_object_unref(image);
 std::puts("filter owning getter=pass expired_cleanup=pass recovery=pass");std::puts("outcome=pass controls=8");gimp_exit(app,TRUE);return 0;
}
