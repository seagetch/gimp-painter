from pathlib import Path
import json,os,subprocess,shutil,tempfile,sys
out=Path(__file__).resolve().parent;build=out.parent/'gimp-native-restore-20261009/build-http'
test=next(t for t in json.loads((build/'meson-info/intro-tests.json').read_text()) if t['name']=='gimp-painter-options')
env=dict(os.environ,**test['env']);env['LD_LIBRARY_PATH']=test['env']['LD_LIBRARY_PATH']+':'+os.environ.get('LD_LIBRARY_PATH','')
variant=sys.argv[1];sites=sys.argv[2:]
env['ASAN_OPTIONS']='detect_leaks=0:abort_on_error=1'
env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
results=[]
for item in sites or ["0"]:
 args=item.split(":");site=int(args[0]);label="-".join(args)
 profile=Path(tempfile.mkdtemp(prefix='guide-profile-',dir=out))
 shutil.copytree(out.parent/'gimp-painter-port-active/app/tests/gimpdir',profile,dirs_exist_ok=True)
 runenv=dict(env,GIMP3_DIRECTORY=str(profile))
 r=subprocess.run([str(out/variant),*args],cwd=build,env=runenv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30)
 (out/f'{variant}-{label}.log').write_text(r.stdout)
 results.append({'site':site,'arguments':args,'exit_code':r.returncode,'log':f'{variant}-{label}.log'})
 print(site,r.returncode,r.stdout[r.stdout.find('result fail_at='):][-1000:],flush=True)
(out/(variant+'-results.json')).write_text(json.dumps(results,indent=2)+'\n')
