#include "config.h"
#include <cstdio>
#include <cstdlib>
#include <new>
#include <execinfo.h>
#include <gegl.h>
#include <gtk/gtk.h>
extern "C" {
#include "core/core-types.h"
#include "widgets/widgets-types.h"
#include "core/gimp.h"
#include "core/gimpimage.h"
#include "core/gimpimage-undo.h"
#include "core/gimpundostack.h"
#include "core/gimpimage-perspective-guide.h"
#include "tests/tests.h"
#include "tests/gimp-app-test-utils.h"
}
namespace fault {
thread_local bool armed=false;
thread_local unsigned attempts=0, fail_at=0;
thread_local bool hit=false;
}
void *operator new(std::size_t size) {
  if(fault::armed && ++fault::attempts==fault::fail_at) {
    fault::armed=false; fault::hit=true;
    std::fprintf(stderr,"allocation_failure index=%u bytes=%zu\n",fault::attempts,size);
    void *trace[24];int n=backtrace(trace,24);backtrace_symbols_fd(trace,n,2);
    throw std::bad_alloc();
  }
  if(void*p=std::malloc(size?size:1))return p;
  throw std::bad_alloc();
}
void *operator new[](std::size_t size){return ::operator new(size);}
void operator delete(void*p)noexcept{std::free(p);}
void operator delete[](void*p)noexcept{std::free(p);}
void operator delete(void*p,std::size_t)noexcept{std::free(p);}
void operator delete[](void*p,std::size_t)noexcept{std::free(p);}
int main(int argc,char**argv) {
  std::setvbuf(stdout,nullptr,_IONBF,0);
  gegl_init(nullptr,nullptr);
  auto*gimp=gimp_init_for_testing();
  auto*image=gimp_image_new(gimp,32,32,GIMP_RGB,GIMP_PRECISION_U8_NON_LINEAR);
  auto*before=gimp_perspective_guide_new(42);
  auto*current=gimp_perspective_guide_new(99);
  gimp_perspective_guide_add_vanish_points(before,1,2);
  gimp_perspective_guide_add_vanish_points(current,10,20);
  gimp_image_set_perspective_guide(image,current);
  fault::fail_at=argc>1?std::strtoul(argv[1],nullptr,10):0;
  fault::armed=true;
  bool escaped=false;
  try {gimp_image_perspective_guide_push_undo(image,before,"Synthetic snapshot");}
  catch(...){escaped=true;}
  fault::armed=false;
  int depth=gimp_undo_stack_get_depth(gimp_image_get_undo_stack(image));
  bool unchanged=gimp_image_get_perspective_guide(image)==current;
  gimp_image_undo(image);
  auto*restored=gimp_image_get_perspective_guide(image);
  guint id=0;if(restored)g_object_get(restored,"id",&id,nullptr);
  std::printf("result fail_at=%u attempts=%u hit=%u escaped=%u depth=%d before_undo_unchanged=%u after_undo_null=%u after_undo_id=%u\n",
    fault::fail_at,fault::attempts,fault::hit,escaped,depth,unchanged,!restored,id);
  g_object_unref(before);g_object_unref(current);g_object_unref(image);gimp_exit(gimp,TRUE);
  return escaped?2:0;
}
