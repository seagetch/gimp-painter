#!/usr/bin/env python3
"""Verify delivered bytes and reclassify unchanged results, without native rerun.
Optional --originals checks exact env-only transforms against locally retained
private artifacts. Original environment values are never printed or copied.
"""
import argparse, copy, hashlib, json, types
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('evidence',type=Path);p.add_argument('--originals',type=Path);a=p.parse_args();root=a.evidence
read=lambda name:json.loads((root/name).read_bytes())
sha=lambda body:hashlib.sha256(body).hexdigest()
def remove_environment_span(raw, start, end):
 prefix=b''.join(raw.splitlines(keepends=True)[:2])
 marker=b'==================================== 1/13 ====================================\n'
 assert raw.startswith(b'Log of Meson test suite run on ') and start==len(prefix)
 assert raw[start:].startswith(b'Inherited environment:') and end>start
 assert raw[end:].startswith(marker)
 return raw[:start]+raw[end:]

manifest=read('publication-manifest.json')
for name,row in manifest['artifacts'].items():
 body=(root/name).read_bytes();assert sha(body)==row['published_sha256'] and len(body)==row['published_bytes'],name
 if row['transform']=='identity':assert row['original_sha256']==row['published_sha256']
 if a.originals and row['original_relative_path']:
  raw=(a.originals/row['original_relative_path']).read_bytes();assert sha(raw)==row['original_sha256'] and len(raw)==row['original_bytes'],name
  if row['transform']=='identity':assert raw==body
  elif row['transform']=='json-env':
   old=json.loads(raw);new=json.loads(body)
   assert new==[{k:v for k,v in r.items() if k!='env'} for r in old]
   assert row['removed_paths']==['/'+str(i)+'/env' for i,r in enumerate(old) if 'env' in r]
  elif row['transform']=='jsonl-env':
   old=[json.loads(l) for l in raw.splitlines()];new=[json.loads(l) for l in body.splitlines()]
   assert new==[{k:v for k,v in r.items() if k!='env'} for r in old]
   assert row['removed_paths']==['/jsonl-row/'+str(i)+'/env' for i,r in enumerate(old) if 'env' in r]
  elif row['transform']=='text-env-header':
   assert row['removed_paths']==['/bytes/[59,9418)','/lines/3-10']
   assert body==remove_environment_span(raw,59,9418)
  else:raise AssertionError('Unknown transform')
# A multiline environment value reproduces the rejected line-3-only leak.
prefix=b'Log of Meson test suite run on synthetic\n\n'
block=b'Inherited environment: EXAMPLE="first line\nPRIVATE-CANARY\nlast line"\n\n'
suffix=b'==================================== 1/13 ====================================\ntest: unchanged\nstdout: exact diagnostic\n'
synthetic=prefix+block+suffix
assert b'PRIVATE-CANARY' in b''.join(synthetic.splitlines(keepends=True)[:2]+synthetic.splitlines(keepends=True)[3:])
assert remove_environment_span(synthetic,len(prefix),len(prefix+block))==prefix+suffix
for start,end in [(len(prefix)+1,len(prefix+block)),(len(prefix),len(prefix+block)-1)]:
 try:remove_environment_span(synthetic,start,end)
 except AssertionError:pass
 else:raise AssertionError('Incorrect environment boundary was accepted')
public_text=(root/'native-01/meson-results.public.txt').read_bytes();text_seal=manifest['text_environment_removal']
assert sha(public_text[:59])==text_seal['retained_prefix_sha256']
assert sha(public_text[59:])==text_seal['retained_test_suffix_sha256']
assert text_seal['removed_half_open_byte_range']==[59,9418] and text_seal['removed_inclusive_lines']==[3,10]
assert public_text[59:].startswith(b'==================================== 1/13 ====================================\n')
f=types.ModuleType('frozen');f.__file__=str(root/'run-painter-frozen-aggregate.py');exec(compile((root/'run-painter-frozen-aggregate.py').read_bytes(),f.__file__,'exec'),f.__dict__)
registry=read('native-01/complete-registry.public.json');chosen=read('native-01/selected-registry.public.json');results=read('native-01/results.json')
assert results==[json.loads(line) for line in (root/'native-01/meson-results.public.jsonl').read_bytes().splitlines()]
def classify(observed, complete=None, selected=None):
 registered=registry if complete is None else complete;selected=chosen if selected is None else selected
 f.validate_registry(registered);wanted=[r['name'] for r in selected];names=set(wanted);matched=[r for r in registered if r['name'] in names]
 if len(wanted)!=13 or len(names)!=13 or matched!=selected or any(sum(r['name']==n for r in registered)!=1 for n in wanted):return {'all_selected_passed':False}
 gate=f.coverage_gate(registered,observed);rows=[r for r in gate['targets'] if r['name'] in names]
 return {'all_selected_passed':len(observed)==len(names)==13 and len(rows)==13 and not gate['unmatched_results'] and all(r['classification']=='passed' for r in rows),'targets':rows,'unmatched_results':gate['unmatched_results'],'actual_result_count':len(observed)}
old=read('native-01/receipt.json');correction=read('native-01/classification-correction.json')
assert old['all_passed'] is False and all(old['integrity'].values())
assert correction['all_passed'] and classify(results)==correction['classification']
for name,digest in correction['native_input_artifact_sha256'].items():
 matches=[r for r in manifest['artifacts'].values() if r['original_relative_path']=='native-01/'+name]
 assert len(matches)==1 and matches[0]['original_sha256']==digest,name
assert correction['complete_registry_sha256']==old['registry_sha256']==manifest['artifacts']['native-01/complete-registry.public.json']['original_sha256']
assert correction['classifier_sha256']==manifest['artifacts']['drivers/classify-native-01.py']['published_sha256']
for family in [('source-before-build.json','source-after-build.json','source-after-tests.json'),('elf-before.json','elf-after.json'),('freshness-before.json','freshness-after.json')]:
 assert all(read('native-01/'+n)==read('native-01/'+family[0]) for n in family)
checks=[]
for label in ['missing','duplicate','wrong-name','wrong-command','nonzero','bad-status','skip','diagnostic']:
 changed=copy.deepcopy(results)
 if label=='missing':changed.pop()
 elif label=='duplicate':changed.append(copy.deepcopy(changed[0]))
 elif label=='wrong-name':changed[0]['name']='unverified-name'
 elif label=='wrong-command':changed[0]['command']=['unverified-command']
 elif label=='nonzero':changed[0]['returncode']=1
 elif label=='bad-status':changed[0]['result']='FAIL'
 elif label=='skip':changed[0]['stdout']+='\nok 1 # SKIP unexpected omitted test\n'
 elif label=='diagnostic':changed[0]['stderr']=changed[0].get('stderr','')+'\nAddressSanitizer: heap-buffer-overflow\n'
 assert not classify(changed)['all_selected_passed'],label;checks.append(label)
assert len({s for r in chosen for s in r['suite']})==1 and len({s for r in registry for s in r['suite']})>1
assert all(r['classification']=='failed' for r in f.coverage_gate(chosen,results)['targets']);checks.append('single-suite-subset-is-insufficient-for-full-registry-names')
ambiguous=copy.deepcopy(registry);other=copy.deepcopy(chosen[0]);other['suite']=['gimp:ambiguous'];ambiguous.append(other)
assert not classify(results,complete=ambiguous)['all_selected_passed'];checks.append('same-selected-name-in-another-suite')
wrong=copy.deepcopy(results);wrong[0]['name']='gimp:wrong / '+chosen[0]['name']
assert not classify(wrong)['all_selected_passed'];checks.append('wrong-qualified-suite')
assert not classify(results,selected=chosen+[copy.deepcopy(chosen[0])])['all_selected_passed'];checks.append('duplicate-selected-registration')
assert checks==[r['case'] for r in correction['negative_controls']]
for name in ['normal-02','sanitizer-01']:
 r=read('standalone/'+name+'.json');assert r['all_passed'] and r['objects_unchanged'] and r['executable_unchanged']
 for key in ['changed_after_verify','changed_after_compile','changed_before_run','changed_after_run']:assert not r[key]
assert not read('standalone/normal-01.json')['all_passed']
print(json.dumps({'all_passed':True,'scope':'Evidence verification/reclassification only; no native rerun','artifacts':len(manifest['artifacts']),'selected_targets':13,'negative_controls':len(checks),'private_transform_verified':bool(a.originals),'multiline_environment_controls':3,'tested_source_commit':old['source_commit'],'tested_source_tree':old['source_tree']}))
