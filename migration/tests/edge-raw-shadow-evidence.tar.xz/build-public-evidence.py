#!/usr/bin/env python3
"""Publish explicit environment-only derivatives; preserve all diagnostic bytes."""
import argparse, hashlib, json, shutil
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('originals',type=Path);p.add_argument('output',type=Path);p.add_argument('repository',type=Path);a=p.parse_args()
a.output.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def remove_environment_span(raw, start, end):
 prefix=b''.join(raw.splitlines(keepends=True)[:2])
 marker=b'==================================== 1/13 ====================================\n'
 assert raw.startswith(b'Log of Meson test suite run on ') and start==len(prefix)
 assert raw[start:].startswith(b'Inherited environment:') and end>start
 assert raw[end:].startswith(marker)
 return raw[:start]+raw[end:]

def emit(src,dst=None,transform=None):
 raw=(a.originals/src).read_bytes();dst=dst or src;body=raw;removed=[]
 if transform=='json-env':
  original=json.loads(raw);rows=[{k:v for k,v in row.items() if k!='env'} for row in original]
  removed=['/'+str(i)+'/env' for i,row in enumerate(original) if 'env' in row]
  assert all(new=={k:v for k,v in old.items() if k!='env'} for old,new in zip(original,rows))
  body=(json.dumps(rows,indent=2)+'\n').encode()
 elif transform=='jsonl-env':
  original=[json.loads(line) for line in raw.splitlines()];rows=[{k:v for k,v in row.items() if k!='env'} for row in original]
  removed=['/jsonl-row/'+str(i)+'/env' for i,row in enumerate(original) if 'env' in row]
  assert rows==json.loads((a.originals/'native-01/results.json').read_bytes())
  body=b''.join((json.dumps(row,ensure_ascii=True)+'\n').encode() for row in rows)
 elif transform=='text-env-header':
  assert sha(raw)=='bc472b56a987eeb44e6d3bf8472379eb882a0ef1fa3b3b951472f31d725115ad'
  body=remove_environment_span(raw,59,9418)
  removed=['/bytes/[59,9418)','/lines/3-10']
 elif transform is not None:raise ValueError(transform)
 target=a.output/dst;target.parent.mkdir(exist_ok=True,parents=True);target.write_bytes(body)
 manifest['artifacts'][dst]={'original_relative_path':src,'original_sha256':sha(raw),'original_bytes':len(raw),'published_sha256':sha(body),'published_bytes':len(body),'transform':transform or 'identity','removed_paths':removed}
manifest={'schema_version':1,'scope':'Evidence-only packaging of completed runs; no native execution repeated','private_originals_excluded':True,'transformation_policy':'Remove only explicitly listed env fields or the complete multiline Inherited environment preamble. All other fields, including names, commands, statuses, counts, stdout and stderr, are unchanged. JSON serialization may change; string values are byte-identical UTF-8.','artifacts':{}}
for name in ['normal-01','normal-02','sanitizer-01']:
 for ext in ['json','stdout','stderr']:emit(name+'.'+ext,'standalone/'+name+'.'+ext)
for name in ['run-native-01.py','classify-native-01.py','classify-native-01-initial-control-error.py','native-driver-01.stdout','native-driver-01.stderr','native-classifier.stdout','native-classifier.stderr']:emit(name,'drivers/'+name)
for name in ['receipt.json','classification-correction.json','results.json','source-before-build.json','source-after-build.json','source-after-tests.json','elf-before.json','elf-after.json','freshness-before.json','freshness-after.json','registered-tests.log','configure.log','default-build.log','executable-check.json','executable-check.log']:emit('native-01/'+name)
for name in ['complete-registry','selected-registry']:emit('native-01/'+name+'.json','native-01/'+name+'.public.json','json-env')
emit('native-01/meson-results.json','native-01/meson-results.public.jsonl','jsonl-env')
emit('native-01/meson-results.txt','native-01/meson-results.public.txt','text-env-header')
for src,dst in [(Path(__file__),'build-public-evidence.py'),(a.originals/'verify-public-evidence.py','verify-public-evidence.py'),(a.repository/'tools/run-painter-frozen-aggregate.py','run-painter-frozen-aggregate.py')]:
 body=src.read_bytes();(a.output/dst).write_bytes(body);manifest['artifacts'][dst]={'original_relative_path':None,'original_sha256':sha(body),'original_bytes':len(body),'published_sha256':sha(body),'published_bytes':len(body),'transform':'identity','removed_paths':[]}
manifest['text_environment_removal']={'original_relative_path':'native-01/meson-results.txt','removed_half_open_byte_range':[59,9418],'removed_inclusive_lines':[3,10],'retained_prefix_sha256':sha((a.originals/'native-01/meson-results.txt').read_bytes()[:59]),'retained_test_suffix_sha256':sha((a.originals/'native-01/meson-results.txt').read_bytes()[9418:]),'rejected_v1_packaging_retained_locally_only':True}
(a.output/'publication-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'artifacts':len(manifest['artifacts']),'transformed':sum(row['transform']!='identity' for row in manifest['artifacts'].values()),'output':str(a.output)}))
