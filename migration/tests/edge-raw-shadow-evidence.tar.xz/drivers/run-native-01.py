#!/usr/bin/env python3
"""Task-scoped default build and complete selected registrations, never aggregate acceptance."""
import fcntl, hashlib, importlib.util, json, os, subprocess, sys, time
from pathlib import Path
ROOT=Path('/workspace/shared/gimp-painter-edge-raw-shadow')
OUT=Path('/workspace/shared/gimp-edge-shadow-validation/native-01')
BUILD=OUT/'build'
COMMIT='87c03ed868f2bc7a0c98350bdd93be7afd38b7e4'
TARGETS=['painter-filter-edge-shadow','painter-filter-edge','painter-filter-gray','painter-filter-raster','painter-filter-raster-kernels','painter-filter-native-kernels','painter-filter-kernel-progress','painter-filter-context-native','painter-filter-context','painter-filter-scheduler','painter-filter-point-shadow','painter-public-header-compilation','painter-additional-header-routes']
OUT.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('frozen',ROOT/'tools/run-painter-frozen-aggregate.py'); f=importlib.util.module_from_spec(spec);exec(compile((ROOT/'tools/run-painter-frozen-aggregate.py').read_bytes(),str(ROOT/'tools/run-painter-frozen-aggregate.py'),'exec'),f.__dict__)
r={'scope':'Full default normal build plus 13 complete selected registered targets; not full aggregate','source_commit':COMMIT,'all_passed':False,'commands':[],'stage':'initial','started_utc':time.time(),'errors':[]}
def write(name,value): (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def run(cmd,name,env):
 r['stage']=name;write('receipt.json',r);started=time.monotonic()
 with (OUT/(name+'.log')).open('x') as log: result=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':cmd,'returncode':result.returncode,'elapsed_seconds':time.monotonic()-started};r['commands'].append(row);write('receipt.json',r)
 if result.returncode: raise RuntimeError(name+' failed with status '+str(result.returncode))
try:
 with Path('/workspace/shared/gimp-painter-build.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX)
  for name in ['normal-02','sanitizer-01']:
   checked=json.loads((OUT.parent/(name+'.json')).read_text())
   if checked.get('all_passed') is not True: raise RuntimeError('Required standalone gate did not pass: '+name)
   for name0,sha in checked['source_sha256'].items():
    if hashlib.sha256((ROOT/name0).read_bytes()).hexdigest()!=sha: raise RuntimeError('Standalone source no longer matches: '+name0)
  helper=f.load_committed_helper(ROOT,COMMIT)
  tree=f.git(ROOT,'rev-parse','HEAD^{tree}');r['source_tree']=tree
  before=f.source_state(ROOT,helper);f.require_source(before,COMMIT,tree);write('source-before-build.json',before)
  (OUT/'private').mkdir(mode=0o700)
  env=f.isolated_child_environment(OUT/'private',os.environ)
  env['PYTHONDONTWRITEBYTECODE']='1';env['CCACHE_DISABLE']='1';env['LANG']='C.UTF-8';env['LC_ALL']='C.UTF-8'
  run(['meson','setup',str(BUILD),str(ROOT),'--prefix='+str(OUT/'prefix'),'-Dauto_features=disabled','-Dlibunwind=false','-Dheadless-tests=disabled','-Dpainter-http=disabled'],'configure',env)
  run(['meson','compile','-C',str(BUILD),'-j','4'],'default-build',env)
  run([sys.executable,'-B',str(ROOT/'tools/verify_build_executables.py'),str(BUILD),'--report',str(OUT/'executable-check.json')],'executable-check',env)
  after_build=f.source_state(ROOT,helper);write('source-after-build.json',after_build)
  if after_build!=before: raise RuntimeError('Source changed during default build')
  r['normal_build']=f.require_normal_build(BUILD,ROOT)
  registry=json.loads((BUILD/'meson-info/intro-tests.json').read_text());chosen=[row for row in registry if row['name'] in TARGETS]
  if sorted(row['name'] for row in chosen)!=sorted(TARGETS): raise RuntimeError('Selected registration missing or ambiguous')
  write('selected-registry.json',chosen);r['registry_sha256']=f.sha(BUILD/'meson-info/intro-tests.json')
  before_elf=f.elf_inventory(BUILD,helper);write('elf-before.json',before_elf)
  before_freshness=helper.capture_freshness_snapshot(BUILD,ROOT);write('freshness-before.json',before_freshness)
  r['build_locales']=f.stage_build_locales(BUILD,OUT/'private/locale');env['GIMP3_LOCALEDIR']=str(OUT/'private/locale')
  logbase=OUT/'meson-results'
  run(['meson','test','-C',str(BUILD),'--no-rebuild','--num-processes','1','--print-errorlogs','--logbase',str(logbase),*TARGETS],'registered-tests',env)
  results=[json.loads(line) for line in logbase.with_suffix('.json').read_text().splitlines()]
  # Strip process environment from the public-facing summary; raw Meson log stays private.
  compact=[{k:v for k,v in row.items() if k!='env'} for row in results];write('results.json',compact)
  gate=f.coverage_gate(chosen,compact);r['selected_coverage']=gate
  after=f.source_state(ROOT,helper);write('source-after-tests.json',after)
  after_elf=f.elf_inventory(BUILD,helper);write('elf-after.json',after_elf)
  after_freshness=helper.capture_freshness_snapshot(BUILD,ROOT);write('freshness-after.json',after_freshness)
  r['integrity']={'source_unchanged':before==after,'elf_unchanged':before_elf==after_elf,'freshness_unchanged':before_freshness==after_freshness,'registry_unchanged':r['registry_sha256']==f.sha(BUILD/'meson-info/intro-tests.json'),'locales_unchanged':f.verify_staged_locales(OUT/'private/locale',r['build_locales'])}
  if not gate['coverage_complete'] or any(t['classification']!='passed' for t in gate['targets']) or not all(r['integrity'].values()): raise RuntimeError('Selected target diagnostics/coverage/integrity gate failed')
  r['all_passed']=True;r['stage']='complete'
except Exception as error:
 r['errors'].append(type(error).__name__+': '+str(error));r['all_passed']=False
finally:
 r['finished_utc']=time.time();write('receipt.json',r);print(json.dumps({k:r[k] for k in ['all_passed','stage','errors']}))
sys.exit(0 if r['all_passed'] else 1)
