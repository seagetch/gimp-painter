#!/usr/bin/env python3
"""Correct selected-target name classification using the sealed COMPLETE registry."""
import copy, hashlib, importlib.util, json, sys
from pathlib import Path
ROOT=Path('/workspace/shared/gimp-painter-edge-raw-shadow'); OUT=Path('/workspace/shared/gimp-edge-shadow-validation/native-01')
spec=importlib.util.spec_from_file_location('frozen',ROOT/'tools/run-painter-frozen-aggregate.py');f=importlib.util.module_from_spec(spec);exec(compile((ROOT/'tools/run-painter-frozen-aggregate.py').read_bytes(),str(ROOT/'tools/run-painter-frozen-aggregate.py'),'exec'),f.__dict__)
old=json.loads((OUT/'receipt.json').read_text());registry_path=OUT/'build/meson-info/intro-tests.json'; registry=json.loads(registry_path.read_text()); chosen=json.loads((OUT/'selected-registry.json').read_text()); results=json.loads((OUT/'results.json').read_text());names={row['name'] for row in chosen}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def classify(observed):
 full=f.coverage_gate(registry,observed)
 rows=[row for row in full['targets'] if row['name'] in names]
 return {'all_selected_passed':len(observed)==len(names)==13 and len(rows)==13 and not full['unmatched_results'] and all(row['classification']=='passed' for row in rows),'targets':rows,'unmatched_results':full['unmatched_results'],'actual_result_count':len(observed)}
assert old['all_passed'] is False and all(old['integrity'].values())
assert digest(registry_path)==old['registry_sha256']
assert all(row in registry for row in chosen)
assert json.loads((OUT/'source-before-build.json').read_text())==json.loads((OUT/'source-after-build.json').read_text())==json.loads((OUT/'source-after-tests.json').read_text())
assert json.loads((OUT/'elf-before.json').read_text())==json.loads((OUT/'elf-after.json').read_text())
assert json.loads((OUT/'freshness-before.json').read_text())==json.loads((OUT/'freshness-after.json').read_text())
checks=[]
for label in ['missing','duplicate','wrong-name','wrong-command','nonzero','bad-status','skip','diagnostic']:
 changed=copy.deepcopy(results)
 if label=='missing':changed.pop()
 elif label=='duplicate':changed.append(copy.deepcopy(changed[0]))
 elif label=='wrong-name':changed[0]['name']='unverified-name'
 elif label=='wrong-command':changed[0]['command']=['unverified-command']
 elif label=='nonzero':changed[0]['returncode']=1
 elif label=='bad-status':changed[0]['result']='FAIL'
 elif label=='skip':changed[0]['stdout']+='\nok 1 # SKIP unexpected omitted test\n'
 elif label=='diagnostic':changed[0]['stderr']+='\nAddressSanitizer: heap-buffer-overflow\n'
 assert classify(changed)['all_selected_passed'] is False, label
 checks.append({'case':label,'rejected':True})
accepted=classify(results);assert accepted['all_selected_passed']
sealed=['receipt.json','selected-registry.json','results.json','source-before-build.json','source-after-build.json','source-after-tests.json','elf-before.json','elf-after.json','freshness-before.json','freshness-after.json','meson-results.json','meson-results.txt','registered-tests.log','configure.log','default-build.log','executable-check.json']
r={'schema_version':1,'scope':'Evidence-only selected-target classifier correction; no native execution repeated','tested_source_commit':old['source_commit'],'tested_source_tree':old['source_tree'],'all_passed':True,'whole_aggregate_claim':False,'original_driver_failure_retained':old['errors'],'correction':'Use canonical names generated from the full sealed registration catalog, then require each selected exact command/name exactly once. No target, result, command or diagnostic was changed.','classification':accepted,'integrity':old['integrity'],'negative_controls':checks,'native_input_artifact_sha256':{name:digest(OUT/name) for name in sealed},'complete_registry_sha256':digest(registry_path),'classifier_sha256':digest(Path(__file__))}
p=OUT/'classification-correction.json'
with p.open('x') as stream:json.dump(r,stream,indent=2);stream.write('\n')
print(json.dumps({'all_passed':True,'selected_targets':len(accepted['targets']),'negative_controls':len(checks),'source_commit':r['tested_source_commit']}))
