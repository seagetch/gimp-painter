
#include <gtk/gtk.h>
#include <cassert>
static bool entered_main;
static unsigned early_calls, all_calls;
static GType register_probe() {
  if (!entered_main) ++early_calls;
  ++all_calls;
  GType type = g_type_register_static_simple(G_TYPE_OBJECT, "PainterOrderControl",
      sizeof(GObjectClass), nullptr, sizeof(GObject), nullptr, GTypeFlags(0));
  assert(type && gtk_window_get_type());
  return type;
}

__attribute__((constructor)) static void any_name() { register_probe(); }
int main() { assert(early_calls==1 && all_calls==1); entered_main=true; }
