
extern "C" int implementation() { return 0; }
extern "C" auto resolve_entry() -> int (*)() { return implementation; }
extern "C" int entry() __attribute__((ifunc("resolve_entry")));
int main() { return entry(); }
