
#include <atomic>
static std::atomic<unsigned> count {0};
static const char *const name = "constant";
int main() { return count.load()!=0 || name[0]!='c'; }
