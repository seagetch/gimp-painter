from pathlib import Path
import json,subprocess,sys
out=Path(__file__).resolve().parent
base=out.parent/'gimp-native-restore-20261009'
v=sys.argv[1]
rows=json.loads((base/(v+'-production-cpp-candidates.json')).read_text())
rows=[r for r in rows if 'painter-xcf-compat-test.p' not in r['object']]
assert len(rows)==len({r['source'] for r in rows})==(73 if v=='default' else 78)
cmd=['ninja','-C',str(base/('build-'+v)),'-f',str(base/(v+'.ninja')),'-j4']+[r['object'] for r in rows]
(out/(v+'-build-command.json')).write_text(json.dumps(cmd,indent=2)+'\n')
(out/(v+'-production-scope.json')).write_text(json.dumps(rows,indent=2)+'\n')
with (out/(v+'-build.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(out/(v+'-build-exit.json')).write_text(json.dumps({'exit_code':r.returncode})+'\n')
print(v,'production object build exit',r.returncode)
raise SystemExit(r.returncode)
