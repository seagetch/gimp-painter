from pathlib import Path
import copy,importlib.util,json
repo=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active')
base=repo.parent/'gimp-native-restore-20261009';out=repo.parent/'static-init-04018-verification/scope-controls';out.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('checker',repo/'tools/check_cpp_static_initialization.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[]
for v,count in [('default',73),('http',78)]:
 build=base/('build-'+v); rows,http=m.production_inputs(repo,build);assert len(rows)==count and http==(v=='http')
 results.append({'case':v+'-complete-scope','passed':True,'objects':len(rows)})
 database=json.loads((build/'compile_commands.json').read_text());targets=json.loads((build/'meson-info/intro-targets.json').read_text());config=(build/'config.h').read_text()
 row=next(r for r in database if r['file'].endswith('app/painter/binding-store.cpp') and '.a.p/' in r['command'])
 for kind in ['missing-object','duplicate-object','missing-owner']+(['http-macro-drift'] if http else []):
  d=out/(v+'-'+kind);(d/'meson-info').mkdir(parents=True,exist_ok=True)
  db=copy.deepcopy(database);ts=copy.deepcopy(targets);cfg=config
  if kind=='missing-object':db.remove(row)
  if kind=='duplicate-object':db.append(row)
  if kind=='missing-owner':
   for t in ts:
    if t['type']=='static library':
     for group in t['target_sources']:
      group['sources']=[s for s in group.get('sources',[]) if not s.endswith('app/painter/binding-store.cpp')]
  if kind=='http-macro-drift':cfg=cfg.replace('#define HAVE_PAINTER_HTTP','#undef HAVE_PAINTER_HTTP')
  (d/'compile_commands.json').write_text(json.dumps(db));(d/'meson-info/intro-targets.json').write_text(json.dumps(ts));(d/'config.h').write_text(cfg)
  try:m.production_inputs(repo,d)
  except ValueError as error:results.append({'case':v+'-'+kind,'passed':True,'diagnostic':str(error)})
  else:raise AssertionError('missed '+v+'/'+kind)
(out/'report.json').write_text(json.dumps({'status':'PASS','results':results},indent=2)+'\n');print('PASS:',len(results),'production scope controls')
