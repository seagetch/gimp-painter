#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
out=/workspace/scratch/5b5281e79681/filter-persistence-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$out/reviewed-exit.txt"' EXIT
ulimit -c 0
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$out/run-native.py" --mode normal --label reviewed-normal --case filter_schema_persistence_reference_identity --case filter_schema_persistence_active_save > "$out/reviewed-normal-driver.log" 2>&1
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$out/run-native.py" --mode sanitized --label reviewed-sanitized --case filter_schema_persistence_reference_identity --case filter_schema_persistence_active_save > "$out/reviewed-sanitized-driver.log" 2>&1
