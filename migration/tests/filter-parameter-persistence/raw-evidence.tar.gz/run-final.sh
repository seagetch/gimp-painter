#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
out=/workspace/scratch/5b5281e79681/filter-persistence-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$out/final-exit.txt"' EXIT
ulimit -c 0
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$out/run-native.py" --mode normal --label final-normal --case filter_schema_persistence_routes --case filter_schema_persistence_special_bits --case filter_schema_persistence_large_tails --case filter_schema_persistence_reference_identity --case filter_schema_persistence_failures --case filter_schema_persistence_nested_null --case filter_schema_persistence_unknown_opaque --case filter_schema_persistence_active_save --case filter_schema_persistence_reference_lease --case filter_schema_persistence_double_cache > "$out/final-normal-driver.log" 2>&1
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$out/run-native.py" --mode sanitized --label final-sanitized --case filter_schema_persistence_routes --case filter_schema_persistence_special_bits --case filter_schema_persistence_large_tails --case filter_schema_persistence_reference_identity --case filter_schema_persistence_failures --case filter_schema_persistence_nested_null --case filter_schema_persistence_unknown_opaque --case filter_schema_persistence_active_save --case filter_schema_persistence_reference_lease --case filter_schema_persistence_double_cache > "$out/final-sanitized-driver.log" 2>&1
bash "$out/run-xcf.sh"
