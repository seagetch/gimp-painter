#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
out=/workspace/scratch/5b5281e79681/filter-persistence-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$out/xcf-exit.txt"' EXIT
ulimit -c 0
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$out/run-regressions.py" > "$out/xcf-regression-driver.log" 2>&1
