import hashlib,json,os,re,resource,subprocess,time
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter-installed-filter');build=root/'build-installed-filter';out=root.parent/'filter-persistence-evidence'
xcf=['/painter-xcf-roundtrip/filter_cache_and_arguments','/painter-xcf-roundtrip/typed_nested_expired_arguments','/painter-xcf-roundtrip/replace_uninterpreted_arguments','/painter-xcf-roundtrip/external_references_remain_unresolved','/painter-xcf-multipart/native-owner-duplicate-edit','/painter-xcf-multipart/native-callback-argument-leases']
reports=[]
for name,paths in [('painter-xcf-roundtrip',xcf)]:
 test=next(t for t in json.loads((build/'meson-info/intro-tests.json').read_text()) if t['name']==name)
 env=os.environ.copy();old=env.get('LD_LIBRARY_PATH','');env.update(test.get('env',{}))
 if 'LD_LIBRARY_PATH' in test.get('env',{}):env['LD_LIBRARY_PATH']+=':'+old
 env['GIMP3_CACHEDIR']=str(build/'filter-spill-cache')
 binary=build/'app/tests'/name;cmd=['dbus-run-session','--']
 if name=='gimp-filter-layer':cmd += ['python3','-B',str(root/'migration/tests/run_filter_owner_context_fixture_test.py'),'--']
 cmd += [str(binary),'--verbose']
 for path in paths:cmd += ['-p',path]
 start=time.monotonic();r=subprocess.run(cmd,cwd=build,env=env,capture_output=True,text=True,timeout=600)
 (out/(name+'-regression.log')).write_text(r.stdout+r.stderr)
 actual=re.findall(r'^ok \d+ (\S+)$',r.stdout,re.M)
 item=dict(command=cmd,exit_code=r.returncode,selected=paths,executed=actual,passed=r.returncode==0 and set(actual)==set(paths),elapsed_seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest());reports.append(item)
 (out/'xcf-regressions.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(item),flush=True)
 if not item['passed']:raise SystemExit(1)
