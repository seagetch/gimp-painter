set -e; source /workspace/shared/gimp-legacy-reference/build/env.sh; make -C app/xcf -j2
