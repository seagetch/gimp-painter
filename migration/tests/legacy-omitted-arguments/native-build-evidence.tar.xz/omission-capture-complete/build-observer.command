set -e; source /workspace/shared/gimp-legacy-reference/build/env.sh; make -C app/tests -j2 test-xcf 'LIBS=../gimp-features.o ../presets/libapppresets.a -ljson-glib-1.0 -lstdc++ -lm'
