set -e; source /workspace/shared/gimp-legacy-reference/build/env.sh; GIMP_PAINTER_OMISSION_CAPTURE=/workspace/shared/gimp-legacy-reference/omission-capture/fixtures timeout 30 app/tests/test-xcf
