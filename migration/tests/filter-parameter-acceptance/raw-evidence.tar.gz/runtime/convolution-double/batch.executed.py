
import hashlib, json, os, struct, time
from pathlib import Path
from gi.repository import Gegl, Gio, Gimp, GLib
c = json.loads(os.environ['GIMP_PAINTER_CONVOLUTION_SMOKE'])
out = Path(c['output'])
width, height = c['width'], c['height']

def emit(kind, **details):
    with (out/'events.jsonl').open('a') as f:
        f.write(json.dumps(dict(event=kind, monotonic=time.monotonic(), **details))+'\n')

def gate(name):
    end = time.monotonic()+30
    while not (out/name).exists():
        if time.monotonic() > end: raise RuntimeError('Observer handshake expired: '+name)
        time.sleep(0.01)

def capsule(path):
    data = path.read_bytes()
    assert data[:10] == b'gimp xcf v' and data[13] == 0
    assert 11 <= int(data[10:13]) <= 23
    def integer(at, size=4):
        assert 0 <= at <= len(data)-size
        return int.from_bytes(data[at:at+size], 'big')
    def string(at):
        size = integer(at); at += 4
        assert 0 < size <= 1048576 and at+size <= len(data) and data[at+size-1] == 0
        return data[at:at+size-1], at+size
    def props(at):
        result = []
        for _ in range(1024):
            tag, size = integer(at), integer(at+4); at += 8
            assert at+size <= len(data)
            if tag == 0:
                assert size == 0
                return result, at
            result.append((tag, at, size)); at += size
        raise AssertionError('Too many XCF properties')
    _, at = props(30)
    found = []
    for _ in range(16):
        layer = integer(at, 8); at += 8
        if layer == 0: break
        name, offset = string(layer+12)
        if name != c['filter_name'].encode(): continue
        values, _ = props(offset)
        for tag, cursor, size in values:
            if tag != 21: continue
            end = cursor+size
            while cursor < end:
                name, cursor = string(cursor)
                size = integer(cursor+4); cursor += 8
                assert cursor+size <= end
                if name == b'gimp-painter-item': found.append(data[cursor:cursor+size])
                cursor += size
    else: raise AssertionError('Too many XCF layers')
    assert len(found) == 1 and found[0][:12] == b'GPXCF\0\0\0\1\0\0\0'
    value = GLib.Variant.new_from_bytes(GLib.VariantType.new('a{sv}'), GLib.Bytes.new(found[0][12:]), False)
    assert value.is_normal_form()
    value = value.unpack()
    assert value['version'] == 1 and value['kind'] == 'filter'
    return value

def definition(value):
    return {k:value[k] for k in ('procedure','has-definition','definition','has-arguments','arguments')}

def pixels(layer):
    return bytes(layer.get_buffer().get(Gegl.Rectangle.new(0,0,width,height), 1.0,
                                       c['format'], Gegl.AbyssPolicy.NONE))

def layers(image):
    assert image is not None and image.get_width() == width and image.get_height() == height
    values = {v.get_name():v for v in image.get_layers()}
    assert set(values) == {c['source_name'],c['filter_name']}
    return values[c['source_name']], values[c['filter_name']]

def save(image, name):
    path = out/name
    assert Gimp.file_save(Gimp.RunMode.NONINTERACTIVE, image, Gio.File.new_for_path(str(path)), None)
    return capsule(path)

def ready(state):
    return state['saved-state'] == 0 and state['cache-complete'] and state['generation'] == state['cache-generation']

def complete(image, effect, name, previous):
    deadline = time.monotonic()+90
    while True:
        state = save(image,name)
        if ready(state) and state['generation'] > previous: break
        assert state['saved-state'] != 6, 'Convolution reached FAILED'
        if time.monotonic() > deadline: raise RuntimeError('Convolution completion timed out')
        time.sleep(0.05)
    assert pixels(effect) == expected, 'Installed completed pixels differ from sealed expectation'
    assert definition(state) == original, 'Typed definition changed during execution'
    return state

source_bytes = Path(c['source']).read_bytes()
initial_bytes = Path(c['initial']).read_bytes()
expected = Path(c['expected']).read_bytes()
assert len(source_bytes) == len(initial_bytes) == len(expected) == width*height*c['bytes_per_pixel']
image = Gimp.file_load(Gimp.RunMode.NONINTERACTIVE,Gio.File.new_for_path(c['fixture']))
source, effect = layers(image)
assert pixels(source) == source_bytes and pixels(effect) == initial_bytes
initial = save(image,'initial.xcf')
assert ready(initial) and bytes(initial['procedure']) == b'plug-in-convmatrix\0'
assert initial['has-arguments'] and len(initial['arguments']) == 11
assert initial['arguments'][4][0] == 'GimpDoubleArray' and initial['arguments'][9][0] == 'GimpInt32Array'
assert initial['arguments'][3] == ('gint',False,25) and initial['arguments'][8] == ('gint',False,5)
assert initial['arguments'][4][2][0] and len(initial['arguments'][4][2][1]) == 25*8
assert initial['arguments'][9][2][0] and len(initial['arguments'][9][2][1]) == 5*4
assert bytes(initial['arguments'][4][2][1]) == struct.pack('<25d',*c['matrix'])
assert bytes(initial['arguments'][9][2][1]) == struct.pack('<5i',*c['channels'])
original = definition(initial)
emit('READY', generation=initial['generation']); gate('start-first')
assert source.update(0,0,width,height)
emit('INVALIDATED', phase='first')
first = complete(image,effect,'first.xcf',initial['generation'])
assert image.delete()
image = Gimp.file_load(Gimp.RunMode.NONINTERACTIVE,Gio.File.new_for_path(str(out/'first.xcf')))
source, effect = layers(image)
assert pixels(source) == source_bytes and pixels(effect) == expected
reopened = save(image,'reopened.xcf')
assert ready(reopened) and definition(reopened) == original
emit('REOPENED_READY',generation=reopened['generation']); gate('start-rerun')
assert source.update(0,0,width,height)
emit('INVALIDATED',phase='reopened-rerun')
second = complete(image,effect,'second.xcf',reopened['generation'])
assert image.delete()
image = Gimp.file_load(Gimp.RunMode.NONINTERACTIVE,Gio.File.new_for_path(str(out/'second.xcf')))
_, effect = layers(image)
assert pixels(effect) == expected
final = save(image,'second-reopened.xcf')
assert ready(final) and definition(final) == original
assert image.delete()
result = dict(status='passed',case=c['id'],format=c['format'],argument_count=11,
              matrix_type='GimpDoubleArray',channels_type='GimpInt32Array',
              expected_sha256=hashlib.sha256(expected).hexdigest(),
              initial_generation=initial['generation'],first_generation=first['generation'],
              reopened_generation=reopened['generation'],second_generation=second['generation'],
              exact_pixels=True,typed_definition_preserved=True,save_reopen_cycles=2)
(out/'batch-result.json').write_text(json.dumps(result,indent=2)+'\n')
emit('DONE')
print('INSTALLED_CONVOLUTION_EXACT_SAVE_REOPEN_OK',flush=True)
