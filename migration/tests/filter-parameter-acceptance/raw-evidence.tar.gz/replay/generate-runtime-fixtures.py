import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent/'gimp-painter-installed-filter'
build=root/'build-installed-filter';out=Path(__file__).resolve().parent
registry=json.loads((build/'meson-info/intro-tests.json').read_text())
test=next(t for t in registry if t['name']=='painter-layer-ui')
env=os.environ.copy();previous=env.get('LD_LIBRARY_PATH','');env.update(test['env'])
if 'LD_LIBRARY_PATH' in test['env']:env['LD_LIBRARY_PATH']+=':'+previous
env['GSETTINGS_BACKEND']='memory'
reports=[]
for route in ['small-tiles','retinex']:
 target=out/(route+'-fixtures');target.mkdir(exist_ok=False)
 corpus=out/(route+'-corpus')/(route+'-evidence')
 command=['dbus-run-session','--',str(build/'app/tests/filter-quit-fixture'),'--'+route,str(corpus),str(target)]
 start=time.monotonic();run=subprocess.run(command,env=env,cwd=build,capture_output=True,text=True,timeout=120)
 (out/(route+'-fixture-generation.log')).write_text(run.stdout+run.stderr)
 record={'route':route,'command':command,'exit_code':run.returncode,'seconds':time.monotonic()-start,'source_sha256':hashlib.sha256((root/'app/tests/test-filter-quit-fixture.cpp').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256((build/'app/tests/filter-quit-fixture').read_bytes()).hexdigest(),'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in target.iterdir()},'scope':'Current native XCF wrapper around unchanged verified genuine-old pixels; not regenerated old oracle'}
 reports.append(record);(out/'fixture-generation.json').write_text(json.dumps(reports,indent=2)+'\n')
 print(json.dumps(record),flush=True)
 if run.returncode or len(record['files'])!=2:raise SystemExit(1)
