#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source ../gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
out=/workspace/scratch/5b5281e79681/filter-acceptance-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$out/fixture-generation-exit.txt"' EXIT
ulimit -c 0
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$out/generate-runtime-fixtures.py" > "$out/fixture-generation-driver.log" 2>&1
