import importlib.util,json,os,signal,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter-installed-filter')
bundle=root.parent/'filter-runtime-phase-e-acceptance-final/baseline/relocated path 日本語/gimp-painter-linux-x86_64'
out=root.parent/'filter-acceptance-evidence/gui';out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('acceptance',root/'migration/tests/run_filter_acceptance_runtime.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
env=m.minimal_environment(out/'profile')
for name in ['DISPLAY','XAUTHORITY','XDG_RUNTIME_DIR']:
 if name in os.environ:env[name]=os.environ[name]
env.update(GIMP_PAINTER_PROFILE=str(out/'gimp-profile'),GIMP_PAINTER_CACHE=str(out/'gimp-cache'),GSETTINGS_BACKEND='memory',GDK_BACKEND='x11')
command=['dbus-run-session','--',str(bundle/'AppRun'),'--new-instance','--no-splash','--no-fonts','--console-messages']
observation=m.Observation(bundle);before=m.verify_manifest(bundle);assert before['passed']
identity={name:m.sha(bundle/name) for name in ['usr/bin/gimp-3.0','usr/libexec/gimp-painter-filter-worker','build-manifest.json','file-manifest.json']}
began=time.monotonic();started=datetime.now(timezone.utc).isoformat();timed_out=False
with (out/'gui.log').open('w') as log:
 process=subprocess.Popen(command,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'started.json').write_text(json.dumps({'started_utc':started,'pid':process.pid,'command':command,'identity':identity,'scope':'Actual relocated application; minimal explicit environment and isolated disposable profile; GUI interactions are recorded separately'},indent=2)+'\n')
 try:
  while process.poll() is None:
   observation.descendants(process.pid)
   if time.monotonic()-began>3600:
    timed_out=True;observation.cleanup();os.killpg(process.pid,signal.SIGKILL);break
   time.sleep(.03)
  code=process.wait(timeout=10)
 finally:
  if process.poll() is None:observation.cleanup();os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=10)
 for _ in range(100):
  if not observation.report()['survivors']:break
  time.sleep(.05)
report=observation.report();report.update(command=command,started_utc=started,exit_code=code,seconds=time.monotonic()-began,timed_out=timed_out,initial_identity=identity,final_manifest=m.verify_manifest(bundle),log_sha256=m.sha(out/'gui.log'),scope='Process/library observations of actual native X11 GUI walkthrough; exit alone is not GUI success; actions/window evidence recorded separately')
(out/'process-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'exit_code':code,'report':str(out/'process-report.json'),'survivors':len(report['survivors'])}),flush=True)
