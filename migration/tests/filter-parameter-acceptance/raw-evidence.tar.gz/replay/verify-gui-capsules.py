import ast,hashlib,json,struct
from pathlib import Path
from gi.repository import GLib
repo=Path('/workspace/scratch/5b5281e79681/gimp-painter-installed-filter')
source=ast.parse((repo/'tools/check_installed_convolution.py').read_text())
batch=next(ast.literal_eval(n.value) for n in source.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BATCH' for t in n.targets))
function=next(n for n in ast.parse(batch).body if isinstance(n,ast.FunctionDef) and n.name=='capsule')
exec(compile(ast.Module(body=[function],type_ignores=[]),'<existing-capsule-parser>','exec'))
out=repo.parent/'filter-acceptance-evidence/gui'
result={}
for file in ['before-close.xcf','four-routes.xcf']:
 path=out/file; rows={}
 for name in ['Blinds E','Tiles E','Retinex E','Convolution E']:
  c={'filter_name':name}; value=capsule(path)
  print(file,name,list(value),flush=True)
  rows[name]=value
 result[file]={'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':path.stat().st_size,'layers':rows}
(out/'saved-capsules-full.json').write_text(json.dumps(result,indent=2)+'\n')
a=result['before-close.xcf']['layers'];b=result['four-routes.xcf']['layers']
for name in a:
 for value in [a[name],b[name]]:
  assert value['saved-state']==0 and value['cache-complete'] and value['generation']==value['cache-generation']
 assert a[name]['procedure']==b[name]['procedure']
 assert a[name]['definition']==b[name]['definition']==[]
 if name!='Convolution E': assert a[name]['arguments']==b[name]['arguments']
assert b['Blinds E']['arguments'][3][2]==47
assert b['Tiles E']['arguments'][3][2]==3
assert b['Retinex E']['arguments'][3][2]==128
conv_a=a['Convolution E']['arguments'];conv_b=b['Convolution E']['arguments']
assert conv_a[:4]+conv_a[5:]==conv_b[:4]+conv_b[5:]
ma=struct.unpack('<25d',bytes(conv_a[4][2][1]));mb=struct.unpack('<25d',bytes(conv_b[4][2][1]))
assert ma[0]==.125 and mb[0]==.25 and ma[1:]==mb[1:] and mb[12]==1
compact={'status':'PASS','command':'/usr/bin/python3 -B verify-gui-capsules.py','parser_source':'tools/check_installed_convolution.py:capsule','parser_source_sha256':hashlib.sha256((repo/'tools/check_installed_convolution.py').read_bytes()).hexdigest(),'files':{},'assertions':['all eight saved filter capsules CLEAN, cache-complete, equal generation/cache-generation','all procedures and raw definitions unchanged','Blinds, SmallTiles and Retinex typed arguments identical across ordinary Close/Open and final Save','Convolution only matrix coefficient 0 changed from 0.125 to 0.25 after reopening; every other typed argument/byte unchanged'],'scope':'Offline capsule inspection of actual GUI ordinary Save outputs; runtime generation tokens need not match across sessions; screenshots/window observations are a separate walkthrough'}
for name,row in result.items():
 compact['files'][name]={'sha256':row['sha256'],'bytes':row['bytes'],'layers':{layer:{k:v[k] for k in ['arguments','cache-complete','cache-generation','generation','saved-state','definition','procedure']} for layer,v in row['layers'].items()}}
(out/'saved-capsules.json').write_text(json.dumps(compact,indent=2)+'\n')
print('PASS: eight clean capsules, three exact preserved models, one precise post-reopen matrix edit')
