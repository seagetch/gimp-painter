#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source ../gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
out=/workspace/scratch/5b5281e79681/filter-acceptance-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$out/fault-prefix-exit.txt"' EXIT
ulimit -c 0
for name in patch_cpp_scalar route_blinds route_small_tiles route_retinex route_convolution; do
  flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B migration/tests/run_filter_acceptance_native.py --build build-installed-filter --output "$out/fault-prefix-$name" --target faults --binary build-installed-filter/filter-allocation-tests-normal/painter-filter-allocation-tests --case "filter_fault_$name" > "$out/fault-prefix-$name-driver.log" 2>&1 || true
done
