#!/usr/bin/env bash
set -euo pipefail
out=/workspace/scratch/5b5281e79681/filter-acceptance-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$out/gui-launch-exit.txt"' EXIT
ulimit -c 0
flock /workspace/shared/gimp-painter-build.lock /usr/bin/python3 -B "$out/observe-gui.py" > "$out/gui-observer-driver.log" 2>&1
