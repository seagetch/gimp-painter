#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source ../gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
out=/workspace/scratch/5b5281e79681/filter-acceptance-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$out/normal-final-exit.txt"' EXIT
ulimit -c 0
for target in core ui xcf; do
  flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B migration/tests/run_filter_acceptance_native.py --build build-installed-filter --output "$out/normal-final-$target" --target "$target" > "$out/normal-final-$target-driver.log" 2>&1
done
