#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source ../gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
out=/workspace/scratch/5b5281e79681/filter-acceptance-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$out/fault-fix2-exit.txt"' EXIT
ulimit -c 0
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B migration/tests/run_filter_acceptance_native.py --build build-installed-filter --output "$out/fault-fix2" --target faults --binary build-installed-filter/app/tests/painter-filter-allocation-tests-normal > "$out/fault-fix2-driver.log" 2>&1
