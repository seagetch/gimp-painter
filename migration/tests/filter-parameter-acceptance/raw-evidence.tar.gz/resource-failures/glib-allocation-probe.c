#include <glib.h>
#include <stdio.h>
#include <string.h>
int main (int argc, char **argv) {
  const gsize size = 256u * 1024u * 1024u;
  if (argc != 2) return 2;
  printf ("GLib %u.%u.%u; requested=%zu\n", glib_major_version,
          glib_minor_version, glib_micro_version, (size_t) size);
  fflush (stdout);
  if (!strcmp (argv[1], "try")) {
    gpointer memory = g_try_malloc (size);
    if (memory) { g_free (memory); return 3; }
    puts ("TRY_ALLOCATION_FAILED_WITHOUT_ABORT");
    return 0;
  }
  if (!strcmp (argv[1], "fatal")) {
    gpointer memory = g_malloc (size);
    g_free (memory);
    return 4;
  }
  return 2;
}
