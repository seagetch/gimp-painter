Keep every part together with parts.json and reassemble.py.
These parts are local review artifacts; package/source completeness and licensing
remain governed by the original package manifest.

From this directory, verify and reassemble with Python3:
  python3 reassemble.py join . --output "gimp-painter-linux-x86_64.tar.zst"

The command refuses to overwrite existing files, checks each part, then verifies
the complete SHA-256 and byte length before reporting success.
