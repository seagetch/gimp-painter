# tasks.md — gimp-painter → GIMP 3.x / C++ 統一移植 WBS

作成日：2026-09-27（JST）
状態：実装中。チェック済みの行は「進捗証跡」に完了根拠を記録する。未チェックの行と Gate は未完了。
設計基準：`gimp-painter-gimp3-migration-analysis-ja.md` 第4版。

## 1. 到達条件とスコープ

- 旧 gimp-painter が正常に開ける作品を、移植版の通常の「開く」から開く。別アプリでの事前変換を要求しない。
- 保存された型・値・参照・階層・引数・資源設定を保持し、再編集して保存・再読込みできる。独自レイヤーの焼込みを互換対応としない。
- CloneLayer の旧仕様を維持する。内部表現の変更によって名前解決・更新・座標・複製・Undo の意味を変えない。
- FilterLayer は独自型・独自制御として、依存先優先、チェックポイント、キャンセル、結果反映、終了条件、非ブロッキング自動更新を維持する。既存 GEGL 非破壊フィルター／レイヤー効果への統合は禁止。画素格納に GeglBuffer を使うこととは区別する。
- 拡張 MyPaint、形状を使う採色、Smudge、動的紙目、非累積描画、stroke opacity、全独自設定を移植する。
- 回転の modifier とスナップ、定規、塗りつぶし、キャンバス UI 等の制作操作を維持する。
- C++ 利用 API は型付きハンドルへ、Impl の管理は単一 BindingStore へ統一する。C の入口と GObject の型・vfunc は残す。移行用旧 adapter は最終的に撤去する。
- GIMP 3.0 の対象ビルドは既に C/C++ 混在である。既存 C 全体を C++ に変更せず、独自 C++ を app に組込み、リンク・寿命・例外・callback・各 OS の実行まで成立させる。
- 初期移植は C++14 を基準とする。Rust 全面移行や Rust 導入実験は必須工程に含めない。
- 初期対象は GIMP 3.0 系。3.x 内部 API の追従手順と検証を用意し、将来の全 3.x 互換を未検証で保証しない。

## 2. 作業単位と実行規則

### タスクの単位

各行は一つの成果物または一つの検証結果を持つ末端タスク。完了条件に挙げる結果が得られてからチェックする。複数機能をまとめた「移植完了」「適宜修正」だけの作業にはしない。ID は `区分.連番` とする。

全件対象の台帳・資産・手順・vfunc の実件数はソース照合によって確定する。それらを扱う行では、実行開始時に `親ID/対象キー` の子チェックを列挙し、対象一件ごとに結果を記録する。未列挙のまま親を完了にしない。対象キーはファイルと symbol、資産名、procedure 名、fixture 名等とし、単なる追加調査で終わらせない。子作業が一つの変更または試験に収まらなければさらに分割する。

対象一件ごとの子チェックは TSV 等の台帳に保持できる。WBS に新しい行を追加するのは、独立した実装・検証の成果物と完了条件が必要なときとする。調査で問題を見つけたことと、その問題を移植先で修正して試験したことは別の状態で管理する。

### 依存と順序

依存列は必須先行 ID。同区分内は確認可能な保守的な直列順序を採用し、先行区分の最終タスクはその区分の全タスク完了を表す。並行作業を開始する場合は必要入力が揃っていることを確認して依存を明示的に更新する。タスクの省略や gate の迂回を意味しない。

外部ブロックが生じた場合は、そのタスクと依存する作業だけを blocked とし、実行可能な他の区分を進める。旧版の再現環境や実機が不足する場合も試験を合格扱いせず、環境修復・代替採取・未完了事項を同じ台帳で追跡する。

2026-10-01の並行化：05の契約は、実appにリンクしてC/GObjectとの往復・寿命試験を通した04.002/common-foundationを入力として開始する。全機能のMeson登録・生成・allocator監査を待つ必要がないため05.001の依存を明示更新した。04の他タスクと各機能の子作業は未完了のまま保持し、G1の全区分完了条件は変更しない。2026-10-04に04.002の元の完了条件（既存CをC++として再コンパイルせず独自C++を追加できる）を現行buildで再検証した。Makefile一律分類の47義務を実hunkで照合し、登録19件と既存の正しいWBSへ戻す28件を区別した。後続機能の実装・登録・検証義務は各既存WBSとソース台帳に残し、04.002へ全機能完了を追加要求しない（`migration/contracts/cpp-registration.md`）。

### 実装中に判明した不足の扱い

この WBS は確認済みソースと現行方針を広く分解した計画であり、未知の差分が存在しないと証明するものではない。そのため、全 hunk・保存項目・型・資産・呼出し境界の全件割当と、最終の未割当ゼロ照合を必須作業として含める。

不足を発見した担当は、関連する親の下に **仕様確定・実装・検証までの子タスク** を登録し、依存と機能追跡表を更新して処理する。「抜けタスクがあった」という報告だけで作業全体を終了しない。既存要件を満たす局所的な実装判断は進め、旧作品互換性や明示された禁止事項を変える判断だけは勝手に行わない。

### 各行に残す証跡

`状態 / 担当 / commitまたは成果物 / 実行した試験 / 結果 / 追加した子ID / 残存制約` を記録する。状態は TODO・DOING・BLOCKED・DONE。チェック済みは DONE に限る。対象なしの行も削除せず、台帳で対象なしを証明して完了理由を残す。

数値互換性は旧対応形式では旧結果を基準とする。高精度形式で許容差が必要なら、比較前に根拠と閾値を固定する。試験失敗に合わせて閾値を緩めない。応答性は入力準備・実行・反映・終了を含め測定し、非同期 API 使用だけを合格理由にしない。

## 3. 区分一覧


| 区分 | 作業範囲 | 先行区分 | 末端タスク数 |
|---|---|---|---:|
| 00 | 基準・成果物・追跡の固定 | なし | 12 |
| 01 | 独自差分の全件棚卸し | 00 | 17 |
| 02 | 旧版の再現環境と比較データ | 00 | 15 |
| 03 | GIMP 3.x 基準ビルド | 00 | 9 |
| 04 | C/C++ 混在ビルドの接続 | 01, 03 | 19 |
| 05 | 単一 C++ API の契約 | 01, 04 | 14 |
| 06 | 単一 C++ API の共通実装 | 05 | 29 |
| 07 | C++ 基盤の寿命・異常系試験 | 06 | 17 |
| 08 | GIMP 内部型への C++ 接続 | 06 | 20 |
| 09 | 画像・画素・Undo の共通基盤 | 03, 06 | 17 |
| 10 | 保存項目と XCF 形式の仕様化 | 01, 02 | 18 |
| 11 | 旧 XCF 読込み経路 | 08, 10, 15 | 23 |
| 12 | 新保存と往復 | 09, 11 | 16 |
| 13 | 独自合成モード | 09, 10 | 14 |
| 14 | CloneLayer の旧仕様移植 | 08, 09, 10 | 20 |
| 15 | FilterLayer のデータモデル | 08, 09, 10 | 14 |
| 16 | FilterLayer 実行器と PDB 接続 | 04, 15 | 23 |
| 17 | FilterLayer の優先順位・チェックポイント | 15, 16 | 29 |
| 18 | FilterLayer の応答性・収束試験 | 02, 12, 17 | 18 |
| 19 | 拡張ブラシ資産の reader/writer | 08, 10 | 16 |
| 20 | 拡張 MyPaint エンジン | 02, 04, 19 | 18 |
| 21 | MyPaint 押印・採色・混色 Surface | 09, 20 | 20 |
| 22 | 紙目・テクスチャ | 09, 20 | 10 |
| 23 | 独立 Smudge と描画入力 | 02, 09 | 15 |
| 24 | ブラシ editor・履歴・プレビュー | 19, 20, 21, 22 | 17 |
| 25 | 回転・反転・スナップ | 02, 03 | 12 |
| 26 | パース定規 | 08, 23 | 14 |
| 27 | 塗りつぶし brush と選択境界 | 08, 09, 23 | 15 |
| 28 | レイヤープリセットと複合構造 | 12, 13, 14, 15, 16 | 15 |
| 29 | キャンバス UI と tile view | 08, 14, 15, 24 | 20 |
| 30 | actions・設定・資源配布の統合 | 24, 25, 26, 27, 28, 29 | 17 |
| 31 | 周辺機能と重複実装の整理 | 01, 30 | 20 |
| 32 | Windows 対応 | 04, 06, 30 | 13 |
| 33 | macOS 対応 | 04, 06, 30 | 13 |
| 34 | Linux 配布と共通 CI | 07, 30 | 15 |
| 35 | GIMP 3.x の版間適合 | 04, 08, 30 | 9 |
| 36 | 作品互換性と組合せ試験 | 12, 13, 14, 18, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30 | 27 |
| 37 | 性能・安全な終了・数値差の仕上げ | 32, 33, 34, 36 | 14 |
| 38 | 差分の全件閉鎖と配布判定 | 31, 35, 37 | 17 |

固定した末端タスク：**661件**。全件照合で確定する対象別の子チェックは各行の配下へ追加し、その完了まで親は未完了とする。

## 4. WBS

### 00 基準・成果物・追跡の固定

主対象：リポジトリ、設計文書、全作業の台帳

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 00.001 | [x] | 移植元 commit を固定する | なし | afa43fae3e920210146abed514f136fd49f671b5 と取得元を baseline.json に記録 |
| 00.002 | [x] | 独自差分の基点を固定する | 00.001 | a61915a8e62aad8855cd8c620bdb7195a25ffb90 の祖先関係を記録 |
| 00.003 | [x] | 移植先の初期 commit を固定する | 00.002 | GIMP_3_0_8 の 6ac8031c9555667e080fef0324fca9f28a02e5ab を初期比較基準として記録 |
| 00.004 | [x] | 対象 3.x 系列の追従規則を決める | 00.003 | 初期 3.0 系と追加対応系列の採用条件を明記し、未試験版を対応済みにしない |
| 00.005 | [x] | 移植作業用ブランチを作る | 00.004 | 元ブランチを変更せず patch 系列を管理できる |
| 00.006 | [x] | 設計上の禁止事項を台帳に固定する | 00.005 | 旧 XCF 不可・焼込み代替・CloneLayer 仕様変更・GEGL 非破壊効果への置換を不合格と記載 |
| 00.007 | [x] | 成果物ディレクトリを定義する | 00.006 | 仕様・差分台帳・fixture・test・計測・配布の保存位置を記録 |
| 00.008 | [x] | タスクの証跡書式を定義する | 00.007 | ID、担当、状態、commit、試験結果、未解決事項を記録可能 |
| 00.008/publication-provenance | [x] | 公開済み127作業commitの内容・履歴対応を保存する | 00.008 | 元IDとGitHub再生成IDを区別し全tree・message・順序・3683blobと最終refを検証。元履歴を保存し同一treeの公開履歴へ安全に接続。CI成功や移植完了の主張ではない |
| 00.009 | [x] | 依存関係の検査器を作る | 00.008 | 未定義 ID と依存閉路を検出する |
| 00.010 | [x] | タスク追加規則を実装運用へ組み込む | 00.009 | 発見事項を親タスク下へ ID 付きで追加し、独立作業を継続する手順を記載 |
| 00.011 | [x] | 機能36項目の追跡表を登録する | 00.010 | 本書末尾の全項目が実装タスクと検証タスクへ対応 |
| 00.012 | [x] | 配布対象を固定する | 00.011 | Linux x86_64、Windows x86_64、macOS arm64/x86_64 を初期検証対象として明記 |

### 01 独自差分の全件棚卸し

主対象：旧全リポジトリ差分、C/C++ だけに限定しない

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 01.001 | [x] | 変更ファイル一覧を出力する | 00.012 | 基点対 HEAD の全ファイルに変更種別と hash を付与 |
| 01.002 | [x] | 変更 hunk 台帳を作る | 01.001 | 各 hunk に機能・基盤・生成物・資産の分類欄を持たせる。子チェック 2,489 件は `migration/inventory/changed-hunks.tsv` に列挙（01.013 の機能割当は別作業） |
| 01.003 | [x] | app 外の差分を分類する | 01.002 | libgimp、plug-ins、tools、po、data、build 等の各変更に処置を付与。子チェック 474 件は `migration/inventory/external-changes.tsv` に列挙 |
| 01.004 | [x] | C++ 型と登録箇所を列挙する | 01.003 | NewGClass、DerivedFrom、UseCStructs、Interface、GType の対応を記録。子チェック 17 件は `migration/inventory/cpp-types.tsv` に列挙 |
| 01.005 | [x] | C/C++ 呼出し境界を列挙する | 01.004 | 旧 C++ 71 ファイルの一次候補 683 件と C/ヘッダー参照 130 件を全件照合。非 gimp_ の C 入口 4 件、static callback 1 件、旧 Binder 71 と直接 class callback 40 件も別走査・現行 slot 対照で補完。間接関数ポインターの所有者、XCF 9 件を含む C 直接呼出し 33 件、共通 bridge 9 経路などを子チェックに記録（`migration/inventory/call-boundary-coverage.md`、`migration/inventory/gimp3-vfunc-contract-summary.md`）。実装時の所有権と例外の試験は機能タスクで実施 |
| 01.005/bridge-core | [x] | NewGClass と Delegator の共通境界を確定する | 01.004 | C ABI callback・登録・破棄・vfunc の 9 経路を旧版の出典行と移植時の確認事項に対応付ける（`migration/inventory/bridge-boundary-findings.tsv`） |
| 01.005/c-linkage | [x] | C 入口候補の未保護ヘッダーを分類する | 01.004 | 28 組のうちヘッダーを extern C 内で読み込む 25 組、定義を extern C 内に置く 1 組、別シグネチャの C++ overload 2 組を旧版の行番号付きで記録（`migration/inventory/c-linkage-review.tsv`） |
| 01.005/c-references | [x] | C とヘッダーの参照候補を用途別に分類する | 01.004 | 130 件を旧版の行と照合し、C の直接呼び出し構文 41、関数ポインター登録 6、C 定義 1、コメント 2、ヘッダーの宣言 65、マクロ 11、テンプレート 3、コメント 1 に分類（`migration/inventory/c-reference-review.tsv`）。直接呼出しの有効性は別子で照合 |
| 01.005/c-parameters | [x] | C 入口の引数表記を照合する | 01.004 | C++ 定義と対応するヘッダー宣言 64 組で、正規化後に一致 61、仮引数名のみ差 2、`guint` と `guint32` の型表記差 1 を記録（`migration/inventory/c-parameter-review.tsv`）。型の ABI 判定と戻り値の照合は別途必要 |
| 01.005/extern-c | [x] | extern C の scope を分類する | 01.004 | 旧 C++ の 69 scope で開閉行を照合し、ヘッダー読み込み 55、関数定義候補 9、両方 3、局所 GObject 型宣言 2 を記録（`migration/inventory/extern-c-block-review.tsv`） |
| 01.005/function-pointers | [x] | 関数ポインター構文を分類する | 01.004 | 候補 34 件を旧版の行と照合し、宣言・引数 13、間接呼び出し 21 に分類（`migration/inventory/function-pointer-review.tsv`）。呼出し先・所有権は別途追跡 |
| 01.005/vfunc-assignments | [x] | 旧 class 代入の callback と値を分ける | 01.004 | 候補 63 件から callback 40 件と class 設定 23 件を分類し、callback の定義元 40 件を行番号で照合（`migration/inventory/vfunc-assignment-review.tsv`）。現行 GIMP 3 slot 署名は別途照合 |
| 01.005/binder-sites | [x] | NewGClass の vfunc 接続を分類する | 01.004 | 候補 92 件のうちマクロ定義 21 と実接続 71 を分離し、class pointer、slot、Impl 型、alias 宣言箇所を記録（`migration/inventory/binder-site-review.tsv`）。現行 slot 署名は別途照合 |
| 01.005/property-accessors | [x] | NewGClass の property accessor を分類する | 01.004 | 旧 C++ 全体の 44 出現をマクロ定義 18、有効な接続 18、`#if 0` 内の無効な接続 8 に分け、有効な C++ メソッド所在を記録（`migration/inventory/property-accessor-review.tsv`）。型と所有権は別途照合 |
| 01.005/callback-registrations | [x] | callback 登録候補の重複と呼出し先を分類する | 01.004 | 94 候補中、対象名が見える signal 接続 60、同一接続の継続行 11、汎用 helper 転送 10 等を分類。FilterLayer の timeout に渡す生の `this` も記録（`migration/inventory/callback-registration-review.tsv`） |
| 01.005/signal-wrappers | [x] | C++ signal wrapper の所有者を分類する | 01.004 | `.connect` 22 件の保存済み handler と `.connect_noret` 25 件のハンドルを返さない接続を識別し、signal・receiver・callback を記録（`migration/inventory/signal-wrapper-review.tsv`）。解除経路の確認は別途必要 |
| 01.005/delegator-sites | [x] | delegator の実体と捕捉を分類する | 01.004 | 候補 107 件をメンバー 90、ラムダ 7、factory 4、汎用転送 4、局所関数 2 に分け、見える所有者・ラムダ捕捉を記録（`migration/inventory/delegator-site-review.tsv`）。実際の接続解除と寿命は別途検証 |
| 01.005/cpp-definitions | [x] | C++ 定義候補から有効な C 入口を分離する | 01.004 | 候補 149 件をヘッダー付き C 入口 64、局所宣言で C linkage を持つ GType 入口 2、別 C++ overload 2、static 71、template 2、`#if 0` 内 8 に分けて旧版の行番号を記録（`migration/inventory/cpp-definition-review.tsv`）。callback の ABI と所有権は別途確認 |
| 01.005/c-returns | [x] | C ヘッダー入口の戻り値を照合する | 01.005/cpp-definitions | C++ 定義と対応する C 宣言 64 組の戻り値型表記を旧版の行番号付きで照合し、空白とポインター表記の正規化後に 64 組一致（`migration/inventory/c-return-review.tsv`）。返却値の所有権と GIMP 3 での型変更は別途確認 |
| 01.005/generated-gtypes | [x] | マクロ生成 GType の C 入口を補う | 01.005/cpp-definitions | 旧 C++ の `G_DEFINE_TYPE` / `G_DEFINE_TYPE_WITH_CODE` が生成する 6 型の `get_type` を、マクロと C ヘッダー宣言の行番号で一対一に照合（`migration/inventory/generated-gtype-review.tsv`）。GIMP 3 型登録と linkage は移植時に再確認 |
| 01.005/c-entry-candidates | [x] | C 入口の構文候補を実定義と照合する | 01.005/cpp-definitions | 28 件を C ヘッダー対応の有効な定義 23、局所 C 宣言付き GType 定義 2、その局所宣言 2、`#if 0` 内の MyPaint core 定義に対応する C++ ヘッダー宣言 1 に分類（`migration/inventory/c-entry-candidate-review.tsv`） |
| 01.005/c-pointer-registrations | [x] | C 側の関数ポインター登録から利用先まで追う | 01.005/c-references | 6 件のうち factory が保持する資源 callback 2 件、渡された callback を同期呼出しするツール 1 件、独自登録へ直接進むツール 3 件の typedef・保持・呼出し箇所を記録（`migration/inventory/c-pointer-registration-review.tsv`）。資源オブジェクトの返却所有権は移植時に確認 |
| 01.005/xcf-c-entries | [x] | 旧 XCF の C→C++ 境界を追う | 01.005/c-references | XCF reader の直接呼出し 6 件と writer の 3 件について返却値・参照・副作用を照合し、CloneLayer の名前遅延解決と FilterLayer 引数のコピー・解放要件を記録（`migration/inventory/xcf-c-entry-review.tsv`）。旧 writer の引数コピー未解放と null source 参照は移植時に修正 |
| 01.005/c-direct-call-activity | [x] | C の直接呼出し候補を有効・無効に分類する | 01.005/c-references | 41 構文候補のうち C++ 入口への有効呼出し 33、別 C 実装への有効呼出し 2、`#if 0` / `#if 1` の反対分岐にある無効呼出し 6 を分離し、ガード行と呼出し式を記録（`migration/inventory/c-direct-call-activity.tsv`） |
| 01.005/non-xcf-c-calls | [x] | XCF 以外の有効な C→C++ 呼出しを追う | 01.005/c-direct-call-activity | 残る 24 件・14 symbol の入口・戻り値・所有者を記録（`migration/inventory/non-xcf-c-call-review.tsv`）。MyPaint editor の矛盾した型検査と NULL options、Guide getter の結果未確認を移植時の修正点として特定 |
| 01.005/deferred-sources | [x] | 遅延 callback の解除経路を追う | 01.005/callback-registrations, 01.005/delegator-sites | FilterLayer の ID 未保存 timeout と、ID を保持し破棄時に解除する layer preview idle の所有者・捕捉を照合（`migration/inventory/deferred-source-review.tsv`）。viewable の寿命は移植時の検証対象 |
| 01.005/fill-brush-boundary | [x] | 塗りつぶしブラシの旧 paint core 入口と現行 GEGL 境界を照合する | 01.004 | 旧 GType・paint vfunc・projection snapshot・有界探索・paint paste を現行 API と対照（`migration/inventory/fill-brush-rendering.md`）。移植と実測は後続子タスク |
| 01.005/candidate-coverage | [x] | 一次候補と分類結果の全件照合を自動化する | 01.005/deferred-sources, 01.005/fill-brush-boundary, 01.005/non-xcf-c-calls | C++ 683 件と C/ヘッダー 130 件を分類済み行に一対一照合し、直接呼出し 33 件、登録 6 件と別走査の項目も検査（`migration/inventory/call-boundary-coverage.md`） |
| 01.005/missed-c-entries | [x] | 正規表現に拾われない C 公開入口と呼出しを照合する | 01.005/candidate-coverage | 旧 app の 2,051 C/C++ ソース・ヘッダーを逆引きし、非 gimp_ C 公開入口 4 件、C 直接呼出し 3 件、C callback 登録 1 件、static callback 1 件を発見・分類（`migration/inventory/non-gimp-c-entry-review.tsv`）。C++ 専用工場 2 件と既存 GType マクロ生成 6 件も照合し後続機能タスクへ割当 |
| 01.005/indirect-callback-owners | [x] | 間接関数ポインターの呼出し先・所有権を確定する | 01.005/candidate-coverage | 34 候補の保存先・呼出し・解放経路を一対一に照合（`migration/inventory/indirect-callback-owner-review.tsv`）。preset action-group static callback は 01.005/preset-action-factory-owner で確認。v1 曲線の無条件スキップ、借用 callable、popover signal の寿命を後続タスクへ割当 |
| 01.005/preset-action-factory-owner | [x] | preset action-group の間接 callback 保持者を追う | 01.005/missed-c-entries | 旧 factory の setup/update 関数ポインター保持・呼出し・解放と現行の group キャッシュを照合（`migration/inventory/preset-action-factory-callback.md`）。移植の実装は 28.014/preset-action-group |
| 01.005/gimp3-vfunc-contract | [x] | 旧 vfunc と現行 GIMP 3 slot の署名・寿命を照合する | 01.005/candidate-coverage | 40 class callback と 71 binding の全111件を子チェックで行単位に照合。削除 slot・独自型再作成・署名変更、所有者と例外境界の後続タスクを記録（`migration/inventory/gimp3-vfunc-contract-summary.md`）。実装・試験は未完了 |
| 01.005/gimp3-layer-slots | [x] | CloneLayer と FilterLayer の旧 vfunc を現行 slot と対照する | 01.005/indirect-callback-owners | 旧 Binder 34 箇所を C ヘッダーの実 slot 署名へ対応付け、削除された `project_region` / `is_editable` と新 GEGL source node、引数・戻り値の変化を記録（`migration/inventory/gimp3-layer-vfunc-review.tsv`）。実装は機能タスク |
| 01.005/gimp3-tool-slots | [x] | 塗りつぶしブラシと操作ツールの vfunc を現行 slot と対照する | 01.005/gimp3-layer-slots | 旧 Binder 18 件の宣言を照合（`migration/inventory/gimp3-tool-vfunc-review.tsv`）。塗りつぶしブラシの paint 引数は GList と GimpSymmetry に変更。定規と placeholder の 17 件は C 宣言の署名が同じ |
| 01.005/gimp3-core-binders | [x] | Undo・canvas・JSON 資源の Binder slot を現行 C ヘッダーと対照する | 01.005/gimp3-tool-slots | 旧 Binder 6 件を行単位で照合（`migration/inventory/gimp3-core-binder-review.tsv`）。canvas の shell 引数削除 2 件、JSON save の出力 stream 追加 1 件、署名一致 3 件。移植は各機能タスク |
| 01.005/gimp3-external-binders | [x] | GTK/GLib と旧独自型の Binder 境界を照合する | 01.005/gimp3-core-binders | 残る 13 件を公開 GTK 2.24 / GTK 3.24、GLib 2.32 / 2.80 の固定ヘッダーと旧独自型宣言へ一対一に照合（`migration/inventory/gimp3-external-binder-review.tsv`）。署名一致 7、変更 3、移植先の型未作成 3。実装は各機能タスク |
| 01.005/gimp3-brush-callbacks | [x] | 拡張 MyPaint ブラシ資源の class callback を現行 slot と対照する | 01.005/gimp3-external-binders | 旧定義と旧 slot の一致も確認した 15 件の照合表（`migration/inventory/gimp3-brush-callback-review.tsv`）。現行署名一致 9、変更 2、独自型再作成待ち 4。save/preview の差分を実装タスクに割当 |
| 01.005/gimp3-tool-callbacks | [x] | 拡張 MyPaint 操作ツールの直接 callback を照合する | 01.005/gimp3-brush-callbacks | 旧 C++ 定義 10 件が旧 slot と現行 GIMP 3 slot の両方で同じ署名（`migration/inventory/gimp3-tool-callback-review.tsv`）。tool core の保持・破棄を機能タスクに割当 |
| 01.005/gimp3-remaining-callbacks | [x] | ブリッジ・MyPaint Undo/options/editor の class callback を照合する | 01.005/gimp3-tool-callbacks | 残り 15 件の旧 C++ 定義・旧 slot・現行 slot の署名一致を記録（`migration/inventory/gimp3-remaining-callback-review.tsv`）。旧例外時の exit と Undo pop の空実装を後続へ割当 |
| 01.006 | [x] | 状態付加箇所を列挙する | 01.005 | data/qdata のキー、Impl 型、所有者、破棄経路を記録 |
| 01.006/cpp-candidates | [x] | 旧 C++ の data/qdata 候補を抽出する | 01.005 | 旧版の 71 C++ ファイルの 30 呼び出し構文、キー、対象、値、destroy callback を TSV に記録 |
| 01.006/owning-attachments | [x] | C++ の所有権付き付加を照合する | 01.006/cpp-candidates | 10 箇所の型、owner、destroy callback、他の参照経路と寿命の懸念を記録 |
| 01.006/cpp-ownership | [x] | C++ 付加値の所有者と破棄経路を照合する | 01.006/cpp-candidates | Impl 型と全使用先を追い、共有ポインターと signal の寿命を判定 |
| 01.006/c-candidates | [x] | 旧差分 C ファイルの data/qdata 候補を抽出する | 01.006/cpp-candidates | 220 ファイルの呼び出し式 185 件を出典行、キー、値、destroy callback とともに列挙 |
| 01.006/c-state | [x] | C ソースの状態付加を照合する | 01.006/cpp-candidates | 旧差分の C 側 data/qdata をキー、型、所有者、破棄経路まで照合 |
| 01.007 | [x] | 参照管理箇所を列挙する | 01.006 | hold/ref、GValue、CXXPointer、raw pointer の保持・解放を記録 |
| 01.007/cpp-candidates | [x] | 旧 C++ の参照管理候補を抽出する | 01.006 | 71 ファイルの hold/ref、GValue、CXXPointer 構文を出典行付きで列挙 |
| 01.007/ref-hold | [x] | 旧 C++ の hold/ref/unref を分類する | 01.007/cpp-candidates | 明示的な 52 箇所を helper、採用、参照追加、解放、借用疑義に分類する |
| 01.007/scoped-pointers | [x] | CXXPointer の対象型と破棄を分類する | 01.007/cpp-candidates | 54 箇所を signal connection、source、delegator、C++ instance に分類する |
| 01.007/gvalue | [x] | 旧 C++ の GValue 使用箇所を分類する | 01.007/cpp-candidates | 136 箇所の helper、配列借用、初期化、引数、値ポインターを分類する |
| 01.007/raw-candidates | [x] | C++ の raw pointer 寿命構文を抽出する | 01.007/cpp-candidates | new/delete/g_free/weak pointer の出典行を列挙し、弱参照解除漏れの候補を記録する |
| 01.007/weak-pointers | [x] | C++ weak pointer の登録と解除を照合する | 01.007/raw-candidates | 4 箇所の対象、スロット、存続期間、解除経路を出典行付きで記録する |
| 01.007/mapping-array | [x] | MyPaint Mapping 配列の確保・破棄を照合する | 01.007/raw-candidates | new[] と delete の不一致、既定コピー構築の共有リスクを出典行で記録する |
| 01.007/raw-activity | [x] | raw pointer 候補の有効性を分類する | 01.007/raw-candidates | 168 箇所を確保・解放・weak 登録とコメント/文字列に分ける |
| 01.007/class-pointer-exception | [x] | class 初期化時の pointer 例外を追跡する | 01.007/raw-activity | InvalidClass の new/throw と未解放経路を出典行で記録する |
| 01.007/dict-transfer | [x] | MyPaint 設定辞書の返り値参照を照合する | 01.007/ref-hold | 7 箇所の hold の取得元と HashTable の解放、静的辞書の追加保持を出典行で記録する |
| 01.007/router-tree | [x] | 旧 HTTP router の規則木の所有を照合する | 01.007/raw-activity | 二世代の Router の生成・破棄と TokenRule 派生型の削除契約を追跡する |
| 01.007/connection-signal | [x] | signal Connection の補助文字列を追跡する | 01.007/scoped-pointers | g_strdup した signal 名の解放先と target・closure の解放契約を調べる |
| 01.007/value-wrapper | [x] | GValue wrapper の代入時所有権を追跡する | 01.007/gvalue | CopyValue の copy/move 代入と一時値の破棄経路を出典行で確認する |
| 01.007/array-wrapper | [x] | GLib 配列 wrapper の代入時所有権を追跡する | 01.007/raw-activity | Array の二種類の移動代入と旧 GArray の解放経路を確認する |
| 01.007/icon-buffer | [x] | MyPaint アイコン画素の所有権を追跡する | 01.007/raw-activity | Cairo surface と backing buffer の解放・stride・自己代入経路を旧ソースで照合する |
| 01.007/mypaint-brush-private | [x] | MyPaint ブラシ資源の raw pointer を対応付ける | 01.007/raw-activity | 16 箇所を GObject private・設定・preview・weak slot の所有者と解放経路へ対応付ける |
| 01.007/mypaint-core-raw | [x] | MyPaint paint core の raw pointer を対応付ける | 01.007/raw-activity | 14 候補の active/非 active、surface・stroke・brush・signal connection の破棄経路を追う |
| 01.007/surface-regions | [x] | MyPaint Surface の一時 PixelRegion を対応付ける | 01.007/raw-activity | 14 箇所の一時領域解放と Surface factory の所有者を描画・採色経路で照合する |
| 01.007/cpp-ownership | [x] | C++ 参照と raw pointer の所有権を確定する | 01.007/cpp-candidates | 候補を用途別に分類し、新規参照・借用・解放・例外経路を対応付ける |
| 01.007/c-candidates | [x] | 旧差分 C ファイルの参照操作を抽出する | 01.007/cpp-candidates | 220 ファイルの ref/unref と GValue 操作を hunk 位置とともに列挙する |
| 01.007/c-hunk-roles | [x] | C の変更 hunk 内参照操作を分類する | 01.007/c-candidates | 74 件を参照追加、sink、解放、GValue 初期化・格納に分類する |
| 01.007/c-added-lines | [x] | C の変更行と上流文脈を判別する | 01.007/c-hunk-roles | hunk 内の 74 件を変更前・変更後 blob の実差分と照合する |
| 01.007/toolbar-ref | [x] | 旧 toolbar の widget 参照経路を確定する | 01.007/c-added-lines | data-full の保持、付け替え時の一時参照、hide 時の余剰参照を出典行付きで記録する |
| 01.007/c-state | [x] | C 側の変更行で参照管理を照合する | 01.007/cpp-candidates | 追加差分 74 行の ref/unref、GValue、raw pointer の所有者・解放契約と移植時の追跡先を記録 |
| 01.008 | [x] | シグナルと idle source を列挙する | 01.007 | 接続先、user data、解除、優先度、再入可能性を記録 |
| 01.009 | [x] | 保存経路を列挙する | 01.008 | XCF、myb、JSON、設定、parasite の reader/writer を記録 |
| 01.010 | [x] | 追加 enum と生成元を列挙する | 01.009 | 手書き定義・生成スクリプト・生成物・保存数値を対応 |
| 01.011 | [x] | 旧依存ライブラリーを列挙する | 01.010 | API、版、リンク方法、ライセンス、配布対象を記録 |
| 01.012 | [x] | 上流に取り込まれた変更を照合する | 01.011, 01.012/hunk-coverage, 01.012/contract-review, 01.012/counterexamples | 全2,489 hunk×2固定比較先と19契約を照合。実ソースから切り出したC式で筆圧・丸め反例とXCF番号衝突を検証。全体の動作同等性は認定せず各後続試験へ追跡（`migration/inventory/upstream-comparison.md`） |
| 01.012/hunk-coverage | [x] | 全旧hunkを二つの固定上流へ対照する | 01.011 | 4,978子チェックにblob・payload hash・連続追加行／削除行の存在と同等性未証明を記録。元hunk集合の完全性を検査する |
| 01.012/contract-review | [x] | 同名機能の実装と保存・操作契約を照合する | 01.011 | 19契約×2比較先を実ソース行と後続WBSへ対応し、ヘッダー一致と機能同等性を分離する |
| 01.012/counterexamples | [x] | 実ソース式の筆圧・丸め・属性番号反例を実行する | 01.011 | C99で切り出した両式をrint/floor両経路で実行し、静止筆圧の差と32/33属性衝突を確認。GIMP全体replayの代用にしない |
| 01.013 | [x] | 各差分を WBS に割り当てる | 01.012 | 全2,489 hunk・947変更pathと402資産/manifestをsource blob・範囲・hash付きで具体的WBSと検証先へ割当。未割当ゼロ、3子タスク追加（`migration/inventory/wbs-assignment.md`）。実装は未完了 |
| 01.014 | [x] | 不要候補を分類する | 01.013 | 全947 pathを固定blobで確認し、空linker carrier・非空backup・生成物16件・コメント等のみ9件・live editor・placeholder・Ruby generator・実presetを分離（`migration/inventory/cleanup-candidates.md`）。削除は未実施 |
| 01.015 | [x] | C++ 以外の補助スクリプトを照合する | 01.014 | 全37 auxiliary path・83 hunkと6生成関係を照合。Ruby/Bash/Perl・Scheme定数・未変更Python依存を対応し、欠落generatorと旧dispatch生成不整合を記録（`migration/inventory/auxiliary-scripts.md`） |
| 01.016 | [x] | 標準 paint の独自差分を照合する | 01.015, 01.016/bucket-selection-source | paintbrush・Smudge・dynamics・context・bucket・入力36pathの306hunkを全変更行と固定移植先へ対応（`migration/inventory/standard-paint-contracts.md`）。実行互換性は後続試験 |
| 01.016/bucket-selection-source | [x] | 旧標準 bucket fill の選択境界差分を現行全域探索と照合する | 01.015, 01.005/fill-brush-boundary | source mask入力・境界・alpha・offset・探索後clipとの差を確認。旧C式の6試験で部分coverageと閾値255の通過反例を検証、実作品fixtureは27.005/selection-threshold-contractへ追跡 |
| 01.017 | [x] | 全差分の粒度を検査する | 01.016 | 2,891 sourceチェックを16,153実装・6,881検証の単一WBS義務へ展開し全23,034実行行をTODOで分離。複合event・factory・tool登録を分割、欠落/重複/根拠なしDONEをgateで拒否（`migration/inventory/granularity-audit.md`） |

### 02 旧版の再現環境と比較データ

主対象：旧版実行・代表作品・入力記録

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 02.001 | [x] | 旧版ビルド依存を固定する | 00.012 | Debian13署名済snapshotのpackage/hash、babl0.1.46・GEGL0.3.34固定commit、ローカルtool relocationと全build適合patchを記録（`migration/baseline/legacy/`） |
| 02.002 | [x] | 旧版のビルド手順を再現する | 02.001 | 固定afa43faeと明示build適合patchからGIMP2.8.23をbuild/installしbinary hashと全stage logを保存（`migration/baseline/legacy/build-report.json`）。完成recipeの第二clean replayは未実施 |
| 02.003 | [x] | 旧版の起動と描画を確認する | 02.002 | 隔離profileの実旧版をheadless起動し、新規96×80画像と制御された一筆・PNG・XCFを記録（`migration/fixtures/legacy-runtime/`）。GUI/ペンdevice操作は未検証 |
| 02.004 | [x] | 通常レイヤーの旧 XCF fixture を作る | 02.003 | 属性・画像・期待値を保存 |
| 02.005 | [x] | CloneLayer の旧 XCF fixture を作る | 02.004 | 参照元種類と階層を識別したファイルを保存 |
| 02.005/resize-undo-capture | [x] | 実旧CloneLayerのresize/Undo/maskを観測する | 02.005 | 2有効RGB scene・12状態・8 Undo/Redoの実行を記録し、非理想な座標/history増加とmask不変を保存（`migration/fixtures/legacy-clone-undo/`） |
| 02.006 | [ ] | FilterLayer の旧 XCF fixture を作る | 02.005 | procedure・引数・キャッシュ・下層を含むファイルを保存 |
| 02.006/writer-negative-fixture | [x] | 実旧FilterLayerの実行・保存とreader失敗を記録する | 02.005 | 実plug-in-edge非同期完了後のcache・6引数を旧writerで保存し、旧readerの再読込segfaultを別途再現（`migration/fixtures/legacy-runtime/`）。成功往復の代用にしない |
| 02.007 | [ ] | 複合レイヤー作品を fixture 化する | 02.006 | アニメ塗り・水彩の再編集操作記録を保存 |
| 02.008 | [x] | 同梱ブラシ資産を固定する | 00.001 | 177 個の myb の version と hash を保存。固定 commit の386資産を Git blob ID・SHA256・出典へ対応（`migration/fixtures/legacy-source/`）。旧版実行を必要としない独立採取へ依存を明示変更 |
| 02.009 | [x] | 筆跡入力の記録形式を定義する | 02.008 | 全GimpCoords・原時刻・筆圧・傾き・方向・RNGのfloat保存bitと実seed・初期状態・資産・出力hashを表現（`migration/fixtures/strokes/FORMAT.md`）。11形式試験に合格。実測採取は02.010 |
| 02.010 | [ ] | 旧版の筆跡記録を採取する | 02.007, 02.009 | 代表ブラシごとの入力列と結果画素を保存 |
| 02.011 | [ ] | 旧版のレイヤー操作を記録する | 02.010 | 移動・複製・削除・Undo の参照と更新結果を保存 |
| 02.012 | [ ] | 旧版の回転操作を記録する | 02.011 | 修飾キー遷移・半刻み・反転時の期待角を保存 |
| 02.013 | [ ] | 旧版の実行順序を計測する | 02.012 | FilterLayer 開始・停止要求・完了・伝播の時系列を保存 |
| 02.014 | [ ] | 比較用資産の権利と由来を記録する | 02.013, 02.014/source-register | 再配布可能 fixture とローカル専用作品を分離 |
| 02.014/source-register | [x] | 固定source資産と比較fixtureの由来を分類する | 02.008 | 元のnoticeとhashを記録し、未採取の実行fixtureと非公開作品を分離（`migration/fixtures/PROVENANCE.md`） |
| 02.015 | [ ] | 旧版起動失敗の復旧手順を用意する | 02.014, 02.015/recovery-procedure | 依存修復・既存実行環境利用・静的仕様抽出を手順化し、未採取の比較試験は未完了のまま追跡 |

| 02.015/recovery-procedure | [x] | 旧環境の失敗を記録し復旧手順を固定する | 00.001 | 実際のbootstrap失敗と固定source・隔離依存・別環境利用・静的採取の手順を記録。旧実行未確認は親02.015に保持（`migration/baseline/legacy-build.md`） |

### 03 GIMP 3.x 基準ビルド

主対象：Meson、依存、変更前の起動

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 03.001 | [x] | 対象版 Meson 定義を確認する | 00.012 | 既に C と C++ が有効なこと、C++14 と最低 Meson 条件を記録 |
| 03.002 | [x] | Linux 基準ビルド環境を固定する | 03.001 | compiler・GLib・GTK・GEGL・babl 等の版を記録 |
| 03.003 | [x] | 変更前の Linux GIMP をビルドする | 03.002 | 設定からリンクまでの成功ログを保存 |
| 03.004 | [x] | 変更前の GIMP を起動する | 03.003 | 空画像・標準描画・保存・終了が動作 |
| 03.005 | [x] | 隔離ユーザープロファイルを用意する | 03.004 | 既存 GIMP 設定とテスト資産が混ざらない |
| 03.006 | [x] | Meson オプションの台帳を作る | 03.005 | debug/release、sanitizer、optional dependency を記録 |
| 03.007 | [x] | C++ 標準の指定箇所を整理する | 03.006 | 初期 C++14、対象別引上げの条件が明示される |
| 03.008 | [x] | 基準版の標準試験を実行する | 03.007 | 既存失敗と移植起因の失敗を区別可能。基準版 app suite 4/5 成功、`save-and-export` は移植前から失敗（`migration/baseline/standard-tests.md`） |
| 03.009 | [x] | ビルドキャッシュの再現条件を記録する | 03.008 | cache 無効の clean build 手順を保持（`migration/baseline/linux-build.md`） |

2026-10-02の並行化：04.003は既存C headerの可読性監査なので、全feature登録ではなく01.017の確定source台帳と04.002/common-foundationの混在compiler環境を入力とする。未実装featureのheader/link検証とG1全区分完了条件は維持する。

### 04 C/C++ 混在ビルドの接続

主対象：app の Meson と C 公開境界

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 04.001 | [x] | 独自 C++ モジュールの配置を決める | 01.017, 03.009 | GLib/GObjectのみの共通bridgeとcore・paint・PDB・UI・presetsの依存方向、C公開ヘッダーとprivate C++配置を記録（`migration/contracts/module-layout.md`） |
| 04.002 | [x] | C++ ソースを Meson の対象へ登録する | 04.001 | 既存 C ソースを C++ として再コンパイルせず追加できる |
| 04.002/common-foundation | [x] | 共通C++基盤を実appと最小混在試験へ接続する | 04.001 | GObject-only static library、C入口とGimp.dispose、明示C++ link、31寿命/例外試験を統合。通常・ASan/UBSan・Meson・install後smokeに合格（`migration/tests/painter-integration.json`）。旧証跡は履歴として保持し、現行登録の再検証は親04.002の証跡を参照 |
| 04.002/foundation-acceptance-matrix | [x] | 基盤WBS全50項目を実装・実行証跡・未達へ照合する | 04.002/common-foundation, 17.001/configured-spill-budget | 46component検証済/3partial/1platform未達を別台帳化し親依存は維持。実base/derived/GInterface/property/parent dispose再入を追加し34通常/ASan・UBSan/Meson合格、5台帳改竄検査合格。新規qdata残存箇所も未解決として保持 |
| 04.002/evidence-reproducibility | [x] | test証跡のJSON/JSONLと継承環境の最小化を検証する | 04.002/foundation-acceptance-matrix | 単行/複数行/nested JSONとtext framing/冪等性の7検査合格。未公開4commitの環境metadataと対応checksumのみ修正しcode・構造化結果不変を検証、全移植history/復旧archive再scanで残存markerゼロ。認識外opaque秘密の不存在までは主張しない |
| 04.003 | [x] | C ヘッダーの C++ 可読性を監査する | 04.002/common-foundation, 01.017 | 既存42 header経路・89 hunk義務を監査し予約語/flags変換を修正。C/C++二重include、全18macro展開とABI配置の88 probe合格（`migration/contracts/c-header-audit.md`）。後続feature追加headerと他platformは各作業で検証 |
| 04.004 | [ ] | C 公開ヘッダーの linkage を整える | 04.003 | C と C++ の両方から include できる |
| 04.005 | [ ] | C++ 専用ヘッダーの公開範囲を制限する | 04.004 | C の translation unit に template・STL が漏れない |
| 04.006 | [ ] | 相互呼出しの最小試験を作る | 04.005 | C→C++→C の値とエラーが往復する |
| 04.007 | [ ] | GObject callback から C++ への最小試験を作る | 04.006 | constructor・callback・destructor の順が確認できる |
| 04.008 | [ ] | 最終リンクの C++ runtime を接続する | 04.007 | C 主体 executable から C++ object を解決できる |
| 04.009 | [ ] | 静的 library のリンク順を検証する | 04.008 | 未参照登録 object の脱落と循環依存を検出 |
| 04.009/json-dependency | [ ] | JSON reader/writer の直接リンク依存を登録する | 04.009, 01.011 | JSON-GLib のinclude/linkをcore・presetsへ明示し、他依存を外しても未解決symbolが出ない |
| 04.010 | [ ] | 例外方針を compiler 設定に反映する | 04.009 | C++ 内部での扱いと C 境界での捕捉が一致 |
| 04.011 | [ ] | RTTI 使用箇所を分離する | 04.010 | 移行用 dynamic_cast の条件と新 API の非依存を記録 |
| 04.011/sanitizer-rtti-scope | [x] | focused sanitizerのRTTI補完範囲を実compile DBから区別する | 04.002/common-foundation | 3 metadata試験でC++各suffix・command/arguments・production境界を確認。-fno-rtti補完はRTTI-onlyとinstrumentedを区別しvptrを無効化しない。過去cpp-only helperをSHA付き保存し拡張closureの全runtime合格は主張しない |
| 04.012 | [ ] | symbol visibility を設定する | 04.011 | 必要な C 入口のみ公開し、内部 C++ ABI を配布契約にしない |
| 04.013 | [ ] | enum 等の生成規則を Meson に接続する | 04.012 | 生成元変更で C/C++ 両方の対象が再ビルドされる |
| 04.013/brush-setting-generator | [x] | 旧MyPaint設定の生成元を復元する | 04.002/common-foundation, 01.010 | 旧treeにないgenerate.pyの代わりに名前・index・型・既定値の正本を定め、103定数と設定tableを再生成し差分検査する |
| 04.014 | [ ] | ヘッダー単体のコンパイル試験を登録する | 04.013 | 対象 C ヘッダーを C と C++ で検査 |
| 04.015 | [ ] | incremental build を検証する | 04.014 | 共通ヘッダー変更で必要な object が更新される |
| 04.016 | [ ] | install 後の起動を検証する | 04.015 | build tree に依存せず独自モジュールを含め起動する |
| 04.017 | [ ] | 生成 C ヘッダーの二重 include を試験する | 04.016 | C linkage と include guard が安定 |
| 04.018 | [ ] | C++ static 初期化の順序依存を除去する | 04.017 | GIMP 初期化前に型登録や GTK 呼出しを行わない |
| 04.019 | [ ] | 異なる allocator の解放を監査する | 04.018 | new/delete と GLib allocation の対応が全境界で一致 |

### 05 単一 C++ API の契約

主対象：ObjectRef、BindingStore、typed slot の設計

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 05.001 | [x] | 型付きハンドルの型一覧を定義する | 01.017, 04.002/common-foundation | 旧traits・全独自型・C入口ownerの90型に一意な名前付きhandleを定義し、76 C入口への単一路を照合（`migration/contracts/cpp-handle-registry.tsv`）。各feature実装は別途未完了 |
| 05.002 | [x] | ハンドルの所有規約を定義する | 05.001 | retain・adopt・sink の差を記載 |
| 05.003 | [x] | ハンドルの copy/move 規約を定義する | 05.002 | 参照数増減と moved-from 状態を記載 |
| 05.003/retained-item-lifetime | [x] | 所有handleがImage/Gimpを越えるItem寿命を修正する | 14.015/reference-undo-snapshot | imageとID-table ownerをweak追跡しreplace/移動/終了を対称解除。37通常/focused sanitizer、実Gimp終了後のitem解放を検証。no-font既知guardを明示 |
| 05.003/native-tool-press-lease | [x] | 公開tool press呼出し後処理までownerを保持する | 05.003/retained-item-lifetime | subclass callbackが最後の外部refを解放する実public wrapper再現が通常/3unit ASan・UBSan合格。subclass return後のcontrol/座標bookkeeping UAFをoperation leaseで防止。実device配送は別gate |
| 05.004 | [x] | 短期借用の規約を定義する | 05.003, 05.004/bound-method-lifetime | 保存不可・非同期持出し不可の境界を明示 |
| 05.004/bound-method-lifetime | [x] | 旧 BoundMethod の借用 object 寿命を新 API に定義する | 05.003, 01.005/indirect-callback-owners | `operator[]` から返る callable が object の参照を持たないことを考慮し、保持・遅延使用を禁止または weak/strong handle へ移す |
| 05.005 | [x] | C++ メソッドと C 入口を対応付ける | 05.004 | 同じ操作の第二実装を作らない対応表がある |
| 05.006 | [x] | 型付き slot の宣言形式を定義する | 05.005 | GType・Impl 型・key・close 方針が固定される |
| 05.007 | [x] | BindingStore の登録規約を定義する | 05.006 | 一 object 一 store、重複登録・稼働中置換の扱いを明記 |
| 05.008 | [x] | 構築状態の遷移を定義する | 05.007 | 未接続・稼働・終了・解放の許可操作を列挙 |
| 05.009 | [x] | close の契約を定義する | 05.008 | 冪等、非待機、世代失効、接続解除を明記 |
| 05.010 | [x] | dispose 後の操作契約を定義する | 05.009 | 読取り可能項目と失敗すべき変更操作を列挙 |
| 05.011 | [ ] | 親 vfunc の呼出し規約を定義する | 05.010 | 対象型ごとの呼出し順と callback 再入を記載 |
| 05.012 | [ ] | main context の所有規約を定義する | 05.011 | GObject・UI と worker の操作可能範囲を記載 |
| 05.013 | [ ] | エラー境界を定義する | 05.012 | 型不一致・未登録・終了済み・例外の返し方を統一 |
| 05.013/class-init-error | [ ] | class 初期化失敗を C ABI 内で処理する | 05.013, 01.007/class-pointer-exception | pointer 例外を廃止し、部分登録と再試行の状態を試験する |
| 05.013/legacy-exit-removal | [ ] | 旧 property callback の例外時 exit を C ABI 安全な処理へ変更する | 05.013, 01.005/gimp3-remaining-callbacks | setter/getter の例外でプロセスを終了せず、GValue と登録済み property の状態を整合させて通知・復帰する |
| 05.014 | [ ] | 移行 adapter の撤去条件を定義する | 05.013 | 旧 API 利用箇所ゼロを機械検査できる |

### 06 単一 C++ API の共通実装

主対象：共通 bridge library

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 06.001 | [ ] | ObjectRef の retain factory を実装する | 05.014 | 受取時に一参照を取得する |
| 06.002 | [ ] | ObjectRef の adopt factory を実装する | 06.001 | 受取済み所有参照を重複取得しない |
| 06.003 | [ ] | ObjectRef の sink factory を実装する | 06.002 | floating ref の扱いが GTK の所有規約と一致 |
| 06.004 | [ ] | ObjectRef の copy/move を実装する | 06.003 | copy と移動の参照数が契約どおり |
| 06.005 | [ ] | ObjectRef の型検査を実装する | 06.004 | 誤った GType を拒否する |
| 06.006 | [ ] | weak handle を実装する | 06.005 | 消滅後の取得が失敗し、取得時だけ strong ref を得る |
| 06.007 | [ ] | BindingStore の qdata 登録を実装する | 06.006 | 予約 key 一つで store が一意に存在 |
| 06.008 | [ ] | typed slot の登録を実装する | 06.007 | 重複・不正型・終了後登録を拒否する |
| 06.009 | [ ] | typed slot の取得を実装する | 06.008 | 取得が暗黙生成を起こさない |
| 06.010 | [ ] | Impl の所有と解放を実装する | 06.009 | store が一度だけ destructor を呼ぶ |
| 06.011 | [ ] | close の状態遷移を実装する | 06.010 | 再入と二重呼出しが安全 |
| 06.012 | [ ] | 呼出し中の再入保護を実装する | 06.011 | close が発生しても stack 上の Impl を破棄しない |
| 06.013 | [ ] | C 入口の例外変換を実装する | 06.012 | C の呼出し元へ例外が越境しない |
| 06.014 | [ ] | vfunc の型付き trampoline を実装する | 06.013 | 不一致な関数ポインター cast を使わない |
| 06.015 | [ ] | property の転送を実装する | 06.014 | 型・既定値・notify を保持 |
| 06.016 | [ ] | GInterface の登録 adapter を実装する | 06.015 | class と interface の登録を混同しない |
| 06.017 | [ ] | Connection の所有管理を実装する | 06.016 | target 先行破棄時にも安全に切断できる |
| 06.018 | [ ] | Connection の block/unblock を実装する | 06.017 | 旧 after と一時抑制の順序を維持 |
| 06.019 | [ ] | idle source の所有管理を実装する | 06.018 | close 後に user data を参照しない |
| 06.020 | [ ] | GValue の所有 wrapper を実装する | 06.019 | borrow・copy・unset・free を明示して二重解放しない |
| 06.020/value-assignment | [ ] | GValue wrapper の再代入を安全にする | 06.020, 01.007/value-wrapper | copy/move/self 代入で旧値を解放し、確保領域と値を一度だけ破棄する |
| 06.021 | [ ] | GLib 配列と文字列の所有 wrapper を実装する | 06.020 | allocator 対応が一致 |
| 06.021/array-reassignment | [ ] | 配列 wrapper の再代入を安全にする | 06.021, 01.007/array-wrapper | 旧 GArray 参照を解放し、自己移動と空配列の操作を検証する |
| 06.022 | [ ] | mutex guard の置換を実装する | 06.021 | 早期 return・例外でも unlock する |
| 06.023 | [ ] | GTK DSL を新ハンドルへ接続する | 06.022 | Definer/Packer の旧二重所有を排除 |
| 06.024 | [ ] | qdata lookup の処理単位を制限する | 06.023 | 画素ループ内では解決済み借用だけを使う |
| 06.025 | [ ] | 派生型と基底型の slot 解決を実装する | 06.024 | 同一 object 上の複数階層の Impl を誤取得しない |
| 06.026 | [ ] | 継承 property の委譲を実装する | 06.025 | 未知 property ID を正しい親処理へ渡す |
| 06.027 | [ ] | 終了フックの順序を実装する | 06.026 | 派生・基底・store の close と親 dispose が二重解放しない |
| 06.028 | [ ] | 非同期 job の独立状態を実装する | 06.027 | owner Impl を捕捉せず入力・結果・cancel 状態を所有 |
| 06.029 | [ ] | 構築失敗の解放経路を実装する | 06.028 | 例外や登録失敗で半構築 store を漏らさない |

### 07 C++ 基盤の寿命・異常系試験

主対象：bridge の独立検証

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 07.001 | [ ] | retain/adopt/sink を試験する | 06.029 | 各経路の最終 refcount と解放回数を検証 |
| 07.002 | [ ] | copy/move/null を試験する | 07.001 | 自己代入と空ハンドルを含め二重解放がない |
| 07.003 | [ ] | 誤型と未登録 slot を試験する | 07.002 | 明示エラーとなりメモリーを触らない |
| 07.004 | [ ] | 多重 slot の終了を試験する | 07.003 | 各 Impl の解放回数が一回 |
| 07.005 | [ ] | 構築中 property を試験する | 07.004 | 接続前に設定でき未初期化 callback が走らない |
| 07.006 | [ ] | dispose の再実行を試験する | 07.005 | 二度目以降でも状態が壊れない |
| 07.007 | [ ] | signal 中の close を試験する | 07.006 | 呼出し中 Impl が生存する |
| 07.008 | [ ] | 接続先先行破棄を試験する | 07.007 | Connection の destructor が解放済み object を触らない |
| 07.008/untracked-signals | [ ] | 返却 Connection を捨てる接続を追跡可能にする | 07.008, 01.008 | 旧 connect_noret と未保存の接続を owner の終了時に解除し、emitter・owner の先行破棄と callback 中の close を試験する |
| 07.008/connection-name | [ ] | Connection の signal 名を解放する | 07.008, 01.007/connection-signal | 接続・切断・再切断で複製文字列を一回解放し、closure と target の寿命を検証する |
| 07.009 | [ ] | 投入済み callback の失効を試験する | 07.008 | 切断前に予約済みでも変更を行わない |
| 07.010 | [ ] | 例外の境界変換を試験する | 07.009 | C 入口と vfunc の両方で契約どおり返す |
| 07.011 | [ ] | weak handle と終了状態を試験する | 07.010 | 生存中だが close 済みの object を更新しない |
| 07.012 | [ ] | worker 完了と画像終了の競合を試験する | 07.011 | UI object の最終 unref を worker が行わない |
| 07.013 | [ ] | bridge の sanitizer 試験を実行する | 07.012 | ASan/UBSan の未解決異常がない |
| 07.014 | [ ] | 最小混在 executable を各 OS でリンクする | 07.013 | runtime・visibility・callback ABI が一致 |
| 07.015 | [ ] | 派生階層の取得を試験する | 07.014 | 基底・派生・複数 slot を正しい型として取得 |
| 07.016 | [ ] | 構築失敗を注入して試験する | 07.015 | C 境界を越えず半構築資源を回収 |
| 07.017 | [ ] | 親 dispose の再入を試験する | 07.016 | close 済みの子状態を親 callback が安全に扱う |

### 08 GIMP 内部型への C++ 接続

主対象：core/tools/widgets の型登録と初期化

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 08.001 | [ ] | 独自型登録の初期化順を接続する | 06.029 | 読込み前に必要 GType が登録済み |
| 08.002 | [ ] | CloneLayer の GType 骨格を移植する | 08.001 | GimpLayer 派生型として生成・終了できる |
| 08.003 | [ ] | FilterLayer の GType 骨格を移植する | 08.002 | 同じ BindingStore 規約で生成・終了できる |
| 08.004 | [ ] | CloneLayerUndo の型を移植する | 08.003 | 現行 GimpItemUndo と親処理を接続 |
| 08.005 | [ ] | MyPaint 資源型を移植する | 08.004 | data factory から生成できる |
| 08.006 | [ ] | MyPaint paint core 型を移植する | 08.005 | 現行 GimpPaintCore に登録できる |
| 08.006/core-options-init | [ ] | MyPaint core の options 借用参照を初期化する | 08.006, 01.007/mypaint-core-raw | 初回 stroke_to の比較前に NULL 初期化し、signal 接続・切断と options 先行破棄を検証する |
| 08.007 | [ ] | MyPaint options 型を移植する | 08.006 | 現行 property と設定機構に接続 |
| 08.007/dict-owner | [ ] | MyPaint 設定辞書の静的参照を整理する | 08.007, 01.007/dict-transfer | 辞書五種のキャッシュ参照と呼出し元へ渡す参照を分離し、初期化・終了・再取得を検証する |
| 08.008/weak-pointer-teardown | [ ] | MyPaint GUI の weak pointer 登録を対称に解除する | 08.008, 01.007/raw-candidates | options/widget の先行破棄と GUI helper の先行破棄で解放済み領域に書き込まない |
| 08.008 | [ ] | MyPaint tool 型を移植する | 08.007 | tool manager に登録できる |
| 08.008/tool-core-lifetime | [ ] | MyPaint tool と core の生成・破棄順を明示する | 08.008, 01.005/gimp3-tool-callbacks | constructed で保持する core が finalize/停止時に二重解放や残存を起こさず、qdata と Undo の解除順が整合 |
| 08.009 | [ ] | パース定規モデル型を移植する | 08.008 | 画像との所有関係を接続 |
| 08.009/removed-signal | [ ] | パース定規型の削除通知 slot を復元する | 08.009, 01.005/gimp3-external-binders | 独自 `GimpPerspectiveGuideClass.removed` を新しい型に再定義し、削除時に一度だけ発火・接続解除する |
| 08.009/guide-owner | [ ] | パース定規の image setter の参照移譲契約を確定する | 08.009, 01.007/c-state | setter の旧値解放と新値代入を対称にし、呼出し元・画像終了時の二重解放と残存を防ぐ |
| 08.010 | [ ] | パース定規 tool 型を移植する | 08.009 | draw tool と options に登録 |
| 08.011 | [ ] | 塗りつぶし brush core 型を移植する | 08.010 | paint core と親 vfunc を接続 |
| 08.012 | [ ] | 塗りつぶし tool/options 型を移植する | 08.011 | tool manager と設定に登録 |
| 08.013 | [ ] | LayerTileView 型を移植する | 08.012 | GTK3 の親 widget と終了を接続 |
| 08.014 | [ ] | ToolTileView 型を移植する | 08.013 | GTK3 の親 widget と終了を接続 |
| 08.015 | [ ] | Popover 型を移植する | 08.014 | window のイベント・destroy を接続 |
| 08.016 | [ ] | CellRendererPopup 型を移植する | 08.015 | cell renderer の vfunc と callback を接続 |
| 08.016/pixbuf-owner | [ ] | popup renderer の pixbuf 寿命を修正する | 08.016, 01.007/cpp-ownership | 初期値・生成失敗・再生成・破棄時の参照を一回だけ解放し、NULL pixbuf を描画しない |
| 08.017 | [ ] | 既存 widget behavior を store に移す | 08.016 | 全登録箇所が共通 slot を利用 |
| 08.018 | [ ] | C 公開操作を新 Impl へ接続する | 08.017 | C 入口から旧 Interface::cast を排除 |
| 08.018/core-extension-hooks | [ ] | 標準coreの独自操作hookを現行APIへ接続する | 08.018, 01.013 | hunk台帳のcore補助関数・公開宣言ごとの子チェックを処理し、同名APIの所有・座標・更新・失敗時の意味を検証する |
| 08.019 | [ ] | C++ 利用箇所をハンドルへ移す | 08.018 | ref 関数添字と公開 interface cast を排除 |
| 08.020 | [ ] | 旧 registration helper の残用途を整理する | 08.019 | 必要な型登録だけ adapter に残り、旧 Impl 配置がない |

### 09 画像・画素・Undo の共通基盤

主対象：TileManager/PixelRegion から現行格納方式への接続

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 09.001 | [ ] | 画素形式の対応表を作る | 03.009, 06.029 | 旧形式と RGB/Gray/Indexed、alpha、精度、色空間を対応 |
| 09.002 | [ ] | 座標契約を固定する | 09.001 | 画像・レイヤー・buffer・画面の原点と境界を記録 |
| 09.003 | [ ] | DrawableFeature の buffer read を実装する | 09.002 | 負の offset と部分領域を読める |
| 09.003/region-lifetime | [ ] | MyPaint Surface の一時領域を GEGL buffer 寿命へ移す | 09.003, 01.007/surface-regions | draw_dab と get_color の全 return・失敗経路で read/write/snapshot/mask/texture の buffer を一度だけ解放する |
| 09.004 | [ ] | DrawableFeature の buffer write を実装する | 09.003 | 範囲外に書かず dirty 領域を返す |
| 09.005 | [ ] | TempBuf の変換を実装する | 09.004 | stride・format・所有権を保持 |
| 09.006 | [ ] | 選択マスクの読取りを接続する | 09.005 | オフセットと coverage が一致 |
| 09.007 | [ ] | レイヤーマスクの読取りを接続する | 09.006 | 適用・非適用を区別 |
| 09.008 | [ ] | ストローク開始 snapshot を実装する | 09.007 | 開始前画素を後続変更から分離 |
| 09.009 | [ ] | 作業用 buffer の確保を実装する | 09.008 | 必要領域へ制限し上限を扱う |
| 09.010 | [ ] | dirty 領域の集約を実装する | 09.009 | 重複・隣接・範囲外を処理 |
| 09.011 | [ ] | 現行 Undo への buffer 差分記録を実装する | 09.010 | 一操作単位で復元できる |
| 09.011/mypaint-undo-stroke | [ ] | MyPaint stroke の pop/free と所有権を現行 Undo に接続する | 09.011, 01.005/gimp3-remaining-callbacks | 旧 pop の空処理を引き継がず Undo/Redo で画素と stroke 状態が往復し、pointer を一度だけ破棄 |
| 09.012 | [ ] | 描画の確定と破棄を実装する | 09.011 | cancel と commit で正しい画素が残る |
| 09.013 | [ ] | projection 更新通知を接続する | 09.012 | 変更領域が表示へ伝わる |
| 09.013/gegl-graph-invalidation | [ ] | paint buffer 更新と GEGL 投影キャッシュの無効化を接続する | 09.013 | 変更 ROI と座標を source node・投影へ通知し画面更新と再評価範囲が一致 |
| 09.014 | [ ] | 色変換の配置を実装する | 09.013 | 採色と合成で意図しない二重変換がない |
| 09.015 | [ ] | 高精度・色空間変換の扱いを実装する | 09.014 | unsupported 時も情報を黙って欠落させない |
| 09.016 | [ ] | buffer 基盤の境界試験を作る | 09.015 | 小画像・負座標・端・alpha・stride を検証 |
| 09.017 | [ ] | buffer 基盤の Undo 試験を作る | 09.016 | 描画前後の差分と復元が一致 |

2026-10-02の並行化：旧XCF wire framingのsource監査と純粋byte decoderは、02.005までの実fixtureと確定sourceを入力に行う。全旧fixture合格やFilter/UI/新writerの完了を前提としない。10/11親作業とG2のapp互換性ゲートは未完了のまま保持する。

### 10 保存項目と XCF 形式の仕様化

主対象：旧 reader/writer と新保存形式

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 10.001 | [ ] | 保存項目台帳を埋める | 01.017, 02.015 | 全項目に型・既定値・所有型・reader/writer・試験 ID がある |
| 10.001/wire-framing-audit | [x] | 旧XCFのwire定数と実消費長を監査する | 01.017, 02.005 | 63 wire記録のreader/writer位置・衝突・既定動作を記録。constructor既定値とapp適用/全保存項目は親作業に残す（`migration/inventory/xcf-wire-records.tsv`） |
| 10.002 | [ ] | 旧 v4 ヘッダーを解析する | 10.001 | precision がない実レイアウトを byte fixture で説明 |
| 10.003 | [ ] | 標準 XCF と旧 XCF の判定規則を決める | 10.002 | v004 文字列だけで判定しない |
| 10.004 | [ ] | 属性32と33の識別規則を決める | 10.003 | 標準属性との衝突を文脈で判別 |
| 10.005 | [ ] | 旧 mode23〜29の対応を固定する | 10.004 | 数値の直接流用を禁止した対応表がある |
| 10.005/gegl-byte-operators | [x] | 衝突する旧7modeを明示IDとGEGL byte演算へ接続する | 10.001/wire-framing-audit, 04.003 | upstream値を変えず独立modeを追加。56実旧projection fixtureをC kernel/GEGL graph/実GimpImageで全RGBA byte比較し通常/focused ASan/UBSan合格。高精度・全mode・新保存は別gate |
| 10.005/normal-multiply-parity | [x] | 共通旧Normal/Multiplyのbyte丸めを復元する | 10.005/gegl-byte-operators | 追加16実旧sceneを含む72ケースがC kernel/GEGL/実imageで通常とfocused sanitizerに一致。共有旧形式のXCFでは別途canonical解釈を検証しmodernの意味を保持 |
| 10.005/native-paint-mode-route | [x] | Painter modeをPaintCore直接dispatchと旧opacity演算へ接続する | 10.005/normal-multiply-parity | 未prepare graph境界による無描画を修正しeffective opacity/255.999を使用。216直接caseと72実旧projectionが通常/3unit focused sanitizer合格。Fill実stroke統合は別gate |
| 10.006 | [ ] | FilterLayer 引数の wire 型を列挙する | 10.005 | 整数・浮動小数点・文字列・参照・未対応型を区別 |
| 10.007 | [ ] | INT16 の writer/reader 不整合を確定する | 10.006 | サイズ宣言と実書込みの両方を fixture 化 |
| 10.008 | [ ] | 文字列型の不整合を確定する | 10.007 | 実際に旧 reader が読める表現を記録 |
| 10.009 | [ ] | 旧配列・drawable 引数の可読範囲を確定する | 10.008 | 記録されない情報と回収可能情報を区別 |
| 10.010 | [ ] | CloneLayer 名前解決規則を確定する | 10.009 | 探索順・同名・階層・未解決の期待値を記録 |
| 10.011 | [ ] | 新保存拡張の識別子と版を定義する | 10.010 | 標準属性番号と衝突しない表現を選択 |
| 10.012 | [ ] | 新保存拡張のレコード仕様を定義する | 10.011 | 型・参照・処理・引数・未知情報を記録可能 |
| 10.013 | [ ] | 定義とキャッシュの世代仕様を定義する | 10.012 | 実行中保存でも混同しない |
| 10.014 | [ ] | 未知項目の保持規則を定義する | 10.013 | 読めるが未解釈の payload を失わない |
| 10.015 | [ ] | 圧縮・offset・サイズ上限を定義する | 10.014 | 現行 XCF 読込みと互換 decoder の境界が明確 |
| 10.016 | [ ] | 形式判定の曖昧ケースを列挙する | 10.015 | 推測で標準ファイルを壊さない回復経路を記録 |
| 10.017 | [ ] | 旧形式の画像単位情報を仕様化する | 10.016 | resolution・unit・colormap・profile・guide 等の保存有無を台帳へ記録 |
| 10.018 | [ ] | 属性の順序と重複規則を仕様化する | 10.017 | 旧 reader が採用する値と未知 payload の扱いを記録 |

### 11 旧 XCF 読込み経路

主対象：通常の「開く」に組込む compatibility reader

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 11.001 | [ ] | 形式 probe を実装する | 08.020, 10.018, 15.014, 14.018 | 読取り状態を汚さず旧・標準候補を判定 |
| 11.001/byte-record-foundation | [x] | 不変byte列の候補probeと拡張record decoderを実装する | 10.001/wire-framing-audit, 04.002/common-foundation | 旧/標準候補を独立budgetで判定し曖昧/資源制限を維持、Filter/Clone raw範囲と衝突enum意味を保存。144142通常・ASan/UBSan assertion合格。normal Openは親作業に残す |
| 11.002 | [ ] | 旧ヘッダー decoder を実装する | 11.001 | 旧 v4 で属性列の開始位置を正しく取得 |
| 11.003 | [ ] | 属性長の境界検査を実装する | 11.002 | 切断・overflow・範囲外参照を検出 |
| 11.004 | [ ] | 旧 mode decoder を実装する | 11.003 | 全7モードを正しい内部値へ変換 |
| 11.005 | [ ] | FilterLayer レコード decoder を実装する | 11.004 | procedure と型付き引数を回収 |
| 11.006 | [ ] | INT16 互換 decoder を実装する | 11.005 | 確認済みの旧可読表現を読める |
| 11.007 | [ ] | 文字列互換 decoder を実装する | 11.006 | 旧型不整合でも既存可読ファイルを読める |
| 11.008 | [ ] | CloneLayer レコード decoder を実装する | 11.007 | 元の source name を保持 |
| 11.009 | [ ] | 未知レコードの保持を実装する | 11.008 | 再保存用の raw payload と文脈を保持 |
| 11.009/item-origin-copy | [x] | Item複製で不変のimport provenanceを共有保持する | 11.020/first-application-route | coreだけのGBytes/string複製hookで元property/extension/header/nameを保持。現在のtyped状態が優先。writer全往復は別gate |
| 11.010 | [ ] | レイヤー生成を二段階化する | 11.009 | 全型・階層を生成してから参照を解決 |
| 11.011 | [ ] | 通常レイヤー属性を適用する | 11.010 | 位置・サイズ・可視・不透明度・ロックが欠落しない |
| 11.012 | [ ] | マスクとチャンネルを復元する | 11.011 | 関連付けと設定を保持 |
| 11.013 | [ ] | テキストレイヤーを復元する | 11.012 | 編集可能な文字情報を保持 |
| 11.014 | [ ] | パスを復元する | 11.013 | 座標・制御点・属性を保持 |
| 11.015 | [ ] | parasite と画像メタデータを復元する | 11.014 | 独自と標準の双方を保持 |
| 11.016 | [ ] | 旧画素と圧縮データを読み込む | 11.015 | 各対応形式の buffer が得られる |
| 11.017 | [ ] | 保存済み FilterLayer cache を復元する | 11.016 | 初回表示と再評価の状態を区別 |
| 11.018 | [ ] | 未解決参照を保持する | 11.017 | 元記録を残し別レイヤーへ勝手に接続しない |
| 11.019 | [ ] | 読込み取消しと途中失敗を処理する | 11.018 | 生成済み object と buffer を解放 |
| 11.020 | [ ] | 通常の開く処理に reader を接続する | 11.019 | 事前変換なしで旧 XCF が開く |
| 11.020/first-application-route | [x] | 実旧XCFを通常Openと明示recoveryへ接続する | 11.001/byte-record-foundation, 14.001/core-implementation, 15.001/core-scheduler-edge, 10.005/gegl-byte-operators | 旧Clone/Filter型・raw記録・参照/cacheを復元しcancelと曖昧形式を処理。upstream4/4、Open11通過/1 exact画素TODO、focused sanitizer確認。writerと全metadata/画素gateは未完了 |
| 11.020/property-order-partial-recovery | [x] | 属性順序と不完全XCFの回復・保存拒否を実装する | 11.020/first-application-route, 17.022/explicit-owner-cancel | 通常5suiteと246 focused ASan/UBSan合格。144合法配置・alias・短tile・後続破損・反復marker・Clone/Filter/group属性・duplicate原bytesを検証。381入力seal、全malformed/effect/resource/platformは別gate |
| 11.020/effects-offset-cleanup | [x] | effects offset短読時の未移管mask/listを解放する | 11.020/property-order-partial-recovery | 実Saveのeffect/maskと0..7byte故障注入で所有権を検証。通常target1/1・247 focused sanitizer合格、143入力をcompile前保存。multipart/全失敗経路は別gate |
| 11.021 | [ ] | 標準 XCF の既存経路を維持する | 11.020 | probe による誤認と標準属性欠落がない |
| 11.022 | [ ] | 画像単位の情報を復元する | 11.021 | 台帳で保存される解像度・単位・palette・profile 等を保持 |
| 11.023 | [ ] | 階層 offset と tile offset を検査する | 11.022 | 循環・範囲外・巨大確保を避けつつ旧可読データを受理 |

### 12 新保存と往復

主対象：writer と開く→保存→再読込

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 12.001 | [ ] | 独自レイヤー識別の writer を実装する | 09.017, 11.023 | 新 reader が型を再構築可能 |
| 12.001/preservation-writer | [x] | 標準XCF containerに独自型・参照・raw originを保存して再構築する | 11.020/first-application-route, 10.005/normal-multiply-parity, 14.015/reference-undo-snapshot, 17.001/fair-checkpoint-state | 27通常/10 focused sanitizer合格。旧Clone/Filter・未知記録・型付き引数・exact画素往復、cancel/失敗時既存file保持。外部live参照/全metadata/GUI等は別gate |
| 12.002 | [ ] | CloneLayer 参照の writer を実装する | 12.001 | 旧解決結果と元記録を保持 |
| 12.002/clone-unresolved-write | [ ] | 未解決 CloneLayer の元の参照名を保存する | 12.001, 11.018 | source pointer が NULL でも名前の dereference をせず、旧 source name を保存する。別レイヤーへ勝手につながない |
| 12.003 | [ ] | FilterLayer 定義の writer を実装する | 12.002 | procedure と型・順序・値を保持 |
| 12.003/filter-args-ownership | [ ] | FilterLayer の保存引数を安全に複写・解放する | 12.002 | GValue を型付きで複写し、一時 GArray と元 GValueArray を成功・失敗の両経路で解放。runner 内の値は変えない |
| 12.004 | [ ] | 未知情報の writer を実装する | 12.003 | 未解釈 payload を欠落させない |
| 12.005 | [ ] | 階層と通常属性の保存を接続する | 12.004 | 独自型でも標準属性を落とさない |
| 12.006 | [ ] | 新拡張 reader を実装する | 12.005 | 新 writer の全レコードを読み戻せる |
| 12.007 | [ ] | 新拡張の版移行を実装する | 12.006 | 既知版を判別し未知版の情報を保持 |
| 12.008 | [ ] | 保存時の snapshot を実装する | 12.007 | 定義・参照・cache の世代が一貫 |
| 12.009 | [ ] | 実行中保存の規則を実装する | 12.008 | 未完成結果を完成 cache として記録しない |
| 12.010 | [ ] | 原子的なファイル置換を接続する | 12.009 | 保存失敗で既存作品を破損しない |
| 12.011 | [ ] | 保存失敗の後処理を実装する | 12.010 | 一時ファイル・dirty 状態・エラーが整合 |
| 12.012 | [ ] | autosave/recovery に独自情報を接続する | 12.011 | 復旧後にも型と参照が残る |
| 12.013 | [ ] | 旧ファイルの初回再保存を試験する | 12.012 | 元ファイルを保持して新形式へ往復 |
| 12.014 | [ ] | 通常 XCF の往復を試験する | 12.013 | 標準属性・画素・テキストが一致 |
| 12.015 | [ ] | 独自型の構造往復を試験する | 12.014 | 階層・参照・引数・未知情報が一致 |
| 12.015/opaque-preservation | [x] | 未知引数の複製/Undoと欠落参照・image originを往復する | 12.001/preservation-writer, 15.008/opaque-definition-state | 32通常/14 focused sanitizer合格。実supported実行後Undoの元画素、未変更duplicateのactive opaque、欠落ID無再結合/保持、path/全型array、明示marker判定を検証 |
| 12.015/external-reference-preservation | [x] | 外部Clone/Filter参照を明示未解決descriptorとして保存する | 12.015/opaque-preservation | 33通常/15 focused ASan+UBSan合格。in-session参照不変・cache保持・同名同IDの無誤結合・元image終了後resaveを検証。URI/path/credentialを格納せず外部探索しない |
| 12.015/capsule-schema-preservation | [x] | duplicate keyと未知kindを無損失で拒否/保持する | 12.015/external-reference-preservation | 34通常/16 focused sanitizer合格。normal-form重複keyは置換前拒否、未知/型不正kindはopaqueで再保存保持、remote URI/query名を診断metadataから除外。compile/run hash安定を記録 |
| 12.015/native-recovery-save | [x] | crash backupを現行3引数XCF procedureへ接続する | 12.015/capsule-schema-preservation | 36通常/18 focused sanitizer合格。Clone/Filter/cache/rawのbackup再Open、dirty/file不変、原file保持・失敗時無renameを検証。既存crash処理のasync-signal安全性を新規保証しない |
| 12.015/semantic-envelope-validation | [x] | 既知Filter/Clone envelopeを型変換前に検証する | 12.015/native-recovery-save | 38通常/20 focused sanitizer合格。Filter24/Clone18不正sceneと有効境界7sceneでopaque保持・無誤fresh・duplicate/resaveを確認。旧unitで両欠陥を再現し証跡保持 |
| 12.015/field-owner-checkpoint | [ ] | XCF全保存fieldとowner・実行中状態を照合する | 12.015/semantic-envelope-validation, 31.016/typed-provenance-store | 185行台帳と実旧text/unit/palette/path、wrong owner10、native precision72、同名Clone ID、RUNNING/IMPORTING Saveを実装し通常59case合格。追加sanitizer・全不正順序/graph/platformは未完了。巨大未知recordの通常Save chunk保持は12.015/multipart-storage参照、GUI応答/全platformは別gate |
| 12.015/multipart-storage | [x] | 巨大未知XCF記録を不変file snapshotと分割transportで保持する | 12.015/semantic-envelope-validation, 31.016/typed-provenance-store, 11.020/effects-offset-cleanup | 325 native＋307 focused sanitizer（38 instrumented/34 RTTI-only）、256/512MiB+1通常PDBを3回往復。owner/digest/inert保持、複製/re-edit、OOM保護・cancel/disk/stream/close失敗と実RSS/disk/FDを検証。全field/GUI/全platformは別gate |
| 12.015/parameter-schema-roundtrip | [x] | 引数schema統合後の既存XCF保存互換を往復検証する | 30.001/parameter-schema-editor, 12.015/multipart-storage | 通常10組/focused ASan+UBSan10組と最終2組のassertion再検証、既存XCF6組合格。4editor・DOUBLE実cache・Duplicate/Undo/Redo・巨大opaque/tail・実RUNNING/IMPORTING・失敗時元fileを確認。実weak targetで保存し原descriptorとlive runtime IDを区別、wire不変。PhaseE/全field/platform親gateは未完了 |
| 12.015/clone-unresolved-roundtrip | [ ] | 未解決 CloneLayer 参照を往復試験する | 12.014, 12.002/clone-unresolved-write | 保存前に source が NULL の fixture を保存・再読込し、参照名を欠落させず crash しない |
| 12.015/filter-args-roundtrip | [ ] | FilterLayer の引数所有権と往復を試験する | 12.014, 12.003/filter-args-ownership | 複数の型付き引数を繰返し保存・再読込し、値一致と一時領域の解放を確認する |
| 12.016 | [ ] | 保存中断からの回復を試験する | 12.015 | 元作品が開け、編集状態を誤って保存済みにしない |

### 13 独自合成モード

主対象：旧演算と現行 compositing の接続

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 13.001 | [ ] | 旧7モードの式を抽出する | 09.017, 10.018 | alpha・premultiplication・丸め・clamp の仕様を記録 |
| 13.001/gegl-operation-route | [ ] | 独自合成ごとに現行 GEGL operator との数値・ノード接続を決める | 13.001 | 7 モードの式、Babl 形式、mask、opacity、group 順序と operator の採用・追加を一件ずつ記録 |
| 13.002 | [ ] | Erase 演算を移植する | 13.001 | 旧代表画素と一致 |
| 13.003 | [ ] | Replace 演算を移植する | 13.002 | 旧代表画素と一致 |
| 13.004 | [ ] | Anti-Erase 演算を移植する | 13.003 | 旧代表画素と一致 |
| 13.005 | [ ] | src-in 演算を移植する | 13.004 | source/destination の扱いが一致 |
| 13.006 | [ ] | dst-in 演算を移植する | 13.005 | source/destination の扱いが一致 |
| 13.007 | [ ] | src-out 演算を移植する | 13.006 | source/destination の扱いが一致 |
| 13.008 | [ ] | dst-out 演算を移植する | 13.007 | source/destination の扱いが一致 |
| 13.009 | [ ] | モード選択 UI を登録する | 13.008 | 表示名と内部値が一致 |
| 13.010 | [ ] | layer opacity と mask を接続する | 13.009 | 演算順が旧仕様と一致 |
| 13.011 | [ ] | group compositing を接続する | 13.010 | 隔離・通過・順序を現行基盤と整合 |
| 13.012 | [ ] | 精度別の演算経路を実装する | 13.011 | 旧8bit再現と高精度拡張を区別 |
| 13.013 | [ ] | 合成の数値試験を作る | 13.012 | 透明・半透明・端値・順序を比較 |
| 13.014 | [ ] | 合成の作品試験を実行する | 13.013 | CloneLayer と複合構造の見た目が一致 |

### 14 CloneLayer の旧仕様移植

主対象：app/core/gimpclonelayer*

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 14.001 | [ ] | source の所有と監視を実装する | 08.020, 09.017, 10.018 | 旧仕様に沿う参照が close で解除される |
| 14.001/core-implementation | [x] | CloneLayerの実core型・参照追従を統合する | 04.003, 05.010, 02.005/resize-undo-capture | 単一store/typed handle・GEGL完成画素・source/name・group duplicate再対応付け・resize Undo/maskを実装し21通常/ASan/UBSan試験合格。XCF/UI/参照変更Undo等は親区分に残す |
| 14.002 | [ ] | 名前による旧 source 解決を実装する | 14.001 | 探索順と同名の解決が fixture と一致 |
| 14.003 | [ ] | source レイヤーの画素追従を実装する | 14.002 | 編集領域が clone に更新される |
| 14.003/gegl-source-node | [ ] | CloneLayer の参照画素を GEGL source node に接続する | 14.003, 09.013/gegl-graph-invalidation | source の変更 ROI、offset、参照解除が projection の再評価へ届く |
| 14.003/clone-pickable-opacity | [ ] | CloneLayer の不透明度照会を現行型へ接続する | 14.002, 01.005/gimp3-layer-slots | 旧 gint 返却のゼロ透明を現行 gdouble 契約で保ち、参照画素・子レイヤー表示への影響を試験 |
| 14.004 | [ ] | source グループの追従を実装する | 14.003 | 子の変更と合成が更新される |
| 14.005 | [ ] | source の座標・サイズ追従を実装する | 14.004 | 移動と resize の見え方が一致 |
| 14.006 | [ ] | clone 自身の座標処理を実装する | 14.005 | source 座標との合成が一致 |
| 14.006/editability-contract | [ ] | CloneLayer の編集可否を現行ロック規約へ対応付ける | 14.005, 01.005/gimp3-layer-slots | 廃止された GimpItemClass.is_editable を仮定せず、許可操作と選択・移動の可否を確認 |
| 14.007 | [ ] | source の可視性・合成変更を処理する | 14.006 | 旧版の更新範囲と表示が一致 |
| 14.008 | [ ] | source 改名を処理する | 14.007 | 既存参照を旧仕様に沿って維持 |
| 14.009 | [ ] | 同名 source を処理する | 14.008 | 保存前後で別レイヤーへ変わらない |
| 14.010 | [ ] | clone の複製を実装する | 14.009 | 複製先の source が旧仕様と一致 |
| 14.011 | [ ] | group の複製を実装する | 14.010 | 内部・外部参照の扱いが旧版と一致 |
| 14.012 | [ ] | source の削除を処理する | 14.011 | 旧挙動を保持し stale pointer を残さない |
| 14.013 | [ ] | source の差替えを実装する | 14.012 | 旧接続解除と新接続が一度ずつ行われる |
| 14.014 | [ ] | 参照循環の旧挙動を照合して処理する | 14.013 | 旧版で有効な参照を壊さず無限更新を防ぐ |
| 14.015 | [ ] | clone の変更 Undo を実装する | 14.014 | source と参照状態を復元 |
| 14.015/reference-undo-snapshot | [x] | opt-in参照Undoと非変更snapshotを実装する | 14.001/core-implementation, 05.010 | 旧setterの履歴なしを保ち、live/pending/expired/none・cache/位置・stable ID未解決を別APIで復元。33通常/focused sanitizer。別画像操作/保存の全gateと共通Item寿命fixは未完了 |
| 14.016 | [ ] | source 削除の Undo を接続する | 14.015 | 復元後に追従が再開 |
| 14.017 | [ ] | 画像終了時の解除を実装する | 14.016 | 遅延通知が clone を触らない |
| 14.018 | [ ] | 参照が別画像へ移る操作を処理する | 14.017 | コピー・移動の旧意味と矛盾しない |
| 14.018/genuine-rgb-comparison | [x] | 実旧版の画像間Clone複製・参照移動を比較する | 14.001/core-implementation, 14.015/reference-undo-snapshot, 05.003/retained-item-lifetime | RGB direct/group複製・内部/外部参照・移動・元画像終了後更新の19記録が実旧版と完全一致、37 app通常/focused sanitizer合格。未測定画像型/GUI等は別gate |
| 14.019 | [ ] | CloneLayer の機能試験を実行する | 14.018, 13.014 | 位置・階層・参照・複製・削除の全 fixture に一致 |
| 14.020 | [ ] | CloneLayer の保存後再編集を試験する | 14.019, 12.016 | 再読込後の source 編集が反映される |

### 15 FilterLayer のデータモデル

主対象：独自型と procedure 定義、GEGL 非破壊効果を使用しない

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 15.001 | [ ] | procedure 定義の所有モデルを実装する | 08.020, 09.017, 10.018 | 名前と型付き引数を独立に保持 |
| 15.001/core-scheduler-edge | [x] | 独立FilterLayerと世代scheduler・edge互換実行を統合する | 14.001/core-implementation, 05.010, 02.006/writer-negative-fixture | 定義/raw値/weak引数とUndo、完成cacheのみGEGL公開、依存順・非待機cancel・分割入出力を実装。20 app/14 scheduler/76実旧edge比較とfocused sanitizer合格。全PDB/XCF/UI/性能gateは未完了 |
| 15.001/gvalue-deep-copy | [ ] | FilterLayer の GValue 配列を深くコピーする | 15.001, 01.007/gvalue | 元 GValueArray と保存先を独立に解放し、getter の値を正しく返す |
| 15.001/pdb-temporary-gvalue | [ ] | PDB 一時 GValue の破棄を保証する | 15.001, 01.007/gvalue | 変換用一時値を全経路で unset し、引数配列との所有権を分ける |
| 15.002 | [ ] | 引数の旧値と実行値を分離する | 15.001 | 変換後も保存された元情報を失わない |
| 15.003 | [ ] | FilterLayer の property を接続する | 15.002 | 設定の読取り・変更・通知が一経路 |
| 15.004 | [ ] | 処理対象の下層範囲を実装する | 15.003 | 位置と階層に応じ旧範囲を選ぶ |
| 15.005 | [ ] | 位置・サイズ変更を処理する | 15.004 | 入力と出力 buffer の座標が一致 |
| 15.006 | [ ] | マスク・opacity・mode を接続する | 15.005 | 独自型でも通常属性が適用される |
| 15.006/gegl-result-source | [ ] | FilterLayer の確定結果を GEGL source node へ供給する | 15.006, 09.013/gegl-graph-invalidation | 未完成・旧世代の結果を見せず source 変更が投影を更新し operator 評価から runner を起動しない |
| 15.006/filter-pickable-opacity | [ ] | FilterLayer の不透明度照会を現行型へ接続する | 15.005, 01.005/gimp3-layer-slots | 旧 gint 返却のゼロ透明を現行 gdouble 契約で保ち、合成結果との矛盾を試験 |
| 15.006/filter-progress-start | [ ] | FilterLayer の progress 開始 callback を現行 ABI に合わせる | 15.005, 06.016, 01.005/gimp3-layer-slots | cancellable と message の新しい引数順を守り、進捗通知・取消しが逆転しない |
| 15.006/native-owner-progress | [x] | 実GimpProgressと独立worker通知・GTK取消しを接続する | 15.001/core-scheduler-edge, 17.022/explicit-owner-cancel, 16.003/isolated-convolution-route, 30.001/isolated-filter-editors, 01.005/gimp3-layer-slots | 現行start ABI、固定mailbox/GPF6、native kernel/4実helper進捗、世代別cancelとGTK再入を検証。通常5target・native7/GTK7と33source+39RTTI focused sanitizer合格、3072RGB実Retinexの表示/取消し/可視cache保持/正常終了を確認。全latency/platformとmanual GTK/GDK critical原因は未完了 |
| 15.006/editability-contract | [ ] | FilterLayer の編集可否を現行ロック規約へ対応付ける | 15.005, 01.005/gimp3-layer-slots | 廃止された GimpItemClass.is_editable を仮定せず、定義編集と通常画素編集の権限を検証 |
| 15.007 | [ ] | loaded 状態を実装する | 15.006 | 保存済み cache の初回表示を区別 |
| 15.008 | [ ] | 定義変更の世代を実装する | 15.007 | procedure/引数変更で結果を失効 |
| 15.008/opaque-definition-state | [x] | 未解釈引数と確定cacheをdefinition所有へ統一する | 17.001/dependency-publication, 12.001/preservation-writer | 57 app通常/focused sanitizer合格。opaque bytesの複製/Undo/明示clear、実行後Undoで元cache復元、stale保持と再入を検証。file統合は次子作業 |
| 15.009 | [ ] | 依存構造の世代を実装する | 15.008 | 並替え・移動で結果を失効 |
| 15.010 | [ ] | FilterLayer の複製を実装する | 15.009 | 定義は複製し実行中 runner は共有しない |
| 15.011 | [ ] | 設定変更の Undo を実装する | 15.010 | 旧定義と再評価状態を復元 |
| 15.012 | [ ] | 削除・復元の Undo を実装する | 15.011 | 復元後に最新下層から評価 |
| 15.013 | [ ] | 未解決 procedure の保持を実装する | 15.012 | ファイルは開け、定義を再保存できる |
| 15.014 | [ ] | FilterLayer の構造試験を実行する | 15.013 | 設定・属性・複製・Undo が一致 |

### 16 FilterLayer 実行器と PDB 接続

主対象：app/pdb/pdb-cxx-utils* と現行 procedure API

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 16.001 | [ ] | 使用 procedure の全件対応表を作る | 04.019, 15.014 | fixture・preset の名前と現行実装を対応 |
| 16.002 | [ ] | 現行内部 PDB API の型を確定する | 16.001 | 公開 libgimp API と本体内部 API を混同しない |
| 16.002/parameter-schema-contract | [x] | GIMP3引数取得・検証・編集・保持の段階契約を採用する | 16.003/isolated-blinds-route, 16.003/isolated-small-tiles-route, 16.003/isolated-retinex-route, 16.003/isolated-convolution-route, 30.001/isolated-filter-editors, 15.006/native-owner-progress | 現行source/API・context位置ABI・copy/validation/寿命・旧意味と保存no-opを照合し、filter-parameter-schema.mdと5未着手子を登録。文書/WBSのみ、実装・最低GLib build・追加資源上限の達成は未検証。既存親/GTK AT-SPI/全移植gateは未完了 |
| 16.002/parameter-name-binder | [x] | helper4経路の引数bindingと署名・制約照合を名前へ移す | 16.002/parameter-schema-contract, 16.003/isolated-blinds-route, 16.003/isolated-small-tiles-route, 16.003/isolated-retinex-route, 16.003/isolated-convolution-route, 15.006/native-owner-progress | context prefix0/1/2固定・input reorder、missing/duplicate/type/constraint拒否、assigned検査、コピー前後exact比較とFALSE mutation、既存強参照寿命を検証。4経路pixel/status/progress/cancel不変、GUI/wire/保存/scheduler無変更 |
| 16.003 | [ ] | 旧 procedure 名の変換を実装する | 16.002 | 改名された手順を同じ意味へ解決 |
| 16.003/gauss-executor | [x] | 同梱presetの旧Gaussian実行を復元する | 15.001/core-scheduler-edge | plug-in-gaussのIIR/RLE・分数/片軸半径・旧shadow mergeを実装し104実旧PDB fixtureにbyte一致。実FilterLayer両methodと21 app通常/focused sanitizer合格 |
| 16.003/native-color-transfer | [x] | 旧Filterのnative符号化色空間と世代変更を保持する | 16.003/gauss-executor, 17.001/fair-checkpoint-state | sRGB/Adobe RGB両Gaussianと実行中profile変更を含む36 app通常/focused sanitizer合格。Gray/高精度の再実行は一時的に明示失敗し元定義/cacheを保持、対応gateは未完了 |
| 16.003/native-gray-transfer | [x] | Gray/Gray-alphaの旧native値を色変換なしで実行する | 16.003/native-color-transfer, 15.008/opaque-definition-state | 77実旧PDB出力完全一致、9入力roundtripとindexed拒否を記録。61 actual app通常/focused sanitizer、Gray単体ASan/UBSan/float-cast-overflow合格。高精度/linearは別gate |
| 16.003/isolated-blinds-route | [x] | 同梱Blindsの独立process実行と終了境界を接続する | 16.003/native-gray-transfer, 17.001/configured-spill-budget, 17.022/explicit-owner-cancel | 320実旧byte比較・94native通常・22source focused sanitizerと実行中1/2jobの実Quit合格。U8 nonlinear RGB/Grayの有界範囲のみ。selection/component phase、UI progress、swap無効、再配置/platformは未完了 |
| 16.003/context-merge-foundation | [x] | 旧selection境界とshadow mergeの独立scalar基盤を検証する | 16.003/native-gray-transfer, 17.001/fair-checkpoint-state | C++14で304実旧record/boundsと117440512厳密旧C比較を通常/ASan・UBSan検証。idle/running各6sceneのphaseを記録し誤fixtureも別archive保存。native接続/ROI/chunked snapshotは未実装 |
| 16.003/native-blinds-context | [x] | 旧Blindsのowner contextとraw shadow mergeを実行へ接続する | 16.003/isolated-blinds-route, 16.003/context-merge-foundation, 34.005/installed-filter-smoke | native105・270実旧owner record・実process60比較・Gray48 scene・旧Blinds320・9target通常、27source/22nativeと独立gate/race sanitizer合格。選択のstart/final phase・全active mask・own lock・XCF mask置換・sealed import・取消/旧世代破棄・巨大要求FAILED保持、再配置4096² Save/定義再読込を確認。1GiB保守的extent制限・全latency/platform/UI進捗・他procedureは未完了 |
| 16.003/isolated-small-tiles-route | [x] | 旧Small Tilesの独立process実行と共有owner contextを接続する | 16.003/native-blinds-context | 実旧196helper比較・25scene/50native出力・public24不変/hidden196/非interactive拒否2、9target/114native、29source+41RTTI/1736入力/31native sanitizer合格。factor0..6・ROI・late mask/components/own lock・型付き定義/Save再編集・取消/依存/終了と再配置factor0/3を検証。1GiB保守的制限・全latency/platform/UI進捗・他procedure/releaseは未完了 |
| 16.003/isolated-retinex-route | [x] | 旧Retinexの独立process実行とnative RGB/RGBA統計を接続する | 16.003/isolated-small-tiles-route | 実旧174helper・6scene/12live merge、public32不変/hidden174/非interactive拒否2、9target/124native、30source+41RTTI/1742入力/41native sanitizer合格。RGB3/RGBA4・旧float cvar・GPF4 binary64・ROI/late context・保存再編集・取消/依存/終了、1160割当失敗/34幾何拒否、再配置2variant各2Save/reopenを検証。Gray/高精度・全latency/platform/UI進捗・他procedure/releaseは未完了 |
| 16.003/isolated-convolution-route | [x] | 旧Convolution Matrixの型付き配列とGIMP3独立実行を接続する | 16.003/isolated-retinex-route | 実旧304+補助8capture・296raw/merge・12live、11/12slotと25double/5int・GPF5を保持。34native形式/TRC/profile・HDR/HALF/FLOAT格納overflow・配列Save/reopen/Undo・取消/終了、33source+44RTTI/50live sanitizer、再配置U8/Double各2実行/2Saveを検証。旧未保存配列はopaque保持し推測復元しない。GTK配列editor・全latency/platform・他procedure/releaseは未完了 |
| 16.003/spill-components | [x] | 独立raster・有界転送queue・旧演算をspill対応する | 16.003/native-gray-transfer, 17.001/bounded-admission | storage6/transport9と257実旧・212追加・234失敗注入が通常/sanitizer合格。64bit addressing・transpose・cancel/cleanupを検証。tmpfs/RSS境界とWindows未検証を明示、live大画像gateは未完了 |
| 16.003/gauss-alias-regions | [x] | 旧Gaussian alias全4名と負半径region・identityを保持する | 17.001/cold-graph-quanta | 78 actual app通常/17unit focused sanitizer、11target合格。457実旧buffer/220追加/234取消し失敗と4GiB超を通常/sanitizer比較。小さい負領域の透明borderとempty identity、両flag offを保持。alias直接UI編集とdisk予算・全latencyは別gate |
| 16.003/native-point-precision | [ ] | 旧point処理・native精度拡張・alias編集を検証する | 16.003/gauss-alias-regions, 17.001/configured-spill-budget | 108行の旧選択候補台帳、3pointの実旧40buffer、34追加native形式/2種spillとalias原形編集を実装。通常82+単独巨大1・GTK24・kernel6/scheduler37/native82 sanitizer合格。巨大単独ASanもSIGKILLで未合格、一般99route/process/latencyは未完了 |
| 16.004 | [ ] | 非対応 procedure の互換実行経路を設計する | 16.003 | 代替実装か互換プラグインへ割当し未割当を残さない |
| 16.005 | [ ] | 旧整数引数の変換を実装する | 16.004 | 幅・符号・範囲を保持 |
| 16.006 | [ ] | 旧実数引数の変換を実装する | 16.005 | 精度と特殊値の扱いを固定 |
| 16.007 | [ ] | 旧文字列引数の変換を実装する | 16.006 | encoding と null を保持 |
| 16.008 | [ ] | 旧配列引数の変換を実装する | 16.007 | 保存から復元可能な範囲を正しく渡す |
| 16.009 | [ ] | 旧画像・drawable 引数の解決を実装する | 16.008 | 一時入力と現行参照型へ対応 |
| 16.010 | [ ] | 引数の default と順序を実装する | 16.009 | 省略値の意味が旧版と一致 |
| 16.010/parameter-semantic-policy | [x] | runtime引数schemaと旧意味adapterを分離する | 16.002/parameter-name-binder | 旧range/default/alias/count/flagを共有しpublic/hidden metadataと区別。11,506 request通常/sanitizer比較、旧4経路corpus不変、16 native/10 focused sanitizer、最小API修正後再確認と実GLib2.70/GIMP3.0.9 default build・5 native loader検証を受入。model保持とXCF永続化gateを区別 |
| 16.011 | [ ] | 一時入力画像または drawable を生成する | 16.010 | 独立した世代の入力を処理できる |
| 16.012 | [ ] | 出力 buffer の回収を実装する | 16.011 | 実行途中の出力を確定画像に混ぜない |
| 16.013 | [ ] | 非同期起動を実装する | 16.012 | UI で完了を待たない |
| 16.014 | [ ] | runner の予約を実装する | 16.013 | 同世代の重複起動を防ぐ |
| 16.015 | [ ] | cancel 要求を実装する | 16.014 | 対応手順へ停止要求を伝える |
| 16.016 | [ ] | 正常完了の通知を実装する | 16.015 | 結果と世代を main context へ返す |
| 16.017 | [ ] | 失敗・中止の通知を実装する | 16.016 | 正常完了とは異なる終端状態を返す |
| 16.018 | [ ] | 応答しない処理の隔離を実装する | 16.017 | in-process thread の強制停止を使わず UI を維持 |
| 16.019 | [ ] | 終了待ち資源の所有を実装する | 16.018 | 画像削除後も実行器が必要資源を保持し安全に回収 |
| 16.020 | [ ] | プラグイン crash を検出する | 16.019 | 待機状態を解除し定義を保持 |
| 16.021 | [ ] | Undo 抑制の範囲を接続する | 16.020 | 内部実行がユーザー Undo を汚染しない |
| 16.022 | [ ] | 互換処理の不足分を実装する | 16.021 | 対応表の各不足手順に実装と比較試験がある |
| 16.023 | [ ] | 実行器の試験を実行する | 16.022 | 成功・失敗・中止・crash・遅延完了で資源が残らない |
| 16.023/parameter-schema-acceptance | [x] | 引数schema統合をsanitizer・実app・再配置runtimeで受け入れる | 12.015/parameter-schema-roundtrip | source/binary hash付き新旧pixel・4経路native/editor/取消/終了/再Open・OOM/malformed/schema drift証跡を保存。未検証platform・GTK AT-SPI・全移植残課題を別記し親gateを閉じない |

### 17 FilterLayer の優先順位・チェックポイント

主対象：独自 scheduler と投影の接続

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 17.001 | [ ] | 状態遷移表を作る | 15.014, 16.023 | dirty・入力準備・依存待ち・予約・実行・反映・失敗を列挙 |
| 17.001/fair-checkpoint-state | [x] | 公平dispatchと保存状態/世代の安全な境界を接続する | 15.001/core-scheduler-edge, 16.003/gauss-executor, 05.003/retained-item-lifetime | FIFO/input優先・owner終了・buffer通知再入を処理し、stored世代とruntime epochを分離。32 app/20 scheduler/8 dispatcher通常・focused sanitizer。大画像spool/全性能/色空間gateは未完了 |
| 17.001/dependency-publication | [x] | Clone経由依存と非同期投影通知・再入を安全に接続する | 17.001/fair-checkpoint-state, 16.003/native-color-transfer, 14.015/reference-undo-snapshot | 51実app通常/focused sanitizer、21 scheduler合格。非解決snapshotで依存検証、遅延cycle/通知中close/定義Undo再入と自動canvas更新を処理。実測p99/maxの大きなstallは未解決 |
| 17.001/bounded-admission | [x] | 複数Filterのsnapshot/worker資源を公平FIFOで制限する | 17.001/dependency-publication, 16.003/native-gray-transfer | 63 actual app・25 scheduler・9 admission通常/focused sanitizer合格。2job/宣言1GiB上限、cancel worker寿命・待機自動再開・staging/chunk破棄を検証。spill/巨大画像/全latencyは未完了 |
| 17.001/undo-owner-lifetime | [x] | callback中の最終image参照解放でもUndo stackを保護する | 17.001/bounded-admission, 12.015/external-reference-preservation | 67 actual app通常/focused sanitizer、12 phaseのordinary/strong Undo/Redo再入を検証。隣接Clone37/XCF16とnative GTK16合格。旧failure/source hash保持 |
| 17.001/filter-end-timeout-contract | [ ] | FilterLayer の遅延終了通知の所有権を定義する | 17.001, 01.005/deferred-sources | source ID、所有者寿命、close とキャンセルの順序、通知の一回性を状態遷移表へ明記 |
| 17.001/live-spill-execution | [x] | spill転送を実FilterLayerの準備/worker/反映へ接続する | 17.001/bounded-admission, 16.003/spill-components | 72 actual app/34scheduler通常・17unit focused sanitizer合格。8193²実Edge完走と1025²RGB/Gray両Gauss byte比較・世代/取消し/失敗leaseを検証。3実測12.34–12.79s、heartbeat最大89–119ms/RSS約1.33GiB/最終unref最大133.9msを明示、全latency/総資源gate未完了 |
| 17.001/cold-graph-quanta | [x] | cold graph準備を所有付きdispatchへ分割し全step時間を測る | 17.001/live-spill-execution | 75 actual app通常/17unit focused sanitizerと10target合格。node/変換cache準備を分割し変更/削除/最終owner/遅いobserverを検証。8193²heartbeat最大23.1–31.6ms、複雑graphは最大129.7ms、close最大106.7ms/RSS約1.33GiB。全応答性/総disk予算は未達と明示 |
| 17.001/configured-spill-budget | [x] | 設定所有のFIFOでFilter一時file領域を予約・制限する | 17.001/cold-graph-quanta, 16.003/gauss-alias-regions | native80通常/19source sanitizer＋26 RTTI-only、13admission/7raster/11spool/35scheduler sanitizer合格。保存可能8GiB既定・0停止・cache保持・増額自動再開・worker容量確認とfile extent課金を検証。OS実予約/総GEGL資源/全latency/Windowsは未達 |
| 17.001/spill-preferences-uint64 | [x] | 一時容量Preferencesを全uint64を保持するUIへ接続する | 17.001/configured-spill-budget | 4TiB上限widgetによるPreferences起動停止を修正。8GiB既定・UINT64_MAXまで丸めず保持し不正入力/再入破棄を検証。7通常target167case・2C unit限定ASan/UBSan4GTK合格。全aggregate/platformは別gate |
| 17.002 | [ ] | 更新イベントの入力を実装する | 17.001 | 下層画素・設定・階層変更を分類 |
| 17.003 | [ ] | 上層変更の除外を実装する | 17.002 | 無関係な変更で再評価しない |
| 17.004 | [ ] | 可視下層の依存検出を実装する | 17.003 | 評価前に未確定依存を識別 |
| 17.005 | [ ] | 依存先優先の起動順を実装する | 17.004 | 下層結果が確定してから上層を起動 |
| 17.006 | [ ] | 依存循環の検出を実装する | 17.005 | 参照を含む cycle で無限待ちしない |
| 17.007 | [ ] | dirty 領域の重複排除を実装する | 17.006 | 連続入力で同領域を無制限に追加しない |
| 17.008 | [ ] | 入力準備の分割を実装する | 17.007 | 一定仕事量ごとに UI へ制御を返す |
| 17.009 | [ ] | 投影済み領域の消化を実装する | 17.008 | 未準備領域を正しく減らす |
| 17.010 | [ ] | 入力 snapshot の世代固定を実装する | 17.009 | 画素・設定・依存が同じ世代に属す |
| 17.011 | [ ] | 開始チェックポイントを実装する | 17.010 | dirty 有・依存待ち無・未準備領域無でのみ起動 |
| 17.012 | [ ] | 入力と描画を優先する dispatch を実装する | 17.011 | 背景評価が入力 source を飢餓にしない |
| 17.013 | [ ] | 依存変更時の停止判断を実装する | 17.012 | 実行中の古い評価へ cancel を要求 |
| 17.014 | [ ] | 待機解除を実装する | 17.013 | 依存完了・非表示・削除による変化を反映 |
| 17.015 | [ ] | 未完成結果の遮断を実装する | 17.014 | 上層が実行途中の出力を確定入力に使わない |
| 17.016 | [ ] | 完了結果の世代検査を実装する | 17.015 | 入力・設定・依存・生存状態を全確認 |
| 17.017 | [ ] | 結果反映の分割を実装する | 17.016 | 大画像の copy で UI を長時間占有しない |
| 17.018 | [ ] | 結果公開の境界を実装する | 17.017 | 全結果が整う前に部分結果を完成扱いしない |
| 17.019 | [ ] | 反映後の更新伝播を実装する | 17.018 | 依存する上層と表示へ一度通知 |
| 17.020 | [ ] | 自己更新の除外を実装する | 17.019 | 結果通知から無限再起動しない |
| 17.021 | [ ] | 古い結果の廃棄を実装する | 17.020 | 新世代の確定画素へ書き戻さない |
| 17.022 | [ ] | cancel 完了の再起動判断を実装する | 17.021 | 最新 dirty を失わず予約を解除 |
| 17.022/explicit-owner-cancel | [x] | Filterの明示cancel入口で確定cacheとdefinitionを保持する | 17.001/configured-spill-budget | native2試験とfocused ASan/UBSan2試験で待機/準備/実行/反映中取消し、cache/raw保持、通知再入を確認。381入力seal一致。全Filter/aggregate/platformは別gate |
| 17.023 | [ ] | 失敗時の再試行制限を実装する | 17.022 | 同じ失敗で無限ループしない |
| 17.024 | [ ] | 終了判定を実装する | 17.023 | 最新世代反映済・dirty無・依存待ち無・実行無を判定 |
| 17.025 | [ ] | 保存との同期点を接続する | 17.024, 12.016 | UI を止めず一貫した保存 snapshot を渡す |
| 17.026 | [ ] | close に scheduler を接続する | 17.025 | 世代失効・source 解除・cancel を非待機で実施 |
| 17.026/filter-end-timeout-cancel | [ ] | FilterLayer の遅延通知 source を close 時に解除する | 17.025, 17.001/filter-end-timeout-contract | timeout の ID を管理し、close 後に raw `this` へ callback しない。終了通知の重複を防ぐ |
| 17.027 | [ ] | 実行 trace を実装する | 17.026 | 優先順位・checkpoint・終了理由を ID 付きで記録 |
| 17.028 | [ ] | UI callback の同期 flush を監査する | 17.027 | 旧同期 flush を無制限の main-thread 処理として残さない |
| 17.029 | [ ] | 評価経路の禁止事項を検査する | 17.028 | 独自 FilterLayer の制御が既存 GEGL 非破壊効果へ委譲されていない |

### 18 FilterLayer の応答性・収束試験

主対象：重負荷・多層・競合・異常終了

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 18.001 | [ ] | 応答時間の測定基準を決める | 02.015, 12.016, 17.029 | 基準機・作品・p95/p99・最大 UI 占有の合格値を固定 |
| 18.002 | [ ] | 単層の更新試験を作る | 18.001 | 下層変更から最新結果へ収束 |
| 18.003 | [ ] | 多層の順序試験を作る | 18.002 | 依存先優先が trace で確認できる |
| 18.004 | [ ] | 連続描画の試験を作る | 18.003 | 入力が進み dirty が失われない |
| 18.005 | [ ] | 実行中の設定変更を試験する | 18.004 | 古い世代を反映しない |
| 18.006 | [ ] | 実行中の並替えを試験する | 18.005 | 依存を再評価し待機を解除 |
| 18.007 | [ ] | 非表示切替を試験する | 18.006 | 不要待ちと旧仕様との差がない |
| 18.008 | [ ] | 実行中の削除を試験する | 18.007 | 完了 callback が削除済み型を触らない |
| 18.008/filter-end-timeout-teardown | [ ] | FilterLayer の timeout 待機中に削除する試験を実行する | 18.007, 17.026/filter-end-timeout-cancel | timeout 予約直後に layer と画像を破棄して source が解除され、遅延 callback で解放済み所有者を触らない |
| 18.009 | [ ] | 画像終了を試験する | 18.008 | 終了処理で join せず資源を回収 |
| 18.010 | [ ] | Undo/Redo 中の評価を試験する | 18.009 | 復元した定義と画素へ収束 |
| 18.011 | [ ] | 実行中の保存を試験する | 18.010 | 再読込で定義と cache 世代が整合 |
| 18.012 | [ ] | 初回 loaded 表示を試験する | 18.011 | 保存済み画素と再評価の順序が一致 |
| 18.013 | [ ] | 中止と失敗を試験する | 18.012 | 待機・予約が残らず無限再試行しない |
| 18.014 | [ ] | 応答しない手順を試験する | 18.013 | 入力・表示・終了操作が進む |
| 18.015 | [ ] | 大画像の入力準備を計測する | 18.014 | 合格 UI 占有時間以下 |
| 18.016 | [ ] | 大画像の結果反映を計測する | 18.015 | 合格 UI 占有時間以下 |
| 18.017 | [ ] | 終了条件の収束を検証する | 18.016 | 編集停止後に最新世代で全待機が解消 |
| 18.018 | [ ] | 多画像の公平性を検証する | 18.017 | 一画像の重処理が他画像を飢餓にしない |

### 19 拡張ブラシ資産の reader/writer

主対象：myb、資源参照、data factory

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 19.001 | [ ] | myb v2 の decoder を移植する | 08.020, 10.018 | 同梱1件の設定を取得 |
| 19.001/resource-foundation | [x] | 拡張myb資源と所有/stream契約を実装する | 04.002/common-foundation, 04.013/brush-setting-generator, 01.017 | 全177資源の実旧parser 81420記録一致、8 model/4 native通常とASan/UBSan、未知値/非対応入力/preview保持。factory・選択・editorは別gate |
| 19.002 | [ ] | myb v3 の decoder を移植する | 19.001 | 同梱176件の設定を取得 |
| 19.003 | [ ] | settings の全キーを対応付ける | 19.002 | 独自値を含め未割当キーがない |
| 19.004 | [ ] | switches の decoder を実装する | 19.003 | 既定値と明示値を区別 |
| 19.005 | [ ] | texts の decoder を実装する | 19.004 | 文字列と資源参照を保持 |
| 19.006 | [ ] | 入力カーブの decoder を実装する | 19.005 | 点列・入力名・範囲を保持 |
| 19.006/v1-curve-validation | [ ] | 旧 myb v1 の曲線点読込みを修正して移植する | 19.005, 01.005/indirect-callback-owners | 旧 `parse_points_v1` の余分なセミコロンによる全点スキップを排除し、x の単調性・y 変換・異常な点列を処理 |
| 19.006/mapping-value-owner | [ ] | 曲線点列の値所有を実装する | 19.006, 01.007/mapping-array | 点列を独立にコピー・移動し、再代入・破棄で配列の多重解放を起こさない |
| 19.007 | [ ] | 未知キーの保持を実装する | 19.006 | 読込→保存で消えない |
| 19.008 | [ ] | GIMP ブラシ参照を解決する | 19.007 | 資源名と識別規則を旧版に合わせる |
| 19.009 | [ ] | 紙目参照を解決する | 19.008 | 旧参照から対象資源を選ぶ |
| 19.010 | [ ] | 欠落資源の扱いを実装する | 19.009 | 参照文字列を失わず再指定可能 |
| 19.011 | [ ] | writer の設定出力を実装する | 19.010 | 独自設定と入力カーブを全保存 |
| 19.011/output-stream-save | [ ] | 拡張 myb writer を現行 GimpData.save の stream 契約へ移す | 19.011, 01.005/gimp3-brush-callbacks | 渡された GOutputStream に JSON を書き、出力失敗を呼出元へ返し、アイコン保存との整合と再読込みを確認 |
| 19.012 | [ ] | writer のメタデータ出力を実装する | 19.011 | 未知情報と参照を保持 |
| 19.013 | [ ] | data factory を接続する | 19.012 | 検索パス・読込み・更新を処理 |
| 19.013/dedicated-factory | [x] | 拡張brushの独立factoryと配布pathを接続する | 19.001/resource-foundation | 実appで177読込→複製改名保存/再読込178→削除177、標準MyPaint件数不変を確認。全asset install登録、tool/editorは別gate |
| 19.013/native-context-resource | [x] | 拡張brushを独立context property・継承・保存へ接続する | 19.013/dedicated-factory | 4 native通常/12source focused sanitizer合格。型/通知/継承・旧mypaint-brush別名読込・欠落名保存・finalizer再入とstale通知抑制を検証。標準MyPaint不変、登録tool/editorは別gate |
| 19.013/preview-contract | [ ] | 拡張ブラシのサイズ・preview を GIMP 3 契約へ移す | 19.013, 01.005/gimp3-brush-callbacks | get_size の成功時に幅・高さを必ず設定し、GimpTempBuf と GeglColor の preview を所有権込みで検証 |
| 19.013/icon-buffer | [ ] | MyPaint アイコンの画素バッファーを安全に所有する | 19.013, 01.007/icon-buffer | surface と data の破棄を結び、実 stride の領域を確保し、同一 surface の再設定を安全にする |
| 19.014 | [ ] | ブラシの複製・改名・削除を接続する | 19.013 | 資源所有と保存先が整合 |
| 19.015 | [ ] | 全177件の往復試験を実行する | 19.014 | 設定の意味差分がゼロ |
| 19.015/v1-curve-roundtrip | [ ] | 旧 myb v1 曲線の読込・保存・再読込を試験する | 19.014, 19.006/v1-curve-validation | 変換あり・なしと点列順序の fixture で欠落・停止がない |
| 19.016 | [ ] | 設定ファイルの旧キーを移行する | 19.015 | 旧 tool preset 等から拡張設定を復元 |

### 20 拡張 MyPaint エンジン

主対象：演算と拡張 Surface API

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 20.001 | [ ] | 旧設定評価の仕様を抽出する | 02.015, 04.019, 19.016 | 各入力と mapping の評価順を記録 |
| 20.002 | [ ] | 旧混色状態の仕様を抽出する | 20.001 | 採色・状態更新・押印の順序を記録 |
| 20.003 | [ ] | 現行 libmypaint の拡張差分を試作する | 20.002 | 独自入力を Surface へ渡す最小経路が動作 |
| 20.004 | [ ] | 旧拡張エンジンの現行ビルドを試作する | 20.003 | 比較可能な fallback が動作 |
| 20.004/evaluator-comparison | [x] | 独立旧Brush評価器をC++14で復元し比較する | 19.001/resource-foundation, 01.009 | 177資源+明示synthetic拡張例の5637911 trace bytes/27392 dabsが旧評価器と完全一致。Surface採色はsyntheticで実drawable/Undoは未主張 |
| 20.005 | [ ] | 同一入力で両案を比較する | 20.004 | 代表ブラシの画素差・遅延・保守差分を記録 |
| 20.006 | [ ] | 採用エンジンを固定する | 20.005 | 再現性を満たす方を選び再現性不足で停止しない |
| 20.007 | [ ] | 依存と symbol を分離する | 20.006 | 標準 libmypaint との二重 symbol 衝突がない |
| 20.008 | [ ] | 筆圧 mapping を移植する | 20.007 | 旧カーブの評価値が一致 |
| 20.009 | [ ] | 速度・方向 mapping を移植する | 20.008 | 時刻・角度境界を含め一致 |
| 20.010 | [ ] | 傾き mapping を移植する | 20.009 | 軸と単位が一致 |
| 20.011 | [ ] | 乱数の状態管理を移植する | 20.010 | seed 固定で再現可能 |
| 20.012 | [ ] | dab 間隔と時間積分を移植する | 20.011 | 入力列から押印順が再現 |
| 20.013 | [ ] | texture_grain 評価を移植する | 20.012 | dab ごとに Surface へ伝わる |
| 20.014 | [ ] | texture_contrast 評価を移植する | 20.013 | dab ごとに Surface へ伝わる |
| 20.015 | [ ] | stroke_opacity 評価を移植する | 20.014 | dab opacity と独立に保持 |
| 20.016 | [ ] | 拡張採色 API を実装する | 20.015 | 硬さ・縦横比・角度・形状を受け渡す |
| 20.017 | [ ] | stroke 状態の開始・終了を実装する | 20.016 | 一筆の内部状態を初期化・確定 |
| 20.018 | [ ] | エンジン単体の数値比較を実行する | 20.017 | 固定入力の mapping と状態更新が基準に一致 |

### 21 MyPaint 押印・採色・混色 Surface

主対象：DrawableFeature、BrushFeature、Surface

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 21.001 | [ ] | 通常形状の押印を実装する | 09.017, 20.018 | 硬さ・半径・alpha が一致 |
| 21.001/native-surface-session | [x] | 旧押印演算をGEGL Surfaceとnative paint transactionへ接続する | 20.004/evaluator-comparison, 19.013/dedicated-factory, 05.003/retained-item-lifetime | 148実旧Surface/24bitmap mask/72generated mask一致、9 native通常と22source sanitizer合格。開始/終了再入・selection・Undo・資源寿命を検証。実旧full-session画素/tool/高精度は別gate |
| 21.001/full-session-oracle | [x] | 実旧applicationのstroke・Undo・Redo画素を比較する | 21.001/native-surface-session | 32scenario/96RGBA snapshot/129recordの9587537 bytesが完全一致。旧cold crashを別保存しwarm-upを明示。11 fixture試験合格、登録tool・ICC/高精度は未完了 |
| 21.001/options-session-adapter | [x] | 全拡張optionsと単一slot native session adapterを接続する | 21.001/full-session-oracle, 19.013/native-context-resource | 8 options/6 session通常・26source focused sanitizer合格。curve編集/commit競合・閉鎖snapshot・brush/paper名双方向・欠落名保持・旧論理Undo分割/通知再入を検証。Surface9と129旧record再確認、tool/hover/editor未完了 |
| 21.001/sampling-only-hover | [x] | hoverでengine採色状態を進め画素/空Undoを書かない | 21.001/options-session-adapter | 5 native通常/26source focused sanitizer合格。定数opacity/pressure0・1でも無描画、既存transactionを旧logical splitまで維持し旧image解放・close再入を検証。Surface9/session6/旧129record再合格 |
| 21.001/registered-tool | [x] | 拡張MyPaintの実tool・hover・保存/target寿命を接続する | 21.001/options-session-adapter, 21.001/sampling-only-hover, 05.003/native-tool-press-lease | 13実GTK/33source focused sanitizer合格。options8/session8/hover6/Surface9・129旧record再確認。evaluatorと資源selectorのhover pressure0を統一し旧論理Undo分割を維持。generic Stroke Pathは誤代替せず明示拒否、editor/ICC/pipe/旧profileは未完了 |
| 21.001/atomic-generic-strokes | [x] | 実native stroke/path/boundaryを既存MyPaint Sessionの原子的batchへ接続する | 21.018/native-rgb-surface, 04.011/sanitizer-rtti-scope | 13 native/28source focused sanitizer＋24 RTTI-only合格。複数subpath全rollback・旧Undo/Redo保持・push_undo=false・Options最終ref・座標state実native比較を検証。interactive8/6と旧129/385record再確認。実PDB transport/GTK集約・Gray/precision等は別gate |
| 21.002 | [ ] | GIMP ブラシ mask の取得を実装する | 21.001 | 旧形状と資源選択を保持 |
| 21.002/resource-owner | [ ] | Surface のブラシと紙目の参照・使用期間を対称にする | 21.002, 01.007/cpp-ownership | 同一資源の再設定、NULL 切替、Surface 先行終了時に begin_use/end_use と ref/unref を一回ずつ対応付ける |
| 21.002/native-pipe-release | [x] | native pipeの状態/RNGとpressure-zero入力前の正筆圧tail・Clipboard previewを保持する | 21.018/gray-tool-save-roundtrip, 24.012/private-preview-resources | 全8selector/32旧scene/416画像/2817recordsの消費状態・画素がexact。normal9suiteと3focused sanitizer、実GTK15/38unit sanitizer15合格。cold非累積旧crash/未使用previous coords差とempty-shell単発fatalを保存、ICC/precisionは別gate |
| 21.003 | [ ] | GIMP ブラシ mask の変形を実装する | 21.002 | サイズ・角度・縦横比を反映 |
| 21.004 | [ ] | 形状 mask の押印を実装する | 21.003 | ブラシ coverage を画素へ反映 |
| 21.005 | [ ] | 通常採色の重みを実装する | 21.004 | 硬さ・縦横比・角度を使用 |
| 21.006 | [ ] | GIMP ブラシ形状での採色を実装する | 21.005 | 押印と採色で同じ変形規則を使用 |
| 21.007 | [ ] | 透明採色の状態更新を実装する | 21.006 | alpha0 なら直前の有効色を保持 |
| 21.008 | [ ] | 有効採色の状態更新を実装する | 21.007 | 混色状態を旧順序で更新 |
| 21.009 | [ ] | 色と alpha の混合を実装する | 21.008 | premultiplication と丸めを維持 |
| 21.010 | [ ] | 採色元 buffer の切替を実装する | 21.009 | 開始前・作業中・合成後を仕様どおり参照 |
| 21.011 | [ ] | 非累積の作業 buffer を実装する | 21.010 | 同位置の dab が旧仕様で蓄積 |
| 21.012 | [ ] | ストローク全体の不透明度を実装する | 21.011 | dab opacity への単純置換をしない |
| 21.013 | [ ] | 非累積の表示合成を実装する | 21.012 | 作業中の見た目と確定結果が整合 |
| 21.014 | [ ] | ストローク確定を Undo に接続する | 21.013 | 一筆一 Undo で開始前へ戻る |
| 21.015 | [ ] | ストローク取消しを実装する | 21.014 | 作業 buffer を破棄し開始前を保持 |
| 21.016 | [ ] | dirty と extent 更新を接続する | 21.015 | ブラシ外への不要更新を抑える |
| 21.017 | [ ] | 負座標・画面外の dab を処理する | 21.016 | buffer 境界を破らない |
| 21.018 | [ ] | 色精度別の Surface を検証する | 21.017 | 旧形式再現と高精度動作を区別 |
| 21.018/native-rgb-surface | [x] | 実旧RGB u8 Surfaceとerase・alpha lockを一致させる | 21.001/registered-tool | 96実旧scene/288全画像/385recordが21575701 bytes通常と26source focused sanitizerで一致、RGBA129recordとSurface10群を再確認。16非累積fully-locked無変化sceneの旧Undoも保持。Gray/高精度・generic path・全GTKは別gate |
| 21.018/native-gray-surface | [x] | 実旧1byte Gray Surfaceの描画・Undo/Redoを保持する | 21.018/native-rgb-surface, 04.011/sanitizer-rtti-scope | 48実旧scene/193record・3599558bytes完全一致、native4と各26source sanitizer合格。Gray-alpha/非累積の旧未定義経路は明示拒否し次の定義拡張へ分離。全app linkとSurface10/generic13/RGBA129/RGB385再合格 |
| 21.018/defined-gray-alpha | [x] | 旧未定義のGray-alpha/非累積へnative2byteの安全な意味を与える | 21.018/native-gray-surface | 180scalar invariantと192paired native session/Undo/Redo、透明erase/lock/cancelが通常・26source focused sanitizer＋26 RTTI-only合格。旧193/129/385recordを独立再確認。旧oracle同等とは主張せずhighprecision/TRC/ICC・実GTKは別gate |
| 21.018/gray-tool-save-roundtrip | [x] | 実GTK拡張MyPaintでGray4種の描画・XCF保存再読込を検証する | 21.018/defined-gray-alpha, 21.001/registered-tool | native14/37source focused sanitizer＋24 RTTI-only合格。Gray/Gray-alpha×累積/非累積のpress-motion・実XCF Save・native byte再読込・Undo/Redo一致。D65gray/sRGB TRCを実行し任意ICC/高精度/実tabletは未主張 |
| 21.018/native-precision-trc-icc | [x] | native72formatとTRC/ICC境界へ既存MyPaint Surfaceを拡張する | 21.018/gray-tool-save-roundtrip, 21.002/native-pipe-release | native scalar codecでu32/doubleLSB保持、144profile cell・18precision実GTK/XCFを初期通常/38unit sanitizer＋32 RTTI-onlyで確認、旧4corpus不変。setter review後backend8通常/sanitizerとnative144通常再合格。post-review全native/GTK sanitizerのcoherent aggregateは別gate |
| 21.019 | [ ] | 固定入力の筆跡比較を実行する | 21.018 | 形状採色・透明境界・非累積・opacity を個別比較 |
| 21.020 | [ ] | 押印の遅延とコピー量を計測する | 21.019 | 一 dab ごとの画像全体コピーがない |

### 22 紙目・テクスチャ

主対象：通常ブラシと MyPaint の共有資源・演算

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 22.001 | [ ] | 紙目座標の仕様を固定する | 09.017, 20.018 | 画像・layer・stroke の原点と位相を記録 |
| 22.001/native-paper-runtime | [x] | 通常BrushCoreと共有Texture・queued Fill/Smudgeへ旧紙目演算を接続する | 23.005/native-smudge-tool, 27.010/bounded-interpolation, 21.018/native-gray-surface | native12/GTK7通常・29source sanitizer＋28 RTTI-only合格。216mask/1296変形入力・24+384定義済通常scene/Smudge48×2/Fill12×3 exact。Clipboard snapshotとsignal最終ref/失敗no-fallbackを検証。旧未定義DSTは安全拡張、geometry全体/platform/tabletは未完了 |
| 22.001/native-legacy-geometry | [x] | 旧profile由来の通常brush geometry・既定curve・pixmapを保持する | 22.001/native-paper-runtime, 30.010/native-profile-migration | 2592旧mask/336旧全strokeとUndoRedoがexact、288未指定modern scene不変。native7/26unit sanitizer＋37 RTTI-only、GTK profile9通常/sanitizer合格。固定marker/private POD/cacheとstateless mathで二重Implなし。追加144旧scene/axes正常系exact・登録4Meson合格、aggregate/platformは別gate |
| 22.002 | [ ] | 紙目資源の読取りを接続する | 22.001 | 階調・alpha・反復を旧仕様と一致 |
| 22.003 | [ ] | 紙目 mask の生成を実装する | 22.002 | grain と contrast の数値を反映 |
| 22.004 | [ ] | 動的紙目の dab 更新を実装する | 22.003 | 入力カーブ変化が dab ごとに反映 |
| 22.005 | [ ] | 紙目と brush mask の合成を実装する | 22.004 | 適用順を維持 |
| 22.006 | [ ] | 通常 paintbrush の紙目経路を移植する | 22.005 | 既存の描画オプションへ接続 |
| 22.007 | [ ] | MyPaint の紙目経路を接続する | 22.006 | 共通資源から旧拡張値を使用 |
| 22.008 | [ ] | 紙目キャッシュの無効化を実装する | 22.007 | 資源・倍率・角度・設定変更へ追従 |
| 22.009 | [ ] | 紙目設定の保存を接続する | 22.008 | 再起動・再読込で値を保持 |
| 22.010 | [ ] | 紙目の比較試験を実行する | 22.009 | 移動・反転・拡縮・非累積時の位相と結果が一致 |

### 23 独立 Smudge と描画入力

主対象：gimpsmudge、motion・smoothing・pressure

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 23.001 | [ ] | 旧 blending-output の式を抽出する | 02.015, 09.017 | Flow/Rate と区別した仕様を記録 |
| 23.001/runtime-old-strokes | [x] | 独立Smudgeの旧実描画・蓄積・blending出力を採取する | 02.003, 04.002/common-foundation | 48実旧scene/192全native画素snapshotをRGB/Gray・alpha有無・rate・色混合・size dynamicsで採取し、独立再実行2952800 bytes完全一致。全Undo/Redo一致・4fixture試験合格。現行Flow同等性・移植は未完了 |
| 23.001/blending-dynamics-model | [x] | 独立blending-outputとnative曲線往復を復元する | 23.001/runtime-old-strokes | 既存enumをずらさず旧value11/nick・aggregateを追加しFlowと分離。5 native/5unit ASan・UBSan合格。空curveのnull/zero長memcpy・memcmpも実検出してguard、旧property・curve roundtripとcopy独立を確認。Smudge toolは別gate |
| 23.002 | [ ] | Smudge の蓄積 buffer を移植する | 23.001 | 初期採色と更新が一致 |
| 23.002/native-byte-kernels | [x] | 旧Smudge蓄積・shade・native描画の別々の数式を保持する | 23.001/runtime-old-strokes | 1024実旧caseの全byte重み/RGB/Gray/alpha/選択を採取し891487 bytesが通常/ASan・UBSan・float-cast-overflow完全一致。PaintCore replaceとLayer Replaceの異なる半透明/透明色roundingを維持。native全stroke/toolは後続gate |
| 23.002/native-owner-smudge | [x] | 旧Smudgeを専用native coreと単一Undo・取消しへ接続する | 23.002/native-byte-kernels, 27.009/native-start-preflight | Y/YA/RGB/RGBA48実旧sceneの193record/2952800 bytesがrawとowned経路で完全一致。10 lifecycle群と15source focused sanitizer合格。旧mask丸め/独立blendingを保持。GUI登録・長距離分割・memory admission・全precision/pipe・旧profile移行は別gate |
| 23.003 | [ ] | Smudge の色混合を移植する | 23.002 | 旧 blending-output を再現 |
| 23.004 | [ ] | Smudge のサイズ変化を処理する | 23.003 | 蓄積 buffer の再配置が一致 |
| 23.005 | [ ] | Smudge の設定 UI と保存を接続する | 23.004 | 値が描画と往復に反映 |
| 23.005/native-smudge-tool | [x] | 独立Smudgeの実tool・owner入力queue・1dab継続・設定UIを接続する | 23.002/native-owner-smudge, 27.010/bounded-interpolation | 26実GTK通常/30source focused sanitizer、13core/17source sanitizer合格。2 owned routeで実旧193record/2952800 bytes一致。Undo/取消/Save query・長距離・再入を確認。既存標準S不変、旧profile・generic stroke・全dabメモリ/遅延・paper/pipe等は別gate |
| 23.006 | [ ] | Smudge の比較試験を実行する | 23.005 | 色境界・透明境界・サイズ変化を比較 |
| 23.007 | [ ] | 微小移動の筆圧イベントを接続する | 23.006 | 座標差が小さくても筆圧を失わない |
| 23.008 | [ ] | 位置固定の筆圧イベントを接続する | 23.007 | 必要な dab 状態更新が進む |
| 23.009 | [ ] | 入力時刻の扱いを接続する | 23.008 | 間引き・逆行・同時刻を処理 |
| 23.010 | [ ] | 手ぶれ補正の入力履歴を移植する | 23.009 | 旧履歴長と評価順を保持 |
| 23.011 | [ ] | 手ぶれ補正の stroke 終端を移植する | 23.010 | pen up 時の残り処理が一致 |
| 23.012 | [ ] | 定規と補正の順序を実装する | 23.011 | 拘束後の入力が旧動作と一致 |
| 23.013 | [ ] | 対称描画との順序を接続する | 23.012 | 現行機能と併用して座標が破綻しない |
| 23.014 | [ ] | tool 切替・focus loss の取消しを接続する | 23.013 | 途中 stroke と pointer 状態を解放 |
| 23.014/event-compression-order | [ ] | motion圧縮と非motionイベント再投入の順序を維持する | 23.013, 01.017 | 旧compress_motionとnext_event経路を現行入力へ接続し、pen up・key・crossing・device切替が欠落せずイベント所有が一回解放される |
| 23.015 | [ ] | ペン入力の回帰試験を実行する | 23.014 | 連続・微小・固定筆圧・pen up を比較 |

### 24 ブラシ editor・履歴・プレビュー

主対象：tools/widgets/actions の拡張ブラシ UI

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 24.001 | [ ] | 設定 model を共通化する | 19.016, 20.018, 21.020, 22.010 | dock・popup・横型 UI が同一データを操作 |
| 24.001/editor-context-contract | [ ] | MyPaint editor の context と options の取得契約を定める | 24.001, 01.005/non-xcf-c-calls | `GimpContext` を正しい型として受け、選択中ブラシと編集 options の取得方法、NULL の扱い、所有権を明記する |
| 24.001/application-history | [x] | 任意Options間で旧履歴をapplication所有として共有する | 21.001/registered-tool | 10 native/26source focused sanitizer合格。単一Gimp BindingStore slotとweak/generation observerで共有し、別app分離・閉鎖/通知再入・未知値/curve/reference復元を検証。閉鎖Options name/restoreを明示拒否。全editor/previewは別gate |
| 24.002 | [ ] | 数値設定 editor を移植する | 24.001 | 独自パラメーターを全編集可能 |
| 24.003 | [ ] | switch editor を移植する | 24.002 | 値と表示が双方向に同期 |
| 24.004 | [ ] | 入力カーブ editor を移植する | 24.003 | 各入力の点追加・移動・削除が可能 |
| 24.005 | [ ] | ブラシ形状 selector を移植する | 24.004 | 選択が押印と採色へ反映 |
| 24.006 | [ ] | 紙目 selector を移植する | 24.005 | 資源と動的設定へ反映 |
| 24.007 | [ ] | ブラシ一覧を移植する | 24.006 | tag・検索・選択の資源対応が保たれる |
| 24.008 | [ ] | 保存 action を接続する | 24.007 | 編集中状態を正しい資源へ書く |
| 24.009 | [ ] | 複製・改名・削除 action を接続する | 24.008 | 選択中資源と editor が整合 |
| 24.010 | [ ] | ブラシ履歴 model を移植する | 24.009 | 編集中状態と保存資源を区別 |
| 24.011 | [ ] | 履歴選択の復元を実装する | 24.010 | 独自値・曲線・参照を全復元 |
| 24.012 | [ ] | preview 入力を固定する | 24.011 | 同設定で同じ試し描きを生成 |
| 24.012/private-preview-resources | [x] | previewのbrush/paper/pipe/RNG状態を実strokeから分離する | 24.001/application-history, 21.001/registered-tool | 4 native/28source focused sanitizer合格。8pipe mode・child/paper deep copy・元状態/use-count/global RNG非変更・unknown selector拒否を検証。Surface9/旧129record再確認。検証時PaintCore headerも保存し後続ABI変更のaggregate再試験、旧widget preview画素は別gate |
| 24.013 | [ ] | preview 描画を実装する | 24.012 | 紙目・Smudge・非累積を含む独自設定が反映 |
| 24.014 | [ ] | preview 更新の取消しを実装する | 24.013 | 古い設定の結果を表示しない |
| 24.015 | [ ] | dock と popup の共有 UI を接続する | 24.014 | 二重保存・二重通知がない |
| 24.015/brush-popup-signal-owner | [ ] | ブラシ popup の旧資源への通知接続を解除する | 24.015, 01.008 | 選択変更時に旧ブラシの notify を解除して新ブラシへ接続し、popup 終了時には保持した接続先を解除して解放済み user data を呼ばない |
| 24.015/mypaint-editor-create | [ ] | MyPaint editor の生成条件と options を修正する | 24.014, 24.001/editor-context-contract | `GimpContext` への誤った `GIMP_IS_MYPAINT_OPTIONS` 判定と NULL options の参照を排除し、正しいブラシを表示する |
| 24.016 | [ ] | 横型 GUI を共通部品へ接続する | 24.015 | 旧操作を削らず重複実装を排除 |
| 24.017 | [ ] | editor の往復試験を実行する | 24.016 | 編集→保存→再選択で全設定が一致 |
| 24.017/native-editor-workflow | [x] | 共通MyPaint editorの縦横dock・popup・全設定保存と旧previewを接続する | 24.012/private-preview-resources, 24.001/application-history | 12実GTK/37source focused sanitizerとmanual視認1、全45/5/2設定・9curve入力・range/enable・factory操作・再入を検証。実旧16preview/33record/8389189 bytes完全一致、4fixture確認。検証時の未commit依存4sourceを保存し全app/実device/platform/177全renderは別gate |
| 24.017/mypaint-editor-constructor-test | [ ] | MyPaint editor の起動・破棄を検証する | 24.016, 24.015/mypaint-editor-create | 有効 context と未選択・無効 context の各ケースで作成結果、ブラシ表示、エラー処理、破棄後の参照数を確認 |

### 25 回転・反転・スナップ

主対象：display shell と tool event

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 25.001 | [ ] | 旧回転の開始条件を移植する | 02.015, 03.009 | button・modifier・tool 状態が一致 |
| 25.001/start-relative-route | [x] | 旧回転開始基準と修飾キーrouteを現行表示へ接続する | 01.017, 04.003 | 5184件の不変旧関数演算/Cairo行列一致、5 pure通常/ASan/UBSanと4実native GTK設定往復に合格。custom制約・任意button ID・設定inheritanceを保持。実drag/device・旧zoom/panは別gate |
| 25.002 | [ ] | 開始角度基準の計算を移植する | 25.001 | 旧位置基準から角度を算出 |
| 25.003 | [ ] | Ctrl ビットの判定を移植する | 25.002 | 追加 modifier があっても旧条件で判定 |
| 25.004 | [ ] | Ctrl 押下中への切替を実装する | 25.003 | drag 継続中に旧仕様の snap へ切替 |
| 25.005 | [ ] | Ctrl 解除時の切替を実装する | 25.004 | 非 snap の角度へ旧仕様で戻る |
| 25.006 | [ ] | 15度の丸めを実装する | 25.005 | 正負と半刻みの期待値が一致 |
| 25.007 | [ ] | 0/360度の境界を処理する | 25.006 | 角度飛びと方向反転がない |
| 25.008 | [ ] | 表示反転中の方向を移植する | 25.007 | 旧水平反転時の計算と一致 |
| 25.008/mirrored-arrow-input | [ ] | 表示反転中の左右キー入力を移植する | 25.007, 01.017 | mirrored時のLeft/Right変換と非反転時の不変を、押下・解除・toolへの転送・回転併用で試験する |
| 25.009 | [ ] | 現行表示行列へ接続する | 25.008 | canvas と overlay が同じ角度を使用 |
| 25.009/drag-zoom-scroll | [ ] | 修飾キー付きdrag zoomと変換座標panを維持する | 25.008, 01.017 | Shift回転・Ctrl scaling・通常scrollの開始/drag/終了、zoom距離300、device→image変換と原点を旧操作fixtureで比較する |
| 25.009/radial-default | [x] | 旧Ctrl+middleの距離300 radial zoomを接続する | 25.001/start-relative-route | 開始scale最大値・整数中心・固定anchorを保持し2400不変旧関数演算に一致、6 pure通常/ASan/UBSan合格。明示custom zoomは現行設定を保持。実display clamp/pan/deviceは未完了 |
| 25.010 | [ ] | 回転 reset action を接続する | 25.009 | 状態と UI 表示が一致 |
| 25.011 | [ ] | modifier を含む操作試験を実行する | 25.010 | 記録した全キー遷移の期待角に一致 |
| 25.011/native-event-route | [x] | 実DisplayShellへ回転/zoom修飾キーeventを通して検証する | 25.001/start-relative-route, 25.009/radial-default | Native Xfce上の4通常/4 focused sanitizerで反転・Ctrl解除・任意button・radial zoom・picker grab回収を検証。synthetic GDKであり実tablet/全focus/panは別gate |
| 25.012 | [ ] | ペン・マウスの両方を試験する | 25.011 | 入力デバイスで snap 条件が変わらない |

### 26 パース定規

主対象：定規 model・overlay・拘束 tool

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 26.001 | [ ] | 消失点の model を移植する | 08.020, 23.015 | 最大3点を保持 |
| 26.001/model-editor-checkpoint | [x] | 定規model・編集Undo・overlayを現行native UIへ接続する | 01.017, 05.003/retained-item-lifetime | 9 core/6 native GUIを通常・focused ASan/UBSanで検証。7500旧演算・14実旧model記録、image切替/再入/shortcut/toolrc保持を確認。stroke拘束は別gate |
| 26.002 | [ ] | 消失点の追加を実装する | 26.001 | 上限と初期位置が旧仕様どおり |
| 26.003 | [ ] | 消失点の移動を実装する | 26.002 | 画像座標へ変換して保持 |
| 26.004 | [ ] | 消失点の削除を実装する | 26.003 | 残りの参照と選択が整合 |
| 26.005 | [ ] | 定規の表示を移植する | 26.004 | zoom・pan・回転・反転に追従 |
| 26.006 | [ ] | 消失点 hit test を移植する | 26.005 | 画面縮尺を考慮して選択 |
| 26.007 | [ ] | 描画方向の決定を移植する | 26.006 | 旧判定距離と優先方向が一致 |
| 26.008 | [ ] | 筆跡拘束を移植する | 26.007 | 確定方向へ入力座標を射影 |
| 26.008/production-event-route | [x] | 定規の遅延開始・全motion・解除をnative eventへ接続する | 26.001/model-editor-checkpoint, 25.011/native-event-route | core9/UI6/events9/navigation4の28通常/28 focused sanitizer合格。32px拘束・history/autoscroll・tool/image再入・Escape・hover圧・statusbarを検証。実tablet/全brush smoothing/symmetry併用は別gate |
| 26.009 | [ ] | stroke 終了時の拘束解除を実装する | 26.008 | 次の stroke に状態が漏れない |
| 26.010 | [ ] | 定規編集 Undo を接続する | 26.009 | 追加・移動・削除を復元 |
| 26.011 | [ ] | 定規の保存対象を照合して接続する | 26.010 | 旧保存・非保存の境界を変更せず対応 |
| 26.012 | [ ] | 画像切替と終了を接続する | 26.011 | 別画像の点や signal を保持しない |
| 26.012/empty-display-toolrc-regression | [x] | 最終画像終了tickと旧toolrcの定規UI統合を修復する | 26.008/production-event-route, 30.010/native-profile-migration | queued resizeの実native停止/stackを再現し空shellで解除、元v1fixtureのgroups/orderを保ち新Painter4toolを追加。4target39case・全UI10反復70case・2C unit限定ASan/UBSan7case合格。全aggregate/platformは別gate |
| 26.013 | [ ] | 定規と補正の併用を試験する | 26.012 | 順序と描き味が一致 |
| 26.014 | [ ] | 3消失点と表示変換を試験する | 26.013 | 回転・反転中も期待方向に拘束 |

### 27 塗りつぶし brush と選択境界

主対象：領域探索、brush tool、選択境界

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 27.001 | [ ] | stroke 開始時の参照画像を固定する | 08.020, 09.017, 23.015 | 途中の塗りで探索元が変わらない |
| 27.001/snapshot-contract | [ ] | 投影 snapshot の所有と開始色の座標契約を確定する | 27.001, 01.005/fill-brush-boundary | 書込み後も入力不変、旧投影と同じ合成段階、画像・drawable 原点と format が一致 |
| 27.002 | [ ] | 開始色の取得を実装する | 27.001 | 旧座標・alpha の基準が一致 |
| 27.003 | [ ] | 固定閾値と色許容差の判定を移植する | 27.002 | 旧ブラシの固定閾値 30、色差と透明領域の扱いが一致 |
| 27.004 | [ ] | ブラシ内の探索を実装する | 27.003 | 領域探索が brush 外へ出ない |
| 27.004/gegl-bounded-search | [ ] | snapshot・固定開始色・矩形・ブラシ mask を受ける GEGL buffer 有界探索入口を実装する | 27.004 | 範囲外経由の回込みを許さず旧色判定・coverage・grow と一致 |
| 27.004/runtime-search-foundation | [x] | 旧有界探索・距離penalty・growをGEGL独立jobで比較する | 01.016/bucket-selection-source, 04.002/common-foundation | 128実旧search/grow scenario・257record完全一致、5通常/ASan/UBSan/float-cast-overflow不変条件と3 fixture検査合格。snapshot・step予算・取消しを検証。tool合成/全UI待時間/queue admissionは未完了 |
| 27.005 | [ ] | 選択境界内の探索を実装する | 27.004 | 探索自体が選択外を経由しない |
| 27.005/selection-threshold-contract | [ ] | 選択maskの旧距離penaltyと閾値境界を保持して試験する | 27.004, 01.016/bucket-selection-source | 0/部分/全coverage・閾値0/30/100/255・透過seed・offsetを旧実行fixtureと比較し、単純なboolean境界や探索後clipへ置換せず探索と最終描画の意味を維持する |
| 27.005/selection-barrier | [ ] | 選択 mask を探索中の通過条件に接続する | 27.005, 01.016/bucket-selection-source | 選択外経由の連結を除外し部分選択の coverage を旧結果と比較 |
| 27.006 | [ ] | 連結規則を移植する | 27.005 | 隣接・斜め・境界条件が一致 |
| 27.007 | [ ] | 塗りの coverage を接続する | 27.006 | mask と opacity を旧順序で適用 |
| 27.007/paintcore-gegl-compose | [ ] | 探索 mask と paint buffer を現行 paint core の合成に接続する | 27.007, 09.013/gegl-graph-invalidation | ブラシ変形・塗り・erase・不透明度・constant mode の順と ROI が旧筆跡と一致 |
| 27.008 | [ ] | 消去を接続する | 27.007 | 塗りモードとの差が一致 |
| 27.009 | [ ] | stroke 中の brush 移動を実装する | 27.008 | 各範囲の探索と開始参照が整合 |
| 27.009/stroke-lifecycle | [ ] | 描画中の snapshot と mask の寿命を paint vfunc の start・motion・finish に接続する | 27.009 | 終了と cancel で解放し複数 drawable・symmetry の扱いを明示して一筆の Undo を維持 |
| 27.009/native-paint-transaction | [x] | Fill探索jobを実native PaintCore・Undoへ接続する | 27.004/runtime-search-foundation, 27.012/legacy-dab-origin, 10.005/native-paint-mode-route | 36実旧RGBA snapshotが逐次/全入力queue両方1814962 bytes完全一致。12 native試験と17unit ASan/UBSan/float-cast-overflow合格。再入・invalid入力・外部編集/format/size/lock失効とpending queryを検証。GUI/全brush/ICC/有界補間は別gate |
| 27.009/native-start-preflight | [x] | Fill開始前の一回限りadmissionで未統合・再入native startを安全拒否する | 27.010/bounded-interpolation | 26 native/18source focused sanitizer合格、全app build・実旧Fill3通り・native補間6budget再確認。拒否時は既存stroke stateを変更しない。generic Stroke Path実装と自動Save継続は別gate |
| 27.009/owned-generic-strokes | [ ] | Fill/Smudgeのnative stroke/path/boundaryを同一所有transactionへ接続する | 27.009/native-start-preflight, 23.002/native-owner-smudge, 21.001/atomic-generic-strokes | 実旧180scene/690record/14303286 bytesが6route完全一致、Fill36/Smudge23/MyPaint13群と既存5trace合格。複数subpath原子Undo・取消/再入・Boundary不変・Bezier metadata初期化を実装。追加focused sanitizerは未実行 |
| 27.010 | [ ] | 大領域探索の実行量を制限する | 27.009 | 取消しと UI 入力へ戻れる |
| 27.011 | [ ] | 塗りつぶしの Undo を接続する | 27.010 | 一操作で元画像へ復元 |
| 27.012 | [ ] | tool options を移植する | 27.011 | 旧 rate・eraser-mode・継承描画設定を編集・保存し、固定閾値を新規 UI 設定と混同しない。rate の実効性を旧版で測定 |
| 27.012/legacy-brush-oracle | [x] | 旧Fill Brush実strokeのrate・paint/erase・Undoを採取する | 27.004/runtime-search-foundation | 12実旧native stroke/36全画素snapshotを保存。rate0/50/100は4組すべて完全一致、Undo初期画素・Redo結果一致。4 fixture試験合格。現行tool比較は未完了 |
| 27.012/legacy-dab-origin | [x] | 旧stroke fixtureの補間原点と実dab列を固定する | 27.012/legacy-brush-oracle | 初回stamp後last_coordsを設定した正しい旧tool初期化へ修正し初期harnessを保持。透明vfunc観測24dabと36全画素snapshotが同一、4fixture試験合格。現行stroke比較は後続gate |
| 27.012/native-tool-controller | [x] | Fillの実GTK入力・旧shortcut・自動描画と保存前flightを接続する | 27.009/native-paint-transaction | 25 native GTK/26unit focused sanitizer合格。実appの選択/paint/Undo/Redo/XCF保存を確認。未完入力を保持しSave/export/PDB/XCFはBUSY安全拒否。2K/512brush通常max32.640msを記録、完全有界補間・自動Save継続・pipe順序は未完了 |
| 27.010/bounded-interpolation | [x] | native補間とinput admissionを応答可能な単位へ分割する | 27.012/native-tool-controller | 180現行native scenario/8883recordが同期と5pause予算で4655000 bytes一致、旧Fill36snapshotを3mode完全一致。25core/26GTK通常・focused sanitizer合格。49999998300候補から1dab、1e9px入力を非展開で取消し。全準備/queue/pipe/Save境界は別gate |
| 27.010/owned-save-continuation | [ ] | pending paint後の保存継続を所有付きで実装する | 27.012/native-tool-controller | destination/progress/cancelを保持し未完strokeを破棄せず完了後に一回だけSave/exportを継続、reentryと画像closeも検証する |
| 27.012/owned-save-continuation | [x] | 受理済みpaintを失わずGUI Save/export/Save-and-closeを自動継続する | 27.009/native-start-preflight, 04.011/sanitizer-rtti-scope | Save13実GTK/34unit sanitizer、Fill26実GTK/30unit sanitizerと全build合格。immutable宛先・実dialog cancel/destruction・再入/owner寿命・nested COMMIT・保存再open/Undoを検証。低位/PDB BUSYは維持、実file書込同期と全paint latency/memory/pipeは別gate |
| 27.013 | [ ] | 範囲外回込みの試験を作る | 27.012 | 全体探索後の mask 適用との差を検出 |
| 27.013/gegl-render-regression | [ ] | 塗りつぶしブラシの探索・paint 合成・GEGL 表示の比較試験を作る | 27.013, 27.007/paintcore-gegl-compose | 旧筆跡の画素と画面を比較し offset・縮小・回転・grow・Undo と再描画を検証 |
| 27.014 | [ ] | 選択外回込みの試験を作る | 27.013 | 探索境界の意味を検証 |
| 27.015 | [ ] | 半透明と小レイヤーを試験する | 27.014 | offset・境界・alpha が旧版と一致 |

### 28 レイヤープリセットと複合構造

主対象：presets、アニメ塗り、水彩

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 28.001 | [ ] | preset JSON の全件 schema を抽出する | 12.016, 13.014, 14.020, 15.014, 16.023 | キー・型・既定値・参照規則を記録 |
| 28.001/native-presets | [x] | 全同梱preset・資源/実適用・Undo・GTK導線を接続する | 14.015/reference-undo-snapshot, 15.008/opaque-definition-state, 12.001/preservation-writer, 27.009/native-paint-transaction | 8実旧construction完全一致、11 native/ASan・UBSan core、2実GTK/同sanitizer合格。未知JSON独立copy・原source順序・単一Undo・既存history保持rollback・編集可能XCF・factory/prefs/action-cache寿命を検証。最終name/parent修正後はcore再試験、GTK証跡は直前版。全platform/実install gateは別 |
| 28.002 | [ ] | JSON 資源 model を移植する | 28.001 | 未知項目を保持 |
| 28.003 | [ ] | preset factory を移植する | 28.002 | 検索パス・読込み・選択を接続 |
| 28.004 | [ ] | 通常 layer の生成を実装する | 28.003 | 属性と順序を定義どおり作る |
| 28.005 | [ ] | group の生成を実装する | 28.004 | 親子関係と内部順序を再現 |
| 28.006 | [ ] | CloneLayer の生成を接続する | 28.005 | 定義中の source を旧規則で解決 |
| 28.007 | [ ] | FilterLayer の生成を接続する | 28.006 | procedure と引数を解決 |
| 28.008 | [ ] | mode と opacity の適用を接続する | 28.007 | 旧数値を正しく変換 |
| 28.009 | [ ] | preset 適用の Undo を実装する | 28.008 | 構成全体を一操作で取消し |
| 28.010 | [ ] | preset 適用失敗の rollback を実装する | 28.009 | 中途半端な構成を残さない |
| 28.011 | [ ] | アニメ塗り preset を検証する | 28.010 | clone・dst-in・shadow・group が一致 |
| 28.012 | [ ] | 水彩 preset を検証する | 28.011 | edge filter・difference・opacity・group が一致 |
| 28.013 | [ ] | その他同梱 preset を検証する | 28.012 | 全定義に生成結果 fixture がある |
| 28.014 | [ ] | preset 選択 UI を接続する | 28.013 | 旧導線から適用可能 |
| 28.014/applier-owner | [ ] | preset 適用オブジェクトの寿命を修正する | 28.014, 01.007/cpp-ownership | C++ の適用インスタンスを GObject として解放せず、選択・起動・tile view の各経路で一回だけ delete し、失敗時も残存しない |
| 28.014/preset-preferences | [ ] | preset 設定ページ入口を移植する | 28.013, 04.004 | C 側でページを構築し返却 GArray を処理後に参照解放する |
| 28.014/preset-dialog-actions | [ ] | preset ダイアログアクションを移植する | 28.013, 04.004 | エントリが NULL の場合に参照せず、空配列も安全に登録する |
| 28.014/preset-action-group | [ ] | preset action-group 登録 callback を移植する | 28.013, 04.004, 01.005/preset-action-factory-owner | entry/update の C ABI と登録者の寿命・解除、現行 get_group/delete_group のキャッシュと初期化順を確認する |
| 28.015 | [ ] | preset 生成後の保存を試験する | 28.014 | 再読込して source 編集・filter 再評価が可能 |

### 29 キャンバス UI と tile view

主対象：display overlay、layer/tool/color UI

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 29.001 | [ ] | overlay の配置 model を移植する | 08.020, 14.020, 15.014, 24.017 | 画像表示と独立して位置を保持 |
| 29.001/preview-idle-lifetime-contract | [ ] | layer preview idle の捕捉寿命を定義する | 29.001, 01.005/deferred-sources | preview と viewable の所有・破棄順、再予約時の旧 source 解除を明記 |
| 29.001/native-canvas-tiles | [x] | 実canvas overlay・layer/tool tiles・色とnative optionsを接続する | 30.001/layer-create-edit, 30.010/native-profile-migration, 24.017/native-editor-workflow | 実GTK19/52unit sanitizer19/HiDPI19合格。pointer選択/DND/Undo・Clone popup・黒赤描画・portraitを視認。alpha previewの上流bounds不具合を修正しRGBA/Gray pixel検査。full options共有は実装、旧compact toolbar/persist overlay/実tabletは未完了 |
| 29.002 | [ ] | layer tile の表示を移植する | 29.001 | 名前・preview・選択状態が一致 |
| 29.002/add-timeout-owner | [ ] | layer tile の長押し timeout を安全に終了する | 29.002, 06.019, 01.007/cpp-ownership | callback 実行中に自身の handler を破棄せず、押下・移動・離上・widget 破棄の各順序で popup が重複せず source を解除する |
| 29.003 | [ ] | layer tile の可視切替を実装する | 29.002 | 状態と projection が同期 |
| 29.004 | [ ] | layer tile の順序操作を実装する | 29.003 | group と独自参照の更新を通知 |
| 29.005 | [ ] | layer tile の複数選択を接続する | 29.004 | 現行選択 model と整合 |
| 29.006 | [ ] | layer tile の popup を接続する | 29.005 | 独自型設定へ到達可能 |
| 29.006/proc-args-owner | [ ] | layer popup の filter 引数を深くコピーする | 29.006, 15.001/gvalue-deep-copy, 01.007/cpp-ownership | PDB 既定値を GValue ごとに複写し、元配列と編集配列を個別に解放する。文字列・object・数値の編集、filter 切替、閉鎖を反復試験する |
| 29.006/cellrenderer-gtk3 | [ ] | popup 用 cell renderer を GTK 3 描画 ABI へ移す | 29.006, 01.005/gimp3-external-binders | activate/get_size の const GdkRectangle と render の Cairo コンテキスト・領域引数を守り、描画とクリックを確認 |
| 29.006/popover-class-signals | [ ] | popup 独自型の cancel/confirm class slot を再定義する | 29.006, 01.005/gimp3-external-binders | GTK 3 の window 子型で class closure・キー割当と終了時の接続解除を確認 |
| 29.006/menu-borrowed-reference | [ ] | layer popup の menu 参照の所有権を確定する | 29.006, 01.007/ref-hold | UI manager の menu 取得が借用か確認し、保持 wrapper と破棄順を修正・検証する |
| 29.006/popover-handler-teardown | [ ] | popup の signal と view callback を終了時に解除する | 29.005, 06.017, 01.005/indirect-callback-owners | widget・popup を先に破棄しても借用中の owner を参照せず、scroll/button/confirm/cancel の接続が解除される |
| 29.007 | [ ] | color UI を移植する | 29.006 | 前景・背景色が context と同期 |
| 29.007/palette-popup-teardown | [ ] | 色パレット popup の借用 editor を終了時に切り離す | 29.007, 01.008 | popup を保持したまま editor を破棄する経路を閉じ、context 解除前に通知を外す。選択・確定・editor 先行破棄を反復試験する |
| 29.008 | [ ] | tool tile の表示を移植する | 29.007 | tool manager の現在選択と同期 |
| 29.008/icon-null | [ ] | tile icon 生成失敗時の NULL 経路を処理する | 29.002, 29.008, 01.007/cpp-ownership | layer/tool 両 tile の icon 未登録・render 失敗時に NULL を unref せず、代替表示を確認 |
| 29.009 | [ ] | tool group を接続する | 29.008 | 旧分類と現行 action の対応が明確 |
| 29.010/toolbar-ref-balance | [ ] | toolbar の再表示と終了時の参照数を修正する | 29.010, 01.007/toolbar-ref | hide 時の余剰参照をなくし、移動・反復表示・破棄を検証する |
| 29.010/native-compact-runtime | [x] | 一つのnative ToolOptions GUIを可逆な横型・縦型popoversへ接続する | 29.001/native-canvas-tiles, 30.010/native-profile-migration | 50登録GUI/2868widgetのidentity・親順序・packing復元、12family/12破棄loop、native編集を通常8/sanitizer8/scale2 8＋実demo確認。旧Painter暗黙Canvas表示をprovenance付き移行し設定保存。後続geometry/HTTP/XCFを含むaggregateは別gate |
| 29.010 | [ ] | 操作バーを移植する | 29.009 | 旧 action を呼び UI 状態を反映 |
| 29.010/standard-tool-options | [ ] | 標準ツールの横型・コンパクト操作部品を保持して共有化する | 29.009, 01.013 | hunk台帳の各tool/optionsごとに旧control・値・通知・popupを対応し、縦横配置・再表示・ツール切替を試験する |
| 29.011 | [ ] | 縦長配置を移植する | 29.010 | 部品の機能を削らず再配置 |
| 29.012 | [ ] | UI 退避を実装する | 29.011 | 描画時の表示切替が一致 |
| 29.013 | [ ] | 入力透過を実装する | 29.012 | 透明表示と hit test を分ける |
| 29.014 | [ ] | pen up 時の復帰を実装する | 29.013 | UI 退避状態が残らない |
| 29.015 | [ ] | popup 終了時の復帰を実装する | 29.014 | focus・pointer・選択が戻る |
| 29.016 | [ ] | 画像切替時の再接続を実装する | 29.015 | 旧画像 signal を解除 |
| 29.017 | [ ] | HiDPI の座標を接続する | 29.016 | 表示倍率と入力領域が一致 |
| 29.018 | [ ] | keyboard 操作を接続する | 29.017 | focus と shortcut が描画を妨げない |
| 29.019 | [ ] | widget destroy を close へ接続する | 29.018 | behavior の遅延通知が残らない |
| 29.019/preview-idle-owner | [ ] | preview idle の viewable 寿命を保証する | 29.018, 29.001/preview-idle-lifetime-contract | viewable を保持または弱参照で検査し、破棄済み preview・viewable へのアクセスを抑止 |
| 29.020 | [ ] | UI の操作試験を実行する | 29.019 | ペン・マウス・複数画像・popup の状態復帰を確認 |
| 29.020/preview-idle-teardown | [ ] | preview の再予約・破棄試験を実行する | 29.019/preview-idle-owner, 29.019 | idle 待機中に viewable と widget を破棄して source 解除と描画停止を確認 |

### 30 actions・設定・資源配布の統合

主対象：登録、メニュー、gimprc、PDB、データ設置

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 30.001 | [ ] | 追加 actions の登録を統合する | 24.017, 25.012, 26.014, 27.015, 28.015, 29.020 | 重複 ID と未登録 command がない |
| 30.001/layer-create-edit | [x] | Clone/Filter作成・編集を実GTK actions/menuへ接続する | 14.015/reference-undo-snapshot, 17.001/dependency-publication | 16 native GTK通常/focused sanitizer合格、複製参照/定義Undo・未知bytes表示保持・dialog/child寿命再入を確認。実appでbrush→Clone→Filter/Undo/Redoを視認。全popup/device/platformは未完了 |
| 30.001/isolated-filter-editors | [x] | Blinds/Small Tiles/Retinex/Convolutionの作成・再編集をnative GTKへ接続する | 30.001/layer-create-edit, 16.003/isolated-convolution-route | 実GTK35群＋最終境界2群を通常/7unit ASan・UBSanで合格（36unique、51 RTTI-only）。typed値・signed flags・配列・未知値・ignored tail保持、Undo/再入/実行中cache/Save再編集を確認。実app完走は報告済み、raw log消失・GTK/GDK診断原因未検証。全popup/platformは別gate |
| 30.001/parameter-schema-editor | [x] | 既存lossless editorをschema keyと有界metadata取得へ接続する | 16.010/parameter-semantic-policy, 30.001/isolated-filter-editors, 15.006/native-owner-progress | trusted既登録metadataをquery/IPC無しで有界取得。共通BindingStoreでprovider寿命・変更を管理し、immutable差分編集でraw/bits/弱参照/巨大tailを保持。native GTK53組通常/ASan・UBSan、core31組、既存XCF14組、実GLib2.70 headersで変更6単位compileを受入。追加予算と実測・既知GTK/Undo制限はfilter-parameter-editor契約と証跡に明記。D/Eは未完 |
| 30.001/native-dialog-diagnostics | [x] | 実editor/Quitの2assertionをstackと独立GTK対照で分類する | 15.006/native-owner-progress | 同一binaryのAT-SPI操作で2組再現、bounded stackとGTK単独controlでDebian grabのNULL window・upstream ancestor型不一致を確認。既知欠陥mode0/fixed要求mode1、通常Retinex作成/編集/進捗取消し・Quit Cancel・新規XCF保存/正常終了0。依存欠陥と別device16criticalは未修正、全GTK clean/旧log全件同一原因とはしない |
| 30.001/tool-group-state | [ ] | 上流tool groupへ旧展開・選択・保存状態を接続する | 30.001, 01.012 | 旧expanded state、active-tool、toolrc順序とgroup変更を個別に比較し、上流モデルで失う状態は移行する |
| 30.002 | [ ] | 旧 shortcut の対応を実装する | 30.001 | 回転等の旧操作を復元可能 |
| 30.003 | [ ] | 独自 tool の icon を登録する | 30.002 | テーマと scale に応じ表示 |
| 30.004 | [ ] | 独自 tool の表示順を登録する | 30.003 | tool palette から利用可能 |
| 30.005 | [ ] | 追加 dock/dialog の登録を統合する | 30.004 | 再起動後に復元可能 |
| 30.005/shell-reparent-ref | [ ] | display shell の移動時参照を対称にする | 30.005, 01.007/c-state | 空 display 分岐の一時参照を解放し、通常の移動・閉鎖を反復して shell を破棄できる |
| 30.006 | [ ] | 独自設定の gimprc serialization を実装する | 30.005 | 型・既定値・旧キー変換が一致 |
| 30.007 | [ ] | context の独自値を接続する | 30.006 | tool 切替と画像切替で正しい設定 |
| 30.007/device-name-identity | [ ] | 入力deviceのunique-nameと保存状態を照合して移植する | 30.006, 01.016 | 同名の複数device・再接続・設定再読込みで旧unique-names変更の意味を保持し、別deviceの筆圧設定とcontextを混同しない |
| 30.008 | [ ] | 旧 tool preset の移行を実装する | 30.007 | 独自ブラシと紙目設定を保持 |
| 30.008/tool-options-delete-result | [ ] | 旧tool options削除の成否判定を修正して移植する | 30.007, 01.013 | g_unlinkの反転した条件を持ち込まず、削除成功・ENOENT・権限等の失敗を区別し設定と通知を検証する |
| 30.009 | [ ] | 新規ユーザーの資源初期化を接続する | 30.008 | 同梱ブラシ・紙目・preset が使用可能 |
| 30.010 | [ ] | 既存ユーザーの資源移行を実装する | 30.009 | ユーザー編集済み資源を上書きしない |
| 30.010/native-profile-migration | [x] | Painter由来の旧設定を実first-runと登録済みtool/deviceへ移す | 21.001/registered-tool, 23.005/native-smudge-tool, 04.003 | 実旧writer53file+6seedを区別しparser8/nativeGTK9が通常・focused sanitizer合格。原本SHA archive・編集済み非上書き・group/context/device/options/custom shortcut/Gradient filename再読込を検証。実hardware同名identity・crash recovery・全旧geometryは未完了 |
| 30.011 | [ ] | 資源検索パスを接続する | 30.010 | install prefix と user path の双方を解決 |
| 30.012 | [ ] | 追加 PDB 手順を現行形式へ登録する | 30.011 | 引数と戻り値が現行 caller から使える |
| 30.012/scheme-mode-constants | [ ] | Script-Fuの旧独自合成定数を現行APIへ対応する | 30.011, 01.015 | ERASE・REPLACE・ANTI-ERASE・SRC/DST IN/OUTの名前を保持し、衝突する旧数値を現行modeへ明示変換して呼出しと合成を試験する |
| 30.013 | [ ] | 生成された PDB コードを更新する | 30.012 | 生成元と成果物に乖離がない |
| 30.013/public-mode-identity | [x] | 非公開enum slotによるlibgimp Painter mode値のずれを修正する | 10.005/native-paint-mode-route, 04.003 | 実generator出力63–71がapp64–72と不一致な9件を記録しfirst=64で修正。上流65値不変・公開72名一致をC11/C++14四probe・実libgimp GEnumClass・登録Meson検査で確認。全PDB/Script-Fu transportは別gate |
| 30.014 | [ ] | 追加 UI 文字列を翻訳対象へ登録する | 30.013 | 日本語・英語で未表示や欠落がない |
| 30.015 | [ ] | ヘルプ ID と操作説明を接続する | 30.014 | 独自設定の意味を参照できる |
| 30.016 | [ ] | 起動・終了順を統合する | 30.015 | 資源と UI の終了で stale callback がない |
| 30.016/feature-entry-point | [ ] | 旧 features_entry_point の起動時登録を現行初期化へ接続する | 04.018, 28.003 | GUI/console と HTTPD 条件分岐、Gimp 所有者、initialize/restore/exit の接続と解除を検証 |
| 30.017 | [ ] | インストール資産の一覧を生成する | 30.016 | 必要ファイルの欠落を検出できる |
| 30.017/brush-manifest-generator | [ ] | Ruby版ブラシmanifest生成をMeson資源台帳へ置き換える | 30.016, 01.015 | Makefile.am.skelのmyb・preview列挙とsortを保持し、全同梱資産・root未対preview・noticeの欠落を検査する |
| 30.017/brush-preview-generator | [ ] | ImageMagickの旧ブラシpreviewラベル生成を維持する | 30.016, 01.015 | label-brush-mypaint.shのcaption・border・resizeと上書き対象を保持し、空白等のfilename・画素出力・manifest一致を試験する。GIMP batch依存と混同しない |

### 31 周辺機能と重複実装の整理

主対象：HTTP/REST、placeholder、旧補助コード

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 31.001/optional-http-runtime | [x] | optional HTTP/RESTの全endpoint・native PDB/画像/案内UIを接続する | 01.017, 30.001/layer-create-edit, 30.013/public-mode-identity | source/caller台帳、17native+6GTK通常/19unit sanitizer＋38 RTTI-only合格。disabled実buildでSoup照会/依存/起動symbolゼロ、描画10/XCF20/Canvas19合格。認証loopback/明示webhook設定と旧ordinal境界を保持・安全変更明記。外部client/platform/aggregateは別gate |
| 31.001 | [ ] | HTTP の全 endpoint を列挙する | 01.017, 30.017 | 利用側・入力・副作用・返値を記録 |
| 31.002 | [ ] | HTTP 利用元を照合する | 31.001 | 既存 UI や資産からの隠れた依存を検出 |
| 31.003 | [ ] | HTTP の任意ビルド境界を実装する | 31.002 | core 機能に必須依存を作らない |
| 31.004 | [ ] | HTTP を現行依存へ適合する | 31.003 | 採用 libsoup 等でビルドできる |
| 31.005 | [ ] | 画像 tree endpoint を移植する | 31.004 | 独自型・階層を返せる |
| 31.006 | [ ] | PDB endpoint を移植する | 31.005 | 現行引数型へ対応 |
| 31.007 | [ ] | HTTP の main-context 転送を実装する | 31.006 | 通信 callback が直接 UI を操作しない |
| 31.008 | [ ] | HTTP の終了処理を接続する | 31.007 | request と image 終了の競合、派生 RESTResource の破棄、callback context の全経路解放を処理 |
| 31.008/router-lifetime | [ ] | HTTP router の規則派生型を安全に破棄する | 31.008, 01.007/router-tree | 基底型経由の削除で派生メンバーを解放し、route と handler を一度だけ破棄する |
| 31.009 | [ ] | HTTP 無効ビルドを試験する | 31.008 | 保存・描画・UI の必須機能が動く |
| 31.010 | [ ] | HTTP 有効ビルドを試験する | 31.009 | 列挙した endpoint の契約を満たす |
| 31.011 | [ ] | ImageGenerator placeholder の依存を確認する | 31.010 | 保存された実機能を削除しない根拠を記録 |
| 31.012 | [ ] | placeholder の登録を除去する | 31.011 | 空の tool/action を配布しない |
| 31.013 | [ ] | 重複 editor 実装を除去する | 31.012 | 共通 model と部品への接続が残る |
| 31.014 | [ ] | 旧 glib-cxx interface 利用を除去する | 31.013 | 新ハンドル以外の利用入口がゼロ |
| 31.015 | [ ] | 旧 private Impl 配置を除去する | 31.014 | NewGClass placement new と二重所有がゼロ |
| 31.016/typed-provenance-store | [x] | XCF由来値の自由なdata keyを型付き共通store所有へ統合する | 04.002/foundation-acceptance-matrix, 12.015/native-recovery-save | 固定型childの単一slot、既存private C参照のみでpublic ABI不変・active store再登録なし。copy白名簿/不変record snapshot/close/最終ref/finalize再入を含む42通常・25unit sanitizer＋36 RTTI-only合格。dialog/全source-familyと全保存fieldは別gate |
| 31.016/dialog-common-store | [x] | Clone/Filter dialog所有をtyped storeと弱callbackへ統合する | 31.016/typed-provenance-store, 30.001/layer-create-edit | 旧16case維持、close/retained child/最終owner/factory input lease/orphan防止を含む21実GTK通常・7unit sanitizer＋42 RTTI-only合格。原C facadeと保存引数/Undo経路不変、自由key削除。全source-family parent依存は別gate |
| 31.016 | [ ] | 自由な qdata 付加を除去する | 31.015 | 共通 store 以外の独自状態登録がゼロ |
| 31.017 | [ ] | 旧 TileManager/PixelRegion 依存を除去する | 31.016 | 移植対象に旧画素基盤への依存がない |
| 31.018 | [ ] | 空ファイルとバックアップを除去する | 31.017 | ビルド対象と実装参照が残っていない |
| 31.019 | [ ] | Rust 非導入の初期構成を固定する | 31.018 | この移植の完了条件に Rust 試作を追加しない |
| 31.020 | [ ] | 整理後の差分を監査する | 31.019 | 機能削除で保存資産と制作操作を失っていない |

### 32 Windows 対応

主対象：Windows x86_64、将来 arm64 は別判定

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 32.001 | [ ] | Windows toolchain を固定する | 04.019, 06.029, 30.017 | compiler・runtime・依存の互換組合せを記録 |
| 32.002 | [ ] | Windows Meson 構成を作る | 32.001 | C/C++ compiler と pkg-config path が整合 |
| 32.003 | [ ] | UNIX 固有 header を除去または分岐する | 32.002 | execinfo 等が unconditional include されない |
| 32.004 | [ ] | symbol export/import を適合する | 32.003 | C callback と独自型を解決 |
| 32.005 | [ ] | C++ runtime の配布を接続する | 32.004 | clean 環境で不足 DLL がない |
| 32.006 | [ ] | UTF-8 と native path の境界を適合する | 32.005 | 日本語の作品・資源パスを扱える |
| 32.007 | [ ] | 一時ファイルと process 終了を適合する | 32.006 | 実行器の取消し・crash 処理が動く |
| 32.008 | [ ] | Windows release build を作る | 32.007 | 全独自機能がリンク |
| 32.009 | [ ] | Windows pen 入力を試験する | 32.008 | 筆圧・傾き・固定位置入力・回転 modifier を確認 |
| 32.010 | [ ] | Windows 保存往復を試験する | 32.009 | 旧 XCF と資源を開き再保存可能 |
| 32.011 | [ ] | Windows FilterLayer を試験する | 32.010 | cancel・画像終了で UI を止めない |
| 32.012 | [ ] | Windows package を作る | 32.011 | 同梱資源と runtime を含む |
| 32.013 | [ ] | Windows arm64 の追加対応条件を記録する | 32.012 | 未試験を対応済みにせず依存・toolchain の追加タスクを定義 |

### 33 macOS 対応

主対象：arm64、x86_64、universal 配布

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 33.001 | [ ] | macOS toolchain を固定する | 04.019, 06.029, 30.017 | SDK・deployment target・compiler を記録 |
| 33.002 | [ ] | arm64 依存を構成する | 33.001 | 依存 library が対象 architecture と一致 |
| 33.003 | [ ] | x86_64 依存を構成する | 33.002 | 同じ機能集合をビルド可能 |
| 33.004 | [ ] | macOS lifecycle を適合する | 33.003 | main loop・window 終了・callback が整合 |
| 33.005 | [ ] | bundle 内の資源 path を接続する | 33.004 | 相対配置でブラシ・preset を取得 |
| 33.006 | [ ] | dylib の参照 path を修正する | 33.005 | 実行環境の build path を参照しない |
| 33.007 | [ ] | arm64 release build を作る | 33.006 | 全独自機能がリンク |
| 33.008 | [ ] | x86_64 release build を作る | 33.007 | 全独自機能がリンク |
| 33.009 | [ ] | universal bundle を構成する | 33.008 | 両 architecture の実行体と依存を含む |
| 33.010 | [ ] | macOS 入力を試験する | 33.009 | modifier・pen・HiDPI の座標が一致 |
| 33.011 | [ ] | macOS 保存往復を試験する | 33.010 | 旧 XCF と資源が両 architecture で往復 |
| 33.012 | [ ] | macOS FilterLayer を試験する | 33.011 | 起動・取消し・終了が非待機 |
| 33.013 | [ ] | 署名・notarization の構成を用意する | 33.012 | 資格情報がない場合も署名前 package と必要手順まで作成 |

### 34 Linux 配布と共通 CI

主対象：Linux package と継続ビルド

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 34.001 | [ ] | Linux release build を作る | 07.017, 30.017 | debug 専用の依存なしで動く |
| 34.002 | [ ] | Linux install manifest を検証する | 34.001 | 資源・plugin・locale が揃う |
| 34.003 | [ ] | X11 入力を試験する | 34.002 | ペン・popup・回転が動く |
| 34.003/gtk-atk-menu-guards | [ ] | 未表示menuのAT-SPI操作で起きるGTK依存の型guardを修正する | 30.001/native-dialog-diagnostics | Debian offscreen grabのNULL GdkWindowとupstream accessible祖先の型検査を再現可能な依存patchとして適用し、fixed-mode0・offscreen/通常入力/AT-SPIを独立検証する。GTK3.24.52側も未修正、source/license/runtime hashも更新する |
| 34.003/dialog-device-diagnostics | [x] | New Filter初回表示のGimpDeviceInfo/GdkDevice criticalをstackから修正する | 30.001/native-dialog-diagnostics | 同一baselineの通常pointerで16criticalを再現しbounded stackで初回focus前のcurrent-device未初期化を確認。canvas境界guard、negative trap・実GTK lifecycle1+navigation4を通常/8C unit ASan・UBSanで合格、非計測実appの初回/再表示・Escape/Cancel/終了0でcritical0。GTK別2欠陥・tablet/hot-plug/Wayland/集約gateは未完了 |
| 34.004 | [ ] | Wayland 入力を試験する | 34.003 | 座標・focus・popup 復帰が動く |
| 34.005 | [ ] | clean 環境 package を作る | 34.004 | 作業ディレクトリ外から起動 |
| 34.005/runtime-prototype | [x] | Linuxの隔離・再配置runtime梱包と検証手順を実装する | 03.009, 04.002/common-foundation | 5255file/418ELF・177brush/8presetをseal、別日本語pathでversion/Save再読込と実GTK stroke保存再開、11helper安全検査合格。prototypeのみでfinal source/binary一致・配布source/license・release/platform gateは未完了 |
| 34.005/tested-freshness-gate | [x] | PHONY/restatと実変更を区別する梱包gateを検証する | 34.005/runtime-prototype | 全source/output/graph/command/install inputの集約前後sealを要求しNinja収束後も同一でなければstage前拒否。32fixtureと実失敗gate3改竄拒否合格。旧gateや104/4結果を合格へ変えず、実Gimp新集約/候補作成は未実行 |
| 34.005/installed-filter-smoke | [x] | 再配置runtimeで実Filter process・旧画素・Save再読込を検証する | 34.005/runtime-prototype, 16.003/isolated-blinds-route | fresh buildの5270file/419ELF runtimeを再配置、実helper/Blinds・4096²実旧byte・Save再読込と欠損2caseのFAILED/定義cache保持・無残留を確認。6native target・selector12通常/ASan/UBSan・35recipe・focused23source/11native合格。prototypeのみ、全aggregate/GUI/platform/release gateは未完了 |
| 34.005/license-manifest | [ ] | 実配布依存の版とlicense noticeを収集する | 34.005, 01.011 | 各OSの実リンク・同梱ライブラリーと資産を実source hashへ対応し、旧台帳の未取得noticeを解消してpackageへ添付する |
| 34.006 | [ ] | C/C++ compile CI を登録する | 34.005 | 主要 OS で全追加 module を検査 |
| 34.007 | [ ] | bridge 単体試験を CI に登録する | 34.006 | 寿命と例外の回帰を検知 |
| 34.008 | [ ] | XCF fixture 試験を CI に登録する | 34.007 | 標準・旧・新形式を検査 |
| 34.009 | [ ] | 描画入力 replay を CI に登録する | 34.008 | seed 固定で画素差を記録 |
| 34.010 | [ ] | FilterLayer trace 試験を CI に登録する | 34.009 | 順序・世代・終了を検査 |
| 34.011 | [ ] | sanitizer job を登録する | 34.010 | 対応環境で ASan/UBSan を実行 |
| 34.012 | [ ] | 独立 worker の競合検査を登録する | 34.011 | 対象を絞って TSan 等で競合を調べる |
| 34.013 | [ ] | 生成物の差分検査を登録する | 34.012 | enum/PDB 等の再生成漏れを検出 |
| 34.014 | [ ] | 資源 manifest の検査を登録する | 34.013 | 同梱ファイルの欠落と未登録を検出 |
| 34.015 | [ ] | ログと失敗 fixture を保存する | 34.014 | 再現に必要な入力と版が残る |
| 34.015/frozen-linux-aggregate | [ ] | commit固定の全Linux登録targetを一括検証する | 03.009, 34.005/runtime-prototype | 修正後996297f09f（公開13b795a27aと同一tree）を全buildし108全targetをserial実行、107 OK/1 FAIL/skip・timeoutゼロ。GUI3失敗は解消、3003具体output等の前後seal不変。既存Saveと12件Script-Fu診断を保持してgate false、最終clean集約は未完了 |
| 34.015/baseline-batch-repair | [x] | 基準由来のfile-loadとScript-Fu起動・終了障害を修正する | 03.009 | 復旧環境の16通常targetと6native+7Script-Fuの5C unit focused ASan/UBSanが診断込み合格。282source/header/scriptと879外部headerをseal。過去の失敗集約は維持し全aggregateは別gate |

### 35 GIMP 3.x の版間適合

主対象：初期3.0と後続3.xを混同しない

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 35.001 | [ ] | 内部 API 依存一覧を生成する | 04.019, 08.020, 30.017 | GimpLayer・PaintCore・projection・PDB・widgets の利用 symbol を記録 |
| 35.002 | [ ] | 初期 3.0 系列の差分を照合する | 35.001 | 固定基準と採用候補の API 変更を検出 |
| 35.003 | [ ] | 後続 3.x 系列の差分を照合する | 35.002 | 利用 API と ABI の変更を版別に記録 |
| 35.004 | [ ] | 版差吸収 adapter を分離する | 35.003 | 機能本体へ version 条件を散在させない |
| 35.005 | [ ] | 版検査を Meson に接続する | 35.004 | 未対応系列を誤って成功扱いしない |
| 35.006 | [ ] | 採用対象ごとのビルドを実行する | 35.005 | 対応表の各行に成功ログがある |
| 35.007 | [ ] | 採用対象ごとの fixture を実行する | 35.006 | XCF・clone・filter・brush の合格証跡がある |
| 35.008 | [ ] | 追従 patch の適用手順を作る | 35.007 | 競合解決と再試験対象を明示 |
| 35.009 | [ ] | 将来版の対応表を公開情報へ反映する | 35.008 | 未試験版を一括して全3.x対応と表示しない |

### 36 作品互換性と組合せ試験

主対象：実作品を開いて編集し再保存する受入れ

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 36.001 | [ ] | 旧通常 XCF 全 fixture を開く | 12.016, 13.014, 14.020, 18.018, 21.020, 22.010, 23.015, 24.017, 25.012, 26.014, 27.015, 28.015, 29.020, 30.017 | 画像・属性・編集可能性が一致 |
| 36.002 | [ ] | 旧独自 XCF 全 fixture を開く | 36.001 | 通常の開くで型と参照を復元 |
| 36.003 | [ ] | 属性番号衝突の試験を実行する | 36.002 | 標準32/33を独自属性と誤認しない |
| 36.004 | [ ] | モード番号衝突の試験を実行する | 36.003 | 標準と旧の23〜29を区別 |
| 36.005 | [ ] | 旧 writer 不整合の試験を実行する | 36.004 | 旧版で可読な INT16・文字列を読める |
| 36.006 | [ ] | 通常属性の全項目往復を実行する | 36.005 | 台帳の全保存項目に合格結果がある |
| 36.007 | [ ] | 同名・未解決 source を試験する | 36.006 | 情報保持と旧参照解決を満たす |
| 36.008 | [ ] | CloneLayer と FilterLayer の組合せを試験する | 36.007 | 依存・座標・cache が収束 |
| 36.009 | [ ] | アニメ塗り作品を再編集する | 36.008 | source 描画後の構造と合成が一致 |
| 36.010 | [ ] | 水彩作品を再編集する | 36.009 | 下層編集後の自動更新が一致 |
| 36.011 | [ ] | mask と group を組み合わせて試験する | 36.010 | 可視・順序・opacity の意味が維持 |
| 36.012 | [ ] | 移動・crop・resize を試験する | 36.011 | 独自型の座標と参照が整合 |
| 36.013 | [ ] | 色形式と精度の変更を試験する | 36.012 | 独自型と brush buffer が破綻しない |
| 36.014 | [ ] | 全同梱ブラシを読み描画する | 36.013 | 177件が読み込め代表 stroke を実行 |
| 36.015 | [ ] | ブラシの編集後保存を試験する | 36.014 | 独自値と未知値を保持 |
| 36.016 | [ ] | 定規・補正・MyPaint の併用を試験する | 36.015 | 入力順序と状態が整合 |
| 36.017 | [ ] | 塗りつぶし・選択・Undo を試験する | 36.016 | 境界外経由の誤探索がない |
| 36.018 | [ ] | 長時間描画を試験する | 36.017 | メモリーと接続数が単調増加しない |
| 36.019 | [ ] | 複数画像の切替を試験する | 36.018 | tool・resource・preview の状態が漏れない |
| 36.020 | [ ] | 処理中の autosave と復旧を試験する | 36.019 | 作品を開き直して再評価可能 |
| 36.021 | [ ] | 破損・切断ファイルを試験する | 36.020 | crash・越境読取り・元作品破損がない |
| 36.022 | [ ] | 欠落資源と欠落 procedure を試験する | 36.021 | 開くことと元情報保持を維持 |
| 36.023 | [ ] | UI と CLI/batch の読込みを試験する | 36.022 | 通常経路以外でも保存構造を失わない |
| 36.024 | [ ] | 他 OS で保存した作品を開く | 36.023 | encoding・数値・参照が相互互換 |
| 36.025 | [ ] | XCF parser の境界入力を自動生成する | 36.024 | 長さ・offset・型不整合で crash と情報破損を検出 |
| 36.026 | [ ] | myb/JSON parser の境界入力を自動生成する | 36.025 | 不正な数値・文字列・配列で安全に失敗 |
| 36.027 | [ ] | 旧版で保存し開ける組合せを追加採取する | 36.026 | 差分台帳の未カバー保存経路ごとに fixture を補充 |

### 37 性能・安全な終了・数値差の仕上げ

主対象：性能予算、memory、numeric、cleanup

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 37.001 | [ ] | 性能計測の比較条件を固定する | 32.013, 33.013, 34.015, 36.027 | 同作品・入力・hardware・build option を記録 |
| 37.002 | [ ] | 筆跡の入力遅延を計測する | 37.001 | 代表ブラシの p95/p99 が基準内 |
| 37.003 | [ ] | preview 更新遅延を計測する | 37.002 | 設定操作を阻害しない |
| 37.004 | [ ] | XCF 読込み時間を計測する | 37.003 | 形式 probe の重複全読込みを抑える |
| 37.005 | [ ] | 保存時 peak memory を計測する | 37.004 | snapshot の不要複製を特定 |
| 37.006 | [ ] | FilterLayer peak memory を計測する | 37.005 | 連続更新で古い job が無制限に増えない |
| 37.007 | [ ] | worker 数と queue 上限を調整する | 37.006 | 飢餓と無制限蓄積がない |
| 37.008 | [ ] | 数値差を分類する | 37.007 | 旧仕様違反と許容する高精度差を明示 |
| 37.009 | [ ] | 互換性に影響する数値差を修正する | 37.008 | 旧 fixture の合格範囲を満たす |
| 37.010 | [ ] | 入力準備の占有超過を修正する | 37.009 | 18で固定した時間予算を満たす |
| 37.011 | [ ] | 結果反映の占有超過を修正する | 37.010 | 18で固定した時間予算を満たす |
| 37.012 | [ ] | 終了時の残存 source を除去する | 37.011 | object・connection・job の残数が基準へ戻る |
| 37.013 | [ ] | 例外と process crash 後の回復を検証する | 37.012 | 通常操作へ戻り定義を保持 |
| 37.014 | [ ] | 性能レポートを作る | 37.013 | 基準と測定値と残る制約を記録 |

### 38 差分の全件閉鎖と配布判定

主対象：未割当と未試験をゼロにする gate

| ID | 完了 | 作業 | 依存ID | 完了条件・証跡 |
|---|:---:|---|---|---|
| 38.001 | [ ] | 変更 hunk の割当を再集計する | 31.020, 35.009, 37.014 | 01の台帳に未処置差分がない |
| 38.002 | [ ] | 保存項目の対応を再集計する | 38.001 | 全項目に reader・writer・試験を対応 |
| 38.003 | [ ] | 独自型の対応を再集計する | 38.002 | 全型に登録・所有・終了・保存方針を対応 |
| 38.004 | [ ] | C++ 境界の旧 API を検索する | 38.003 | 移行 adapter の残存がない |
| 38.004/all-vfunc-exception-containment | [ ] | 全 vfunc callback の C ABI 例外封じ込めを実装・試験する | 05.013, 01.005/gimp3-vfunc-contract | Binder 71 件と class callback 40 件の実装に例外方針を適用し、初期化・描画・保存・終了の失敗が C を越えない |
| 38.005 | [ ] | 資源の全件対応を再集計する | 38.004 | 全配布資産に利用先か除外根拠がある |
| 38.006 | [ ] | 機能36項目の完了を監査する | 38.005 | 末尾追跡表の各項目に実装・検証証跡がある |
| 38.007 | [ ] | 未解決 P0 を監査する | 38.006 | 旧作品不可・情報損失・clone差異・filter停止を残さない |
| 38.008 | [ ] | 未解決 P1 を監査する | 38.007 | 制作操作の欠落を残さない |
| 38.009 | [ ] | 新規発見タスクを閉鎖する | 38.008 | 台帳から生成した全子タスクに処置と証跡がある |
| 38.010 | [ ] | 配布 license と notice を整える | 38.009 | 追加依存と同梱資産の条件を満たす |
| 38.011 | [ ] | 利用者向け移行説明を書く | 38.010 | 旧ファイルを普通に開く手順と対応範囲を記載 |
| 38.012 | [ ] | 開発者向け C++ 接続説明を書く | 38.011 | ハンドル・slot・close・vfunc・試験追加方法を記載 |
| 38.013 | [ ] | 障害再現用情報の採取手順を書く | 38.012 | 作品・入力・trace・版を収集できる |
| 38.014 | [ ] | release 候補 package を生成する | 38.013 | 全対象 OS の成果物と hash がある |
| 38.015 | [ ] | clean install の最終試験を行う | 38.014 | 起動・旧作品・描画・保存・終了が成功 |
| 38.016 | [ ] | 配布判定レポートを作る | 38.015 | 対応版・合格 gate・未対応範囲を明示 |
| 38.017 | [ ] | release tag と変更一覧を準備する | 38.016 | 配布物からソース commit を追跡可能 |

## 5. 機能36項目の追跡表

区分番号は第4節の末端タスク一式を指す。実行時には対象別子IDと試験結果のリンクをこの表へ追記する。

| No. | 優先度 | 機能 | 実装・検証区分 |
|---:|---|---|---|
| 1 | P0 | 旧 XCF の識別と読込み | 10, 11, 36 |
| 2 | P0 | 保存情報の往復 | 10, 12, 36 |
| 3 | P0 | CloneLayer | 14, 36 |
| 4 | P0 | CloneLayer の参照保存 | 10, 12, 14, 36 |
| 5 | P0 | FilterLayer のデータモデル | 15, 12, 36 |
| 6 | P0 | FilterLayer の実行制御 | 17, 18 |
| 7 | P0 | FilterLayer の処理実行 | 16, 18 |
| 8 | P0 | 独自合成モード | 13, 36 |
| 9 | P0 | 複合レイヤー構造 | 28, 36 |
| 10 | P0 | アニメ塗り構成 | 28, 36 |
| 11 | P0 | 水彩構成 | 28, 36 |
| 12 | P0 | その他の XCF 情報 | 10, 11, 12, 36 |
| 13 | P0 | 拡張 MyPaint エンジン | 20, 21, 36 |
| 14 | P0 | GIMP ブラシ形状 | 21, 36 |
| 15 | P0 | 紙目・テクスチャ | 22, 36 |
| 16 | P0 | 動的紙目パラメーター | 20, 22, 36 |
| 17 | P0 | MyPaint 内の拡張 Smudge | 21, 36 |
| 18 | P0 | 非累積描画 | 21, 36 |
| 19 | P0 | ストローク不透明度 | 20, 21, 36 |
| 20 | P0 | 拡張ブラシ保存・詳細編集 | 19, 24, 36 |
| 21 | P0 | ブラシ履歴・プレビュー | 24, 36 |
| 22 | P0 | レイヤープリセット資産 | 28, 36 |
| 23 | P1 | 独立 Smudge の色混合拡張 | 23, 36 |
| 24 | P1 | 手ぶれ補正 | 23, 26, 36 |
| 25 | P1 | 微小移動時の筆圧 | 23, 36 |
| 26 | P1 | 回転・反転 | 25, 36 |
| 27 | P1 | 回転スナップ | 25, 36 |
| 28 | P1 | パース定規 | 26, 36 |
| 29 | P1 | 塗りつぶしブラシ | 27, 36 |
| 30 | P1 | 選択境界を使う塗りつぶし | 27, 36 |
| 31 | P1 | キャンバス UI | 29, 36 |
| 32 | P1 | ツールグループ・操作バー | 29, 30, 36 |
| 33 | P2 | editor／横型 GUI の重複 | 24, 31 |
| 34 | P2 | HTTP／REST 連携 | 31 |
| 35 | P2 | ImageGenerator placeholder | 31 |
| 36 | P2 | 旧基盤・補助コード | 04, 06, 08, 09, 31 |

## 6. C++ ブリッジ12種類の追跡表

| 旧機構 | 移植・検証区分 | 最終状態 |
|---|---|---|
| Traits・型宣言・cast | 01, 05, 06, 07, 08 | 型付きハンドルと GType 検査へ統一 |
| NewGClass・private Impl | 05, 06, 08, 31 | 型登録 adapter と BindingStore に分離 |
| Binder・GInterface | 04, 06, 07, 08 | 正しい C signature の trampoline |
| C/C++ 二重入口 | 05, 08, 31 | C++ は名前付きメソッド、C 入口を共有 |
| ref の関数添字 | 05, 06, 08, 31 | ハンドルのメソッドへ置換 |
| Object・IObject・ScopeGuard | 05, 06, 07 | 明示した参照所有と短期借用 |
| property・GValue | 06, 07, 08, 16 | 型・notify・値所有を保持 |
| Delegator・Connection | 06, 07, 17, 29 | 共通接続管理と close |
| data/qdata 状態付加 | 05, 06, 08, 31 | 一 store・型付き slot に統一 |
| GTK DSL | 06, 24, 29 | 共通ハンドルで GTK3 を操作 |
| PDB runner | 15, 16, 17, 18 | 独自実行契約を現行 API へ接続 |
| DrawableFeature・BrushFeature | 09, 20, 21, 22 | 演算を維持し buffer backend を置換 |

## 7. 完了ゲート

| Gate | 必須区分 | 判定 |
|---|---|---|
| G0 基準固定 | 00–03 | 全件台帳と旧比較環境が存在する |
| G1 C++ 混在基盤 | 04–08 | C と C++ が相互に呼べ、全型の寿命と単一 API が成立 |
| G2 作品構造 | 09–15 | 旧作品を開き独自型・参照・合成を保持して保存できる |
| G3 自動評価 | 16–18 | 依存順序・checkpoint・中止・非ブロッキング・終了条件が合格 |
| G4 描画と編集 | 19–30 | 全拡張描画・操作・資源 UI が保存とともに動く |
| G5 配布基盤 | 31–35 | 旧方式撤去、OS 別 package、版間 adapter が成立 |
| G6 互換・性能 | 36–37 | 実作品の往復・再編集・応答性・寿命が合格 |
| G7 完了判定 | 38 | 未割当・未解決 P0/P1・未完了子タスクがなく成果物を追跡可能 |

Gate は進捗指標であり、早期 gate の合格だけで互換移植完了としない。P2 でも旧資産や P0/P1 から参照される部分は、その依存を解決するまで削除しない。実際の外部公開・署名サービスへの送信は、本書作成による実行対象ではない。

## 8. 基準ソース

- 移植元：[seagetch/gimp-painter](https://github.com/seagetch/gimp-painter/tree/afa43fae3e920210146abed514f136fd49f671b5)
- 差分基点：`a61915a8e62aad8855cd8c620bdb7195a25ffb90`
- 初期移植先：[GIMP 3.0.8](https://github.com/GNOME/gimp/tree/6ac8031c9555667e080fef0324fca9f28a02e5ab)
- C++ 登録：[glib-cxx-impl.hpp](https://github.com/seagetch/gimp-painter/blob/afa43fae3e920210146abed514f136fd49f671b5/app/base/glib-cxx-impl.hpp)
- C++ 接続・寿命：[delegators.hpp](https://github.com/seagetch/gimp-painter/blob/afa43fae3e920210146abed514f136fd49f671b5/app/base/delegators.hpp)
- フィルター制御：[gimpfilterlayer.cpp](https://github.com/seagetch/gimp-painter/blob/afa43fae3e920210146abed514f136fd49f671b5/app/core/gimpfilterlayer.cpp)
- clone 仕様：[gimpclonelayer.cpp](https://github.com/seagetch/gimp-painter/blob/afa43fae3e920210146abed514f136fd49f671b5/app/core/gimpclonelayer.cpp)
- 保存：[app/xcf](https://github.com/seagetch/gimp-painter/tree/afa43fae3e920210146abed514f136fd49f671b5/app/xcf)
- 拡張描画：[app/paint](https://github.com/seagetch/gimp-painter/tree/afa43fae3e920210146abed514f136fd49f671b5/app/paint)
