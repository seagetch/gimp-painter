#include <stdlib.h>
int main(void) { void *p = malloc(32); if (!p) return 1; free(p); return 0; }
