import copy, importlib.util, pathlib, tempfile, types, unittest
p=pathlib.Path(__file__).with_name('run_registered_profile.py');spec=importlib.util.spec_from_file_location('adapter',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Controls(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.build=pathlib.Path(self.tmp.name)/'build';self.target=self.build/'app/tests/gimpdir-output';self.target.mkdir(parents=True,mode=0o700)
  self.name=m.NAMES[0];self.env={'GIMP3_DIRECTORY':'/private/attempt/profile','HOME':'/private/attempt/home','ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1:abort_on_error=1'};self.reg={'name':self.name,'env':{'GIMP3_DIRECTORY':str(self.target)}};self.keys=['HOME','GIMP3_DIRECTORY']
 def tearDown(self):self.tmp.cleanup()
 def call(self):return m.align_profile(self.name,'test',self.env,self.reg,self.build,self.keys)
 def test_exact_single_key(self):
  v=self.call();self.assertEqual(v['GIMP3_DIRECTORY'],str(self.target));self.assertEqual(v['HOME'],self.env['HOME']);self.assertEqual(v['ASAN_OPTIONS'],self.env['ASAN_OPTIONS']);self.assertEqual(self.env['GIMP3_DIRECTORY'],'/private/attempt/profile')
 def test_wrong_name(self):
  self.name='painter-smudge-legacy-strokes'
  with self.assertRaises(RuntimeError):self.call()
 def test_wrong_registry_name(self):
  self.reg['name']='other'
  with self.assertRaises(RuntimeError):self.call()
 def test_foreign_path(self):
  self.reg['env']['GIMP3_DIRECTORY']='/tmp/other'
  with self.assertRaises(RuntimeError):self.call()
 def test_other_private_override(self):
  self.reg['env']['HOME']='/tmp/other'
  with self.assertRaises(RuntimeError):self.call()
 def test_missing_override(self):
  self.reg['env'].clear()
  with self.assertRaises(RuntimeError):self.call()
 def test_symlink_escape(self):
  self.target.rmdir();self.target.symlink_to(pathlib.Path(self.tmp.name),target_is_directory=True)
  with self.assertRaises(RuntimeError):self.call()
 def test_unsafe_mode(self):
  self.target.chmod(0o777)
  with self.assertRaises(RuntimeError):self.call()
 def test_missing_launch_profile(self):
  self.env.pop('GIMP3_DIRECTORY')
  with self.assertRaises(RuntimeError):self.call()
 def test_scope(self):
  m.validate_scope(types.SimpleNamespace(mode='sanitizer',action='test',name=self.name,attempt=m.ATTEMPTS[self.name]))
  m.validate_scope(types.SimpleNamespace(mode='sanitizer',action='seal',name=None,attempt='sanitizer-seal-001'))
 def test_reject_scope_variants(self):
  for mode,action,name,attempt in [('normal','test',self.name,m.ATTEMPTS[self.name]),('sanitizer','build',None,'x'),('sanitizer','prepare',None,'x'),('sanitizer','freeze',None,'x'),('sanitizer','test',self.name,'sanitizer-test-005'),('sanitizer','seal','bad','sanitizer-seal-001')]:
   with self.subTest(action=action,mode=mode),self.assertRaises(RuntimeError):m.validate_scope(types.SimpleNamespace(mode=mode,action=action,name=name,attempt=attempt))
 def test_complete_proof(self):
  m.validate_proof({'amendment_sha256':'a','adapter_sha256':'b','name':self.name,'attempt':'c'},self.name,'c','a','b')
 def test_missing_or_changed_proof(self):
  good={'amendment_sha256':'a','adapter_sha256':'b','name':self.name,'attempt':'c'}
  for k in good:
   for absent in [False,True]:
    v=dict(good)
    if absent:v.pop(k)
    else:v[k]='wrong'
    with self.subTest(key=k,absent=absent),self.assertRaises(RuntimeError):m.validate_proof(v,self.name,'c','a','b')
if __name__=='__main__':unittest.main()
