#!/usr/bin/env python3
"""Explicit invocation amendment; original package and validators remain intact."""
import argparse, hashlib, importlib.util, json, os, stat, sys
from pathlib import Path
BASE = Path('/workspace/shared/gimp-generic-acceptance/preparation/generic-v4')
ROOT = Path('/workspace/shared/gimp-generic-acceptance/run-003')
HERE = Path(__file__).resolve().parent
NAMES = ('painter-fill-brush-legacy','painter-fill-brush-legacyqueued','painter-fill-brush-legacyasync')
ATTEMPTS = dict(zip(NAMES, ('sanitizer-legacy-profile-001','sanitizer-legacy-profile-002','sanitizer-legacy-profile-003')))
REGISTRY_SHA = '7816b0417768f0a84b0f8f5e6ee2e31b89e5d28a93711f34958ee7c7f1687e3d'
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require(ok, message):
 if not ok: raise RuntimeError(message)
def align_profile(name, label, env, registration, build, private_keys):
 require(name in NAMES and label=='test', 'Amendment scope mismatch')
 require(registration['name']==name, 'Registration name mismatch')
 target=build/'app/tests/gimpdir-output'
 require(registration.get('env',{}).get('GIMP3_DIRECTORY')==str(target), 'Registered directory is not exact private-build path')
 require(not (set(registration.get('env',{})) & (set(private_keys)-{'GIMP3_DIRECTORY'})), 'Unexpected private-directory registration override')
 require(build.is_absolute() and build.resolve()==build and target.resolve()==target, 'Aliased private-build directory')
 for p in [build, build/'app', build/'app/tests', target]:
  require(p.is_dir() and not p.is_symlink() and p.stat().st_uid==os.getuid() and not (stat.S_IMODE(p.stat().st_mode)&0o022), 'Unsafe private-build directory')
 require(stat.S_IMODE(target.stat().st_mode)==0o700, 'Registered profile is not private')
 require('GIMP3_DIRECTORY' in env, 'Missing original launch profile')
 result=dict(env);result['GIMP3_DIRECTORY']=str(target)
 require({k:v for k,v in result.items() if k!='GIMP3_DIRECTORY'}=={k:v for k,v in env.items() if k!='GIMP3_DIRECTORY'},'Unrelated launch policy changed')
 return result

def validate_scope(args):
 require(args.mode=='sanitizer' and args.action in {'test','seal'},'Amendment is sanitizer test/seal only')
 if args.action=='test':require(args.name in ATTEMPTS and args.attempt==ATTEMPTS[args.name],'Use exact fresh amended attempt')
 else:require(args.attempt=='sanitizer-seal-001' and args.name is None,'Use exact final seal')
def validate_proof(proof, name, attempt, amendment_sha, adapter_sha):
 require(proof.get('amendment_sha256')==amendment_sha and proof.get('adapter_sha256')==adapter_sha and proof.get('name')==name and proof.get('attempt')==attempt,'Amended registration provenance mismatch')
def main():
 ap=argparse.ArgumentParser(add_help=False)
 ap.add_argument('--amendment-sha256',required=True);ap.add_argument('--review',required=True,type=Path);ap.add_argument('--review-sha256',required=True)
 opts,rest=ap.parse_known_args()
 scope=argparse.ArgumentParser(add_help=False);scope.add_argument('action');scope.add_argument('--mode',required=True);scope.add_argument('--name');scope.add_argument('--attempt',required=True)
 invocation,_=scope.parse_known_args(rest);validate_scope(invocation)
 manifest=HERE/'amendment.json'
 require(digest(manifest)==opts.amendment_sha256,'Amendment manifest mismatch')
 m=json.loads(manifest.read_text());require(digest(__file__)==m['adapter_sha256'],'Adapter bytes changed')
 require(digest(opts.review)==opts.review_sha256,'Independent review changed')
 review=json.loads(opts.review.read_text());require(review['status']=='passed' and review['amendment_sha256']==opts.amendment_sha256,'Amendment lacks exact independent review')
 require(digest(HERE/'test_registered_profile.py')==m['control_script_sha256'] and digest(HERE/'controls.json')==m['controls_sha256'],'Control evidence changed')
 require(json.loads((HERE/'controls.json').read_text())['status']=='passed','Controls did not pass')
 require(digest(BASE/'preparation.json')==m['base_preparation_sha256'],'Base preparation changed')
 require(digest(ROOT/'snapshot/snapshot.json')==m['snapshot_sha256'],'Base snapshot changed')
 require(digest(ROOT/'evidence/sanitizer/sanitizer-build-001/phase.json')==m['compiled_phase_sha256'] and digest(ROOT/'evidence/sanitizer/sanitizer-build-001/public/receipt.json')==m['compiled_public_receipt_sha256'],'Compiled evidence changed')
 runner=BASE/'run_generic_validation.py';require(digest(runner)==json.loads((BASE/'preparation.json').read_text())['runner_files']['run_generic_validation.py'],'Base runner source changed')
 sys.path.insert(0,str(BASE));spec=importlib.util.spec_from_file_location('original_generic_runner',runner);original=importlib.util.module_from_spec(spec);exec(compile(runner.read_bytes(),str(runner),'exec'),original.__dict__)
 OldPhase=original.Phase
 class AmendedPhase(OldPhase):
  def __init__(self,args):
   validate_scope(args)
   require(args.continuation_sha256==m['base_preparation_sha256'] and args.snapshot_sha256==m['snapshot_sha256'] and args.source_input_sha256==m['source_input_sha256'],'Invocation base bindings differ')
   super().__init__(args)
   original.save(self.private/'invocation-amendment.json',{'schema':'registered-private-profile-invocation-amendment-v1','amendment_sha256':opts.amendment_sha256,'adapter_sha256':m['adapter_sha256'],'independent_review_sha256':opts.review_sha256,'base_preparation_sha256':m['base_preparation_sha256'],'snapshot_sha256':m['snapshot_sha256'],'phase':args.action,'name':args.name,'attempt':args.attempt,'original_validator_bytes_unchanged':True,'native_effective_environment_unchanged':True,'failed_attempt_reinterpreted':False})
  def profile(self,label):
   e=super().profile(label)
   if self.args.action!='test' or label!='test':return e
   registry=self.build/'meson-info/intro-tests.json';require(digest(registry)==REGISTRY_SHA,'Registered test metadata changed')
   rows=[r for r in original.read(registry) if r['name']==self.args.name];require(len(rows)==1,'Registration missing/duplicate')
   fixed=align_profile(self.args.name,label,e,rows[0],self.build,self.a.PRIVATE_DIRECTORIES)
   original.save(self.private/'registered-profile-alignment.json',{'registration':self.args.name,'registry_sha256':REGISTRY_SHA,'original_launch_GIMP3_DIRECTORY':e['GIMP3_DIRECTORY'],'aligned_launch_GIMP3_DIRECTORY':fixed['GIMP3_DIRECTORY'],'registered_effective_GIMP3_DIRECTORY':rows[0]['env']['GIMP3_DIRECTORY'],'only_launch_key_changed':'GIMP3_DIRECTORY','original_assertions_unchanged':True})
   return fixed
  def seal_phase(self):
   for name,attempt in ATTEMPTS.items():
    p=self.root/'evidence/sanitizer'/attempt;phase=original.read(p/'phase.json');proof=original.read(p/'private/invocation-amendment.json');public=original.read(p/'public/receipt.json')
    require(phase['status']=='passed' and not phase['errors'] and phase['name']==name and phase['native_result']['complete'],'Missing complete amended registration')
    for record in (phase,public):
     require(record['phase']=='test' and record['mode']=='sanitizer' and record['snapshot_sha256']==m['snapshot_sha256'] and record['continuation_sha256']==m['base_preparation_sha256'] and record['status']=='passed' and not record['errors'] and record['name']==name,'Amended receipt base binding mismatch')
    require(proof['schema']=='registered-private-profile-invocation-amendment-v1' and proof['phase']=='test' and proof['base_preparation_sha256']==m['base_preparation_sha256'] and proof['snapshot_sha256']==m['snapshot_sha256'] and proof['independent_review_sha256']==opts.review_sha256,'Amended proof policy binding mismatch')
    validate_proof(proof,name,attempt,opts.amendment_sha256,m['adapter_sha256'])
    for filename in ('invocation-amendment.json','registered-profile-alignment.json'):
     require(public['private_evidence_sha256'][filename]==digest(p/'private'/filename),'Amendment proof not sealed in public receipt')
    aligned=original.read(p/'private/registered-profile-alignment.json');expected=str(self.build/'app/tests/gimpdir-output')
    require(aligned['registration']==name and aligned['registry_sha256']==REGISTRY_SHA and aligned['aligned_launch_GIMP3_DIRECTORY']==expected and aligned['registered_effective_GIMP3_DIRECTORY']==expected and aligned['only_launch_key_changed']=='GIMP3_DIRECTORY' and aligned['original_assertions_unchanged'] is True,'Alignment proof differs')
   super().seal_phase()
 original.Phase=AmendedPhase;sys.argv=[str(BASE/'run_generic_validation.py'),*rest]
 return original.main()
if __name__=='__main__':raise SystemExit(main())
