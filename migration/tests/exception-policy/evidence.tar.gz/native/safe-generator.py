from pathlib import Path
import os,pickle,shlex,subprocess,sys
repo='/workspace/scratch/5b5281e79681/gimp-painter-port-active'
base=Path('/workspace/shared/gimp-cpp-boundary-04005')
variant=sys.argv[1]
assert variant in ('default','http')
build=base/('build-'+variant)
shadow=Path('/workspace/shared/gimp-exception-policy-04010')/('generator-source-'+variant)
args=shlex.split(Path(sys.argv[2]).read_text())
env=dict(os.environ);cwd=str(build);capture=None
if '--unpickle' in args:
 data=pickle.loads(Path(args[args.index('--unpickle')+1]).read_bytes())
 args=data.cmd_args;env=data.env.get_env(env);cwd=data.workdir or str(build);capture=data.capture
elif args[0]=='env':
 args=args[1:]
 while args and '=' in args[0]:
  key,value=args.pop(0).split('=',1);env[key]=value
args=[arg.replace(repo,str(shadow)) for arg in args]
env={key:value.replace(repo,str(shadow)) for key,value in env.items()}
cwd=cwd.replace(repo,str(shadow))
if capture:
 with open(build/capture,'wb') as output:result=subprocess.run(args,cwd=cwd,env=env,stdout=output)
else:result=subprocess.run(args,cwd=cwd,env=env)
raise SystemExit(result.returncode)
