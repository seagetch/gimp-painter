from pathlib import Path
import hashlib,json,os,subprocess,time
R=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active');D=Path('/workspace/shared/gimp-exception-policy-04010');B=Path('/workspace/shared/gimp-cpp-boundary-04005')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
results=[]
for variant in ['default','http']:
 build=B/('build-'+variant);binary=build/'app/painter/painter-foundation'
 c=build/'app/painter/painter-foundation.p/tests_test-c-api.c.o';cpp=build/'app/painter/painter-foundation.p/tests_test-foundation.cpp.o'
 env={k:os.environ[k] for k in ['PATH','LD_LIBRARY_PATH'] if k in os.environ};env.update(LC_ALL='C',G_DEBUG='fatal-warnings')
 begin=sha(binary);r=subprocess.run([str(binary),'--tap'],cwd=R,env=env,text=True,capture_output=True,timeout=60)
 (D/(variant+'-foundation.log')).write_text(r.stdout+r.stderr)
 assert r.returncode==0,(variant,r.returncode)
 assert '1..39' in r.stdout and r.stdout.count('\nok ')==39,r.stdout
 for test in ['result-boundary-policy','void-boundary-policy']: assert test in r.stdout
 assert sha(binary)==begin
 c_symbols=subprocess.check_output(['nm','-u',str(c)],text=True)
 cpp_symbols=subprocess.check_output(['nm','-g','--defined-only',str(cpp)],text=True)
 assert ' U painter_test_cpp_exception' in c_symbols
 assert ' T painter_test_cpp_exception' in cpp_symbols
 results.append({'configuration':variant,'command':[str(binary),'--tap'],'returncode':r.returncode,'binary_sha256':begin,'stdout_sha256':hashlib.sha256(r.stdout.encode()).hexdigest(),'stderr':r.stderr,'test_cases':39,'c_boundary_policy_cases':2,'injected_boundary_calls':16,'exception_kinds':['typed Error','std::runtime_error','injected std::bad_alloc','non-standard int'],'boundary_variants':['boundary','boundary_void'],'checks':['FALSE safe return','GError domain/code','stable error messages','single C++ RAII cleanup','C caller continuation','NULL GError accepted'],'c_object_sha256':sha(c),'cpp_object_sha256':sha(cpp),'unmangled_c_reference_and_cpp_definition':True})
report={'task':'04.010','status':'PASS','base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'verified_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'results':results,'source_sha256':{p:sha(R/p) for p in ['app/painter/boundary.hpp','app/painter/gimp-painter-error.cpp','app/painter/tests/test-c-api.c','app/painter/tests/test-c-api.h','app/painter/tests/test-foundation.cpp','app/painter/meson.build','app/core/meson.build','app/display/meson.build']},'limitations':['Native Linux GCC only; no sanitizer or cross-platform result inferred.','std::bad_alloc is injected; aborting GLib allocation failure and exceptions thrown from noexcept destructors are not recoverable through this boundary.','Common boundary/compiler policy only; whole-feature callback migration and class-initialization failure remain separate WBS gates.']}
(D/'foundation-native.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'PASS','configurations':2,'cases_each':39,'injections_each':16}))
