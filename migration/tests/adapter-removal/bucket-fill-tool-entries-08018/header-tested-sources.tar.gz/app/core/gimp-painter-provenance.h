/* SPDX-License-Identifier: GPL-3.0-or-later */
#ifndef GIMP_PAINTER_PROVENANCE_H
#define GIMP_PAINTER_PROVENANCE_H
#include <glib-object.h>
G_BEGIN_DECLS
/* Fixed, typed value fields. No arbitrary key/type association is accepted.
 * Getters return an independent reference/copy; they never create a component.
 * All calls belong to the native object's main thread. */
typedef enum {
  GIMP_PAINTER_PROVENANCE_PROPERTIES,
  GIMP_PAINTER_PROVENANCE_EXTENSION,
  GIMP_PAINTER_PROVENANCE_HEADER,
  GIMP_PAINTER_PROVENANCE_EXTERNAL,
  GIMP_PAINTER_PROVENANCE_ORIGINAL,
  GIMP_PAINTER_PROVENANCE_N_BYTES
} GimpPainterProvenanceBytes;
typedef enum {
  GIMP_PAINTER_PROVENANCE_NAME,
  GIMP_PAINTER_PROVENANCE_TYPE,
  /* Incomplete recovery or unsupported native effects forbid lossy Save. */
  GIMP_PAINTER_PROVENANCE_SAVE_REFUSAL,
  /* A partial tile recovery is never a complete Filter cache. */
  GIMP_PAINTER_PROVENANCE_INCOMPLETE_PIXELS,
  GIMP_PAINTER_PROVENANCE_N_TEXT
} GimpPainterProvenanceText;
typedef enum {
  GIMP_PAINTER_PROVENANCE_NAMESPACE_IMAGE,
  GIMP_PAINTER_PROVENANCE_NAMESPACE_ITEM,
  GIMP_PAINTER_PROVENANCE_NAMESPACE_ORIGIN,
  GIMP_PAINTER_PROVENANCE_N_NAMESPACES
} GimpPainterProvenanceNamespace;
/* One byte per raw inner parasite record. Only a complete validated wire set
 * may claim a namespace; semantic validation still decides whether to use it. */
typedef enum {
  GIMP_PAINTER_PROVENANCE_TRANSPORT_INERT = 0,
  GIMP_PAINTER_PROVENANCE_TRANSPORT_IMAGE,
  GIMP_PAINTER_PROVENANCE_TRANSPORT_ITEM,
  GIMP_PAINTER_PROVENANCE_TRANSPORT_ORIGIN
} GimpPainterProvenanceDisposition;
typedef struct {
  GPtrArray *records;
  GBytes   *dispositions;
  GBytes   *capsules[GIMP_PAINTER_PROVENANCE_N_NAMESPACES];
  gboolean  present[GIMP_PAINTER_PROVENANCE_N_NAMESPACES];
  gboolean  invalid[GIMP_PAINTER_PROVENANCE_N_NAMESPACES];
} GimpPainterProvenanceTransport;
GBytes   *gimp_painter_provenance_ref_bytes (GObject *, GimpPainterProvenanceBytes);
gboolean  gimp_painter_provenance_set_bytes (GObject *, GimpPainterProvenanceBytes, GBytes *);
gchar    *gimp_painter_provenance_dup_text (GObject *, GimpPainterProvenanceText);
gboolean  gimp_painter_provenance_set_text (GObject *, GimpPainterProvenanceText, const gchar *);
/* Arrays are snapshots of GBytes references, never shared mutable containers. */
GPtrArray *gimp_painter_provenance_ref_records (GObject *);
gboolean  gimp_painter_provenance_set_records (GObject *, GPtrArray *);
/* A single fixed transport value in the existing ProvenanceSlot. Ref returns
 * an independently owned container snapshot; set borrows every input and
 * publishes all fields together before releasing any overwritten resource.
 * NULL clears the value. No function interprets raw records as executable state. */
GimpPainterProvenanceTransport *gimp_painter_provenance_ref_transport (GObject *);
void      gimp_painter_provenance_free_transport (GimpPainterProvenanceTransport *);
gboolean  gimp_painter_provenance_set_transport (GObject *, const GimpPainterProvenanceTransport *);
GVariant *gimp_painter_provenance_ref_definition (GObject *);
gboolean  gimp_painter_provenance_set_definition (GObject *, GVariant *);
gboolean  gimp_painter_provenance_has_definition (GObject *);
gboolean  gimp_painter_provenance_get_offset (GObject *, guint64 *);
gboolean  gimp_painter_provenance_set_offset (GObject *, guint64);
gint      gimp_painter_provenance_get_dialect (GObject *);
gboolean  gimp_painter_provenance_set_dialect (GObject *, gint);
guint32   gimp_painter_provenance_get_save_id (GObject *);
gboolean  gimp_painter_provenance_set_save_id (GObject *, guint32);
/* Copies only immutable import provenance. No whole-file snapshot, current
 * definition, dialect, original offset or last-save ID is transferred. */
void      gimp_painter_copy_provenance (GObject *source, GObject *target);
G_END_DECLS
#endif
