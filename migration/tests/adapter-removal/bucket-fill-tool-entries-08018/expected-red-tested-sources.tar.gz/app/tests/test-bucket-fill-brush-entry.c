/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "config.h"
#include <gegl.h>
#include <gtk/gtk.h>
#include "libgimpbase/gimpbase.h"
#include "core/core-types.h"
#include "tools/tools-types.h"
#include "core/gimp.h"
#include "tools/gimpfillbrushtool.h"
#include "gimpcoreapp.h"
#include "gimp-app-test-utils.h"
#include "tests.h"

/* Expected-red uses the exact original C signatures without inventing a provider. */
extern GType gimp_bucket_fill_brush_tool_get_type (void) __attribute__((weak));
extern void gimp_bucket_fill_brush_tool_register (GimpToolRegisterCallback, gpointer) __attribute__((weak));
static Gimp *gimp;
static void original_registration_entry (void)
{
  g_assert_nonnull (gimp_bucket_fill_brush_tool_get_type);
  g_assert_nonnull (gimp_bucket_fill_brush_tool_register);
  g_assert_cmpuint (gimp_bucket_fill_brush_tool_get_type (), ==, GIMP_TYPE_FILL_BRUSH_TOOL);
}
int main (int argc, char **argv)
{
  gint result;
  g_test_init (&argc, &argv, NULL);
  if (!gtk_init_check (&argc, &argv)) return GIMP_EXIT_TEST_SKIPPED;
  gimp_test_utils_setup_menus_path ();
  gimp = gimp_init_for_gui_testing (TRUE);
  g_object_set (gimp->config, "painter-canvas-ui", TRUE, NULL);
  g_test_add_func ("/bucket-fill-entry/original-symbols", original_registration_entry);
  g_application_run (gimp->app, 0, NULL);
  result = gimp_core_app_get_exit_status (GIMP_CORE_APP (gimp->app));
  g_application_quit (G_APPLICATION (gimp->app)); g_clear_object (&gimp->app); return result;
}
