from pathlib import Path
import sys,json,subprocess,importlib.util,hashlib,collections
r=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active');out=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('adapter',r/'tools/check_painter_legacy_adapters.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
current=json.loads((out/'current-scan.json').read_text());revision='95f6410f25c5186686db7a489d79c1e79187cd41'
paths=sorted({x['path'] for x in current['data_sites']});upstream={};sources={};missing=[]
for path in paths:
 p=subprocess.run(['git','show',revision+':'+path],cwd=r,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if p.returncode:missing.append(path);continue
 data=p.stdout;old=m.inspect_source(data.decode(),path)['data_sites'];sources[path]={'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'sha256':hashlib.sha256(data).hexdigest()}
 upstream[path]=collections.Counter((x['operation'],x['sha256']) for x in old)
groups=collections.Counter((x['path'],x['operation'],x['sha256']) for x in current['data_sites']);matched=[];different=[]
for (path,operation,digest),count in groups.items():
 row={'path':path,'operation':operation,'sha256':digest,'count':count}
 if upstream.get(path,{}).get((operation,digest),0)>=count:
  row.update(reason='Unchanged native upstream data site',provenance='upstream');matched.append(row)
 else:
  row.update(tokens=next(x['tokens'] for x in current['data_sites'] if x['path']==path and x['operation']==operation and x['sha256']==digest));different.append(row)
result={'upstream_commit':revision,'upstream_sources':sources,'matched':matched,'different':different,'missing_upstream_paths':missing};(out/'upstream-all-data-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print('sites',sum(groups.values()),'upstream',sum(x['count'] for x in matched),'different',sum(x['count'] for x in different))
for row in different:print(row['path'],row['operation'],row['count'],' '.join(x[1] for x in row['tokens']))
