/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "config.h"
#include <gegl.h>
#include <gtk/gtk.h>
extern "C" {
#include "core/core-types.h"
#include "widgets/widgets-types.h"
}
#include "presets/preset-factory-gui.hpp"
#include "presets/preset-factory-gui.hpp"
extern "C" void preset_gui_handle_test (GimpActionGroup *group);
extern "C" void preset_gui_handle_test (GimpActionGroup *group)
{
  using namespace GimpPainter;
  ActionGroupRef empty; empty.register_preset_actions ();
  auto owner = ActionGroupRef::retain (group);
  auto copy = owner;
  owner.reset ();
  g_assert_true (copy.get () == group);
  copy.register_preset_actions ();
  g_assert_cmpuint (TypeTraits<GimpActionGroup>::type (), ==, gimp_action_group_get_type ());
  auto *raw = gimp_action_group_new (group->gimp, "preset-handle-owned", "Owned", nullptr, nullptr, nullptr);
  gpointer weak = raw;
  g_object_add_weak_pointer (G_OBJECT (raw), &weak);
  auto adopted = ActionGroupRef::adopt (raw);
  auto retained = ActionGroupRef::retain (raw);
  adopted.reset ();
  g_assert_nonnull (weak);
  retained.register_preset_actions ();
  retained.reset ();
  g_assert_null (weak);
  auto *wrong = G_OBJECT (g_object_new (G_TYPE_OBJECT, nullptr));
  bool rejected = false;
  try { auto bad = ActionGroupRef::retain (reinterpret_cast<GimpActionGroup *> (wrong)); }
  catch (const Error &) { rejected = true; }
  g_assert_true (rejected);
  g_object_unref (wrong);
}

extern "C" void preset_gui_dialog_handle_test (GimpActionGroup *group);
extern "C" void preset_gui_dialog_handle_test (GimpActionGroup *group)
{
  auto owner = GimpPainter::ActionGroupRef::retain (group);
  owner.register_preset_dialog_actions ();
}

extern "C" void preset_gui_preferences_handle_test (Gimp *application);
extern "C" void preset_gui_preferences_handle_test (Gimp *application)
{
  using namespace GimpPainter;
  ApplicationRef empty;
  auto independent = empty.preset_preferences ();
  g_assert_cmpuint (independent.get ()->len, ==, 1);
  auto owner = ApplicationRef::retain (application);
  auto copy = owner;
  owner.reset ();
  g_assert_true (copy.get () == application);
  auto array = copy.preset_preferences ();
  auto shared = array;
  array.reset ();
  g_assert_cmpstr (g_array_index (shared.get (), PrefsDialogEntry, 0).tree_label, ==, "Layer Presets");
  auto raw = shared.release ();
  g_assert_null (shared.get ());
  g_array_unref (raw);
  copy.reset ();
  auto *wrong = G_OBJECT (g_object_new (G_TYPE_OBJECT, nullptr));
  bool rejected = false;
  try { auto bad = ApplicationRef::retain (reinterpret_cast<Gimp *> (wrong)); }
  catch (const Error &) { rejected = true; }
  g_assert_true (rejected);
  g_object_unref (wrong);
  const guint initial_refs = G_OBJECT (application)->ref_count;
  auto adopted = ApplicationRef::adopt (GIMP (g_object_ref (application)));
  auto retained = ApplicationRef::retain (application);
  g_assert_cmpuint (G_OBJECT (application)->ref_count, ==, initial_refs + 2);
  adopted.reset ();
  g_assert_cmpuint (G_OBJECT (application)->ref_count, ==, initial_refs + 1);
  retained.reset ();
  g_assert_cmpuint (G_OBJECT (application)->ref_count, ==, initial_refs);
}
