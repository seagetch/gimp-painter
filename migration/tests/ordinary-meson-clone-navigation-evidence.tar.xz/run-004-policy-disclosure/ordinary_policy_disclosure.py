#!/usr/bin/env python3
"""Evidence-only reviewed extraction attestation for run-004 policy redaction.

No configure/build/native test is executed. Original runner, receipt, logs and
validation remain immutable. Withheld raw environment cannot be reconstructed
from its hash; the portable record is an independently reviewed extraction.
"""
from __future__ import annotations
import argparse,hashlib,importlib.util,json,re,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve()
SCHEMA='ordinary-meson-runtime-policy-disclosure-v1'
RUNNER_SHA256='607de99f2babee17d82157d8e2ea7813c749b86162fc38494c3ec83294d647f9'
RECEIPT_SHA256='db0cbf6086c25eb82314ff649a8b01aa5079e8dec349c1b697377f90b854186f'
VALIDATION_SHA256='31f4b130c7b0afe225a3fcecf5f8146a6855d3be9766460bd482c4046d595393'
RAW_LOG_SHA256='b4d83aa4a77c0a78c3884153770cf15cffb3efa8ab4ac6f2817382a153c12582'
COMMIT='47202852286b654d88d3fa4f0bafd59e08030cad'
TREE='47edf23ea7f95390751c76d649acb9429d38ff61'
ASAN='detect_leaks=0:halt_on_error=1:abort_on_error=1'
UBSAN='halt_on_error=1:abort_on_error=1:print_stacktrace=1'
FAILURE=['RuntimeError: Runtime sanitizer policy weakened']
REDACTED='[environment line omitted]\n'
DISCLOSURE='Reviewed extraction attestation; the withheld raw environment is not independently reconstructible from its hash.'
FORBIDDEN=['LD_PRELOAD','LD_AUDIT','LSAN_OPTIONS']
ALLOWED_ENV=['ASAN_OPTIONS','UBSAN_OPTIONS','GSETTINGS_BACKEND']

def require(ok,message):
    if not ok:raise RuntimeError(message)
def digest(value):return hashlib.sha256(value).hexdigest()
def sha(path):return digest(Path(path).read_bytes())
def canonical(value):return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
def read(path):return json.loads(Path(path).read_text())
def load_module(path,name):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    exec(compile(Path(path).read_bytes(),str(path),'exec'),module.__dict__);return module

def original(public):
    require(sha(public/'receipt.json')==RECEIPT_SHA256,'Unexpected immutable execution receipt')
    require(sha(public/'ordinary_meson_validation.py')==RUNNER_SHA256,'Unexpected immutable execution validator')
    receipt=read(public/'receipt.json')
    require(receipt['schema']=='ordinary-meson-clone-navigation-sealed-runtime-continuation-v1' and
            receipt['status']=='passed' and receipt['errors']==[] and receipt['runner_sha256']==RUNNER_SHA256,
            'Execution receipt is not the exact completed run-004')
    require(sha(public.parent/'validation.json')==VALIDATION_SHA256,'Original validation bytes changed')
    require(read(public.parent/'validation.json')=={'passed':False,'errors':FAILURE,'receipt_sha256':RECEIPT_SHA256},
            'Original validation differs from the sole policy-redaction failure')
    policy=read(public/'sanitizer-runtime-policy.json')
    require(policy['asan_options']==policy['ubsan_options']==REDACTED,'Original fields are not exactly the known two redactions')
    require(sha(public/'sanitizer-runtime-policy.json')==receipt['files']['sanitizer-runtime-policy.json'],'Changed original policy')
    transform=read(public/'transforms.json')['sanitizer-results.json']
    require(transform['raw_sha256']==RAW_LOG_SHA256 and
            transform['public_sha256']==sha(public/'sanitizer-results.json'),'Raw/public evidence hash binding differs')
    module=load_module(public/'ordinary_meson_validation.py','frozen_run004_validator')
    return receipt,policy,transform,module

def validate_attestation(public,attestation):
    receipt,policy,transform,module=original(public)
    expected_keys={'schema','kind','disclosure','execution_receipt_sha256','execution_runner_sha256','extractor_sha256',
                   'private_log_sha256','public_results_sha256','observed_environment_keys','checked_absent_environment_keys','rows'}
    require(set(attestation)==expected_keys,'Unexpected attestation disclosure fields')
    require(attestation['schema']==SCHEMA and attestation['kind']=='evidence-only policy extraction' and
            attestation['disclosure']==DISCLOSURE,'Attestation scope/limitations changed')
    require(attestation['execution_receipt_sha256']==RECEIPT_SHA256 and attestation['execution_runner_sha256']==RUNNER_SHA256 and
            attestation['extractor_sha256']==sha(HERE) and attestation['private_log_sha256']==RAW_LOG_SHA256 and
            attestation['public_results_sha256']==transform['public_sha256'],'Attestation identity/hash binding changed')
    require(attestation['observed_environment_keys']==ALLOWED_ENV and attestation['checked_absent_environment_keys']==FORBIDDEN,
            'Environment disclosure allowlist changed')
    results=read(public/'sanitizer-results.json');rows=attestation['rows']
    require(len(results)==len(rows)==4,'Missing/extra sanitizer extraction rows')
    row_keys={'index','name','public_result_sha256','raw_record_sha256','observed','absent'}
    for index,(result,row) in enumerate(zip(results,rows)):
        require(set(row)==row_keys and row['index']==index and row['name']==result['name'] and
                row['public_result_sha256']==digest(canonical(result)),'Extraction/public result identity differs')
        require(isinstance(row['raw_record_sha256'],str) and re.fullmatch('[0-9a-f]{64}',row['raw_record_sha256']),
                'Missing raw record fingerprint')
        require(row['observed']=={'ASAN_OPTIONS':ASAN,'UBSAN_OPTIONS':UBSAN,'GSETTINGS_BACKEND':'memory'} and
                row['absent']==FORBIDDEN,'Observed runtime policy is not prescribed or forbidden overrides present')
        require(result['result']=='OK' and result['returncode']==0,'Sanitizer result is not successful')
    return module,policy

def validate(public,attestation):
    """Compose the frozen full validator with one narrowly scoped policy read."""
    public=Path(public).resolve();module,policy=validate_attestation(public,attestation)
    require(module.validate(public,COMMIT,TREE)==FAILURE,'Original validator does not reproduce the sole known redaction error')
    observed=attestation['rows'][0]['observed']
    replacement=dict(policy)
    replacement['asan_options']=observed['ASAN_OPTIONS'];replacement['ubsan_options']=observed['UBSAN_OPTIONS']
    require({k for k in policy if policy[k]!=replacement[k]}=={'asan_options','ubsan_options'},'Adapter scope changed')
    target=(public/'sanitizer-runtime-policy.json').resolve();read_original=module.read;uses=[]
    def bounded_read(path):
        if Path(path).resolve()==target and not uses:
            uses.append(str(target));return dict(replacement)
        # Later reads (the frozen GSettings check) see the exact original data.
        return read_original(path)
    try:
        module.read=bounded_read
        errors=module.validate(public,COMMIT,TREE)
    finally:module.read=read_original
    require(len(uses)==1,'Policy adapter was not used exactly once')
    require(not errors,'Full immutable execution evidence fails after scoped policy extraction: '+str(errors))
    require(sha(public/'receipt.json')==RECEIPT_SHA256 and read(public/'sanitizer-runtime-policy.json')==policy,
            'Original evidence changed during recovery validation')
    return {'schema':SCHEMA,'passed':True,'kind':'evidence-only recovery; no native execution',
            'execution_receipt_sha256':RECEIPT_SHA256,'execution_runner_sha256':RUNNER_SHA256,
            'extractor_sha256':sha(HERE),'attestation_sha256':digest(canonical(attestation)),
            'original_validation_errors':FAILURE,'original_terminal_exit_code':1,'policy_adapter_uses':1,'adapted_fields':['asan_options','ubsan_options'],
            'normal_cases':267,'sanitizer_cases':103,'original_evidence_unchanged':True,'disclosure':DISCLOSURE}

def extract(public,private_log):
    """Read private JSONL, disclose three known fields after exact full transform."""
    public=Path(public).resolve();receipt,policy,transform,module=original(public)
    raw=Path(private_log).read_bytes();require(digest(raw)==RAW_LOG_SHA256,'Private Meson log does not match sealed raw hash')
    # Import only the helper bytes already sealed by the immutable full receipt.
    for name in module.UTILITIES:require(sha(public/'helpers'/name)==receipt['helpers_sha256'][name],'Changed privacy helper')
    clone=load_module(public/'helpers/tools/clone_evidence.py','sealed_policy_privacy_helper')
    filtered,detail=clone.public_json(raw,True)
    safe=canonical(clone.aggregate.Sanitizer({}).object(json.loads(filtered)))
    require(safe==(public/'sanitizer-results.json').read_bytes() and detail==transform['environment_removal'],
            'Private log does not reproduce the exact published result transformation')
    public_results=json.loads(safe);lines=[line for line in raw.splitlines() if line.strip()]
    require(len(lines)==len(public_results)==4,'Unexpected private extraction row count')
    rows=[]
    for index,(line,result) in enumerate(zip(lines,public_results)):
        private=json.loads(line);env=private.get('env')
        require(isinstance(env,dict),'Missing actual Meson child environment')
        observed={key:env.get(key) for key in ALLOWED_ENV}
        require(observed=={'ASAN_OPTIONS':ASAN,'UBSAN_OPTIONS':UBSAN,'GSETTINGS_BACKEND':'memory'},'Private observed runtime options differ')
        require(not any(key in env for key in FORBIDDEN),'Private forbidden runtime override present')
        rows.append({'index':index,'name':result['name'],'public_result_sha256':digest(canonical(result)),
                     'raw_record_sha256':digest(line),'observed':observed,'absent':list(FORBIDDEN)})
    attestation={'schema':SCHEMA,'kind':'evidence-only policy extraction','disclosure':DISCLOSURE,
        'execution_receipt_sha256':RECEIPT_SHA256,'execution_runner_sha256':RUNNER_SHA256,'extractor_sha256':sha(HERE),
        'private_log_sha256':digest(raw),'public_results_sha256':digest(safe),'observed_environment_keys':list(ALLOWED_ENV),
        'checked_absent_environment_keys':list(FORBIDDEN),'rows':rows}
    validate_attestation(public,attestation)
    return attestation

def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='mode',required=True)
    make=sub.add_parser('extract',help='evidence-only private read and strictly allowlisted publication')
    make.add_argument('--public',type=Path,required=True);make.add_argument('--private-log',type=Path,required=True)
    make.add_argument('--output',type=Path,required=True)
    check=sub.add_parser('validate',help='offline immutable-evidence validation; no private data needed')
    check.add_argument('--public',type=Path,required=True);check.add_argument('--attestation',type=Path,required=True)
    args=parser.parse_args()
    if args.mode=='extract':
        require(not args.output.exists(),'Never overwrite an attestation')
        require(not args.output.resolve().is_relative_to(args.public.resolve().parent),'Attestation must be outside original execution evidence')
        value=extract(args.public,args.private_log);report=validate(args.public,value)
        with args.output.open('xb') as stream:stream.write(canonical(value))
        print(json.dumps(report,indent=2));return 0
    print(json.dumps(validate(args.public,read(args.attestation)),indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
