#include <glib-object.h>
#include "test-hierarchy.h"
void probe_constructed (GParamSpec *);
void probe_set (GObject *, guint, const GValue *, GParamSpec *);
gint probe_read (PainterReadable *, GError **);
void probe_assign (GObjectClass *klass, PainterReadableInterface *iface)
{
  klass->constructed = probe_constructed;
  klass->set_property = probe_set;
  iface->read = probe_read;
}
