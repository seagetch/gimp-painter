#include <gio/gio.h>
#include <type_traits>
gssize endian_input_read (GInputStream *stream, void *buffer, gsize count,
                                 GCancellable *cancel, GError **error);
static_assert(std::is_same<decltype(&endian_input_read), decltype(GInputStreamClass::read_fn)>::value, "native stream slot mismatch");
