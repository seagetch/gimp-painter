import pathlib,subprocess,json,hashlib,os
repo=pathlib.Path('/workspace/scratch/0015fc5d1a03/gimp-painter');base=pathlib.Path('/tmp/current-source-gates-9abddbd319');root=base/'source';commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();out=base/('current-'+commit[:10]);out.mkdir(exist_ok=False)
records={};changed=[];proc=subprocess.Popen(['git','cat-file','--batch'],cwd=repo,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
for entry in subprocess.check_output(['git','ls-tree','-rz',commit],cwd=repo).split(b'\0'):
 if not entry:continue
 meta,name=entry.split(b'\t',1);mode,kind,blob=meta.decode().split();name=name.decode()
 if kind!='blob' or not (name.startswith(('app/','libgimp','pdb/','tools/','migration/')) or name in ('tasks.md','meson.build')):continue
 p=root/name;data=p.read_bytes() if p.is_file() else None
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest() if data is not None else None
 if actual!=blob:
  proc.stdin.write(blob.encode()+b'\n');proc.stdin.flush();header=proc.stdout.readline().split();data=proc.stdout.read(int(header[2]));assert proc.stdout.read(1)==b'\n';p.parent.mkdir(parents=True,exist_ok=True)
  if p.is_symlink():p.unlink()
  p.write_bytes(data);changed.append(name)
 records[name]={'git_blob':blob,'sha256':hashlib.sha256(data).hexdigest(),'linked':p.is_symlink()}
proc.stdin.close();proc.wait()
# Remove only formerly tracked inputs absent from new tree; no source objects outside this private snapshot.
old=json.loads((base/'source-manifest.json').read_text())['files']
for name in old.keys()-records.keys():(root/name).unlink()
(out/'source-manifest.json').write_text(json.dumps({'commit':commit,'files':records,'refreshed_paths':changed},indent=2)+'\n');print('current',commit,'inputs',len(records),'updated',len(changed),flush=True)
for name,cmd in [('adapter',['tools/check_painter_legacy_adapters.py']),('persistence',['migration/tests/test_persistence_field_contract.py'])]:
 with (out/(name+'.log')).open('w') as f:r=subprocess.run(['python3']+cmd+['--root',str(root),'--report',str(out/(name+'.json'))],cwd=root,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'TMPDIR':'/tmp','PYTHONDONTWRITEBYTECODE':'1'})
 (out/(name+'.status')).write_text(str(r.returncode)+'\n');print(name,r.returncode,flush=True)
changed=[n for n,r in records.items() if hashlib.sha256((root/n).read_bytes()).hexdigest()!=r['sha256']]
(out/'source-after.json').write_text(json.dumps({'checked':len(records),'changed':changed},indent=2)+'\n');assert not changed
