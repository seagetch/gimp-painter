# Superseded capture attempt

Harness did not force lazy old projection pixels; live FilterLayer never started. Mask fixture bounds were also stale.

The capture-harness.c file was reconstructed and its SHA256 verified against the original report. Reports and original pixels remain unchanged. Use migration/fixtures/legacy-filter-context/capture-report.json for the corrected capture.
