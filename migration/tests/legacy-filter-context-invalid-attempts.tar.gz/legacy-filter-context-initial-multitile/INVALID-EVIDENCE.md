# Superseded capture attempt

Old multi-tile projection did not settle under this bounded harness. Mask fixture bounds were also stale.

The capture-harness.c file was reconstructed and its SHA256 verified against the original report. Reports and original pixels remain unchanged. Use migration/fixtures/legacy-filter-context/capture-report.json for the corrected capture.
