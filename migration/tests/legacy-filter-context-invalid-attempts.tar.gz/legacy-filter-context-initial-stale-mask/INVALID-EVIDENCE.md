# Superseded capture attempt

INVALID CONTEXT EVIDENCE: direct mask fixture writes did not invalidate the old cached bounds. All masks were incorrectly treated as globally empty. The original report says passed because its validation was incomplete; no selection or context acceptance is counted from this run.

The capture-harness.c file was reconstructed and its SHA256 verified against the original report. Reports and original pixels remain unchanged. Use migration/fixtures/legacy-filter-context/capture-report.json for the corrected capture.
