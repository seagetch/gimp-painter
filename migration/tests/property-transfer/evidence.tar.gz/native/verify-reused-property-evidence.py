"""Verify source-equal historical production evidence, without rewriting it."""
from pathlib import Path
import csv,hashlib,io,json,tarfile
root=Path(__file__).resolve().parent.parent/'gimp-painter-port-active'
directory=root/'migration/tests/property-boundary'
report=json.loads((directory/'report.json').read_text())
assert report['task']=='05.013/legacy-exit-removal' and report['status']=='PASS'
for path,digest in report['source_sha256'].items():
 assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
raw=(directory/'evidence.tar.gz').read_bytes()
assert len(raw)==report['evidence_bytes'] and hashlib.sha256(raw).hexdigest()==report['evidence_sha256']
manifest=json.loads((directory/'evidence-manifest.json').read_text())
with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
 members=tar.getmembers();assert len(members)==len(manifest)==report['evidence_members']
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  content=tar.extractfile(member).read()
  assert len(content)==manifest[member.name]['size'] and hashlib.sha256(content).hexdigest()==manifest[member.name]['sha256']
 old=list(csv.DictReader(io.StringIO(tar.extractfile('baseline-review/original-header-ledger.tsv').read().decode()),delimiter='\t'))
current={x['work_id']:x for x in csv.DictReader((root/'migration/inventory/legacy-port-work-items.tsv').open(),delimiter='\t')}
mutable={'status','owner','artifact','test','result','limitations'}
for row in old:
 assert all(row[k]==current[row['work_id']][k] for k in row if k not in mutable),row['work_id']
result={'status':'PASS','kind':'source-equal historical production evidence, not a fresh runtime pass','original_task':report['task'],'report_sha256':hashlib.sha256((directory/'report.json').read_bytes()).hexdigest(),'source_count':len(report['source_sha256']),'source_sha256':report['source_sha256'],'archive_sha256':report['evidence_sha256'],'archive_members':len(members),'immutable_source_obligations':len(old),'historical_checker_limitation':'Original checker compares mutable completion fields with old ledger; later task completion legitimately differs. Original reports and digests remain unchanged.'}
Path(__file__).with_name('reused-property-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS: source-equal production evidence; %d sources; %d immutable ledger rows; archive seals unchanged' % (len(report['source_sha256']),len(old)))
