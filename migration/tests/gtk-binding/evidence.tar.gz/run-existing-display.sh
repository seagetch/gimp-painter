#!/usr/bin/env bash
set -eo pipefail
if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
  echo 'No existing desktop display in this shell'
  exit 77
fi
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/env-http.sh
cd /workspace/scratch/5b5281e79681/gtk-binding-06023-verification
set +e
python3 run-ui-tests.py --start-index 4 > ui-run.log 2>&1
result=$?
set -e
printf '%s\n' "$result" > ui-run.exit
printf 'GTK_BINDING_UI_EXIT=%s\n' "$result"
exit "$result"
