#!/bin/bash
set -eo pipefail
if [ -z "${DISPLAY:-}" ] && [ -z "${WAYLAND_DISPLAY:-}" ]; then
  echo 'Existing desktop display required'; exit 77
fi
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/env-http.sh
cd /workspace/scratch/5b5281e79681/gtk-binding-06023-verification
set +e
python3 run-sanitized-ui.py > sanitized-run.log 2>&1
result=$?
printf '%s\n' "$result" > sanitized-run.exit
printf 'GTK_BINDING_SANITIZER_EXIT=%s\n' "$result"
exit "$result"
