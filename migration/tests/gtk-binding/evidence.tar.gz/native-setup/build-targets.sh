#!/usr/bin/env bash
set -euo pipefail
base="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$base/env-http.sh"
exec flock "$GIMP_PAINTER_BUILD_LOCK" ninja -C "$base/build-http" -f "$base/http.ninja" -j 4 \
  app/tests/gimp-painter-options app/tests/painter-compact-options \
  app/tests/painter-canvas-ui app/tests/painter-mypaint-editor app/tests/painter-layer-ui \
  menus/image-menu.ui menus/dockable-menu.ui
