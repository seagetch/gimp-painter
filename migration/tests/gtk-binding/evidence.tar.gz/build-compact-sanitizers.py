from pathlib import Path
import hashlib,json,shlex,subprocess
base=Path(__file__).resolve().parent;root=base.parent/'gimp-painter-port-active';build=base.parent/'gimp-native-restore-20261009/build-http';out=base/'compact-sanitizers';out.mkdir(exist_ok=True)
sources=['app/painter/binding-store.cpp','app/painter/gimp-painter-binding.cpp','app/painter/gimp-painter-error.cpp','app/widgets/gimppaintercompactoptions.cpp','app/paint/painter-mypaint-surface/gimp-painter-options.cpp','app/tests/test-painter-compact-options.c']
headers=[str(p.relative_to(root)) for p in sorted((root/'app/painter').glob('*.hpp'))]+['app/widgets/gimppaintercompactoptions.h']
hashes={x:hashlib.sha256((root/x).read_bytes()).hexdigest() for x in sources+headers};entries=json.loads((build/'compile_commands.json').read_text());objects={};originals={};commands=[]
flags=['-fsanitize=address,undefined','-fno-sanitize=vptr','-fno-omit-frame-pointer','-O1','-g']
for source in sources:
 e=next(e for e in entries if (Path(e['directory'])/e['file']).resolve()==root/source);cmd=shlex.split(e['command']);clean=[];skip=False
 for arg in cmd:
  if skip:skip=False;continue
  if arg in ['-MF','-MQ','-MT']:skip=True;continue
  if arg in ['-MD','-MMD']:continue
  clean.append(arg)
 obj=out/(Path(source).name+'.o');clean[clean.index('-o')+1]=str(obj);clean+=flags;commands.append(clean)
 subprocess.run(clean,cwd=build,check=True);objects[source]=str(obj);originals[e['output']]=source
cmd=shlex.split(subprocess.check_output(['ninja','-f',str(build.parent/'http.ninja'),'-t','commands','app/tests/painter-compact-options'],cwd=build,text=True).strip().splitlines()[-1]);exe=out/'painter-compact-options';cmd[cmd.index('-o')+1]=str(exe)
absolute={str((build/key).resolve()):objects[value] for key,value in originals.items()};replaced=[]
for archive in sorted({x for x in cmd if x.endswith('.a') and (build/x).resolve().is_relative_to(build)}):
 members=[str((build/x).resolve()) for x in subprocess.check_output(['ar','t',archive],cwd=build,text=True).splitlines()]
 if not any(x in absolute for x in members):continue
 dest=out/archive.replace('/','_')
 if dest.exists():dest.unlink()
 arcmd=['ar','crsT',str(dest),*[absolute.get(x,x) for x in members]];commands.append(arcmd);subprocess.run(arcmd,cwd=build,check=True);replaced.extend(x for x in members if x in absolute);cmd=[str(dest) if x==archive else x for x in cmd]
cmd=[objects[originals[x]] if x in originals and originals[x].startswith('app/tests/') else x for x in cmd];cmd[1:1]=flags;commands.append(cmd);subprocess.run(cmd,cwd=build,check=True)
assert all(hashlib.sha256((root/x).read_bytes()).hexdigest()==h for x,h in hashes.items()),'source changed during build'
report={'instrumented_sources':sources,'source_sha256':hashes,'commands':commands,'replaced_archive_members':replaced,'executable':str(exe),'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'vptr_sanitizer':False,'leak_sanitizer':False,'limitation':'Only these six units instrumented; remaining host and dependency libraries are native uninstrumented objects. LSan disabled because of previously observed ptrace restriction. C remains C, C++ remains no RTTI.','run_status':'Not run by builder; needs existing native desktop'}
(out/'build-report.json').write_text(json.dumps(report,indent=2)+'\n');print(exe)
