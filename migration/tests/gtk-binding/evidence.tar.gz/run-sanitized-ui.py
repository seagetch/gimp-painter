from pathlib import Path
import hashlib,json,os,re,subprocess
base=Path(__file__).resolve().parent;root=base.parent/'gimp-painter-port-active';build=base.parent/'gimp-native-restore-20261009/build-http'
report=json.loads((base/'compact-sanitizers/build-report.json').read_text())
for p,h in report['source_sha256'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
exe=Path(report['executable']);assert hashlib.sha256(exe.read_bytes()).hexdigest()==report['executable_sha256']
assert os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY'),'Existing display required'
row=next(x for x in json.loads((build/'meson-info/intro-tests.json').read_text()) if x['name']=='painter-compact-options');env=os.environ.copy()
for k,v in row['env'].items():env[k]=v+(':'+env.get(k,'') if k=='LD_LIBRARY_PATH' else '')
env.update(G_DEBUG='fatal-warnings',ASAN_OPTIONS='detect_leaks=0:alloc_dealloc_mismatch=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
with (base/'sanitized-stdout.log').open('w') as out,(base/'sanitized-stderr.log').open('w') as err:
 p=subprocess.Popen([str(exe)],cwd=build,env=env,stdout=out,stderr=err);(base/'sanitized-active.json').write_text(json.dumps({'pid':p.pid,'executable':str(exe)})+'\n')
 try:status=p.wait(timeout=300)
 except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=10);status=124
text=(base/'sanitized-stdout.log').read_text();result={'exit_code':status,'passed':len(re.findall(r'^ok \d+',text,re.M)),'executable_sha256':report['executable_sha256'],'stdout_sha256':hashlib.sha256((base/'sanitized-stdout.log').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256((base/'sanitized-stderr.log').read_bytes()).hexdigest(),'instrumented_sources':report['instrumented_sources'],'vptr':False,'lsan':False}
(base/'sanitized-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(status or (0 if result['passed']==10 else 1))
