from pathlib import Path
import argparse,hashlib,json,os,re,subprocess,sys
base=Path(__file__).resolve().parent;repo=base.parent/'gimp-painter-port-active';build=base.parent/'gimp-native-restore-20261009/build-http'
manifest=json.loads((base/'ui-inputs.json').read_text())
for path,digest in manifest['sha256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest,path
if not os.environ.get('DISPLAY') and not os.environ.get('WAYLAND_DISPLAY'):raise SystemExit('No existing desktop display supplied')
tests={x['name']:x for x in json.loads((build/'meson-info/intro-tests.json').read_text())}
parser=argparse.ArgumentParser();parser.add_argument('--start-index',type=int,default=0);args=parser.parse_args();results=[]
if args.start_index:
 results=json.loads((base/'accepted-prefix.json').read_text());assert len(results)==args.start_index
 for index,prior in enumerate(results):
  item=manifest['runs'][index];row=tests[item['target']]
  assert prior['index']==index and prior['target']==item['target'] and prior['test']==item['test'] and prior['exit_code']==0 and prior['passed']==item['expected']
  assert prior['executable_sha256']==manifest['sha256'][row['cmd'][0]]
  for field in ['stdout','stderr']:assert hashlib.sha256((base/prior[field]).read_bytes()).hexdigest()==prior[field+'_sha256']
for index,item in enumerate(manifest['runs']):
 if index<args.start_index:continue
 row=tests[item['target']];env=os.environ.copy()
 for key,value in row['env'].items():env[key]=value+(':'+env.get(key,'') if key=='LD_LIBRARY_PATH' else '')
 env['G_DEBUG']='fatal-warnings'
 command=row['cmd']+(['-p',item['test']] if item['test'] else [])
 out=base/('ui-%02d-stdout.log'%index);err=base/('ui-%02d-stderr.log'%index)
 with out.open('w') as stdout,err.open('w') as stderr:
  process=subprocess.Popen(command,cwd=build,env=env,stdout=stdout,stderr=stderr)
  (base/'ui-active.json').write_text(json.dumps({'index':index,'command':command,'pid':process.pid},indent=2)+'\n')
  try:status=process.wait(timeout=300)
  except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=10);status=124
 text=out.read_text();result={'index':index,'target':item['target'],'test':item['test'],'command':command,'exit_code':status,'passed':len(re.findall(r'^ok \d+',text,re.M)),'stdout':out.name,'stderr':err.name,'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest(),'executable_sha256':manifest['sha256'][row['cmd'][0]]};results.append(result);(base/'ui-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
 if status or result['passed']!=item['expected']:raise SystemExit(status or 1)
(base/'ui-active.json').write_text(json.dumps({'finished':True,'runs':len(results),'passed':sum(x['passed'] for x in results)},indent=2)+'\n')
