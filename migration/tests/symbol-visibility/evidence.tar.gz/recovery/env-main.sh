export GIMP_DEPS_DIRECTORY=/workspace/scratch/5b5281e79681/gimp-native-restore-20261008/deps
export GIMP_BUILD_PREFIX=/workspace/scratch/5b5281e79681/gimp-native-restore-20261008/prefix
source /workspace/scratch/5b5281e79681/gimp-painter-port-active/tools/linux-debian13-env.sh
export CCACHE_DISABLE=1
export LC_ALL=C
