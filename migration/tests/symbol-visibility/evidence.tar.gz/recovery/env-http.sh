source /workspace/scratch/5b5281e79681/gimp-native-restore-20261008/env-main.sh
export GIMP_HTTP_DEPS_ROOT=/workspace/scratch/5b5281e79681/gimp-native-restore-20261008/deps-http/root
export PKG_CONFIG_PATH="$GIMP_HTTP_DEPS_ROOT/usr/lib/x86_64-linux-gnu/pkgconfig:$GIMP_HTTP_DEPS_ROOT/usr/share/pkgconfig:$PKG_CONFIG_PATH"
export LD_LIBRARY_PATH="$GIMP_HTTP_DEPS_ROOT/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH"
export LIBRARY_PATH="$GIMP_HTTP_DEPS_ROOT/usr/lib/x86_64-linux-gnu:$LIBRARY_PATH"
export CPATH="$GIMP_HTTP_DEPS_ROOT/usr/include:$GIMP_HTTP_DEPS_ROOT/usr/include/x86_64-linux-gnu:$CPATH"
export GI_TYPELIB_PATH="$GIMP_HTTP_DEPS_ROOT/usr/lib/x86_64-linux-gnu/girepository-1.0:$GI_TYPELIB_PATH"
