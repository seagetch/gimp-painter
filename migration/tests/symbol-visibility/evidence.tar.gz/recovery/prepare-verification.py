from pathlib import Path
import hashlib,json,re,tarfile

base=Path(__file__).resolve().parent
repo=base.parent/'gimp-painter-port-active'
with tarfile.open(repo/'migration/tests/exception-policy/evidence.tar.gz') as archive:
    protected={target for item in json.loads(archive.extractfile('native/default-protected-generators.json').read()) for target in item['targets']}
for variant in ('default','http'):
    build=base/('build-'+variant)
    original=(build/'build.ninja').read_text()
    blocks=original.split('\n\n')
    changes=[]
    for index,block in enumerate(blocks):
        if not block.startswith('build '): continue
        targets=block.split(': ',1)[0][6:].split()
        if not protected.intersection(targets): continue
        match=re.search(r'^ COMMAND = (.+)$',block,re.M)
        if not match: raise RuntimeError(targets)
        command_file=base/(variant+'-'+str(len(changes))+'.command')
        command_file.write_text(match.group(1).replace('$ ',' ').replace('$$','$'))
        replacement=f'/usr/bin/python3 {base}/safe-generator.py {variant} {command_file}'
        blocks[index]=block[:match.start(1)]+replacement+block[match.end(1):]
        changes.append({'targets':targets,'original_command':match.group(1),'replacement_command':replacement})
    assert len(changes)==len(protected)==17
    manifest=base/(variant+'.ninja')
    manifest.write_text('\n\n'.join(blocks))
    (base/(variant+'-protected-generators.json')).write_text(json.dumps(changes,indent=2)+'\n')
    (build/'prerequisites-report.json').write_text(json.dumps({'protected_targets':sorted(protected),'original_manifest_sha256':hashlib.sha256(original.encode()).hexdigest(),'verification_manifest':str(manifest),'compiler_and_link_recipes_unchanged':True},indent=2)+'\n')
    print(variant, 'redirected exactly 17 generator recipes; all other manifest bytes preserved')
