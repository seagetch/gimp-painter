from pathlib import Path
import argparse,json,re
parser=argparse.ArgumentParser();parser.add_argument('stage');args=parser.parse_args()
root=Path(__file__).resolve().parent;repo=root.parents[1];restore=repo.parent/'gimp-native-restore-20261008'
for variant in ('default','http'):
 def warnings(paths):
  result={}
  for path in paths:
   for line in path.read_text().splitlines():
    clean=re.sub(r'\x1b\[[0-9;]*m','',line)
    match=re.search(r'([^\s]+):\d+:\d+: warning: (.+)',clean)
    if match:
     source=match.group(1).removeprefix('../../gimp-painter-port-active/')
     key=source+': '+match.group(2)
     result.setdefault(key,[]).append({'log':str(path),'diagnostic':clean})
  return result
 baseline=warnings([root/'baseline'/variant/'build.log',root/'baseline'/variant/'controls-build.log',restore/(variant+'-build.log')])
 current=warnings([root/args.stage/variant/'build.log'])
 new=sorted(set(current)-set(baseline))
 result={'status':'PASS' if not new else 'FAIL','baseline':baseline,'current':current,'new_warning_kinds':new,'preexisting_warning_kinds':sorted(set(current)&set(baseline)),'new_visibility_warnings':[key for key in new if 'visibility' in key or '[-Wattributes]' in key]}
 (root/args.stage/variant/'warning-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
 print(variant,result['status'],'new warning kinds',len(new),'preexisting',len(result['preexisting_warning_kinds']))
