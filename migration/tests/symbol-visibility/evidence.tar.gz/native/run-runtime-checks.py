from pathlib import Path
import argparse,hashlib,json,os,subprocess,tempfile

parser=argparse.ArgumentParser()
parser.add_argument('--export-report',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
args.output=args.output.resolve()
report=json.loads(args.export_report.read_text())
assert report['status']=='PASS', 'Run only after a passing export comparison'
build=Path(report['build_directory'])
args.output.mkdir(parents=True,exist_ok=False)
results=[]
with tempfile.TemporaryDirectory(prefix='isolated-runtime-',dir=args.output) as temporary:
 isolated=Path(temporary)
 env=dict(os.environ)
 overrides={'HOME':str(isolated/'home'),'XDG_CONFIG_HOME':str(isolated/'config'),
            'XDG_CACHE_HOME':str(isolated/'cache'),'XDG_DATA_HOME':str(isolated/'data'),
            'XDG_STATE_HOME':str(isolated/'state'),'GIMP3_DIRECTORY':str(isolated/'gimp-profile'),
            'GIMP3_CACHEDIR':str(isolated/'gimp-cache'),'GIMP3_TEMPDIR':str(isolated/'gimp-tmp'),
            'G_DEBUG':'fatal-warnings','LC_ALL':'C'}
 env.update(overrides)
 for name in ('DISPLAY','WAYLAND_DISPLAY','DBUS_SESSION_BUS_ADDRESS'):
  env.pop(name,None)
 for index,(name,argv,expected) in enumerate([
  ('foundation',['app/painter/painter-foundation','--tap'],0),
  ('gui-version',['app/gimp-3.0','--version'],0),
  ('console-version',['app/gimp-console-3.0','--version'],0),
  ('worker-rejected-version',['app/gimp-painter-filter-worker','--version'],125),
 ]):
  binary=build/argv[0]
  sha=hashlib.sha256(binary.read_bytes()).hexdigest()
  if argv[0] in report['artifacts']:
   assert sha==report['artifacts'][argv[0]]['sha256'],'Export-checked binary changed'
  result=subprocess.run([str(binary)]+argv[1:],env=env,stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,text=True,timeout=60,cwd=isolated)
  stdout=args.output/(name+'.stdout.log'); stderr=args.output/(name+'.stderr.log')
  stdout.write_text(result.stdout);stderr.write_text(result.stderr)
  passed=result.returncode==expected
  cases=None
  if name=='foundation':
   cases=sum(line.startswith('ok ') for line in result.stdout.splitlines())
   passed=passed and cases==39 and not any(line.startswith('not ok ') for line in result.stdout.splitlines())
  elif name in ('gui-version','console-version'):
   passed=passed and 'GNU Image Manipulation Program version' in result.stdout
  else:
   passed=passed and not result.stdout and not result.stderr
  results.append({'name':name,'command':[str(binary)]+argv[1:],'binary_sha256':sha,
                  'returncode':result.returncode,'expected_returncode':expected,
                  'test_cases':cases,'passed':passed,'isolated_entries_after_check':sorted(str(p.relative_to(isolated)) for p in isolated.rglob('*')),'stdout_sha256':hashlib.sha256(result.stdout.encode()).hexdigest(),
                  'stderr_sha256':hashlib.sha256(result.stderr.encode()).hexdigest()})
 created=sorted(str(p.relative_to(isolated)) for p in isolated.rglob('*'))
 created_files=sorted(str(p.relative_to(isolated)) for p in isolated.rglob('*') if not p.is_dir())
 profile_created=(isolated/'gimp-profile').exists()
 allowed_empty_data=not created_files and not profile_created and set(created)<= {'data'}
result={'configuration':report['configuration'],'status':'PASS' if all(x['passed'] for x in results) and allowed_empty_data else 'FAIL',
        'checks':results,'runtime_environment_overrides':overrides,'display_and_session_bus_removed':True,
        'isolated_directory_entries_created':created,'isolated_files_created':created_files,'profile_directory_created':profile_created,'only_allowed_empty_xdg_data_directory':allowed_empty_data,'profile_started':False,'gui_started':False,'listener_started':False,
        'worker_note':'Unsupported --version is rejected by main with 125 before worker protocol/profile initialization.'}
(args.output/'report.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
raise SystemExit(0 if result['status']=='PASS' else 1)
