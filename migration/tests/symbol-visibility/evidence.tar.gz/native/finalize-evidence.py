from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile
root=Path(__file__).resolve().parent
repo=root.parents[1]
restore=repo.parent/'gimp-native-restore-20261008'
destination=repo/'migration/tests/symbol-visibility'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
summary={'task':'original WBS 04.012 native symbol visibility','status':'PASS','baseline_head':json.loads((root/'checkpoint.json').read_text())['head'],'configurations':{},'source_stability':json.loads((root/'source-stability.json').read_text()),'checker_self_tests':7,'baseline_source_manifest_sha256':sha(root/'source-baseline.json'),'verified_source_manifest_sha256':sha(root/'source-post-attempt2.json'),'limitations':['Native Linux x86_64 GCC14 ELF evidence only; Windows/macOS visibility and runtimes are not established.','Application runtime checks stop at --version or the worker invalid-argument guard; no GUI, profile or HTTP listener starts.','Generic/upstream inline C++ exports also decrease under the C++-only hidden-inline switch; these are separately enumerated and are not presented as preserved C exports.'],'diagnosed_attempts':{'first_native_attempt':'Builds succeeded, but17 C exports were inadvertently hidden in all6 executables; HTTP GUI/console retained3 private class vtables, and new visibility warnings were emitted. Explicit C-entry attributes, attributed forward declarations, hidden opaque holder and source-only HTTP namespace annotations corrected these gates. Original failure reports and warnings are retained.','first_runtime_harness':'All39 foundation cases and expected process exits passed. An overly strict zero-directory assertion rejected creation of an empty isolated XDG data directory by GUI --version. Revised harness still rejects files/profile creation and records each process; bounded reruns passed.'}}
guards=[]
for variant in ('default','http'):
 baseline=json.loads((root/f'baseline-{variant}-exports/report.json').read_text())
 final=json.loads((root/f'verified-{variant}-exports/report.json').read_text())
 runtime=json.loads((root/f'runtime-verified-{variant}/report.json').read_text())
 layout=json.loads((root/'record-layout'/variant/'report.json').read_text())
 warnings=json.loads((root/'attempt-2-build'/variant/'warning-comparison.json').read_text())
 original=(restore/('build-'+variant)/'build.ninja').read_text()
 guarded=(restore/(variant+'.ninja')).read_text()
 substitutions=json.loads((restore/(variant+'-protected-generators.json')).read_text())
 replay=original
 for item in substitutions:
  replay=replay.replace(' COMMAND = '+item['original_command']+'\n',' COMMAND = '+item['replacement_command']+'\n',1)
 guard={'configuration':variant,'protected_generator_recipes':len(substitutions),'all_other_manifest_bytes_unchanged':replay==guarded,'original_manifest_sha256':hashlib.sha256(original.encode()).hexdigest(),'guarded_manifest_sha256':hashlib.sha256(guarded.encode()).hexdigest()}
 links={block.split(': ',1)[0][6:]:block for block in original.split('\n\n') if block.startswith('build ') and block.split(': ',1)[0][6:] in final['artifacts']}
 baseline_links=json.loads((root/'baseline'/variant/'link-recipes.json').read_text())
 guard['all21_normal_link_recipes_unchanged']=links==baseline_links
 guard['application_export_dynamic_retained']=all('--export-dynamic' in links[name] for name,kind in final['output_kinds'].items() if kind=='application')
 assert guard['all21_normal_link_recipes_unchanged'] and guard['application_export_dynamic_retained']
 guards.append(guard)
 assert guard['protected_generator_recipes']==17 and guard['all_other_manifest_bytes_unchanged']
 assert final['status']==runtime['status']==layout['status']==warnings['status']=='PASS'
 applications={}
 other={}
 for name,kind in final['output_kinds'].items():
  if kind!='application':continue
  old=baseline['artifacts'][name];new=final['artifacts'][name];diff=final['comparison']['exports'][name]
  applications[name]={'baseline_defined_dynamic':old['defined_dynamic_count'],'final_defined_dynamic':new['defined_dynamic_count'],'baseline_private_cpp':len(old['private_cpp_exports']),'final_private_cpp':len(new['private_cpp_exports']),'removed_private_cpp':len(diff['removed_private_cpp']),'removed_other_cpp':len(diff['removed_other_cpp']),'removed_c':diff['removed_c'],'baseline_nonmangled_count':old['defined_dynamic_count']-old['cpp_dynamic_count'],'binary_sha256':new['sha256']}
  for symbol in diff['removed_other_cpp']:other[symbol['name']]=symbol['demangled']
 dump(destination/(variant+'-removed-other-cpp.json'),other)
 summary['configurations'][variant]={'status':'PASS','applications':applications,'c_compile_vectors_unchanged':len(final['compile_vectors']['c']),'upstream_cc_commands':len(final['compile_vectors']['upstream_cc']),'upstream_cc_commands_with_only_added_hidden_inline':len(final['comparison']['upstream_cc_flag_changes']),'sdk_libraries_binary_and_export_identical':sum(kind=='sdk' for kind in final['output_kinds'].values()),'c_modules_binary_and_export_identical':sum(kind=='module' for kind in final['output_kinds'].values()),'module_entry_names':['gimp_module_query','gimp_module_register'],'install_manifest_entries_unchanged':len(final['installed']),'private_app_sdk_installs':final['private_app_sdk_installs'],'foundation_cases_passed':next(x['test_cases'] for x in runtime['checks'] if x['name']=='foundation'),'process_exit_checks':{x['name']:x['returncode'] for x in runtime['checks']},'runtime_files_created':runtime['isolated_files_created'],'runtime_profile_created':runtime['profile_directory_created'],'runtime_empty_xdg_data_directory_created':runtime['isolated_directory_entries_created']==['data'],'record_layout':{'records':layout['records'],'fields':layout['fields'],'baseline_current_c_cpp_equal':layout['all_c_cpp_baseline_current_layouts_equal']},'new_compiler_warning_kinds':warnings['new_warning_kinds'],'preexisting_warning_kinds':warnings['preexisting_warning_kinds'],'unique_other_cpp_exports_removed':len(other),'full_export_report':f'native/verified-{variant}-exports/report.json'}
assert summary['source_stability']['status']=='PASS'
dump(root/'final-generator-guard.json',guards)
dump(destination/'report.json',summary)
(root/'production.patch').write_text(subprocess.check_output(['git','diff','--','app'],cwd=repo,text=True))
# Explicit allowlist: native evidence and compiler inputs only. No inherited
# environment dumps, unrelated scratch files, browser state, or conversation.
selected={}
def add(path,name=None):
 assert path.is_file(),path
 selected[name or ('native/'+str(path.relative_to(root)))]=path
for name in ('source-baseline.json','source-pre-final-build.json','source-pre-attempt2.json','source-post-attempt2.json','source-stability.json','baseline-generator-guard.json','final-generator-guard.json','checker-self-test.log','check-record-layout.py','run-runtime-checks.py','run-runtime-checks-attempt1.py','compare-build-warnings.py','finalize-evidence.py','production.patch','control-targets.json'):
 add(root/name)
for variant in ('default','http'):
 for phase in ('baseline','verified','final'):
  directory=root/f'{phase}-{variant}-exports'
  for name in ('report.json','summary.json'):add(directory/name)
  if phase!='final':
   for file in sorted(directory.rglob('*.txt')):add(file)
 for stage in ('baseline','attempt-1-build','attempt-2-build'):
  directory=root/stage/variant
  names=['build.log','build-result.json']
  if stage=='baseline':names+=['controls-build.log','controls-build.result.json','link-recipes.json']
  else:names+=['build-command.json','warning-comparison.json']
  if stage in ('baseline','attempt-2-build'):names+=['build.ninja','compile_commands.json','intro-targets.json','intro-buildoptions.json']
  for name in names:add(directory/name)
 for name in ('configure.log','configure-result.json','protected-generators.json','compile-scope-check.json'):
  add(root/'final-build'/variant/name)
 for phase in ('runtime','runtime-verified'):
  for file in sorted((root/(phase+'-'+variant)).iterdir()):
   if file.is_file() and (file.suffix=='.json' or file.suffix=='.log'):add(file)
 for file in sorted((root/'record-layout'/variant).iterdir()):
  if file.is_file() and file.suffix in ('.json','.h','.log','.txt'):add(file)
 for file in sorted(restore.glob(variant+'-*-result.json')):add(file,'generators/'+file.name)
 add(restore/(variant+'-protected-generators.json'),'generators/'+variant+'-protected-generators.json')
for file in sorted((root/'namespace-probe').rglob('*')):
 if file.is_file() and file.suffix in ('.json','.txt','.md','.py','.c','.cpp','.hpp','.stdout'):
  add(file)
for name in ('prepare-verification.py','safe-generator.py','env-main.sh','env-http.sh','recovery-report.json'):
 add(restore/name,'recovery/'+name)
for name in ('tools/check_painter_symbol_visibility.py','app/painter/gimp-painter-visibility.h','migration/tests/symbol-visibility/filter-record-layout.c','migration/tests/symbol-visibility/README.md','migration/tests/symbol-visibility/report.json','migration/tests/symbol-visibility/default-removed-other-cpp.json','migration/tests/symbol-visibility/http-removed-other-cpp.json'):
 add(repo/name,'repository/'+name)
archive=destination/'evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as handle:
 for name,path in sorted(selected.items()):handle.add(path,arcname=name,recursive=False)
manifest={'archive':archive.name,'archive_sha256':sha(archive),'size':archive.stat().st_size,'files':{name:{'sha256':sha(path),'size':path.stat().st_size} for name,path in sorted(selected.items())}}
with tarfile.open(archive) as handle:
 for name,item in manifest['files'].items():
  assert hashlib.sha256(handle.extractfile(name).read()).hexdigest()==item['sha256'],name
manifest['archive_members_verified']=len(manifest['files'])
dump(destination/'evidence-manifest.json',manifest)
print(json.dumps({'status':summary['status'],'archive':str(archive),'size':archive.stat().st_size,'files':len(selected),'sha256':manifest['archive_sha256']},indent=2))
