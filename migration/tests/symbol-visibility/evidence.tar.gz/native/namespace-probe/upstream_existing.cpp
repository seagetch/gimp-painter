// Separately compiled pre-existing upstream C++ translation unit.
namespace ExistingUpstream {
inline int inline_entry () { return 41; }
int cpp_entry () { return inline_entry (); }
}
