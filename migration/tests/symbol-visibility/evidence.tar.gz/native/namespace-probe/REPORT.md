# WBS04.012 isolated namespace visibility probe

Result: native GCC 14.2.0 / ELF x86_64 Linux, C++14, binutils 2.44.
All eight final variants build without warnings and pass both a shared-library
client and a directly linked `--export-dynamic` executable. This is synthetic
evidence, not the production object/export audit. No Windows or macOS runtime or
compiler result is implied. No repository sources, production objects, or build
targets were modified by this probe.

## Smallest reliable recommendation

Use a dependency-free private header macro, then annotate the namespace blocks
that introduce private declarations. The exact tested macro is:

```cpp
#if defined(__GNUC__) && defined(__ELF__)
# define GIMP_PAINTER_PRIVATE __attribute__((visibility("hidden")))
#else
# define GIMP_PAINTER_PRIVATE
#endif

namespace GimpPainter GIMP_PAINTER_PRIVATE {
// Private declarations, class and template definitions.
}
```

This ELF-specific guard deliberately confines the claim to the tested platform;
separately choosing support for another object format requires its own platform
policy and validation. The macro needs no GLib include and can be used by the
standalone geometry kernels. For a class outside the private namespace, the
tested equivalent is `class GIMP_PAINTER_PRIVATE PrivateClass { ... };`.

Keep the global C ABI declarations outside the hidden namespace. Do not apply
target-wide `-fvisibility=hidden` to mixed C/C++ targets as a substitute for this
declaration boundary.

Header attributes alone do not guarantee that every emitted template symbol
whose name contains a private class is hidden. At O0, two weak `std::__shared_count`
constructor aliases parameterized by the hidden class still have DEFAULT
visibility and enter `.dynsym`. `-fvisibility-inlines-hidden` on the private C++
translation units removes those aliases. This flag also hides an ordinary
upstream inline function when it is emitted in that same translation unit. Thus
scope it to the Painter C++ sources, leaving pre-existing upstream C++ sources
compiled with their original flags. The probe verifies the separately compiled
upstream inline and out-of-line entries stay exported in that arrangement. If a
real private source also owns a contractual upstream inline export, preserve
that declaration explicitly or use a finer-grained design; this probe does not
establish that target-wide hidden-inline is safe for the real export baseline.

## Observations

- A function and class declared inside an annotated namespace remain HIDDEN
  when their definitions appear in an unannotated namespace reopening
- A new function first declared/defined in that reopening is GLOBAL DEFAULT and
  exported. Namespace visibility is not a permanent property of the namespace;
  annotate every block that introduces new private declarations, or explicitly
  annotate those declarations
- A primary `TypeTraits<T>` declared in the hidden namespace makes a later
  explicit `TypeTraits<LaterForeignObject>` specialization's emitted member
  HIDDEN, even though the specialization is defined in an unannotated reopening
  and its argument is a public foreign type
- The hidden `HiddenClass` methods, vtable, RTTI/typeinfo (when RTTI is enabled),
  and `std::_Sp_counted_ptr_inplace<HiddenClass,...>` control-block typeinfo are
  HIDDEN. The two `std::__shared_count` member-template constructor aliases are
  the observed O0 exception until hidden-inline is applied
- With `-fno-rtti`, no `HiddenClass` RTTI or shared control-block typeinfo is
  emitted by this probe, but `HiddenError` exception typeinfo is still emitted
  and HIDDEN. Both catch/throw paths run successfully. Disabling RTTI is not a
  promise of absence of all typeinfo
- At O2 the two class-name-bearing constructor aliases disappear through
  optimization even without hidden-inline. Do not rely on that optimization to
  enforce the visibility boundary; O0 exposes the gap
- `painter_c_entry`, `upstream_c_entry`, upstream out-of-line C++ entry, and the
  separately compiled upstream inline/out-of-line C++ entries remain DEFAULT
  exports and callable in every final variant. The C object is compiled once,
  unchanged, and reused across all variants

The intentionally public negative-control function remains exported in every
variant. No assertion claims its absence or treats it as a production leak.

| Variant | Shared defined exports | Project-name exports |
|---|---:|---:|
| Default, RTTI | 104 | Full baseline in summary.json |
| Hidden declarations, RTTI | 37 | 3: negative control + 2 shared_count aliases |
| Hidden declarations + hidden-inline, RTTI | 16 | 1: negative control |
| Default, no RTTI | 91 | Full baseline in summary.json |
| Hidden declarations, no RTTI | 29 | 3: negative control + 2 shared_count aliases |
| Hidden declarations + hidden-inline, no RTTI | 9 | 1: negative control |
| Hidden declarations, O2, no RTTI | 9 | 1: negative control |
| Hidden declarations + hidden-inline, O2, no RTTI | 7 | 1: negative control |

Counts include ordinary standard-library metadata/helpers as well as the test
entries; they are not a claim that all non-C names disappeared.

## Reproduction and evidence

From the active checkout:

```sh
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261008/env-main.sh
python3 scratch/gimp-symbol-visibility-04012/namespace-probe/run_probe.py
```

- `private.hpp`, `private.cpp`, `upstream.c`, `upstream_existing.cpp`, `main.cpp`:
  actual synthetic sources
- `run_probe.py`: exact builds and assertions, no original target/object writes
- `metadata.json`: compiler, native environment path, base HEAD, input hashes
- `commands.json`: exact commands, exit codes, stdout, stderr
- `findings.json`: concise selected object visibility and export observations
- `summary.json`: complete checked variant summaries
- `run.stdout`, `run.stderr`: final run output (eight PASS variants; empty stderr)
- Each variant directory preserves `.o`, `.so`, both executables, runtime output,
  wide readelf symbols/dynamic symbols, parsed records and demangled nm output
- `initial-assumption-run/` preserves the initial failed assertion demonstrating
  that namespace attributes alone do not suppress all private-type template
  exports. `phase1-namespace-inline/` preserves the intermediate eight-variant
  run before adding the separately compiled upstream-inline control

The final source checks use two clients per variant, 16 successful runtime
executions total, and independently inspect the shared-library and exported
executable dynamic symbol tables.
