// Isolated GCC/ELF experiment. Deliberately no GLib/GIMP includes.
#ifndef NAMESPACE_PROBE_PRIVATE_HPP
#define NAMESPACE_PROBE_PRIVATE_HPP
#include <memory>
#include <typeinfo>

#if defined(__GNUC__) && defined(__ELF__) && !defined(PROBE_DISABLE_VISIBILITY)
# define PROBE_PRIVATE __attribute__((visibility("hidden")))
#else
# define PROBE_PRIVATE
#endif

// C ABI declarations stay outside the annotated private namespace.
extern "C" int painter_c_entry ();
extern "C" int upstream_c_entry ();

struct ForeignObject {};
struct LaterForeignObject {};

namespace ProbePainter PROBE_PRIVATE {
int declared_before_reopening ();
class HiddenClass {
public:
  explicit HiddenClass (int value);
  virtual ~HiddenClass ();
  virtual int value () const;
private:
  int value_;
};
struct HiddenError { int code; };
template<class T> struct TypeTraits;
template<> struct TypeTraits<ForeignObject> {
  static int type () { return 5; }
};
template<class T> struct ObjectRef {
  int type () const { return TypeTraits<T>::type (); }
};
std::shared_ptr<HiddenClass> make_private ();
int private_exception_roundtrip ();
int traits_roundtrip ();
inline int declared_inline () { return 11; }
#if !defined(PROBE_NO_RTTI)
const std::type_info& private_rtti ();
#endif
}

// Class-level alternative, no namespace annotation.
class PROBE_PRIVATE StandalonePrivateClass {
public:
  int method () const;
};

// Ordinary upstream declarations are not annotated.
namespace Upstream {
int cpp_entry ();
inline int inline_entry () { return 13; }
}
#endif
