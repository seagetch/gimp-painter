int upstream_c_entry (void) { return 37; }
