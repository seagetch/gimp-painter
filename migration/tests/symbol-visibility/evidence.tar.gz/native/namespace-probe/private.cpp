#include "private.hpp"

// Intentionally UNANNOTATED reopening: previous declarations retain visibility.
namespace ProbePainter {
int declared_before_reopening () { return 17; }
HiddenClass::HiddenClass (int value) : value_ (value) {}
HiddenClass::~HiddenClass () = default;
int HiddenClass::value () const { return value_; }
std::shared_ptr<HiddenClass> make_private ()
{
  return std::make_shared<HiddenClass> (19);
}

// Explicit specialization appears later in an unannotated namespace reopening.
template<> struct TypeTraits<LaterForeignObject> {
  static int type () { return 7; }
};
int traits_roundtrip ()
{
  return ObjectRef<ForeignObject>{}.type ()
       + ObjectRef<LaterForeignObject>{}.type ();
}
int private_exception_roundtrip ()
{
  try { throw HiddenError{23}; }
  catch (const HiddenError& error) { return error.code; }
}
#if !defined(PROBE_NO_RTTI)
const std::type_info& private_rtti () { return typeid (HiddenClass); }
#endif

// NEGATIVE CONTROL: newly introduced function has no prior hidden declaration.
int new_in_unannotated_reopening () { return 29; }
}

int StandalonePrivateClass::method () const { return 31; }
namespace Upstream {
int cpp_entry () { return inline_entry (); }
}
extern "C" int painter_c_entry ()
{
  auto private_value = ProbePainter::make_private ();
  return private_value->value ()
       + ProbePainter::declared_before_reopening ()
       + ProbePainter::traits_roundtrip ()
       + ProbePainter::private_exception_roundtrip ()
       + ProbePainter::declared_inline ()
       + ProbePainter::new_in_unannotated_reopening ()
       + StandalonePrivateClass{}.method ();
}
