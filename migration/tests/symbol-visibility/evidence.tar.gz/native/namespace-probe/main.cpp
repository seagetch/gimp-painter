#include <cstdio>
extern "C" int painter_c_entry ();
extern "C" int upstream_c_entry ();
namespace Upstream { int cpp_entry (); }
namespace ExistingUpstream { int cpp_entry (); }
int main ()
{
  int painter = painter_c_entry ();
  int upstream_c = upstream_c_entry ();
  int upstream_cpp = Upstream::cpp_entry ();
  int existing_upstream_cpp = ExistingUpstream::cpp_entry ();
  std::printf ("painter=%d upstream_c=%d upstream_cpp=%d existing_upstream_cpp=%d\n",
               painter, upstream_c, upstream_cpp, existing_upstream_cpp);
  return painter == 142 && upstream_c == 37 && upstream_cpp == 13
         && existing_upstream_cpp == 41 ? 0 : 1;
}
