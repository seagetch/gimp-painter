#include <cstdio>
extern "C" int painter_c_entry ();
extern "C" int upstream_c_entry ();
namespace Upstream { int cpp_entry (); }
int main ()
{
  int painter = painter_c_entry ();
  int upstream_c = upstream_c_entry ();
  int upstream_cpp = Upstream::cpp_entry ();
  std::printf ("painter=%d upstream_c=%d upstream_cpp=%d\n",
               painter, upstream_c, upstream_cpp);
  return painter == 142 && upstream_c == 37 && upstream_cpp == 13 ? 0 : 1;
}
