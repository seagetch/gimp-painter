#!/usr/bin/env python3
"""Bounded isolated experiment; no repository source/build-target mutation."""
import datetime
import hashlib
import json
from pathlib import Path
import platform
import subprocess

ROOT = Path(__file__).resolve().parent
LOG = []

def run(args, output=None):
    result = subprocess.run(args, cwd=ROOT, text=True, capture_output=True)
    LOG.append({"command": args, "cwd": str(ROOT), "returncode": result.returncode,
                "stdout": result.stdout, "stderr": result.stderr})
    (ROOT / "commands.json").write_text(json.dumps(LOG, indent=2) + "\n")
    if output:
        (ROOT / output).write_text(result.stdout)
    if result.returncode:
        raise RuntimeError(f"Failed: {args!r}: {result.stderr}")
    return result.stdout

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def symbols(path, dynamic=False):
    cmd = ["readelf", "--wide", "--dyn-syms" if dynamic else "--syms", str(path)]
    rows = []
    for line in run(cmd, f"{path}.{'dyn' if dynamic else 'all'}.readelf.txt").splitlines():
        columns = line.split()
        if len(columns) >= 8 and columns[0].rstrip(":").isdigit():
            rows.append(dict(zip(["number", "value", "size", "type", "bind", "visibility", "ndx", "name"], columns[:8])))
    names = [row["name"] for row in rows]
    demangled = subprocess.run(["c++filt"], input="\n".join(names), capture_output=True, text=True, check=True).stdout.splitlines()
    for row, name in zip(rows, demangled):
        row["demangled"] = name
    (ROOT / f"{path}.{'dyn' if dynamic else 'all'}.json").write_text(json.dumps(rows, indent=2) + "\n")
    return rows

variants = [
    ("default-rtti", ["-O0", "-DPROBE_DISABLE_VISIBILITY"]),
    ("hidden-rtti", ["-O0"]),
    ("hidden-inline-rtti", ["-O0", "-fvisibility-inlines-hidden"]),
    ("default-no-rtti", ["-O0", "-DPROBE_DISABLE_VISIBILITY", "-fno-rtti", "-DPROBE_NO_RTTI"]),
    ("hidden-no-rtti", ["-O0", "-fno-rtti", "-DPROBE_NO_RTTI"]),
    ("hidden-inline-no-rtti", ["-O0", "-fno-rtti", "-DPROBE_NO_RTTI", "-fvisibility-inlines-hidden"]),
    ("hidden-o2-no-rtti", ["-O2", "-fno-rtti", "-DPROBE_NO_RTTI"]),
    ("hidden-inline-o2-no-rtti", ["-O2", "-fno-rtti", "-DPROBE_NO_RTTI", "-fvisibility-inlines-hidden"]),
]

metadata = {
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "Native Linux ELF probe only, synthetic C/C++14 sources",
    "repo_head": run(["git", "rev-parse", "HEAD"]).strip(),
    "native_environment": "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008/env-main.sh",
    "compiler": run(["c++", "--version"]).splitlines()[0],
    "target": run(["c++", "-dumpmachine"]).strip(),
    "binutils": run(["readelf", "--version"]).splitlines()[0],
    "platform": platform.platform(),
    "inputs_sha256": {name: digest(ROOT / name) for name in ["private.hpp", "private.cpp", "upstream.c", "main.cpp", "run_probe.py"]},
    "applicable_instructions": ["tasks.md sections 1-2", "README", "devel-docs/README.md (no applicable AGENTS.md found)"],
}
(ROOT / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
run(["cc", "-std=c11", "-O0", "-fPIC", "-Wall", "-Wextra", "-Werror", "-c", "upstream.c", "-o", "upstream.o"])
run(["c++", "-std=c++14", "-O0", "-Wall", "-Wextra", "-Werror", "-c", "main.cpp", "-o", "main.o"])
symbols("upstream.o")

summary = []
for name, flags in variants:
    (ROOT / name).mkdir(exist_ok=True)
    obj = f"{name}/private.o"
    lib = f"{name}/libnamespace-probe.so"
    exe = f"{name}/export-dynamic-probe"
    client = f"{name}/shared-library-client"
    run(["c++", "-std=c++14", "-fPIC", "-Wall", "-Wextra", "-Werror", *flags, "-c", "private.cpp", "-o", obj])
    run(["c++", "-shared", "-Wl,--no-undefined", obj, "upstream.o", "-o", lib])
    run(["c++", "-Wl,--export-dynamic", "main.o", obj, "upstream.o", "-o", exe])
    run(["c++", "main.o", f"-L{name}", "-lnamespace-probe", "-Wl,-rpath,$ORIGIN", "-o", client])
    run([f"./{exe}"], f"{name}/executable.stdout")
    run([f"./{client}"], f"{name}/shared-client.stdout")
    full = symbols(obj)
    dynamic = symbols(lib, dynamic=True)
    executable_dynamic = symbols(exe, dynamic=True)
    run(["nm", "-D", "-C", "--defined-only", lib], f"{lib}.nm.txt")
    run(["nm", "-D", "-C", "--defined-only", exe], f"{exe}.nm.txt")
    exported = [row for row in dynamic if row["ndx"] != "UND"]
    executable_exported = [row for row in executable_dynamic if row["ndx"] != "UND"]
    selected = [row for row in full if any(key in row["demangled"] for key in ["ProbePainter", "StandalonePrivateClass", "Upstream", "painter_c_entry", "upstream_c_entry"])]
    row = {
        "variant": name, "flags": flags, "runtime": "PASS: direct export-dynamic and shared-library clients",
        "defined_shared_exports": len(exported), "defined_executable_exports": len(executable_exported),
        "project_shared_exports": [s["demangled"] for s in exported if "ProbePainter" in s["demangled"] or "StandalonePrivateClass" in s["demangled"]],
        "selected_object_symbols": selected,
        "assertions": [],
    }
    for label, symbols_to_check in [("shared", exported), ("export_dynamic", executable_exported)]:
        public_names = [s["demangled"] for s in symbols_to_check]
        for entry in ["painter_c_entry", "upstream_c_entry", "Upstream::cpp_entry()", "ProbePainter::new_in_unannotated_reopening()"]:
            assert entry in public_names, (name, label, entry, "missing public entry")
        row["assertions"].append(f"{label}: C ABI, upstream C/C++, and unannotated-reopening negative control exported")
        if not name.startswith("default"):
            own = [s for s in public_names if "ProbePainter" in s or "StandalonePrivateClass" in s]
            assert own == ["ProbePainter::new_in_unannotated_reopening()"], (name, label, own)
            row["assertions"].append(f"{label}: all annotated private project symbols and dependent templates excluded")
    hidden = [s for s in selected if s["visibility"] == "HIDDEN"]
    if not name.startswith("default"):
        assert any(s["demangled"] == "ProbePainter::declared_before_reopening()" for s in hidden)
        assert any(s["demangled"] == "StandalonePrivateClass::method() const" for s in hidden)
        if "o2" not in name:
            assert any(s["demangled"] == "ProbePainter::TypeTraits<LaterForeignObject>::type()" for s in hidden)
        assert any(s["demangled"] == "typeinfo for ProbePainter::HiddenError" for s in hidden)
    summary.append(row)
    (ROOT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(name, len(exported), "defined shared exports; checks passed", flush=True)
print("All native probe variants passed.", flush=True)
