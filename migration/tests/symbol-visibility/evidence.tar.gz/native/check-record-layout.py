from pathlib import Path
import argparse,hashlib,json,subprocess,sys
parser=argparse.ArgumentParser();parser.add_argument('variant',choices=('default','http'));args=parser.parse_args()
repo=Path(__file__).resolve().parents[2];sys.path.insert(0,str(repo/'tools'))
from check_painter_exception_flags import replay_arguments
out=Path(__file__).resolve().parent/'record-layout'/args.variant;out.mkdir(parents=True,exist_ok=False)
baseline_header=out/'baseline-gimpfilterlayer.h'
head=json.loads((Path(__file__).resolve().parent/'checkpoint.json').read_text())['head']
baseline_header.write_bytes(subprocess.check_output(['git','show',head+':app/core/gimpfilterlayer.h'],cwd=repo))
expected=json.loads((Path(__file__).resolve().parent/'source-baseline.json').read_text())['app/core/gimpfilterlayer.h']
assert hashlib.sha256(baseline_header.read_bytes()).hexdigest()==expected
current_header=repo/'app/core/gimpfilterlayer.h'
fixture=repo/'migration/tests/symbol-visibility/filter-record-layout.c'
build=repo.parent/'gimp-native-restore-20261008'/('build-'+args.variant)
current_database=json.loads((build/'compile_commands.json').read_text())
baseline_database=json.loads((Path(__file__).resolve().parent/'baseline'/args.variant/'compile_commands.json').read_text())
results=[]
for phase,header,database in [('baseline',baseline_header,baseline_database),('current',current_header,current_database)]:
 for language,source in [('c','app/core/gimpdrawable.c'),('cpp','app/core/gimpfilterlayer.cpp')]:
  template=next(entry for entry in database if entry['file'].endswith('/'+source))
  target=out/(phase+'-'+language)
  command=replay_arguments(template)+['-x','c++' if language=='cpp' else 'c', '-DGIMP_FILTER_LAYOUT_HEADER="'+str(header)+'"',str(fixture),'-o',str(target)]
  compile_result=subprocess.run(command,cwd=template['directory'],text=True,capture_output=True)
  (out/(target.name+'-compile.log')).write_text(compile_result.stdout+compile_result.stderr)
  runtime=None
  if compile_result.returncode==0:
   run=subprocess.run([str(target)],text=True,capture_output=True)
   (out/(target.name+'-output.txt')).write_text(run.stdout)
   (out/(target.name+'-stderr.txt')).write_text(run.stderr)
   runtime={'returncode':run.returncode,'output':run.stdout,'stderr':run.stderr}
  results.append({'phase':phase,'language':language,'command':command,'compile_returncode':compile_result.returncode,'header_sha256':hashlib.sha256(header.read_bytes()).hexdigest(),'runtime':runtime})
passed=all(r['compile_returncode']==0 and r['runtime']['returncode']==0 and not r['runtime']['stderr'] for r in results)
outputs={r['runtime']['output'] for r in results if r['runtime']}
report={'configuration':args.variant,'status':'PASS' if passed and len(outputs)==1 else 'FAIL','fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'baseline_header_matches_frozen_hash':True,'all_c_cpp_baseline_current_layouts_equal':passed and len(outputs)==1,'records':3,'fields':15,'results':results}
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='results'},indent=2));raise SystemExit(0 if report['status']=='PASS' else 1)
