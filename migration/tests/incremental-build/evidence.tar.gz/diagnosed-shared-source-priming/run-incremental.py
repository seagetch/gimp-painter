from pathlib import Path
import fcntl,hashlib,json,os,re,subprocess,time

R=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active')
N=R.parent/'gimp-native-restore-20261008'
D=Path(__file__).resolve().parent
A=R.parent/'incremental-04015-audit'
audit=json.loads((A/'native-audit.json').read_text())
matrix=json.loads((A/'source-duty-matrix-v2.json').read_text())
HEADERS=['app/painter/gimp-painter-visibility.h','app/core/core-types.h']
FINALS=['app/gimp-3.0','app/gimp-console-3.0','app/gimp-painter-filter-worker']
sha=lambda b:hashlib.sha256(b).hexdigest()
original={p:(R/p).read_bytes() for p in HEADERS}
report={'status':'RUNNING','task':'04.015','scope':'Current native production closure of GUI,console,filter-worker in default/HTTP; excludes configured tests','headers':{p:sha(b) for p,b in original.items()},'trials':[]}

def save():
    (D/'runtime-report.json').write_text(json.dumps(report,indent=2)+'\n')

def run(variant,label,arguments):
    env=N/('env-main.sh' if variant=='default' else 'env-http.sh')
    command=['bash','-c','set -e\nsource "$1"\nshift\nexec "$@"','incremental-verification',str(env),'ninja','-f',str(N/(variant+'.ninja')),*arguments]
    log=D/(variant+'-'+label+'.log');start=time.monotonic()
    with log.open('wb') as output:
        p=subprocess.run(command,cwd=N/('build-'+variant),stdout=output,stderr=subprocess.STDOUT)
    record={'argv':command,'cwd':str(N/('build-'+variant)),'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name,'log_sha256':sha(log.read_bytes())}
    if p.returncode:raise RuntimeError(record)
    return record

def fresh_consumers(variant,header):
    result=run(variant,'dependency-query-'+Path(header).stem,['-t','deps'])
    wanted=str((R/header).resolve());prod=set(audit['variants'][variant]['production_object_paths'])
    consumers=set();obj=None
    for line in (D/result['log']).read_text().splitlines():
        if line and not line.startswith(' '):
            m=re.match(r'(.+): #deps \d+, deps mtime .+ \((VALID|STALE)\)$',line)
            obj=m[1] if m else None
            if obj in prod and m[2]!='VALID':raise RuntimeError('stale production dependency: '+obj)
        elif obj in prod and line.startswith('    '):
            dep=Path(line.strip());dep=dep if dep.is_absolute() else N/('build-'+variant)/dep
            if os.path.normpath(str(dep))==wanted:consumers.add(obj)
    return consumers,result

def universe(variant):
    variant_data=audit['variants'][variant];objects=set(variant_data['production_object_paths'])
    edges={}
    for line in (N/('build-'+variant)/'build.ninja').read_text().splitlines():
        if not line.startswith('build '):continue
        names,rest=line[6:].split(': ',1);tokens=rest.split();rule=tokens.pop(0)
        for name in names.split():edges[name]={'rule':rule,'inputs':[x for x in tokens if x not in ['|','||','|@']]}
    pending=list(FINALS);reachable=set()
    while pending:
        target=pending.pop()
        if target in reachable:continue
        reachable.add(target)
        if target in edges:pending.extend(edges[target]['inputs'])
    assert objects <= reachable
    archives={p for p in reachable if p in edges and edges[p]['rule']=='STATIC_LINKER'}
    return {'objects':sorted(objects),'archives':sorted(archives),'final_bins':FINALS}

def snapshot(variant,paths):
    build=N/('build-'+variant)
    return {kind:{p:{'mtime_ns':(build/p).stat().st_mtime_ns,'size':(build/p).stat().st_size}
                  for p in values} for kind,values in paths.items()}

def changes(before,after):
    return {kind:sorted(p for p in values if values[p]!=after[kind][p])
            for kind,values in before.items()}

lock=open('/tmp/gimp-painter-build.lock','a')
fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
    save()
    for variant in ['default','http']:
        paths=universe(variant)
        initial=snapshot(variant,paths)
        clean=run(variant,'baseline-noop',['-j3',*FINALS])
        assert all(not x for x in changes(initial,snapshot(variant,paths)).values()),'baseline is not clean'
        for header in HEADERS:
            expected=matrix['trial_expected_sets'][variant][header]
            consumers,dependency_query=fresh_consumers(variant,header)
            assert consumers==set(expected['expected_objects'])
            before=snapshot(variant,paths)
            row={'variant':variant,'header':header,'before':before,'expected':expected,
                 'dependency_query':dependency_query,'status':'RUNNING'}
            report['trials'].append(row);save()
            mutation=original[header]+b'\n/* WBS 04.015 shared-header dependency verification. */\n'
            try:
                (R/header).write_bytes(mutation)
                row['mutation_sha256']=sha(mutation)
                row['build']=run(variant,Path(header).stem+'-changed',['-j3','-v',*FINALS])
                after=snapshot(variant,paths);row['after']=after;row['changed']=changes(before,after)
                for kind in ['objects','archives','final_bins']:
                    assert set(row['changed'][kind])==set(expected['expected_'+kind]),(variant,header,kind,row['changed'][kind],expected['expected_'+kind])
                row['noop']=run(variant,Path(header).stem+'-noop',['-j3',*FINALS])
                row['noop_changes']=changes(after,snapshot(variant,paths))
                assert all(not x for x in row['noop_changes'].values())
            finally:
                (R/header).write_bytes(original[header])
            restore_before=snapshot(variant,paths)
            row['restore']=run(variant,Path(header).stem+'-restored',['-j3',*FINALS])
            restore_after=snapshot(variant,paths);row['restore_changes']=changes(restore_before,restore_after)
            for kind in ['objects','archives','final_bins']:
                assert set(row['restore_changes'][kind])==set(expected['expected_'+kind])
            row['restored_noop']=run(variant,Path(header).stem+'-restored-noop',['-j3',*FINALS])
            row['restored_noop_changes']=changes(restore_after,snapshot(variant,paths))
            assert all(not x for x in row['restored_noop_changes'].values())
            assert (R/header).read_bytes()==original[header]
            row['status']='PASS';save()
            print(json.dumps({'variant':variant,'header':header,'status':'PASS','objects':len(row['changed']['objects']),'archives':len(row['changed']['archives']),'finals':len(row['changed']['final_bins'])}),flush=True)
    subprocess.run(['git','diff','--quiet'],cwd=R,check=True)
    report.update(status='PASS',source_headers_restored=True,tracked_source_unchanged=True)
except BaseException as error:
    report.update(status='FAIL',error=str(error));raise
finally:
    for path,content in original.items():
        if (R/path).read_bytes()!=content:(R/path).write_bytes(content)
    save()
    fcntl.flock(lock,fcntl.LOCK_UN)
