#define _GNU_SOURCE
#include <dlfcn.h>
#include <execinfo.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
/* Diagnostic-only interposer: bounded symbols, no locals, memory or environment. */
void g_return_if_fail_warning(const char *domain, const char *function, const char *expression)
{
  typedef void (*handler)(const char *,const char *,const char *);
  static handler original;
  if (!original) original=(handler)dlsym(RTLD_NEXT,"g_return_if_fail_warning");
  if(function && !strcmp(function,"gimp_device_info_get_device")) {
    void *frames[32];
    int count=backtrace(frames,32);
    dprintf(2,"DEVICE_CRITICAL_STACK domain=%s function=%s expression=%s frames=%d\n",domain?domain:"",function,expression?expression:"",count);
    backtrace_symbols_fd(frames,count,2);
    dprintf(2,"END_DEVICE_CRITICAL_STACK\n");
  }
  if (original) original(domain,function,expression);
}
