#!/usr/bin/env bash
set -eo pipefail
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/env-http.sh
cd /workspace/scratch/5b5281e79681/sink-06003-gtk
exec > >(tee build.log) 2>&1
set -x
date -u +%FT%TZ
git -C ../gimp-painter-port-active rev-parse HEAD
pkg-config --modversion glib-2.0 gtk+-3.0
g++ --version
g++ -std=c++11 -O2 -g -Wall -Wextra -Werror -I../gimp-painter-port-active $(pkg-config --cflags gtk+-3.0) test-object-ref-gtk.cpp -o test-object-ref-gtk $(pkg-config --libs gtk+-3.0)
sha256sum test-object-ref-gtk.cpp test-object-ref-gtk ../gimp-painter-port-active/app/painter/object-ref.hpp > compiled-sha256.txt
cat compiled-sha256.txt
