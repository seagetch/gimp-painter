#!/usr/bin/env bash
set -eo pipefail
if [[ -z "${DISPLAY:-}" && -z "${WAYLAND_DISPLAY:-}" ]]; then
  echo 'SKIP: this shell has no existing desktop display'
  exit 77
fi
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/env-http.sh
cd /workspace/scratch/5b5281e79681/sink-06003-gtk
exec > >(tee run.log) 2>&1
set -x
date -u +%FT%TZ
sha256sum -c compiled-sha256.txt
set +e
G_DEBUG=fatal-warnings ./test-object-ref-gtk --verbose
test_result=$?
set -e
printf '%s\n' "$test_result" > run.exit
printf 'NATIVE_GTK_SINK_RUN_EXIT=%s\n' "$test_result"
exit "$test_result"
