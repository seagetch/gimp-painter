// Standalone native GTK verification of the unchanged production header.
#include <gtk/gtk.h>
#include "app/painter/object-ref.hpp"

struct Events { guint destroyed = 0; guint finalized = 0; };

// True GtkButton/GtkBox subclasses record GObject finalization independently
// of GtkWidget::destroy. A weak-notify callback alone is not sufficient:
// GtkWidget destruction can run dispose before the last owner releases it.
typedef struct { GtkButton parent; Events *events; } SinkProbeButton;
typedef struct { GtkButtonClass parent; } SinkProbeButtonClass;
G_DEFINE_TYPE (SinkProbeButton, sink_probe_button, GTK_TYPE_BUTTON)
static void sink_probe_button_finalize (GObject *object)
{
  auto *self = reinterpret_cast<SinkProbeButton *> (object);
  ++self->events->finalized;
  G_OBJECT_CLASS (sink_probe_button_parent_class)->finalize (object);
}
static void sink_probe_button_class_init (SinkProbeButtonClass *klass)
{ G_OBJECT_CLASS (klass)->finalize = sink_probe_button_finalize; }
static void sink_probe_button_init (SinkProbeButton *self)
{ self->events = nullptr; }

typedef struct { GtkBox parent; Events *events; } SinkProbeBox;
typedef struct { GtkBoxClass parent; } SinkProbeBoxClass;
G_DEFINE_TYPE (SinkProbeBox, sink_probe_box, GTK_TYPE_BOX)
static void sink_probe_box_finalize (GObject *object)
{
  auto *self = reinterpret_cast<SinkProbeBox *> (object);
  ++self->events->finalized;
  G_OBJECT_CLASS (sink_probe_box_parent_class)->finalize (object);
}
static void sink_probe_box_class_init (SinkProbeBoxClass *klass)
{ G_OBJECT_CLASS (klass)->finalize = sink_probe_box_finalize; }
static void sink_probe_box_init (SinkProbeBox *self)
{ self->events = nullptr; }

using Ref = GimpPainter::ObjectRef<GObject>;
static void destroyed (GtkWidget *, Events *events) { ++events->destroyed; }
static GtkWidget *button (Events &events)
{
  auto *self = static_cast<SinkProbeButton *> (g_object_new (
    sink_probe_button_get_type (), "label", "Native sink verification", nullptr));
  self->events = &events;
  g_signal_connect (self, "destroy", G_CALLBACK (destroyed), &events);
  return GTK_WIDGET (self);
}
static GtkWidget *box (Events &events)
{
  auto *self = static_cast<SinkProbeBox *> (g_object_new (
    sink_probe_box_get_type (), "orientation", GTK_ORIENTATION_VERTICAL, nullptr));
  self->events = &events;
  g_signal_connect (self, "destroy", G_CALLBACK (destroyed), &events);
  return GTK_WIDGET (self);
}
static void refs (GtkWidget *widget, guint expected)
{
  // All operations are synchronous on this main thread; no other owner runs.
  g_assert_cmpuint (G_OBJECT (widget)->ref_count, ==, expected);
}
static void events (const Events &value, guint destroy, guint finalize)
{
  g_assert_cmpuint (value.destroyed, ==, destroy);
  g_assert_cmpuint (value.finalized, ==, finalize);
}
static Ref sink (GtkWidget *widget) { return Ref::sink (G_OBJECT (widget)); }

static void floating_sink ()
{
  Events e;
  GtkWidget *child = button (e);
  g_assert_true (g_object_is_floating (child)); refs (child, 1);
  {
    auto owner = sink (child);
    g_assert_false (g_object_is_floating (child)); refs (child, 1);
    gtk_widget_destroy (child);
    events (e, 1, 0); refs (child, 1);
  }
  events (e, 1, 1);
  g_test_message ("floating sink: 1 -> 1; destroy precedes finalization; wrapper destructor finalizes once");
}

static void nonfloating_sink ()
{
  Events e;
  GtkWidget *child = button (e);
  g_object_ref_sink (child);
  g_assert_false (g_object_is_floating (child)); refs (child, 1);
  auto owner = sink (child);
  g_assert_false (g_object_is_floating (child)); refs (child, 2);
  gtk_widget_destroy (child); events (e, 1, 0); refs (child, 2);
  g_object_unref (child); events (e, 1, 0); refs (child, 1);
  owner.reset (); events (e, 1, 1);
  g_test_message ("nonfloating sink: 1 -> 2; original release leaves wrapper ref; reset finalizes once");
}

static void nonfloating_wrapper_first ()
{
  Events e;
  GtkWidget *child = button (e);
  g_object_ref_sink (child);
  {
    auto owner = sink (child); refs (child, 2);
  }
  refs (child, 1); events (e, 0, 0);
  gtk_widget_destroy (child); events (e, 1, 0);
  g_object_unref (child); events (e, 1, 1);
  g_test_message ("nonfloating sink: wrapper destroyed first preserves original owner and finalization occurs once");
}

static void wrapper_then_remove ()
{
  Events parent_events, child_events;
  GtkWidget *parent = box (parent_events), *child = button (child_events);
  auto parent_owner = sink (parent);
  auto child_owner = sink (child); refs (child, 1);
  gtk_container_add (GTK_CONTAINER (parent), child); refs (child, 2);
  child_owner.reset (); refs (child, 1); events (child_events, 0, 0);
  gtk_container_remove (GTK_CONTAINER (parent), child);
  events (child_events, 1, 1);
  parent_owner.reset (); events (parent_events, 1, 1);
  g_test_message ("already-sunk child: add 1 -> 2, wrapper release 2 -> 1, removal finalizes once");
}

static void remove_then_wrapper ()
{
  Events parent_events, child_events;
  GtkWidget *parent = box (parent_events), *child = button (child_events);
  auto parent_owner = sink (parent);
  auto child_owner = sink (child);
  gtk_container_add (GTK_CONTAINER (parent), child); refs (child, 2);
  gtk_container_remove (GTK_CONTAINER (parent), child);
  refs (child, 1); events (child_events, 0, 0);
  g_assert_null (gtk_widget_get_parent (child));
  child_owner.reset (); events (child_events, 1, 1);
  parent_owner.reset (); events (parent_events, 1, 1);
  g_test_message ("removal leaves wrapper-owned widget undestroyed; final wrapper release destroys/finalizes once");
}

static void container_destroy_then_wrapper ()
{
  Events parent_events, child_events;
  GtkWidget *parent = box (parent_events), *child = button (child_events);
  auto parent_owner = sink (parent);
  auto child_owner = sink (child);
  gtk_container_add (GTK_CONTAINER (parent), child); refs (child, 2);
  gtk_widget_destroy (parent);
  events (parent_events, 1, 0); events (child_events, 1, 0); refs (child, 1);
  parent_owner.reset (); events (parent_events, 1, 1);
  events (child_events, 1, 0);
  child_owner.reset (); events (child_events, 1, 1);
  g_test_message ("parent destroy destroys child but wrapper delays child finalization until reset; each finalizes once");
}

static void wrapper_then_container_destroy ()
{
  Events parent_events, child_events;
  GtkWidget *parent = box (parent_events), *child = button (child_events);
  auto parent_owner = sink (parent);
  {
    auto child_owner = sink (child);
    gtk_container_add (GTK_CONTAINER (parent), child); refs (child, 2);
  }
  refs (child, 1); events (child_events, 0, 0);
  gtk_widget_destroy (parent);
  events (parent_events, 1, 0); events (child_events, 1, 1);
  parent_owner.reset (); events (parent_events, 1, 1);
  g_test_message ("wrapper destructor first leaves container owner; container destroy finalizes child once");
}

static void container_first_sink ()
{
  Events parent_events, child_events;
  GtkWidget *parent = box (parent_events), *child = button (child_events);
  auto parent_owner = sink (parent);
  g_assert_true (g_object_is_floating (child)); refs (child, 1);
  gtk_container_add (GTK_CONTAINER (parent), child);
  g_assert_false (g_object_is_floating (child)); refs (child, 1);
  auto child_owner = sink (child); refs (child, 2);
  gtk_container_remove (GTK_CONTAINER (parent), child);
  events (child_events, 0, 0); refs (child, 1);
  child_owner.reset (); events (child_events, 1, 1);
  parent_owner.reset (); events (parent_events, 1, 1);
  g_test_message ("container consumes floating ref; later ObjectRef::sink adds independent ref; removal/reset finalize once");
}

int main (int argc, char **argv)
{
  if (!gtk_init_check (&argc, &argv))
    { g_printerr ("SKIP: no usable existing GTK display\n"); return 77; }
  g_test_init (&argc, &argv, nullptr);
  g_test_message ("Runtime GLib %u.%u.%u; GTK %u.%u.%u; display %s",
                  glib_major_version, glib_minor_version, glib_micro_version,
                  gtk_get_major_version (), gtk_get_minor_version (), gtk_get_micro_version (),
                  gdk_display_get_name (gdk_display_get_default ()));
  g_test_add_func ("/object-ref/gtk/floating-sink", floating_sink);
  g_test_add_func ("/object-ref/gtk/nonfloating-sink", nonfloating_sink);
  g_test_add_func ("/object-ref/gtk/nonfloating-wrapper-first", nonfloating_wrapper_first);
  g_test_add_func ("/object-ref/gtk/wrapper-then-remove", wrapper_then_remove);
  g_test_add_func ("/object-ref/gtk/remove-then-wrapper", remove_then_wrapper);
  g_test_add_func ("/object-ref/gtk/container-destroy-then-wrapper", container_destroy_then_wrapper);
  g_test_add_func ("/object-ref/gtk/wrapper-then-container-destroy", wrapper_then_container_destroy);
  g_test_add_func ("/object-ref/gtk/container-first-sink", container_first_sink);
  return g_test_run ();
}
