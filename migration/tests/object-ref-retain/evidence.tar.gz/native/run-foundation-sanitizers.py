from pathlib import Path
import hashlib,json,os,shlex,subprocess
base=Path(__file__).resolve().parent; repo=base.parent/'gimp-painter-port-active';build=base.parent/'gimp-native-restore-20261009/build-http';out=base/'foundation-sanitizers';out.mkdir(exist_ok=True)
db=json.loads((build/'compile_commands.json').read_text());commands=[];objects=[];source_hashes={}
sources=['app/painter/'+x for x in ['gimp-painter-error.cpp','gimp-painter-binding.cpp','binding-store.cpp']]+['app/painter/tests/'+x for x in ['test-c-api.c','test-fixture.c','test-hierarchy.c','test-hierarchy.cpp','test-foundation.cpp','test-resources.cpp','test-gobject.cpp','test-reentry.cpp']]
for i,source in enumerate(sources):
 matches=[r for r in db if (Path(r['directory'])/r['file']).resolve()==repo/source]
 row=next((r for r in matches if 'painter-foundation.p' in r['command']),matches[0]);argv=shlex.split(row['command']);clean=[];n=0
 while n<len(argv):
  if argv[n] in ('-o','-MF','-MQ'):n+=2;continue
  if argv[n]=='-MD':n+=1;continue
  if argv[n].startswith('-fdiagnostics-color'):n+=1;continue
  clean.append(argv[n]);n+=1
 obj=out/(str(i)+'.o');cmd=clean+['-O1','-g','-fsanitize=address,undefined','-fno-sanitize=vptr','-fno-omit-frame-pointer','-o',str(obj)]
 p=subprocess.run(cmd,cwd=build,text=True,capture_output=True);commands.append({'command':cmd,'cwd':str(build),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,source+'\n'+p.stderr
 objects.append(str(obj));source_hashes[source]=hashlib.sha256((repo/source).read_bytes()).hexdigest()
libs=shlex.split(subprocess.check_output(['pkg-config','--libs','gobject-2.0'],text=True));exe=out/'foundation-asan';cmd=['c++','-fsanitize=address,undefined','-fno-sanitize=vptr','-o',str(exe)]+objects+libs+['-pthread'];p=subprocess.run(cmd,cwd=build,text=True,capture_output=True);commands.append({'command':cmd,'cwd':str(build),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,p.stderr
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:alloc_dealloc_mismatch=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
p=subprocess.run([str(exe)],env=env,cwd=build,text=True,capture_output=True);(out/'stdout.log').write_text(p.stdout);(out/'stderr.log').write_text(p.stderr);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');(out/'report.json').write_text(json.dumps({'exit_code':p.returncode,'source_sha256':source_hashes,'sanitizers':['address','undefined'],'vptr':False,'leak_sanitizer':False,'leak_sanitizer_reason':'Previously observed ptrace restriction; no LSan PASS claimed','alloc_dealloc_mismatch':True,'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()},indent=2)+'\n');print('foundation ASan/UBSan',p.returncode,flush=True);raise SystemExit(p.returncode)
