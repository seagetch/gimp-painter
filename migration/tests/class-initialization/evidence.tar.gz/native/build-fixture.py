from pathlib import Path
import json,shlex,subprocess,sys,hashlib,os
out=Path(__file__).resolve().parent
repo=out.parent/'gimp-painter-port-active'; native=out.parent/'gimp-native-restore-20261009'; build=native/'build-http'
source=repo/'app/paint/painter-mypaint-surface/gimp-painter-options.cpp'
db=json.loads((build/'compile_commands.json').read_text())
entry=next(x for x in db if x['file'].endswith('/gimp-painter-options.cpp'))
flags=shlex.split(entry['command'])[1:]; pos=flags.index('-MD'); flags=flags[:pos]
s=(build/'build.ninja').read_text(); start=s.index('build app/tests/gimp-painter-options:'); block=s[start:s.index('\n\n',start)]
link=shlex.split(block.split(' LINK_ARGS = ',1)[1].strip().replace('$$','$'))
(out/'native-build-inputs.json').write_text(json.dumps({'compile_entry':entry,'link_args':link,'parent_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()},indent=2)+'\n')
variants=sys.argv[1:] or ['baseline','fixed']
for variant in variants:
 kind=variant.split('-')[0]; directory=out/kind/'app/paint/painter-mypaint-surface'; directory.mkdir(parents=True,exist_ok=True)
 support=out/kind/'app/painter'
 if not support.exists():support.symlink_to(repo/'app/painter',target_is_directory=True)
 copied=directory/'gimp-painter-options.cpp'; copied.write_bytes((out/'baseline-options.cpp').read_bytes() if kind=='baseline' else source.read_bytes())
 san=['-fsanitize=address,undefined','-fno-sanitize=vptr','-fno-omit-frame-pointer'] if 'san' in variant else []
 obj=out/(variant+'.o'); binary=out/variant
 if binary.is_dir():binary=out/(variant+'-native')
 cmd=['c++',*flags,*san,'-DOPTIONS_SOURCE="'+str(copied)+'"','-o',str(obj),'-c',str(out/'native-class-init.cpp')]
 link_cmd=['c++',*san,'-o',str(binary),str(obj),'app/tests/gimp-painter-options.p/tests.c.o',*link]
 (out/(variant+'-commands.json')).write_text(json.dumps({'compile':cmd,'link':link_cmd,'source_sha256':hashlib.sha256(copied.read_bytes()).hexdigest()},indent=2)+'\n')
 for label,command in ([('compile',cmd)] if os.environ.get('COMPILE_ONLY') else [('compile',cmd),('link',link_cmd)]):
  with (out/(variant+'-'+label+'.log')).open('w') as log:r=subprocess.run(command,cwd=build,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  print(variant,label,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
