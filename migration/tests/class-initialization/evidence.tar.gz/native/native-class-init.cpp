/* Scratch regression: exact native options source, real GLib registration. */
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>
#include <string>
namespace fault {
static thread_local bool armed = false;
static thread_local unsigned attempts = 0;
static thread_local unsigned fail_at = 0;
static thread_local std::size_t failed_size = 0;
static thread_local std::size_t sizes[256]{};
}
void *operator new(std::size_t size) {
  if (fault::armed) {
    ++fault::attempts;
    if (fault::attempts <= 256) fault::sizes[fault::attempts - 1] = size;
  }
  if (fault::armed && fault::attempts == fault::fail_at) {
    fault::failed_size = size;
    throw std::bad_alloc();
  }
  if (void *p = std::malloc(size ? size : 1)) return p;
  throw std::bad_alloc();
}
void *operator new[](std::size_t size) { return ::operator new(size); }
void operator delete(void *p) noexcept { std::free(p); }
void operator delete[](void *p) noexcept { std::free(p); }
void operator delete(void *p, std::size_t) noexcept { std::free(p); }
void operator delete[](void *p, std::size_t) noexcept { std::free(p); }
#include OPTIONS_SOURCE
extern "C" {
#include "widgets/widgets-types.h"
#include "tests/tests.h"
#include "tests/gimp-app-test-utils.h"
}
static void require(bool value, const char *what) {
  if (!value) { std::fprintf(stderr, "ASSERTION: %s\n", what); std::exit(2); }
}
static void canonical(const char *source, char *dest) {
  while (*source) { *dest++ = *source == '_' ? '-' : *source; ++source; }
  *dest = 0;
}
static void common(GParamSpec *p, GObjectClass *klass, GType type,
                   unsigned id, const char *name, GType value_type,
                   GParamFlags flags) {
  char expected[256];
  require(std::strlen(name) < sizeof expected, "bounded generated property name");
  canonical(name, expected);
  require(p != nullptr, "property was prepared");
  require(std::strcmp(p->name, expected) == 0, "canonical property name");
  require(std::strchr(p->name, '_') == nullptr, "no underscore in canonical name");
  require(p->owner_type == type, "property owned by actual options type");
  require(p->param_id == id, "stable property id");
  require(p->value_type == value_type, "property value type");
  require(p->flags == flags, "exact property flags");
  require(!(p->flags & G_PARAM_STATIC_NAME), "GLib owns and canonicalizes name");
  require(g_object_class_find_property(klass, expected) == p, "installed property identity");
  require(g_object_class_find_property(klass, name) == p, "underscore lookup equivalent");
}
static unsigned verify_class(GObjectClass *klass, GType type, unsigned parent_count) {
  require(G_TYPE_FROM_CLASS(klass) == type, "actual class identity");
  require(std::strcmp(g_type_name(type), "GimpPainterMybrushOptions") == 0, "actual registered type name");
  require(g_type_parent(type) == GIMP_TYPE_PAINT_OPTIONS, "native parent type");
  require(g_type_class_peek(type) == klass, "native class lookup identity");
  require(g_type_class_peek_parent(klass) == gimp_painter_mybrush_options_parent_class, "native parent class identity");
  require(klass->constructed == constructed && klass->dispose == dispose &&
          klass->set_property == set_property && klass->get_property == get_property,
          "all object vfuncs installed");
  auto *context = GIMP_CONTEXT_CLASS(klass);
  require(context->painter_mybrush_changed == selected_changed &&
          context->brush_changed == brush_changed && context->pattern_changed == pattern_changed,
          "all context vfuncs installed");
  require(g_type_is_a(type, GIMP_TYPE_CONFIG), "native config interface implemented");
  auto *iface = static_cast<GimpConfigInterface *>(g_type_interface_peek(klass, GIMP_TYPE_CONFIG));
  require(iface && parent_config_iface, "config interface and parent initialized");
  require(iface->copy == config_copy && iface->duplicate == config_duplicate &&
          !iface->serialize_property && !iface->deserialize_property, "config vfuncs complete");
  unsigned count = 0, own = 0;
  GParamSpec **listed = g_object_class_list_properties(klass, &count);
  for (unsigned i = 0; i < count; ++i) if (listed[i]->owner_type == type) ++own;
  g_free(listed);
  require(own == BRUSH_SETTINGS_COUNT + 3, "all expected own properties installed");
  require(count == parent_count + own, "complete native inherited plus own property count");
  const auto flags = GParamFlags(G_PARAM_READWRITE | GIMP_CONFIG_PARAM_SERIALIZE);
  for (const auto &s : painter_mypaint_settings) {
    auto *p = properties[s.index + 1];
    common(p, klass, type, s.index + 1, s.internal_name, G_TYPE_DOUBLE, flags);
    require(G_IS_PARAM_SPEC_DOUBLE(p), "double GParamSpec type");
    require(G_PARAM_SPEC_DOUBLE(p)->minimum == s.minimum && G_PARAM_SPEC_DOUBLE(p)->maximum == s.maximum &&
            G_PARAM_SPEC_DOUBLE(p)->default_value == s.default_value, "double range and default");
    require(std::strcmp(g_param_spec_get_nick(p), s.displayed_name) == 0, "double display name");
    require(g_strcmp0(g_param_spec_get_blurb(p), s.tooltip) == 0, "double tooltip");
  }
  for (const auto &s : painter_mypaint_switches) {
    auto *p = properties[s.index + 1];
    common(p, klass, type, s.index + 1, s.internal_name, G_TYPE_BOOLEAN, flags);
    require(G_IS_PARAM_SPEC_BOOLEAN(p) && G_PARAM_SPEC_BOOLEAN(p)->default_value == FALSE, "boolean type and default");
  }
  for (const auto &s : painter_mypaint_texts) {
    auto *p = properties[s.index + 1];
    common(p, klass, type, s.index + 1, s.internal_name, G_TYPE_STRING, flags);
    require(G_IS_PARAM_SPEC_STRING(p) && G_PARAM_SPEC_STRING(p)->default_value == nullptr, "string type and default");
  }
  common(properties[PROP_JSON], klass, type, PROP_JSON, "painter-settings", G_TYPE_STRING, flags);
  require(G_IS_PARAM_SPEC_STRING(properties[PROP_JSON]) && !G_PARAM_SPEC_STRING(properties[PROP_JSON])->default_value,
          "JSON string type and default");
  common(properties[PROP_DIRTY], klass, type, PROP_DIRTY, "painter-dirty", G_TYPE_BOOLEAN, G_PARAM_READABLE);
  common(properties[PROP_CONFLICT], klass, type, PROP_CONFLICT, "painter-conflict", G_TYPE_BOOLEAN, G_PARAM_READABLE);
  require(!G_PARAM_SPEC_BOOLEAN(properties[PROP_DIRTY])->default_value &&
          !G_PARAM_SPEC_BOOLEAN(properties[PROP_CONFLICT])->default_value, "state boolean defaults");
  for (const char *signal : {"history-changed", "settings-changed"}) {
    const guint id = g_signal_lookup(signal, type); GSignalQuery query{};
    require(id != 0, "signal installed"); g_signal_query(id, &query);
    require(query.itype == type && query.return_type == G_TYPE_NONE && query.n_params == 0 &&
            query.signal_flags == G_SIGNAL_RUN_LAST, "signal signature and owner");
  }
  return count;
}
static void reject_wrong_instance(GObjectClass *klass, GType type, unsigned parent_count) {
  GParamSpec *before[PROP_CONFLICT + 1]; std::memcpy(before, properties, sizeof before);
  auto *wrong = G_OBJECT(g_object_new(G_TYPE_OBJECT, nullptr)); GError *error = nullptr;
  gchar *json = gimp_painter_mybrush_options_dup_json(reinterpret_cast<GimpPainterMybrushOptions *>(wrong), &error);
  require(json == nullptr && error && error->domain == GIMP_PAINTER_ERROR && error->code == GIMP_PAINTER_ERROR_WRONG_TYPE,
          "wrong native instance rejected at supported options API");
  g_clear_error(&error); g_object_unref(wrong);
  require(std::memcmp(before, properties, sizeof before) == 0, "rejected instance leaves spec identities unchanged");
  verify_class(klass, type, parent_count);
}
int main(int argc, char **argv) {
  std::setvbuf(stdout, nullptr, _IONBF, 0);
  if (argc > 1 && std::strcmp(argv[1], "allocation-control") == 0) {
    fault::armed = true; fault::fail_at = 1;
    try { std::string value("a deliberately non-SSO native libstdc++ string allocation");
          std::printf("unexpected_control=%zu\n", value.size()); }
    catch (const std::bad_alloc &) { fault::armed = false;
      std::printf("control=bad_alloc attempts=%u size=%zu\n", fault::attempts, fault::failed_size); return 0; }
    return 2;
  }
  const unsigned requested = argc > 1 ? std::strtoul(argv[1], nullptr, 10) : 0;
  const bool retry = argc > 2 && std::strcmp(argv[2], "retry") == 0;
  const bool construct = argc > 2 && std::strcmp(argv[2], "construct") == 0;
  gegl_init(nullptr, nullptr);
  auto *parent = static_cast<GObjectClass *>(g_type_class_ref(GIMP_TYPE_PAINT_OPTIONS));
  guint parent_count = 0; auto **parent_specs = g_object_class_list_properties(parent, &parent_count); g_free(parent_specs);
  const GType type = GIMP_TYPE_PAINTER_MYBRUSH_OPTIONS;
  require(g_type_class_peek(type) == nullptr, "fresh process has not initialized native options class");
  GObjectClass *klass = nullptr;
  fault::attempts = 0; fault::fail_at = requested; fault::armed = true;
  try { klass = static_cast<GObjectClass *>(g_type_class_ref(type)); }
  catch (const std::bad_alloc &) {
    fault::armed = false;
    unsigned prepared = 0, installed = 0, floating = 0;
    for (unsigned i = 1; i <= PROP_CONFLICT; ++i) if (properties[i]) {
      ++prepared; if (properties[i]->owner_type == type) ++installed;
      if (properties[i]->owner_type == G_TYPE_INVALID) ++floating;
    }
    std::printf("outcome=escaped_bad_alloc requested=%u attempts=%u size=%zu prepared=%u installed=%u unowned_prepared=%u total_expected=%u\n",
                requested, fault::attempts, fault::failed_size, prepared, installed, floating, PROP_CONFLICT);
    const char *failed_name = "unknown";
    for (const auto &s : painter_mypaint_settings) if (unsigned(s.index + 1) == prepared + 1) failed_name = s.internal_name;
    for (const auto &s : painter_mypaint_switches) if (unsigned(s.index + 1) == prepared + 1) failed_name = s.internal_name;
    for (const auto &s : painter_mypaint_texts) if (unsigned(s.index + 1) == prepared + 1) failed_name = s.internal_name;
    std::printf("failed_property_name=%s string_bytes_with_nul=%zu\n", failed_name, std::strlen(failed_name) + 1);
    require(fault::failed_size == std::strlen(failed_name) + 1, "failed allocation matches native property-name string");
    require(requested != 0 && fault::attempts == requested, "controlled allocation failed at requested attempt");
    require(prepared < PROP_CONFLICT && installed == 0 && prepared == floating, "partial floating preparation before install loop");
    if (retry) {
      std::puts("retry=begin_fault_disabled");
      klass = static_cast<GObjectClass *>(g_type_class_ref(type));
      gpointer visible = g_type_class_peek(type);
      guint listed_count = 0, own_count = 0;
      GParamSpec **listed = g_object_class_list_properties(klass, &listed_count);
      for (unsigned i = 0; i < listed_count; ++i) if (listed[i]->owner_type == type) ++own_count;
      g_free(listed);
      unsigned prepared_after = 0;
      for (unsigned i = 1; i <= PROP_CONFLICT; ++i) if (properties[i]) ++prepared_after;
      std::printf("retry=returned class_type_matches=%u public_class_peek_nonnull=%u public_class_peek_matches=%u inherited_and_own_properties=%u own_properties=%u prepared_after=%u expected_own_properties=%u\n",
                  G_TYPE_FROM_CLASS(klass) == type, visible != nullptr, visible == klass,
                  listed_count, own_count, prepared_after, PROP_CONFLICT);
      require(G_TYPE_FROM_CLASS(klass) == type && !visible && own_count == 0 && prepared_after == prepared,
              "native retry exposes incompletely initialized class, not supported recovery");
      std::puts("retry_outcome=partial_class_not_recovered");
      return 11;
    }
    return 10;
  }
  fault::armed = false;
  const unsigned attempts = fault::attempts;
  std::printf("scoped_cpp_allocation_sizes=");
  for (unsigned i = 0; i < attempts && i < 256; ++i) std::printf("%s%zu", i ? "," : "", fault::sizes[i]);
  std::puts("");
  const unsigned count = verify_class(klass, type, parent_count);
  reject_wrong_instance(klass, type, parent_count);
  for (unsigned i = 0; i < 16; ++i) {
    auto *again = g_type_class_ref(type); require(again == klass, "repeated ref identity");
    g_type_class_unref(again); verify_class(klass, type, parent_count);
  }
  std::printf("outcome=complete requested=%u cpp_allocations=%u properties=%u own=%u inherited=%u metadata=pass vfuncs=pass interfaces=pass signals=pass repeated_refs=16 wrong_instance=pass\n",
              requested, attempts, count, PROP_CONFLICT, parent_count);
  if (construct) {
    require(g_getenv("GIMP3_DIRECTORY") != nullptr, "scratch native profile configured by runner");
    auto *gimp = gimp_init_for_testing(); require(gimp != nullptr, "native testing application");
    for (unsigned i = 0; i < 16; ++i) {
      auto *options = GIMP_PAINTER_MYBRUSH_OPTIONS(g_object_new(type, "gimp", gimp, nullptr));
      require(options && !options->binding_failed, "native instance construction succeeded");
      require(G_OBJECT_GET_CLASS(options) == klass, "constructed instance class identity");
      GError *error = nullptr; gchar *json = gimp_painter_mybrush_options_dup_json(options, &error);
      require(json && !error, "constructed instance binding works"); g_free(json); g_object_unref(options);
      verify_class(klass, type, parent_count);
    }
    std::puts("construction=pass repeated_instances=16");
    // Keep initialization and teardown in the same isolated scratch profile.
    gimp_exit(gimp, TRUE);
  }
  g_type_class_unref(klass); g_type_class_unref(parent);
  return 0;
}
