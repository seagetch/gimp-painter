from pathlib import Path
import json, os, subprocess, re, sys, time, shutil, tempfile
out=Path(__file__).resolve().parent; build=out.parent/'gimp-native-restore-20261009/build-http'
test=next(t for t in json.loads((build/'meson-info/intro-tests.json').read_text()) if t['name']=='gimp-painter-options')
env=dict(os.environ,**test['env']);env['LD_LIBRARY_PATH']=test['env']['LD_LIBRARY_PATH']+':'+os.environ.get('LD_LIBRARY_PATH','')
env['ASAN_OPTIONS']='detect_leaks=0:abort_on_error=1';env['UBSAN_OPTIONS']='halt_on_error=1:print_stacktrace=1'
results=[]
def run(variant,args,timeout=5):
 binary=out/(variant+'-native' if (out/variant).is_dir() else variant)
 label=variant+'-'+('-'.join(args) or 'normal');started=time.monotonic()
 run_env=dict(env)
 if 'construct' in args:
  profile=Path(tempfile.mkdtemp(prefix=label+'-profile-',dir=out))
  shutil.copytree(out.parent/'gimp-painter-port-active/app/tests/gimpdir',profile,dirs_exist_ok=True)
  run_env['GIMP3_DIRECTORY']=str(profile)
 try:
  p=subprocess.run([str(binary),*args],cwd=build,env=run_env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
  text=p.stdout;exit_code=p.returncode;timed_out=False
 except subprocess.TimeoutExpired as e:
  text=e.stdout or '';text=text.decode() if isinstance(text,bytes) else text;exit_code=None;timed_out=True
 (out/(label+'.run.log')).write_text(text)
 result={'variant':variant,'arguments':args,'exit_code':exit_code,'timed_out':timed_out,'timeout_seconds':timeout,'duration_seconds':round(time.monotonic()-started,3),'log':label+'.run.log','output':text}
 results.append(result);(out/'native-results.json').write_text(json.dumps(results,indent=2)+'\n');print(label,exit_code,'TIMEOUT' if timed_out else '',text[-700:],flush=True)
 return result
variants=sys.argv[1:] or ['baseline','fixed','baseline-san','fixed-san']
for variant in variants:
 run(variant,['allocation-control'])
 normal=run(variant,['0'])
 if normal['exit_code']!=0:continue
 allocations=int(re.search(r'cpp_allocations=(\d+)',normal['output']).group(1))
 if variant.startswith('baseline'):
  if allocations==0:raise RuntimeError('Baseline must expose non-SSO string allocations')
  sites=range(1,allocations+1)
  for point in sites:run(variant,[str(point)])
  run(variant,['1','retry'])
 else:
  run(variant,['1'])
  run(variant,['1','retry'])
  run(variant,['0','construct'],timeout=60)

failures=[]
for result in results:
 variant=result['variant'];args=result['arguments']
 expected=0
 if variant.startswith('baseline') and args[0].isdigit() and int(args[0])>0:
  expected=11 if len(args)>1 and args[1]=='retry' else 10
 if result['timed_out'] or result['exit_code']!=expected:failures.append(result)
summary={'subprocesses':len(results),'controlled_baseline_faults':sum(r['exit_code']==10 for r in results),'baseline_partial_retry_outcomes':sum(r['exit_code']==11 for r in results),'unexpected_outcomes':len(failures),'all_expected_outcomes':not failures,'sanitizer_configuration':'address,undefined; vptr omitted (native no RTTI); detect_leaks=0','scope':'Options production translation unit and fixture instrumented; linked native dependency archives are not instrumented'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
if failures:raise SystemExit(1)
