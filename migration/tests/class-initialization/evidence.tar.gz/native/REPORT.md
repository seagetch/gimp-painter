# WBS05.013 native class-initialization regression

The actual `GimpPainterMybrushOptions` class passes the fixed native checks. The preserved baseline reproduces an escaping `std::bad_alloc` at every one of its 22 allocating property-name conversions. Removing those conversions eliminates the intercepted C++ allocations during the first native class reference.

## Final outcomes

| Check | Baseline | Fixed |
|---|---|---|
| First `g_type_class_ref` without a fault | 22 operator-new calls; complete class | 0 operator-new calls; complete class |
| Positive allocation-interception control | Real non-SSO `std::string` throws at allocation 1 | Same positive control succeeds |
| Every allocating property-name position | All 22 escape as `bad_alloc` | Fault armed for allocation 1 is never triggered; class completes |
| Native property metadata | 126 total: 71 inherited and 55 own | Same complete metadata |
| Repeated class references | Healthy baseline: 16 references retain identity | 16 references retain identity, also with failure gate armed |
| Wrong native object supplied to supported options API | Explicit WRONG_TYPE error; class snapshot unchanged | Same rejection and unchanged class/spec identities |
| Native construction | Not part of baseline fault runs | 16 valid constructions, usable bindings, and destruction per normal/sanitizer run |
| Retry after baseline fault | Returns an unfinished class; details below | No class-init exception occurs; ordinary subsequent references are complete |

The final runner used 60 fresh subprocesses: 44 expected baseline allocation failures (all 22 positions in each of normal and sanitizer builds), two expected unfinished-class retry observations, and 14 successful control/healthy/fixed cases. Every outcome matched its expectation. No subprocess timed out. The timeout is five seconds per class/control/fault probe and 60 seconds per native application construction probe; the Python parent kills and collects a timed-out child. There are no unbounded recovery attempts.

All 55 own properties are checked by exact native owner, property ID, canonical hyphenated name, underscore-lookup equivalence, GParamSpec/value type, flags, and defaults. All 45 numeric settings also check minimum and maximum, displayed name and tooltip. The other generated properties are five booleans and two texts, followed by the settings JSON and two state booleans. No property uses `G_PARAM_STATIC_NAME`.

The checks also verify the registered native type and parent class; all four object vfuncs; three context-change vfuncs; the config interface, its parent and copy/duplicate/serialization handlers; and the two native signals with their owner/signature/flags. Complete class verification is repeated after wrong-instance rejection, class references and instance destruction.

## Precisely reproduced baseline failure

The first failed conversion is `opaque_linearize` (17 bytes including NUL). Two real specs have already been prepared. At the middle position, `smudge_radius_log` fails after 31 prepared specs; the last allocating conversion, `texture_specified`, fails after 49. Each of all 22 failure positions records the exact expected name, allocation number/size and prepared count.

At each failure, all prepared specs have `owner_type == G_TYPE_INVALID`, and zero own specs have been installed. These are prepared/unowned native specs before the installation loop. This is distinct from the removed legacy wrapper's failure after installing a property.

One bounded retry is performed only after the first baseline fault, with injection disabled. With native GLib 2.84.4 it returns a pointer whose `G_TYPE_FROM_CLASS` is the correct options GType. However, `g_type_class_peek(type)` is null, only 71 inherited properties are visible, zero of the 55 own properties are installed, and the same two prepared specs remain. Initialization did not finish or recover. This is not evidence of a different GType or a wrong class pointer. The fixed source avoids the exception and maintains normal native class identity; it does not implement recovery from an exception that has already unwound through GLib.

The removed mutable `GClassWrapper`/`InvalidClass` mechanism is not reconstructed or mocked. Its current replacement is verified through valid native class identity and explicit WRONG_TYPE rejection at the supported options API, with unchanged class/spec metadata.

## Native fidelity and provenance

- Baseline commit: `f299d8a5f3982e8bfcae366dc0d2e5a573f6090b`
- Baseline SHA-256: `e61aff31fa66c94af9fb641974e7d2818f0ce7b4b43dd2495cfcf4867138a798`
- Fixed source SHA-256: `428db93b942f2006a6c9b89093f60192e9b47946632a49d2dfc3c83f303d29a2`
- Compiler: Debian GCC 14.2.0; GLib/GObject 2.84.4; GEGL 0.4.62

The fixture includes the exact preserved/current options `.cpp` bytes in its translation unit. This allows inspection of the actual static property array and native vfunc identities. Its real `G_DEFINE_TYPE_WITH_CODE` and exported native options implementation satisfy the symbols, so the duplicate source object is not pulled from the linked archive. No class, GParamSpec constructor, type registry, class pointer or property API is replaced. Compilation uses the actual options compile-database entry; linking uses the native `app/tests/gimp-painter-options` application's link arguments and test-support object. Exact commands and source hashes are retained.

The test executable replaces ordinary `operator new`/`new[]` and matching delete overloads. A thread-local fault gate is armed only around the first options `g_type_class_ref`, after native GEGL initialization and parent-class prewarming. The options type is asserted uninitialized immediately before that scope. A separate real long-string control confirms allocation interception. Each baseline failure's observed allocation size matches the actual property-name string including NUL. GLib's C allocations remain native and are outside this C++ failure mechanism.

## Sanitizer scope and limitations

Both baseline and fixed options source plus the fixture are compiled with ASan and UBSan. Native dependent archives remain their normal builds, so this is not a fully instrumented application. Native no-RTTI settings require omitting vptr checks. `ASAN_OPTIONS=detect_leaks=0:abort_on_error=1` and `UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1` are used. LSan is not claimed because the established environment does not support its ptrace requirements. No ASan or UBSan diagnostic appeared in the final matrix.

This is a C++ `bad_alloc` regression, not an assertion that GLib allocation exhaustion is recoverable. Native `g_malloc` failure/abort behavior is not changed or tested here.

The final normal and sanitizer construction runs each exit zero after 16 successful instances. Both retain the existing GIMP teardown warning that a configured writable data folder is absent from its search path. It occurs after `construction=pass`; it is not hidden or reported as a sanitizer failure. Final construction uses independent scratch copies of the native test profile for initialization and teardown. Earlier exploratory runs used the native suite's source test profile; final runs use independent scratch copies. No tracked production file was edited by this fixture work.

The initial exploratory probe omitted required native GEGL/Babl initialization and exited before reaching options class initialization. `initial-environment-results.json` preserves that result. The final fixture initializes GEGL before parent prewarming. `pre-profile-isolation-results.json` preserves the earlier complete matrix before construction-profile isolation; final authoritative results are `native-results.json`, `summary.json` and `final-run.log`.

## Reproduce in this workspace

From a shell in the existing workspace:

```sh
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/env-http.sh
python /workspace/scratch/5b5281e79681/class-init-05013-verification/build-fixture.py baseline fixed baseline-san fixed-san
python /workspace/scratch/5b5281e79681/class-init-05013-verification/run-fixture.py
```

The build script only writes scratch fixture sources, objects, binaries and logs. It reads existing native archives; do not run it concurrently with an archive rebuild. It does not invoke Ninja or rewrite native build products. Baseline source bytes are retained separately from the current repository source. The evidence ZIP omits large binaries, object files and runtime profiles; all fixture code, source snapshots, exact commands, provenance and result logs are included.
