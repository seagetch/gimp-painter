#!/usr/bin/env python3
"""External, bounded normal + five-C-unit sanitizer rotation-start evidence.

This runner does not replace any tracked acceptance gate. Invoke it once: it
execs the committed authenticated portrait Xvfb wrapper, which runs this script
as its direct child. The child owns the shared lock across builds, tests, seals
and evidence writes. All outputs are new, external and retained on failure.
"""
from __future__ import annotations
import argparse
from collections import Counter
import ctypes
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve()
DEFAULT_REPOSITORY = Path('/workspace/shared/gimp-painter-clone-components')
DEFAULT_BUILD = Path('/workspace/shared/gimp-clone-component-build')
LOCK = Path('/workspace/shared/gimp-painter-build.lock')
SCOPE = 'original25.001-rotation-start-three-normal-targets-five-c-unit-asan-ubsan-v1'
TARGETS = ('painter-navigation-events', 'painter-navigation-ui', 'painter-navigation')
TEST_SOURCES = {name: 'app/tests/test-' + name + '.c' for name in TARGETS}
INSTRUMENTED = frozenset({
    'app/display/gimppainternavigation.c',
    'app/display/gimpmodifiersmanager.c',
    'app/display/gimpdisplayshell-rotate.c',
    'app/display/gimpdisplayshell-tool-events.c',
    TEST_SOURCES[TARGETS[0]],
})
BUILDER = 'migration/tests/build_navigation_event_sanitizers.py'
WRAPPER = 'tools/run-painter-xvfb.py'
UTILITIES = ('tools/clone_evidence.py', 'tools/run-painter-frozen-aggregate.py',
             'tools/package-linux-runtime.py', BUILDER, WRAPPER)
CODE_INPUTS = sorted(INSTRUMENTED | set(TEST_SOURCES.values()) | {
    'migration/fixtures/legacy-navigation/rotation.tsv',
    'migration/fixtures/legacy-rotation-operations/gui-captures/rotation.tsv',
    'migration/fixtures/legacy-zoom/zoom.tsv',
})
SAN_DIRECTORY = 'painter-navigation-event-sanitizers'
SAN_EXE = 'app/tests/painter-navigation-events-asan'
SAN_FILES = tuple(sorted([SAN_DIRECTORY + '/' + Path(name).name + '.o'
                         for name in INSTRUMENTED] +
                        [SAN_DIRECTORY + '/libappdisplay.a', SAN_EXE]))
ASAN = 'detect_leaks=0:halt_on_error=1:abort_on_error=1'
UBSAN = 'halt_on_error=1:print_stacktrace=1'


def canonical(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def git(repository, *args):
    return subprocess.check_output(['git', '-C', str(repository), *args], stderr=subprocess.PIPE)


def committed_modules(repository, commit):
    """Verify every utility before importing its current committed bytes."""
    for name in UTILITIES:
        committed = git(repository, 'show', commit + ':' + name)
        if (repository / name).read_bytes() != committed:
            raise RuntimeError('Utility differs from exact accepted commit: ' + name)
    path = repository / 'tools/clone_evidence.py'
    spec = importlib.util.spec_from_file_location('rotation_clone_evidence', path)
    module = importlib.util.module_from_spec(spec)
    exec(compile(path.read_bytes(), str(path), 'exec'), module.__dict__)
    return module, module.aggregate, module.aggregate.load_committed_helper(repository, commit)


def registrations(path):
    """Read literal GLib names and simple ADD_TEST(name) stringizing macros."""
    source = re.sub(r'/\*.*?\*/|//[^\n]*', '', path.read_text(), flags=re.S)
    names = re.findall(r'\bg_test_add_(?:func|data_func)\s*\(\s*"([^"\n]+)"\s*,', source)
    for macro, prefix in re.findall(
            r'^\s*#define\s+(\w+)\s*\([^\n]*?\)\s*'
            r'(?:\\\n\s*)?g_test_add_(?:func|data_func)\s*\(\s*"([^"\n]+)"\s*#',
            source, re.M):
        body = re.sub(r'^\s*#define[^\n]*(?:\\\n[^\n]*)*', '', source, flags=re.M)
        names += [prefix + name for name in re.findall(r'\b' + re.escape(macro) + r'\s*\(\s*(\w+)\s*\)\s*;', body)]
    if not names or len(names) != len(set(names)):
        raise RuntimeError('Missing or duplicate statically readable test registrations: ' + str(path))
    return names


def tap_result(clone, aggregate, name, text, expected):
    plans = re.findall(r'^1\.\.(\d+)\s*$', text, re.M)
    names = re.findall(r'^ok \d+ (/[\w./-]+)\s*$', text, re.M)
    skipped, crashes, failures, nonfatal = aggregate.diagnostics(name, text)
    passed = (clone.exact_tap(text, expected) and len(names) == len(expected)
              and set(names) == set(expected) and not skipped and not crashes and not failures)
    return {'passed': passed, 'tap_plans': [int(x) for x in plans],
            'passed_count': len(names), 'expected_count': len(expected),
            'test_names': names, 'expected_test_names': expected,
            'skipped': skipped, 'crash_diagnostics': crashes,
            'failure_diagnostics': failures, 'nonfatal_warnings': nonfatal}


def require_wrapper(repository):
    parent_argv = Path('/proc/' + str(os.getppid()) + '/cmdline').read_bytes().split(b'\0')
    decoded = [os.fsdecode(item) for item in parent_argv if item]
    if str(repository / WRAPPER) not in decoded or str(HERE) not in decoded:
        raise RuntimeError('Must be the direct command child of the committed portrait Xvfb wrapper')
    if not re.fullmatch(r'127\.0\.0\.1:(?:9[1-9]|1[0-8][0-9]|190)', os.environ.get('DISPLAY', '')):
        raise RuntimeError('Expected the wrapper loopback TCP display')
    authority = Path(os.environ.get('XAUTHORITY', '/nonexistent'))
    if (not authority.is_file() or authority.is_symlink() or not authority.stat().st_size
            or authority.stat().st_mode & 0o077):
        raise RuntimeError('Missing private wrapper X authority')
    x = ctypes.CDLL('libX11.so.6')
    x.XOpenDisplay.argtypes = [ctypes.c_char_p]
    x.XOpenDisplay.restype = ctypes.c_void_p
    x.XDefaultScreen.argtypes = [ctypes.c_void_p]
    x.XDefaultScreen.restype = ctypes.c_int
    x.XDisplayWidth.argtypes = x.XDisplayHeight.argtypes = [ctypes.c_void_p, ctypes.c_int]
    x.XDisplayWidth.restype = x.XDisplayHeight.restype = ctypes.c_int
    x.XCloseDisplay.argtypes = [ctypes.c_void_p]
    display = x.XOpenDisplay(None)
    if not display:
        raise RuntimeError('Authenticated X connection failed')
    try:
        screen = x.XDefaultScreen(display)
        size = [x.XDisplayWidth(display, screen), x.XDisplayHeight(display, screen)]
    finally:
        x.XCloseDisplay(display)
    if size != [1080, 1920]:
        raise RuntimeError('Expected actual 1080x1920 display geometry')
    return {'wrapper': WRAPPER, 'wrapper_sha256': digest((repository / WRAPPER).read_bytes()),
            'direct_wrapper_child': True, 'transport': 'authenticated loopback TCP',
            'observed_geometry': size,
            'empty_authority_rejected': 'required by committed wrapper before child launch',
            'wrapper_command_timeout_seconds': 3500}


def capture_artifacts(build, destination, helper, require_all):
    """Copy bytes immediately; fixed build-side locations remain authoritative."""
    directory = build / SAN_DIRECTORY
    expected_names = {Path(name).name for name in SAN_FILES if name.startswith(SAN_DIRECTORY + '/')}
    if directory.exists():
        if directory.is_symlink() or {p.name for p in directory.iterdir()} - expected_names:
            raise RuntimeError('Unexpected entry in fixed sanitizer artifact directory')
    seals = {}
    for name in SAN_FILES:
        path = build / name
        if not path.exists():
            if require_all:
                raise RuntimeError('Missing sanitizer artifact: ' + name)
            continue
        if path.is_symlink() or not path.is_file():
            raise RuntimeError('Sanitizer artifact must be a regular file: ' + name)
        seals[name] = helper.path_fingerprint(path)
        if destination is not None:
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                raise RuntimeError('Refusing to replace preserved sanitizer artifact: ' + str(target))
            shutil.copy2(path, target)
            if helper.path_fingerprint(target) != seals[name] or helper.path_fingerprint(path) != seals[name]:
                raise RuntimeError('Sanitizer artifact changed while copying: ' + name)
    return seals


def normal_elf(build, helper, aggregate):
    return {name: seal for name, seal in aggregate.elf_inventory(build, helper).items()
            if name not in SAN_FILES}


def run_locked(args, output, private, clone, aggregate, helper):
    repository, build = args.repository, args.build
    sanitizer = aggregate.Sanitizer()
    receipt = {'schema': 1, 'scope': SCOPE, 'status': 'failed', 'started_utc': utc(),
        'source_commit': args.expected_commit, 'source_tree': args.expected_tree,
        'expected_event_source_sha256': args.expected_event_sha256,
        'source_directory': str(repository), 'build_directory': str(build),
        'external_runner_sha256': digest(HERE.read_bytes()), 'commands': [], 'errors': [],
        'limits': ['Only the three named normal Meson targets are run.',
                   'ASan/UBSan covers exactly five C units; remaining GIMP, GTK and dependencies are uninstrumented.',
                   'LeakSanitizer is disabled; no suppression files or suppression options are used.',
                   'Synthetic display events are not physical-device acceptance.',
                   'No full aggregate, final Clone freeze, package or release acceptance is claimed.',
                   'Old Edge/string old-reader runtime is skipped and unverified; no legacy runtime is accessed.']}
    source, elf, freshness, catalogs, artifacts, transforms = {}, {}, {}, {}, {}, {}
    registry = []
    environment = None
    compile_before = registry_before = None
    locale_directory = None
    expected_tests = {}
    normal_results = []
    normal_gate = []
    sanitizer_run = {}

    def save(name, value, sealed=False):
        public = sanitizer.object(value)
        if sealed and public != value:
            raise RuntimeError('Sanitization would change sealed evidence: ' + name)
        (output / name).write_bytes(canonical(public))

    def text_log(raw_path, name, meson=False):
        if not raw_path.is_file():
            return
        raw = raw_path.read_bytes()
        content, transform = clone.public_meson_text(raw) if meson else (raw, {})
        public = sanitizer.text(content.decode(errors='replace')).encode()
        (output / name).write_bytes(public)
        transforms[name] = {'transform': 'committed-meson-prefix-removal-and-secret-redaction-v1' if meson else 'committed-aggregate-secret-redaction-v1',
                            'raw_sha256': digest(raw), 'public_sha256': digest(public),
                            'prefix_transform': transform}

    def json_log(raw_path, name, jsonl=False):
        if not raw_path.is_file():
            return
        raw = raw_path.read_bytes()
        filtered, transform = clone.public_json(raw, jsonl)
        public = canonical(sanitizer.object(json.loads(filtered)))
        (output / name).write_bytes(public)
        transforms[name] = {'transform': 'committed-recursive-env-removal-and-secret-redaction-v1',
                            'raw_sha256': digest(raw), 'public_sha256': digest(public),
                            'environment_removal': transform}

    def command(argv, name, env, cwd=None):
        original_cwd = Path.cwd()
        record = {'argv': argv, 'cwd': str(cwd or original_cwd), 'exit_code': None, 'started_utc': utc()}
        receipt['commands'].append(record)
        try:
            if cwd is not None:
                os.chdir(cwd)
            record['exit_code'] = aggregate.run_command(argv, private / name, env)
        finally:
            os.chdir(original_cwd)
            record['finished_utc'] = utc()
            if (private / name).is_file():
                text_log(private / name, name)
                record['raw_log_sha256'] = aggregate.sha(private / name)
                record['public_log_sha256'] = aggregate.sha(output / name)
        return record['exit_code']

    def require(ok, message):
        if not ok:
            raise RuntimeError(message)

    try:
        source['before_build'] = aggregate.source_state(repository, helper)
        aggregate.require_source(source['before_build'], args.expected_commit, args.expected_tree)
        receipt['normal_build'] = aggregate.require_normal_build(build, repository)
        receipt['xvfb'] = require_wrapper(repository)
        receipt['provenance_sha256'] = {name: aggregate.sha(repository / name) for name in UTILITIES}
        expected_hashes = {name: digest(git(repository, 'show', args.expected_commit + ':' + name)) for name in CODE_INPUTS}
        require(expected_hashes[TEST_SOURCES[TARGETS[0]]] == args.expected_event_sha256,
                'Accepted event source hash does not match expected commit')
        require(all(aggregate.sha(repository / name) == value for name, value in expected_hashes.items()),
                'Claimed code/fixture input differs from accepted committed bytes')
        save('expected-source-hashes.json', expected_hashes, True)
        expected_tests = {name: registrations(repository / filename) for name, filename in TEST_SOURCES.items()}
        save('expected-tests.json', expected_tests, True)
        inherited = clone.filtered_environment(os.environ)
        inherited['CCACHE_DISABLE'] = '1'
        environment = aggregate.isolated_child_environment(private, inherited)
        (private / 'dependency-display-environment.json').write_bytes(canonical(inherited))
        (private / 'isolated-environment.json').write_bytes(canonical(environment))
        save('runtime-policy.json', {'inherited_key_allowlist': sorted(clone.ENV_ALLOWLIST | {'CCACHE_DISABLE'}),
             'inherited_keys_used': sorted(inherited),
             'private_directory_variables': sorted(aggregate.PRIVATE_DIRECTORIES),
             'gsettings_backend': 'memory', 'raw_environment_published': False,
             'asan_options': ASAN, 'ubsan_options': UBSAN, 'suppression_files': []})
        shutil.copy2(HERE, output / 'external-runner.py')
        require(command(['ninja', '-C', str(build), '-j4'], 'default-build.log', environment) == 0,
                'Full default Ninja build failed')
        source['after_default_build'] = aggregate.source_state(repository, helper)
        aggregate.require_source(source['after_default_build'], args.expected_commit, args.expected_tree)
        require(source['before_build'] == source['after_default_build'], 'Sources changed during default build')
        aggregate.require_normal_build(build, repository)
        locale_directory = private / 'locale'
        catalogs['before'] = aggregate.stage_build_locales(build, locale_directory)
        require(catalogs['before']['catalog_count'] == 361, 'Expected exactly 361 global compiled catalogs')
        environment['GIMP3_LOCALEDIR'] = str(locale_directory)
        for src, dst in ((build / 'compile_commands.json', private / 'compile-database.json'),
                         (build / 'meson-info/intro-tests.json', private / 'registered-tests.json')):
            shutil.copy2(src, dst)
        compile_before = aggregate.sha(build / 'compile_commands.json')
        registry_before = aggregate.sha(build / 'meson-info/intro-tests.json')
        receipt['compile_database_sha256'] = compile_before
        receipt['raw_registry_sha256'] = registry_before
        registry = json.loads((private / 'registered-tests.json').read_text())
        aggregate.validate_registry(registry)
        for row in registry:
            sanitizer.add_environment(row.get('env'))
        counts = Counter(row['name'] for row in registry)
        require(all(counts[name] == 1 for name in TARGETS), 'Selected registry targets missing or duplicated')
        json_log(private / 'registered-tests.json', 'registered-tests.json')
        json_log(private / 'compile-database.json', 'compile-database.json')
        elf['after_default_build'] = normal_elf(build, helper, aggregate)
        require(all(name in elf['after_default_build'] for name in aggregate.EXECUTABLES),
                'Normal full-build GIMP executables missing')
        freshness['after_default_build'] = helper.capture_freshness_snapshot(build, repository)
        artifacts['previous_fixed_artifacts'] = capture_artifacts(build, private / 'previous-sanitizer-artifacts', helper, False)
        report = private / 'report.json'
        require(command([sys.executable, '-B', str(repository / BUILDER), str(build), '--report', str(report)],
                        'sanitizer-build.log', environment) == 0, 'Focused sanitizer build failed')
        builder = json.loads(report.read_text())
        require(builder.get('sanitizers') == ['address', 'undefined'] and builder.get('leak_detection') is False,
                'Unexpected sanitizer configuration')
        require(len(builder.get('sources', [])) == 5 and set(builder['sources']) == INSTRUMENTED,
                'Instrumentation scope must be exactly the five approved C units')
        require(builder.get('source_sha256') == {name: expected_hashes[name] for name in INSTRUMENTED},
                'Sanitizer builder input hashes differ from accepted sources')
        require(builder.get('executable') == str(build / SAN_EXE), 'Unexpected emitted event executable')
        instrumented_commands = [cmd for cmd in builder['commands'] if '-c' in cmd]
        require(len(instrumented_commands) == 5 and all('-fsanitize=address,undefined' in cmd and
                '-fno-omit-frame-pointer' in cmd for cmd in instrumented_commands), 'Missing five instrumented compile commands')
        json_log(report, 'sanitizer-build-report.json')
        artifacts['before_tests'] = capture_artifacts(build, output / 'sanitizer-artifacts', helper, True)
        source['before_tests'] = aggregate.source_state(repository, helper)
        aggregate.require_source(source['before_tests'], args.expected_commit, args.expected_tree)
        require(source['before_build'] == source['before_tests'], 'Sources changed during focused build')
        elf['before_tests'] = normal_elf(build, helper, aggregate)
        require(elf['after_default_build'] == elf['before_tests'], 'Focused builder modified normal ELF files')
        freshness['before_tests'] = helper.capture_freshness_snapshot(build, repository)
        helper.require_same_freshness(freshness['after_default_build'], freshness['before_tests'], 'focused build')
        require(compile_before == aggregate.sha(build / 'compile_commands.json'), 'Compile database changed during focused build')
        require(registry_before == aggregate.sha(build / 'meson-info/intro-tests.json'), 'Registry changed during focused build')
        logbase = private / 'meson'
        meson_status = command(['meson', 'test', '-C', str(build), '--no-rebuild', '--num-processes', '1',
                               '--print-errorlogs', '--logbase', str(logbase), *TARGETS],
                              'meson-console.log', environment)
        raw_results = [json.loads(line) for line in logbase.with_suffix('.json').read_text().splitlines() if line.strip()]
        for row in raw_results:
            sanitizer.add_environment(row.get('env'))
        json_log(logbase.with_suffix('.json'), 'normal-results.json', True)
        text_log(logbase.with_suffix('.txt'), 'testlog.txt', True)
        require(len(raw_results) == 3, 'Expected exactly three Meson result rows')
        matched = set()
        event_result = event_registry = None
        for target in TARGETS:
            registered = next(row for row in registry if row['name'] == target)
            matches = [(index, row) for index, row in enumerate(raw_results)
                       if row.get('name') == aggregate.pretty_name(registered, registry)
                       and row.get('command') == registered['cmd']]
            require(len(matches) == 1, 'No exact unique registered command/name result: ' + target)
            index, row = matches[0]
            matched.add(index)
            tap = tap_result(clone, aggregate, target, row.get('stdout', '') + '\n' + row.get('stderr', ''), expected_tests[target])
            normal_gate.append({'name': target, 'registered_command': registered['cmd'], 'result': row.get('result'),
                                'returncode': row.get('returncode'), 'tap': tap})
            if target == TARGETS[0]:
                event_result, event_registry = row, registered
        require(matched == set(range(3)), 'Unknown or duplicated normal result')
        save('normal-gate.json', normal_gate)
        # Reuse the actual environment Meson applied to this exact registered
        # event command, preserving dependency-path prepend semantics. Raw values
        # remain private; only these two exact sanitizer options are overridden.
        event_environment = event_result.get('env')
        require(isinstance(event_environment, dict) and all(isinstance(k, str) and isinstance(v, str)
                for k, v in event_environment.items()), 'Meson event result lacks actual execution environment')
        for key in ('GIMP_TESTING_ABS_TOP_SRCDIR', 'GIMP_TESTING_ABS_TOP_BUILDDIR', 'GIMP_TESTING_PLUGINDIRS', 'UI_TEST'):
            require(event_environment.get(key) == event_registry['env'].get(key), 'Wrong registered event environment: ' + key)
        for key in (*aggregate.PRIVATE_DIRECTORIES, 'GIMP3_LOCALEDIR', 'DISPLAY', 'XAUTHORITY'):
            require(event_environment.get(key) == environment.get(key), 'Event environment escaped isolation: ' + key)
        require('LD_PRELOAD' not in event_environment, 'Unexpected loader injection')
        san_environment = dict(event_environment)
        san_environment.update(ASAN_OPTIONS=ASAN, UBSAN_OPTIONS=UBSAN)
        (private / 'sanitizer-environment.json').write_bytes(canonical(san_environment))
        sanitizer_run = {'command': [str(build / SAN_EXE)], 'exit_code': None,
            'environment_source': 'actual env of exact registered painter-navigation-events Meson result',
            'private_environment_sha256': digest(canonical(san_environment)),
            'environment_overrides': {'ASAN_OPTIONS': ASAN, 'UBSAN_OPTIONS': UBSAN},
            'instrumented_sources': sorted(INSTRUMENTED), 'suppression_files': []}
        sanitizer_run['exit_code'] = command([str(build / SAN_EXE)], 'sanitizer-run.log', san_environment,
                                            Path(event_registry.get('workdir') or build))
        text = (private / 'sanitizer-run.log').read_text(errors='replace')
        sanitizer_run['tap'] = tap_result(clone, aggregate, TARGETS[0], text, expected_tests[TARGETS[0]])
        save('sanitizer-run.json', sanitizer_run)
        require(meson_status == 0 and all(row['result'] == 'OK' and type(row['returncode']) is int and
                row['returncode'] == 0 and row['tap']['passed'] for row in normal_gate), 'Normal selected targets failed or had incomplete TAP')
        require(sanitizer_run['exit_code'] == 0 and sanitizer_run['tap']['passed'], 'Event sanitizer failed or had incomplete TAP')
    except (Exception, KeyboardInterrupt) as error:
        receipt['errors'].append(type(error).__name__ + ': ' + str(error))
    finally:
        # Independently observed after-facts are retained even on failure. No
        # copied before-seal is ever represented as an after observation.
        for name, destination, capture in (
                ('source', source, lambda: aggregate.source_state(repository, helper)),
                ('normal ELF', elf, lambda: normal_elf(build, helper, aggregate)),
                ('freshness', freshness, lambda: helper.capture_freshness_snapshot(build, repository)),
                ('sanitizer artifacts', artifacts, lambda: capture_artifacts(build, private / 'after-sanitizer-artifacts', helper, False))):
            try:
                destination['after'] = capture()
            except Exception as error:
                receipt['errors'].append('After seal ' + name + ': ' + str(error))
        checks = {}
        try:
            aggregate.require_source(source['after'], args.expected_commit, args.expected_tree)
            checks['source_unchanged'] = bool(source.get('before_tests')) and all(
                value == source['before_build'] for value in source.values())
            changed, aliases, rejected = aggregate.elf_changes(elf.get('before_tests', {}), elf['after'], build)
            receipt['verified_private_profile_elf_aliases'] = aliases
            checks['normal_elf_unchanged'] = bool(elf.get('before_tests')) and not changed and not rejected
            checks['focused_builder_preserved_normal_elf'] = bool(elf.get('after_default_build')) and elf.get('after_default_build') == elf.get('before_tests')
            checks['freshness_unchanged'] = bool(freshness.get('before_tests')) and all(value == freshness['after_default_build'] for value in freshness.values())
            checks['compile_database_unchanged'] = compile_before is not None and compile_before == aggregate.sha(build / 'compile_commands.json')
            checks['registry_unchanged'] = registry_before is not None and registry_before == aggregate.sha(build / 'meson-info/intro-tests.json')
            checks['sanitizer_artifacts_unchanged'] = bool(artifacts.get('before_tests')) and artifacts.get('before_tests') == artifacts.get('after')
            if artifacts.get('before_tests'):
                copied = {name: helper.path_fingerprint(output / 'sanitizer-artifacts' / name) for name in SAN_FILES}
                checks['preserved_sanitizer_copies_match'] = copied == artifacts['before_tests']
            if locale_directory is not None and catalogs.get('before'):
                aggregate.verify_staged_locales(locale_directory, catalogs['before'])
                after = json.loads(json.dumps(catalogs['before']))
                after['metadata_sha256'] = {name: aggregate.sha(build / name) for name in after['metadata_sha256']}
                for name, row in after['catalogs'].items():
                    row['sha256'] = aggregate.sha(locale_directory / name)
                    row['size_bytes'] = (locale_directory / name).stat().st_size
                    require(row['sha256'] == aggregate.sha(build / row['source']), 'Original compiled catalog changed: ' + name)
                catalogs['after'] = after
                checks['all_361_catalogs_unchanged'] = after == catalogs['before'] and after['catalog_count'] == 361
        except Exception as error:
            receipt['errors'].append('Integrity verification: ' + str(error))
        receipt['integrity_checks'] = checks
        required_checks = {'source_unchanged', 'normal_elf_unchanged', 'focused_builder_preserved_normal_elf',
            'freshness_unchanged', 'compile_database_unchanged', 'registry_unchanged',
            'sanitizer_artifacts_unchanged', 'preserved_sanitizer_copies_match', 'all_361_catalogs_unchanged'}
        if set(checks) != required_checks or not all(checks.values()):
            receipt['errors'].append('Missing or false integrity checks')
        for name, value in (('source-integrity.json', source), ('elf-integrity.json', elf),
                            ('freshness.json', freshness), ('locales.json', catalogs),
                            ('sanitizer-artifacts.json', artifacts)):
            try:
                save(name, value, True)
            except Exception as error:
                receipt['errors'].append('Cannot publish seal ' + name + ': ' + str(error))
        # On interrupted/failed commands preserve every available raw result too.
        for raw, name, jsonl in ((private / 'report.json', 'sanitizer-build-report.json', False),
                                (private / 'meson.json', 'normal-results.json', True)):
            try:
                json_log(raw, name, jsonl)
            except Exception as error:
                receipt['errors'].append('Result publication ' + name + ': ' + str(error))
        if (private / 'meson.txt').is_file():
            try:
                text_log(private / 'meson.txt', 'testlog.txt', True)
            except Exception as error:
                receipt['errors'].append('Meson text publication: ' + str(error))
        save('normal-gate.json', normal_gate)
        save('sanitizer-run.json', sanitizer_run)
        save('transforms.json', transforms)
        receipt['normal_target_count'] = len(normal_gate)
        receipt['normal_tap_passed_count'] = sum(row['tap']['passed_count'] for row in normal_gate)
        receipt['sanitizer_tap_passed_count'] = sanitizer_run.get('tap', {}).get('passed_count', 0)
        receipt['finished_utc'] = utc()
        receipt['files'] = {path.relative_to(output).as_posix(): aggregate.sha(path)
                            for path in sorted(output.rglob('*')) if path.is_file() and path.name != 'receipt.json'}
        if not receipt['errors']:
            receipt['status'] = 'passed'
        save('receipt.json', receipt)
    print('Rotation-start evidence ' + receipt['status'] + ': ' + str(output / 'receipt.json'))
    for error in receipt['errors']:
        print(sanitizer.text(error), file=sys.stderr)
    return 0 if receipt['status'] == 'passed' else 1


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository', type=Path, default=DEFAULT_REPOSITORY)
    parser.add_argument('--build', type=Path, default=DEFAULT_BUILD)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--expected-commit', required=True)
    parser.add_argument('--expected-tree', required=True)
    parser.add_argument('--expected-event-sha256', required=True)
    parser.add_argument('--under-xvfb', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    for name in ('repository', 'build', 'output'):
        setattr(args, name, getattr(args, name).resolve())
    if any(re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}', value) is None for value in (args.expected_commit, args.expected_tree)):
        parser.error('Commit and tree must be full hexadecimal object IDs')
    if not re.fullmatch(r'[0-9a-f]{64}', args.expected_event_sha256):
        parser.error('Event source SHA-256 must be exact')
    private = args.output.with_name(args.output.name + '-private')
    if any(path.is_relative_to(args.repository) or path.is_relative_to(args.build) for path in (args.output, private)):
        parser.error('Public and private evidence must be outside source and build')
    if args.output.exists() or private.exists():
        parser.error('Use a new output path; prior evidence is never overwritten')
    clone, aggregate, helper = committed_modules(args.repository, args.expected_commit)
    if aggregate.SHARED_LOCK != LOCK:
        parser.error('Committed shared build lock path differs from approved lock')
    if not args.under_xvfb:
        state = aggregate.source_state(args.repository, helper)
        aggregate.require_source(state, args.expected_commit, args.expected_tree)
        if digest((args.repository / TEST_SOURCES[TARGETS[0]]).read_bytes()) != args.expected_event_sha256:
            parser.error('Event source does not match accepted SHA-256')
        # Exactly one wrapper launch. It authenticates, rejects empty authority,
        # and imposes a 3500-second child lifetime before starting this script.
        environment = clone.filtered_environment(os.environ)
        environment.update(TMPDIR='/tmp', PYTHONDONTWRITEBYTECODE='1', CCACHE_DISABLE='1')
        original = sys.argv[1:] if argv is None else list(argv)
        os.execvpe(sys.executable, [sys.executable, '-B', str(args.repository / WRAPPER),
                   sys.executable, '-B', str(HERE), *original, '--under-xvfb'], environment)
    args.output.mkdir(parents=True, exist_ok=False, mode=0o700)
    private.mkdir(exist_ok=False, mode=0o700)
    old_umask = os.umask(0o077)
    def interrupted(number, frame):
        raise KeyboardInterrupt('Received signal ' + str(number))
    previous = {number: signal.signal(number, interrupted) for number in (signal.SIGTERM, signal.SIGHUP, signal.SIGALRM)}
    # Leave 180 seconds for cleanup/seals before the wrapper's hard bound.
    signal.alarm(3320)
    try:
        with LOCK.open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            return run_locked(args, args.output, private, clone, aggregate, helper)
    finally:
        signal.alarm(0)
        for number, handler in previous.items():
            signal.signal(number, handler)
        os.umask(old_umask)


if __name__ == '__main__':
    sys.exit(main())
