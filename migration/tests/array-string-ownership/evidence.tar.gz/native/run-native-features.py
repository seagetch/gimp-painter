from pathlib import Path
import hashlib,json,os,re,subprocess
base=Path(__file__).resolve().parent;root=base.parent;build=root/'gimp-native-restore-20261009/build-http';repo=root/'gimp-painter-port-active'
selected=('painter-provenance','painter-http','painter-xcf-roundtrip');rows={x['name']:x for x in json.loads((build/'meson-info/intro-tests.json').read_text())};results=[]
for name in selected:
 row=rows[name];env=os.environ.copy()
 for key,value in row['env'].items():env[key]=value+(':'+env.get(key,'') if key=='LD_LIBRARY_PATH' else '')
 p=subprocess.run(row['cmd'],cwd=build,env=env,text=True,capture_output=True,timeout=300)
 (base/(name+'-stdout.log')).write_text(p.stdout);(base/(name+'-stderr.log')).write_text(p.stderr)
 item={'name':name,'command':row['cmd'],'cwd':str(build),'exit_code':p.returncode,'passed':len(re.findall(r'^ok \d+',p.stdout,re.M)),'executable_sha256':hashlib.sha256(Path(row['cmd'][0]).read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(p.stdout.encode()).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr.encode()).hexdigest()};results.append(item);(base/'native-features.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(item),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
