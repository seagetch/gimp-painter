#!/usr/bin/env bash
set -uo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
run=/workspace/scratch/5b5281e79681/dialog-critical-validation
bash migration/tests/gtk-dialog-diagnostics/run-repro.sh "$run/final-repro" --expect-known-defect
known=$?
bash migration/tests/gtk-dialog-diagnostics/run-repro.sh "$run/strict-repro" --check-fixed
strict=$?
printf 'EXPECTED_DEFECT_EXIT=%s STRICT_EXIT=%s\n' "$known" "$strict" | tee "$run/final-repro-summary.txt"
[[ "$known" == 0 && "$strict" == 1 ]]
