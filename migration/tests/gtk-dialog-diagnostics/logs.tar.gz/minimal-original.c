/* Independent GTK3/ATK reproducer: no GIMP headers or code. */
#include <gtk/gtk.h>
#include <atk/atk.h>
#include <stdio.h>
#include <string.h>
static GtkWidget *window, *item, *dialog;
static unsigned dialogs, gdk_count, gtk_count, other_count;
static void log_count(const gchar *domain,GLogLevelFlags level,const gchar *message,gpointer unused)
{
  (void)unused;
  if(strstr(message,"gdk_window_get_window_type")) ++gdk_count;
  else if(strstr(message,"gtk_accessible_get_widget")) ++gtk_count;
  else ++other_count;
  g_log_default_handler(domain,level,message,NULL);
}
static void open_dialog(GtkMenuItem *menu,gpointer unused)
{
  (void)menu;(void)unused;++dialogs;
  dialog=gtk_dialog_new_with_buttons("GTK dependency control",GTK_WINDOW(window),0,"Close",GTK_RESPONSE_CLOSE,NULL);
  g_signal_connect_swapped(dialog,"response",G_CALLBACK(gtk_widget_destroy),dialog);
  gtk_widget_show(dialog);
}
static gboolean automatic(gpointer unused)
{
  (void)unused;
  g_print("PHASE hidden ATK action mapped=%d\n",gtk_widget_get_mapped(item));
  gboolean action=atk_action_do_action(ATK_ACTION(gtk_widget_get_accessible(item)),0);
  g_print("RESULT hidden-atk action=%d dialogs=%u gdk=%u gtk=%u other=%u\n",action,dialogs,gdk_count,gtk_count,other_count);
  gtk_dialog_response(GTK_DIALOG(dialog),GTK_RESPONSE_CLOSE);
  unsigned before_gdk=gdk_count,before_gtk=gtk_count;
  g_print("PHASE direct GTK activation\n");
  gtk_menu_item_activate(GTK_MENU_ITEM(item));
  g_print("RESULT direct-gtk dialogs=%u added_gdk=%u added_gtk=%u other=%u\n",dialogs,gdk_count-before_gdk,gtk_count-before_gtk,other_count);
  gtk_dialog_response(GTK_DIALOG(dialog),GTK_RESPONSE_CLOSE);
  gtk_widget_destroy(window);
  return G_SOURCE_REMOVE;
}
int main(int argc,char **argv)
{
  gtk_init(&argc,&argv);
  g_log_set_handler("Gtk",G_LOG_LEVEL_CRITICAL,log_count,NULL);
  g_log_set_handler("Gdk",G_LOG_LEVEL_CRITICAL,log_count,NULL);
  g_print("GTK runtime=%u.%u.%u\n",gtk_get_major_version(),gtk_get_minor_version(),gtk_get_micro_version());
  window=gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(window),"GTK menu assertion control");
  gtk_window_set_default_size(GTK_WINDOW(window),400,160);
  GtkWidget *bar=gtk_menu_bar_new(),*root=gtk_menu_item_new_with_label("File"),*menu=gtk_menu_new();
  item=gtk_menu_item_new_with_label("Open Dialog");
  gtk_menu_shell_append(GTK_MENU_SHELL(menu),item);
  gtk_menu_item_set_submenu(GTK_MENU_ITEM(root),menu);
  gtk_menu_shell_append(GTK_MENU_SHELL(bar),root);
  gtk_container_add(GTK_CONTAINER(window),bar);
  g_signal_connect(item,"activate",G_CALLBACK(open_dialog),NULL);
  g_signal_connect(window,"destroy",G_CALLBACK(gtk_main_quit),NULL);
  gtk_widget_show_all(window);
  if(argc>1 && !strcmp(argv[1],"--automatic")) g_idle_add(automatic,NULL);
  gtk_main();
  g_print("FINAL dialogs=%u gdk=%u gtk=%u other=%u\n",dialogs,gdk_count,gtk_count,other_count);
  return (argc>1 && (dialogs!=2 || gdk_count!=1 || gtk_count!=1 || other_count!=0))?1:0;
}
