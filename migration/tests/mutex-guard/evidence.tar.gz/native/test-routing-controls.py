from pathlib import Path
import copy,hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent.parent/'gimp-painter-port-active';sys.path.insert(0,str(root/'tools'))
from audit_legacy_granularity import specification,validate
from assign_legacy_hunks import read_tsv
expected,_=specification();actual=read_tsv(root/'migration/inventory/legacy-port-work-items.tsv');key='legacy-d9601d797e1afecd978e';index=next(i for i,x in enumerate(actual) if x['work_id']==key);results=[]
assert not validate(expected,actual);results.append({'case':'positive-current-ledger','pass':True})
for name,edit,required in [
 ('missing-added-obligation',lambda rows:rows.pop(index),'missing work item'),
 ('duplicate-added-obligation',lambda rows:rows.append(dict(rows[index])),'duplicate work item'),
 ('changed-source-identity',lambda rows:rows[index].update(source_blob='0'*40),'changed source/action contract'),
 ('wrong-task-assignment',lambda rows:rows[index].update(wbs_task='06.021'),'changed source/action contract'),
 ('done-without-evidence',lambda rows:rows[index].update(artifact=''),'DONE requires'),
 ('unknown-work-id',lambda rows:rows.append(dict(rows[index],work_id='legacy-unknown')),'unassigned work item')]:
 rows=copy.deepcopy(actual);edit(rows);errors=validate(expected,rows);assert any(required in error for error in errors),(name,errors);results.append({'case':name,'pass':True,'matched_error':next(error for error in errors if required in error)})
paths=list((root/'migration/inventory').glob('*'));before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
p=subprocess.run([sys.executable,str(root/'migration/tests/mutex-guard/reproduce-mutex-routing.py'),'--write'],cwd=root,text=True,capture_output=True);assert p.returncode and 'Refusing to overwrite later work' in p.stderr
assert before=={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
results.append({'case':'write-guard-preserves-completion','pass':True,'exit_code':p.returncode,'stderr':p.stderr,'all_inventory_bytes_unchanged':True})
Path(__file__).with_name('routing-controls.json').write_text(json.dumps(results,indent=2)+'\n');print('PASS:positive ledger, six negative contract controls, later-work write guard')
