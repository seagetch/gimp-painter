import hashlib,json,shlex,subprocess
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter-installed-filter');minimum=root.parent/'filter-policy-minimum';out=root.parent/'filter-schema-evidence/minimum-compile';out.mkdir(exist_ok=True)
source=minimum/'src/gimp';build=minimum/'build/gimp';entries=json.loads((build/'compile_commands.json').read_text())
files=['app/core/gimpfilterlayer.cpp','app/core/gimpfilterpaths.cpp','app/core/gimpfilterparametereditor.cpp','app/dialogs/painter-layer-dialog.cpp','app/plug-in/gimppluginmanager.c','app/plug-in/gimppluginmanager-restore.c']
report={'scope':'Changed-unit compile-only using frozen actual GLib2.70.0 headers; not a new full minimum build or runtime pass','results':[]}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in files:
 template='app/core/gimpfilterprocedure-arguments.cpp' if name.endswith('gimpfilterparametereditor.cpp') else name
 entry=next(e for e in entries if (Path(e['directory'])/e['file']).resolve()==source/template)
 argv=shlex.split(entry['command']);clean=[];i=0
 while i<len(argv):
  a=argv[i];i+=1
  if a in ['-o','-MF','-MQ','-MT']:
   i+=1;continue
  if a in ['-MD','-MMD']:continue
  if a.startswith('-I') and len(a)>2:
   p=(Path(entry['directory'])/a[2:]).resolve()
   if p.is_relative_to(source):a='-I'+str(root/p.relative_to(source))
  if a==entry['file']:a=str(root/name)
  clean.append(a)
 obj=out/(name.replace('/','_')+'.o');dep=obj.with_suffix('.d');cmd=clean+['-MD','-MF',str(dep),'-o',str(obj)]
 r=subprocess.run(cmd,cwd=entry['directory'],capture_output=True,text=True,timeout=180)
 (out/(obj.stem+'.log')).write_text(r.stdout+r.stderr)
 item={'source':name,'source_sha256':sha(root/name),'command':cmd,'exit_code':r.returncode}
 if r.returncode==0:
  deps=shlex.split(dep.read_text().replace('\\\n',' ').split(':',1)[1]);headers={}
  for d in deps:
   p=(Path(entry['directory'])/d).resolve()
   if '/glib-2.0/' in str(p):headers[str(p)]=sha(p)
  item.update(object_sha256=sha(obj),glib_headers=headers)
  if not headers or any(not Path(p).is_relative_to(minimum/'prefix') for p in headers):raise RuntimeError('Unexpected GLib header provenance')
 report['results'].append(item);(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
 if r.returncode:raise RuntimeError('Minimum compile failed: '+name)
header=minimum/'prefix/include/glib-2.0/glib/gversion.h'
report['glib_version_header']={'path':str(header),'sha256':sha(header)};report['passed']=True
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print('Actual GLib2.70 changed-unit compile: 6 passed')
