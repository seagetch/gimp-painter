#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
schema_evidence=/workspace/scratch/5b5281e79681/filter-schema-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$schema_evidence/gui-session-exit.txt"' EXIT
printf 'RUNNING\n' > "$schema_evidence/gui-session-exit.txt"
ulimit -c 0
mkdir -p "$schema_evidence/gui-profile-complete" "$schema_evidence/gui-cache"
cat > "$schema_evidence/gui-profile-complete/gimprc" <<'RC'
(plug-in-path "/workspace/scratch/5b5281e79681/gimp-painter-installed-filter/build-installed-filter/plug-ins/common")
RC
export GIMP3_DIRECTORY="$schema_evidence/gui-profile-complete" GIMP3_CACHEDIR="$schema_evidence/gui-cache"
export GSETTINGS_BACKEND=memory LC_ALL=C.UTF-8
export GIMP_TESTING_MENUS_PATH="$PWD/build-installed-filter/menus:$PWD/menus"
export GIMP3_SYSCONFDIR="$PWD/etc" GIMP_TESTING_PLUGINDIRS="$PWD/build-installed-filter/plug-ins/common"
flock "$GIMP_PAINTER_BUILD_LOCK" dbus-run-session -- build-installed-filter/app/gimp-3.0 --new-instance --no-splash --no-fonts --console-messages > "$schema_evidence/gui.log" 2>&1
