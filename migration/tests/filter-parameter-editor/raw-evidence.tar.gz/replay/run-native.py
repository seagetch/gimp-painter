import argparse,hashlib,json,os,re,resource,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--mode',choices=['normal','sanitized','baseline'],default='normal');p.add_argument('--case',action='append',default=[]);p.add_argument('--label');a=p.parse_args();label=a.label or a.mode
root=Path('/workspace/scratch/5b5281e79681/gimp-painter-installed-filter');build=root/'build-installed-filter';out=root.parent/'filter-schema-evidence'
test=next(t for t in json.loads((build/'meson-info/intro-tests.json').read_text()) if t['name']=='painter-layer-ui')
env=os.environ.copy();old=env.get('LD_LIBRARY_PATH','');env.update(test.get('env',{}))
if 'LD_LIBRARY_PATH' in test.get('env',{}):env['LD_LIBRARY_PATH']+=':'+old
env.update(GIMP3_CACHEDIR=str(build/'filter-spill-cache'),GSETTINGS_BACKEND='memory',ASAN_OPTIONS='detect_leaks=0:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
name='painter-layer-ui'+{'normal':'','sanitized':'-asan','baseline':'-before-schema'}[a.mode];binary=build/'app/tests'/name
cmd=['dbus-run-session','--',str(binary),'--verbose']
for case in a.case:cmd += ['-p','/painter-layer-ui/'+case]
start=time.monotonic();result=subprocess.run(cmd,cwd=build,env=env,capture_output=True,text=True,timeout=600);elapsed=time.monotonic()-start
log=result.stdout+result.stderr;(out/(label+'-native.log')).write_text(log)
actual=re.findall(r'^ok \d+ /painter-layer-ui/(\S+)$',result.stdout,re.M)
plans=[int(n) for n in re.findall(r'^1\.\.(\d+)$',result.stdout,re.M)]
full_ok=bool(plans) and len(actual)==plans[-1] and not re.search(r'^ok .*#\s*SKIP',result.stdout,re.M)
receipt=dict(command=cmd,exit_code=result.returncode,selected=a.case,executed=actual,pass_all=result.returncode==0 and (set(actual)==set(a.case) if a.case else full_ok),elapsed_seconds=elapsed,max_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source_sha256={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in [root/'app/dialogs/painter-layer-dialog.cpp',root/'app/core/gimpfilterparametereditor.cpp',root/'app/core/gimpfilterlayer.cpp',root/'app/core/gimpfilterlayer-arguments.hpp',root/'app/tests/test-painter-layer-ui.c',root/'app/tests/test-filter-schema-editors.inc']})
if a.mode=='baseline':
 receipt.pop('source_sha256',None);receipt['source_limitation']='Retained pre-Phase-C executable; binary hash verified, compile-source identity not re-established.'
(out/(label+'-native.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
raise SystemExit(0 if receipt['pass_all'] else 1)
