import hashlib,json,os,re,resource,subprocess,time
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter-installed-filter');build=root/'build-installed-filter';out=root.parent/'filter-schema-evidence'
core=['parameter_suffix_reordering','parameter_metadata_rejections','parameter_assignment_validation','parameter_object_lifetime','argument_value_dag_is_bounded','typed_argument_import_preserves_descriptors','argument_import_validation','typed_argument_snapshot_survives_expiration','saved_snapshot_generation_restore','duplicate_preserves_cache_freshness','opaque_arguments_duplicate_and_undo','opaque_arguments_never_execute','empty_opaque_arguments_are_distinct','retired_definition_payload_reentry','duplicate_reentry_cannot_certify_new_definition','definition_edit_stops_after_undo_close','definition_edit_preserves_reentered_install','definition_notifications_stop_after_close','definition_revision_separates_cache_updates','definition_undo_redo','object_arguments_do_not_cycle','expired_object_records_and_reassignment','object_array_arguments_do_not_dangle','saved_definition_is_separate','duplicate_keeps_definition','blinds_actual_old_context','small_tiles_actual_old_live','retinex_actual_old_live','convolution_actual_old_live','progress_real_workers','progress_worker_cancel_replace_close']
xcf=['/painter-xcf-roundtrip/filter_cache_and_arguments','/painter-xcf-roundtrip/typed_nested_expired_arguments','/painter-xcf-roundtrip/duplicate_unknown_records','/painter-xcf-roundtrip/cancel_and_reentrant_edit','/painter-xcf-roundtrip/low_level_reentrant_definitions','/painter-xcf-roundtrip/replace_uninterpreted_arguments','/painter-xcf-roundtrip/opaque_argument_shapes','/painter-xcf-roundtrip/external_references_remain_unresolved','/painter-xcf-roundtrip/malformed_filter_cache_stays_opaque','/painter-xcf-fields/modern_effect_argument_families','/painter-xcf-multipart/argument-snapshot-borrow','/painter-xcf-multipart/native-owner-duplicate-edit','/painter-xcf-multipart/native-callback-argument-leases','/painter-xcf-multipart/native-argument-budget']
reports=[]
for name,paths in [('gimp-filter-layer',['/gimp-filter-layer/'+c for c in core]),('painter-xcf-roundtrip',xcf)]:
 test=next(t for t in json.loads((build/'meson-info/intro-tests.json').read_text()) if t['name']==name)
 env=os.environ.copy();old=env.get('LD_LIBRARY_PATH','');env.update(test.get('env',{}))
 if 'LD_LIBRARY_PATH' in test.get('env',{}):env['LD_LIBRARY_PATH']+=':'+old
 env['GIMP3_CACHEDIR']=str(build/'filter-spill-cache')
 binary=build/'app/tests'/name;cmd=['dbus-run-session','--']
 if name=='gimp-filter-layer':cmd += ['python3','-B',str(root/'migration/tests/run_filter_owner_context_fixture_test.py'),'--']
 cmd += [str(binary),'--verbose']
 for path in paths:cmd += ['-p',path]
 start=time.monotonic();r=subprocess.run(cmd,cwd=build,env=env,capture_output=True,text=True,timeout=600)
 (out/(name+'-regression.log')).write_text(r.stdout+r.stderr)
 actual=re.findall(r'^ok \d+ (\S+)$',r.stdout,re.M)
 item=dict(command=cmd,exit_code=r.returncode,selected=paths,executed=actual,passed=r.returncode==0 and set(actual)==set(paths),elapsed_seconds=time.monotonic()-start,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest());reports.append(item)
 (out/'core-xcf-regressions.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(item),flush=True)
 if not item['passed']:raise SystemExit(1)
