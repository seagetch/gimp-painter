#!/usr/bin/env bash
set -euo pipefail
cd /workspace/scratch/5b5281e79681/gimp-painter-installed-filter
source /workspace/scratch/5b5281e79681/gimp-build-restoration/env.sh
source tools/linux-debian13-env.sh
schema_evidence=/workspace/scratch/5b5281e79681/filter-schema-evidence
trap 'result=$?; printf "EXIT %s\n" "$result" > "$schema_evidence/normal-session-exit.txt"' EXIT
printf 'RUNNING\n' > "$schema_evidence/normal-session-exit.txt"
ulimit -c 0
flock "$GIMP_PAINTER_BUILD_LOCK" python3 -B "$schema_evidence/run-native.py" > "$schema_evidence/normal-driver.log" 2>&1
