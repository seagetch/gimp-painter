import hashlib,json,sys,subprocess
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter')
sources=['app/dialogs/preferences-dialog.c','app/tests/test-layer-presets-ui.c','app/tests/test-gimp-filter-layout.cpp','app/config/gimpgeglconfig.c','app/config/gimppainterfilterconfig.cpp','app/painter/work-admission.hpp','app/painter/tests/test-work-admission.cpp']
executables=['app/tests/layer-presets-ui','app/tests/painter-mypaint-editor','app/tests/gimp-filter-layer','app/painter/painter-work-admission','app/painter/painter-filter-raster','app/painter/painter-filter-spool','app/painter/painter-filter-scheduler']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
Path(sys.argv[1]).write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'source_sha256':{p:sha(root/p) for p in sources},'executable_sha256':{p:sha(root/'build-debian13'/p) for p in executables}},indent=2)+'\n')
