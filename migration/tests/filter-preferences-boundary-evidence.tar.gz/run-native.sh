#!/usr/bin/env bash
set -eo pipefail
ROOT=/workspace/shared/painter-filter-preferences-20261002
REPO=/workspace/scratch/5b5281e79681/gimp-painter
cd "$REPO"
exec 9>/workspace/shared/gimp-painter-build.lock
flock -x 9
export GIMP_DEPS_DIRECTORY=/workspace/shared/gimp-build-deps
source tools/linux-debian13-env.sh
export UI_TEST=yes GSETTINGS_BACKEND=memory PYTHONDONTWRITEBYTECODE=1
mkdir -p "$ROOT"/profiles/{config,cache,data,tmp,gimp}
export XDG_CONFIG_HOME="$ROOT/profiles/config" XDG_CACHE_HOME="$ROOT/profiles/cache" XDG_DATA_HOME="$ROOT/profiles/data" TMPDIR="$ROOT/profiles/tmp" GIMP3_DIRECTORY="$ROOT/profiles/gimp"
test -n "$DISPLAY"
python3 "$ROOT/snapshot.py" "$ROOT/before.json"
set +e
meson test -C build-debian13 --no-rebuild --num-processes 1 --timeout-multiplier 3 --print-errorlogs --logbase filter-preferences-boundary-20261002 layer-presets-ui painter-mypaint-editor gimp-filter-layer painter-work-admission painter-filter-raster painter-filter-spool painter-filter-scheduler 2>&1 | tee "$ROOT/native-console.log"
status=${PIPESTATUS[0]}
set -e
printf '%s\n' "$status" > "$ROOT/native-exit.txt"
cp build-debian13/meson-logs/filter-preferences-boundary-20261002.json "$ROOT/native.jsonl"
cp build-debian13/meson-logs/filter-preferences-boundary-20261002.txt "$ROOT/native.txt"
python3 "$ROOT/snapshot.py" "$ROOT/after.json"
python3 migration/tests/sanitize_filter_evidence.py "$ROOT/native.jsonl" "$ROOT/native.txt" "$ROOT/native-console.log" "$ROOT/before.json" "$ROOT/after.json"
touch "$ROOT/wrapper-complete"
printf 'FILTER_PREFERENCES_NATIVE_EXIT=%s\n' "$status"
exit "$status"
