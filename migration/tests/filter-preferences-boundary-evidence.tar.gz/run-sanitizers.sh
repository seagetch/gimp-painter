#!/usr/bin/env bash
set -eo pipefail
ROOT=/workspace/shared/painter-filter-preferences-20261002
REPO=/workspace/scratch/5b5281e79681/gimp-painter
cd "$REPO"
exec 9>/workspace/shared/gimp-painter-build.lock
flock -x 9
export GIMP_DEPS_DIRECTORY=/workspace/shared/gimp-build-deps
source tools/linux-debian13-env.sh
mkdir -p "$ROOT"/sanitizers/profiles/{config,cache,data,tmp,gimp}
export UI_TEST=yes GSETTINGS_BACKEND=memory PYTHONDONTWRITEBYTECODE=1
export XDG_CONFIG_HOME="$ROOT/sanitizers/profiles/config" XDG_CACHE_HOME="$ROOT/sanitizers/profiles/cache" XDG_DATA_HOME="$ROOT/sanitizers/profiles/data" TMPDIR="$ROOT/sanitizers/profiles/tmp" GIMP3_DIRECTORY="$ROOT/sanitizers/profiles/gimp"
export GIMP_TESTING_ABS_TOP_SRCDIR="$REPO" GIMP_TESTING_ABS_TOP_BUILDDIR="$REPO/build-debian13" GIMP_TESTING_PLUGINDIRS="$REPO/build-debian13/plug-ins/common"
export ASAN_OPTIONS=detect_leaks=0:halt_on_error=1:abort_on_error=1 UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
test -n "$DISPLAY"
set +e
python3 "$ROOT/run-sanitizers.py" > "$ROOT/sanitizers/native.log" 2>&1
status=$?
set -e
python3 migration/tests/sanitize_filter_evidence.py "$ROOT/sanitizers/build.json" "$ROOT/sanitizers/run.json" "$ROOT/sanitizers/native.log"
printf '%s\n' "$status" > "$ROOT/sanitizers/native-exit.txt"
printf 'FILTER_PREFERENCES_ASAN_EXIT=%s\n' "$status"
exit "$status"
