#!/usr/bin/env python3
"""Compile only the Preferences boundary and its native GTK regression with ASan/UBSan.
Original objects/archives remain unchanged. Caller must hold the shared build lock.
"""
import hashlib,json,shlex,subprocess
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter')
build=root/'build-debian13'
out=Path('/workspace/shared/painter-filter-preferences-20261002/sanitizers')
out.mkdir(exist_ok=True)
wanted={'app/dialogs/preferences-dialog.c','app/tests/test-layer-presets-ui.c'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hashes={p:sha(root/p) for p in wanted}
flags=['-fsanitize=address,undefined','-fno-omit-frame-pointer','-O1']
replacements={};commands=[]
for entry in json.loads((build/'compile_commands.json').read_text()):
 source=(Path(entry['directory'])/entry['file']).resolve()
 try: relative=source.relative_to(root).as_posix()
 except ValueError: continue
 if relative not in wanted: continue
 cmd=shlex.split(entry['command']); clean=[];skip=False
 for arg in cmd:
  if skip:skip=False;continue
  if arg in ('-MF','-MQ','-MT'):skip=True;continue
  if arg not in ('-MD','-MMD'):clean.append(arg)
 obj=out/(source.name+'.o');clean[clean.index('-o')+1]=str(obj);clean+=flags
 commands.append(clean);subprocess.run(clean,cwd=build,check=True)
 replacements[entry['output']]=str(obj)
assert len(replacements)==2
archive='app/dialogs/libappdialogs.a'
members=subprocess.check_output(['ar','t',archive],cwd=build,text=True).splitlines()
private=out/'libappdialogs.a'
cmd=['ar','crsT',str(private)]+[replacements.get(member,str((build/member).resolve())) for member in members]
commands.append(cmd);subprocess.run(cmd,cwd=build,check=True)
link=shlex.split(subprocess.check_output(['ninja','-t','commands','app/tests/layer-presets-ui'],cwd=build,text=True).strip().splitlines()[-1])
exe=out/'layer-presets-ui-asan';link[link.index('-o')+1]=str(exe)
link=[str(private) if arg==archive else replacements.get(arg,arg) for arg in link]
link[1:1]=flags;commands.append(link);subprocess.run(link,cwd=build,check=True)
report={'scope':'Only preferences-dialog.c and test-layer-presets-ui.c instrumented; GIMP backend and dependencies uninstrumented',
 'instrumented_sources':sorted(wanted),'source_sha256':hashes,'changed_after_compile':[p for p,h in hashes.items() if sha(root/p)!=h],
 'commands':commands,'executable':str(exe),'executable_sha256':sha(exe),'sanitizers':['address','undefined'],'leak_detection':False}
(out/'build.json').write_text(json.dumps(report,indent=2)+'\n')
assert not report['changed_after_compile']
