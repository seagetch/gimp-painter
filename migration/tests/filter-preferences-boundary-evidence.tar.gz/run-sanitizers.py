import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/gimp-painter')
out=Path('/workspace/shared/painter-filter-preferences-20261002/sanitizers')
proof=json.loads((out/'build.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(root/p)==h for p,h in proof['source_sha256'].items())
assert sha(Path(proof['executable']))==proof['executable_sha256']
started=time.monotonic()
p=subprocess.run([proof['executable']],capture_output=True,text=True,timeout=180,cwd=root/'build-debian13')
report={'scope':proof['scope'],'sanitizers':proof['sanitizers'],'leak_detection':False,
 'source_sha256':proof['source_sha256'],'executable_sha256':proof['executable_sha256'],
 'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-started,'stdout':p.stdout,'stderr':p.stderr,
 'changed_after_run':[f for f,h in proof['source_sha256'].items() if sha(root/f)!=h]}
(out/'run.json').write_text(json.dumps(report,indent=2)+'\n')
print(p.stdout);print(p.stderr);raise SystemExit(p.returncode or bool(report['changed_after_run']))
