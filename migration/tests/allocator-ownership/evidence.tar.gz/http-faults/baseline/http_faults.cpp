// SPDX-License-Identifier: GPL-3.0-or-later
// Real httpd-resource.cpp fixture: only unrelated Router factories are isolated.
#include "httpd-resource.hpp"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>

namespace audit {
struct Allocation { void* p; std::size_t size; bool array; unsigned epoch; };
struct Pointer { void* p; unsigned epoch; };
static Allocation allocations[32768] = {};
static Pointer parsers[256] = {}, errors[256] = {}, buffers[256] = {};
static unsigned epoch = 0;
static bool active = false;
static unsigned attempts = 0, fail_at = 0, injected = 0;
static unsigned family_mismatches = 0, observer_overflows = 0;
static int resources_live = 0;
static unsigned parser_created = 0, parser_finalized = 0;
static unsigned error_created = 0, error_freed = 0;
static unsigned buffer_created = 0, buffer_freed = 0;
static void add_pointer(Pointer* records, void* p) {
  if (!active || !p) return;
  for (unsigned i = 0; i < 256; ++i) if (!records[i].p) {
    records[i] = {p, epoch}; return;
  }
  ++observer_overflows;
}
static bool remove_pointer(Pointer* records, void* p) {
  if (!p) return false;
  for (unsigned i = 0; i < 256; ++i) if (records[i].p == p) {
    records[i].p = nullptr; return true;
  }
  return false;
}
static unsigned live_pointers(Pointer* records) {
  unsigned n = 0;
  for (unsigned i = 0; i < 256; ++i) n += records[i].p && records[i].epoch == epoch;
  return n;
}
static void* allocate(std::size_t size, bool array) {
  if (active) {
    ++attempts;
    if (fail_at && attempts == fail_at) { ++injected; throw std::bad_alloc(); }
  }
  void* p = std::malloc(size ? size : 1);
  if (!p) throw std::bad_alloc();
  if (active) {
    bool recorded = false;
    for (unsigned i = 0; i < 32768; ++i) if (!allocations[i].p) {
      allocations[i] = {p, size, array, epoch}; recorded = true; break;
    }
    if (!recorded) ++observer_overflows;
  }
  return p;
}
static void deallocate(void* p, bool array) noexcept {
  if (!p) return;
  for (unsigned i = 0; i < 32768; ++i) if (allocations[i].p == p) {
    if (allocations[i].array != array) ++family_mismatches;
    allocations[i].p = nullptr; break;
  }
  // g_malloc/json_to_string storage must never be released with C++ delete.
  for (unsigned i = 0; i < 256; ++i)
    if (buffers[i].p == p || errors[i].p == p || parsers[i].p == p)
      ++family_mismatches;
  std::free(p);
}
static unsigned live_allocations(std::size_t* bytes) {
  unsigned n = 0; *bytes = 0;
  for (unsigned i = 0; i < 32768; ++i) if (allocations[i].p && allocations[i].epoch == epoch) {
    ++n; *bytes += allocations[i].size;
  }
  return n;
}
}

#ifndef AUDIT_NO_NEW_OVERRIDE
void* operator new(std::size_t n) { return audit::allocate(n, false); }
void* operator new[](std::size_t n) { return audit::allocate(n, true); }
void operator delete(void* p) noexcept { audit::deallocate(p, false); }
void operator delete[](void* p) noexcept { audit::deallocate(p, true); }
void operator delete(void* p, std::size_t) noexcept { audit::deallocate(p, false); }
void operator delete[](void* p, std::size_t) noexcept { audit::deallocate(p, true); }
#endif

extern "C" {
JsonParser* __real_json_parser_new(void);
gboolean __real_json_parser_load_from_data(JsonParser*, const gchar*, gssize, GError**);
gchar* __real_json_to_string(JsonNode*, gboolean);
void __real_g_free(gpointer);
void __real_g_clear_error(GError**);
void __real_g_error_free(GError*);
static void parser_finalized(gpointer, GObject* p) {
  if (audit::remove_pointer(audit::parsers, p)) ++audit::parser_finalized;
}
JsonParser* __wrap_json_parser_new(void) {
  JsonParser* p = __real_json_parser_new();
  if (audit::active) {
    audit::add_pointer(audit::parsers, p); ++audit::parser_created;
    g_object_weak_ref(G_OBJECT(p), parser_finalized, nullptr);
  }
  return p;
}
gboolean __wrap_json_parser_load_from_data(JsonParser* p, const gchar* data,
                                           gssize len, GError** error) {
  gboolean result = __real_json_parser_load_from_data(p, data, len, error);
  if (audit::active && error && *error) {
    audit::add_pointer(audit::errors, *error); ++audit::error_created;
  }
  return result;
}
gchar* __wrap_json_to_string(JsonNode* node, gboolean pretty) {
  gchar* p = __real_json_to_string(node, pretty);
  if (audit::active && p) { audit::add_pointer(audit::buffers, p); ++audit::buffer_created; }
  return p;
}
void __wrap_g_free(gpointer p) {
  if (audit::remove_pointer(audit::buffers, p)) ++audit::buffer_freed;
  for (unsigned i = 0; i < 32768; ++i)
    if (p && audit::allocations[i].p == p) ++audit::family_mismatches;
  __real_g_free(p);
}
void __wrap_g_clear_error(GError** p) {
  if (p && audit::remove_pointer(audit::errors, *p)) ++audit::error_freed;
  __real_g_clear_error(p);
}
void __wrap_g_error_free(GError* p) {
  if (audit::remove_pointer(audit::errors, p)) ++audit::error_freed;
  __real_g_error_free(p);
}
}

namespace GimpPainter { namespace Http {
class CountedResource final : public Resource {
 public:
  CountedResource() { ++audit::resources_live; }
  ~CountedResource() override { --audit::resources_live; }
  Response handle(Gimp*, const Request&) override { return Response{}; }
};
std::unique_ptr<Resource> images_resource() { return std::unique_ptr<Resource>(new CountedResource); }
std::unique_ptr<Resource> pdb_resource() { return std::unique_ptr<Resource>(new CountedResource); }
}}

int main(int argc, char** argv) {
  if (argc != 3) { std::fprintf(stderr, "usage: %s CASE FAIL_AT\n", argv[0]); return 64; }
  using namespace GimpPainter::Http;
  const char* test = argv[1];
  const unsigned fail = static_cast<unsigned>(std::strtoul(argv[2], nullptr, 10));
  if (std::strcmp(test, "router") && std::strcmp(test, "parse_valid") &&
      std::strcmp(test, "parse_invalid") && std::strcmp(test, "parse_empty") &&
      std::strcmp(test, "parse_oversize") && std::strcmp(test, "reply")) return 64;
  // Warm up the real libraries before the bounded failure scope.
  { auto n = parse("{\"warm\":true}"); auto r = reply(std::move(n)); }
  try { auto n = parse("{broken"); } catch (const Failure&) {}
  { Router r; }
  std::string input = "{\"label\":\"actual JSON-GLib parse\",\"items\":[1,2,3]}";
  if (!std::strcmp(test, "parse_invalid")) input = "{\"broken\": [1, 2, invalid-json-for-a-real-error]}";
  if (!std::strcmp(test, "parse_empty")) input.clear();
  if (!std::strcmp(test, "parse_oversize")) input.assign(1024 * 1024 + 1, 'x');
  Json value;
  if (!std::strcmp(test, "reply")) {
    value = object();
    set(value.get(), "payload", string("This is a real JSON-GLib serialization, deliberately long enough to require a heap-backed response body."));
  }
  unsigned observed_status = 0;
  bool semantic_ok = true;
  const char* outcome = "success";
  ++audit::epoch; audit::attempts = 0; audit::fail_at = fail; audit::active = true;
  try {
    if (!std::strcmp(test, "router")) {
      Router router;
    } else if (!std::strcmp(test, "reply")) {
      Response response = reply(std::move(value), 201);
      semantic_ok = response.status == 201 && response.content_type == "application/json; charset=utf-8" &&
                    response.body.find("real JSON-GLib serialization") != std::string::npos;
    } else {
      Json parsed = parse(input);
      semantic_ok = !std::strcmp(test, "parse_valid") && JSON_NODE_HOLDS_OBJECT(parsed.get()) &&
                    json_object_has_member(json_node_get_object(parsed.get()), "label");
    }
  } catch (const std::bad_alloc&) {
    outcome = "bad_alloc";
  } catch (const Failure& e) {
    outcome = "http_failure"; observed_status = e.status;
    semantic_ok = ((!std::strcmp(test, "parse_invalid") || !std::strcmp(test, "parse_empty")) && e.status == 400) ||
                  (!std::strcmp(test, "parse_oversize") && e.status == 413);
  } catch (...) { outcome = "unexpected_exception"; semantic_ok = false; }
  audit::active = false;
  value.reset();
  std::size_t bytes = 0;
  const unsigned cpp_live = audit::live_allocations(&bytes);
  const unsigned parser_live = audit::live_pointers(audit::parsers);
  const unsigned error_live = audit::live_pointers(audit::errors);
  const unsigned buffer_live = audit::live_pointers(audit::buffers);
  const bool leaked = cpp_live || audit::resources_live || parser_live || error_live || buffer_live;
  const bool ok = semantic_ok && !leaked && !audit::family_mismatches && !audit::observer_overflows &&
                 (audit::injected == 0 || !std::strcmp(outcome, "bad_alloc"));
  std::printf("{\"case\":\"%s\",\"fail_at\":%u,\"outcome\":\"%s\",\"status\":%u,\"attempts\":%u,\"injected\":%u,"
              "\"cpp_live\":%u,\"cpp_live_bytes\":%zu,\"resources_live\":%d,\"parser_live\":%u,\"parser_created\":%u,\"parser_finalized\":%u,"
              "\"error_live\":%u,\"error_created\":%u,\"error_freed\":%u,\"buffer_live\":%u,\"buffer_created\":%u,\"buffer_freed\":%u,"
              "\"family_mismatches\":%u,\"observer_overflows\":%u,\"semantic_ok\":%s,\"ok\":%s}\n",
              test, fail, outcome, observed_status, audit::attempts, audit::injected, cpp_live, bytes, audit::resources_live,
              parser_live, audit::parser_created, audit::parser_finalized, error_live, audit::error_created, audit::error_freed,
              buffer_live, audit::buffer_created, audit::buffer_freed, audit::family_mismatches, audit::observer_overflows,
              semantic_ok ? "true" : "false", ok ? "true" : "false");
  return ok ? 0 : 1;
}
