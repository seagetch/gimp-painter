#!/usr/bin/env python3
"""Compile the real HTTP TU with its native compile-db includes/defines, isolated GC link."""
import argparse, hashlib, json, pathlib, shlex, subprocess
p = argparse.ArgumentParser()
p.add_argument('variant', choices=['baseline','fixed'])
p.add_argument('--sanitize', action='store_true')
p.add_argument('--native-new', action='store_true')
a = p.parse_args()
root = pathlib.Path(__file__).resolve().parent
workspace = root.parents[1]
repo = workspace / 'gimp-painter-port-active'
build = workspace / 'gimp-native-restore-20261009/build-http'
db = json.loads((build / 'compile_commands.json').read_text())
entry = next(x for x in db if x['file'].endswith('/httpd-resource.cpp'))
argv = shlex.split(entry['command'])
filtered = []
i = 0
while i < len(argv):
    x = argv[i]
    if x in ['-o','-MF','-MQ']:
        i += 2
    elif x in ['-c','-MD'] or x == entry['file']:
        i += 1
    else:
        filtered.append(x); i += 1
filtered += ['-ffunction-sections','-fdata-sections']
if a.sanitize: filtered += ['-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer']
if a.native_new: filtered += ['-DAUDIT_NO_NEW_OVERRIDE']
name = a.variant + ('-asan-ubsan' if a.sanitize else '') + ('-native-new' if a.native_new else '')
out = root / name
out.mkdir(exist_ok=True)
source = root / 'httpd-resource.baseline.cpp' if a.variant == 'baseline' else repo / 'app/httpd/httpd-resource.cpp'
# A per-build snapshot makes the source hash fully reproducible even if the active tree changes.
snapshot = out / 'httpd-resource.cpp'
snapshot.write_bytes(source.read_bytes())
commands = [filtered + ['-c', str(snapshot), '-o', str(out / 'resource.o')],
            filtered + ['-c', str(root / 'http_faults.cpp'), '-o', str(out / 'fixture.o')]]
libs = shlex.split(subprocess.check_output(['pkg-config','--libs','json-glib-1.0','gtk+-3.0','gobject-2.0'],text=True))
link = ['c++',str(out / 'fixture.o'),str(out / 'resource.o'),'-Wl,--gc-sections']
link += ['-Wl,--wrap='+s for s in ['json_parser_new','json_parser_load_from_data','json_to_string','g_free','g_clear_error','g_error_free']]
if a.sanitize: link += ['-fsanitize=address,undefined']
link += libs + ['-o',str(out / 'http-faults')]
commands.append(link)
(out / 'commands.json').write_text(json.dumps({'cwd':entry['directory'],'commands':commands},indent=2)+'\n')
(out / 'source-hashes.json').write_text(json.dumps({str(x):hashlib.sha256(x.read_bytes()).hexdigest() for x in [snapshot, root / 'http_faults.cpp', root / 'build.py', build / 'compile_commands.json', repo / 'app/httpd/httpd-resource.hpp']},indent=2)+'\n')
for command in commands:
    subprocess.run(command,cwd=entry['directory'],check=True)
print(out / 'http-faults')
