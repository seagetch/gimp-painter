#!/usr/bin/env python3
"""One process per deterministic allocation failure, to isolate intentional baseline leaks."""
import argparse, hashlib, json, os, pathlib, subprocess
p=argparse.ArgumentParser()
p.add_argument('directory',type=pathlib.Path)
p.add_argument('--expect-leaks',action='store_true')
p.add_argument('--control-only',action='store_true')
p.add_argument('--fatal-criticals',action='store_true')
a=p.parse_args()
if a.fatal_criticals: os.environ['G_DEBUG']='fatal-criticals'
exe=a.directory.resolve()/'http-faults'
rows=[]; diagnostics=[]; failures=[]
cases=['router','parse_valid','parse_invalid','parse_empty','parse_oversize','reply']
for case in cases:
    control=subprocess.run([str(exe),case,'0'],capture_output=True,text=True)
    if control.stderr: diagnostics.append({'case':case,'fail_at':0,'stderr':control.stderr})
    if not control.stdout.strip():
        failures.append(f'{case} control produced no result: {control.returncode}')
        continue
    row=json.loads(control.stdout.strip()); row['exit_code']=control.returncode; rows.append(row)
    if not row['ok'] or control.returncode: failures.append(f'{case} control failed')
    if not a.control_only:
        for n in range(1,row['attempts']+2):
            child=subprocess.run([str(exe),case,str(n)],capture_output=True,text=True)
            if child.stderr: diagnostics.append({'case':case,'fail_at':n,'stderr':child.stderr})
            if not child.stdout.strip():
                failures.append(f'{case}/{n} produced no result: {child.returncode}')
                continue
            result=json.loads(child.stdout.strip()); result['exit_code']=child.returncode; rows.append(result)
            if n<=row['attempts'] and result['injected']!=1: failures.append(f'{case}/{n} did not inject')
            if result['outcome']=='unexpected_exception' or not result['semantic_ok']: failures.append(f'{case}/{n} semantic failure')
            if result['family_mismatches'] or result['observer_overflows']: failures.append(f'{case}/{n} audit failure')
            if not a.expect_leaks and (not result['ok'] or child.returncode): failures.append(f'{case}/{n} leaked or failed')
leaks=[r for r in rows if r['cpp_live'] or r['resources_live'] or r['parser_live'] or r['error_live'] or r['buffer_live']]
if a.expect_leaks:
    for case in ['router','parse_invalid','reply']:
        if not any(r['case']==case for r in leaks): failures.append(f'{case}: expected baseline leak not reproduced')
summary={'binary':str(exe),'process_cases':len(rows),'injected_failures':sum(r['injected'] for r in rows),'leak_cases':len(leaks),'leak_details':leaks,'failures':failures,'ok':not failures,'expect_leaks':a.expect_leaks,'control_only':a.control_only,'sweep_source_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'environment':{k:os.environ.get(k) for k in ['ASAN_OPTIONS','UBSAN_OPTIONS','G_DEBUG','G_SLICE']}}
(a.directory/'results.json').write_text(json.dumps({'summary':summary,'results':rows},indent=2)+'\n')
(a.directory/'sanitizer-diagnostics.json').write_text(json.dumps(diagnostics,indent=2)+'\n')
print(json.dumps(summary,indent=2))
raise SystemExit(0 if summary['ok'] else 1)
