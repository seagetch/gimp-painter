# WBS04.019 focused HTTP allocation-failure regression

This fixture compiles the **real** `app/httpd/httpd-resource.cpp`, using the native HTTP build's compile-database command. It adds function/data sections and links with `--gc-sections` against actual JSON-GLib, GTK, and GObject libraries. No successful JSON parse, GType result, parser, error, or serialized string is faked. The only isolation is two counting `Resource` factories for the Router constructor; `Router::dispatch` and unrelated GIMP dispatch dependencies are not executed.

The baseline was copied before the production edits and its SHA-256 also matches `git show be7946decb64097c1b82f7c444481121c5515922:app/httpd/httpd-resource.cpp`:

`6b8385c98fc2c35df90f19783489ed8e95bf6072cf24a2cd16cad81d787e0567  httpd-resource.baseline.cpp`

## Method

Each process warms up the real libraries, starts one bounded allocation-counting scope, executes one scenario, and checks the live owners after exception unwinding. Every C++ `new`/`new[]` position on the successful control path is failed exactly once with `std::bad_alloc`; an extra position beyond the last allocation verifies the normal path. Each failure gets a fresh process, so intentional baseline leaks cannot contaminate later cases.

Six scenarios exercise Router construction, valid JSON, malformed JSON, empty JSON, oversized JSON, and response serialization. Scoped fixed-capacity bookkeeping avoids allocating from the failure observer itself. Global replacement `new`/`delete` counts surviving allocations and checks scalar/array pairing. Counting resources verify virtual destruction. Wrappers call the real `json_parser_new`, `json_parser_load_from_data`, `json_to_string`, `g_free`, `g_clear_error`, and `g_error_free`. GObject weak notifications establish actual parser finalization; wrappers establish actual error and buffer cleanup. Observer capacity overflow is an explicit test failure.

ASan/UBSan runs use the same scenarios. A separate sanitizer build omits replacement new/delete and runs the six controls, preserving ASan's native allocation-family classification. The injected-failure build allocates through malloc/free inside replacement new/delete, so its explicit family counters, rather than ASan's native C++-versus-C family classifier, establish pairing for the fault paths.

## Proven baseline failures

- Router allocation #3: first Rule and counting Resource survive failed vector growth (2 allocations, 64 bytes)
- Router allocation #6: second Rule and counting Resource survive failed vector growth (2 allocations, 64 bytes)
- Router allocation #10: navigation Rule, NavigationResource, and prefix storage survive failed vector growth (3 allocations, 115 bytes)
- Malformed JSON allocation #1: a real JsonParser and its real GError survive failed message string allocation
- Response allocation #1: the real serialized string survives failed default Response content-type construction
- Response allocation #2: the real serialized string survives failed response body assignment

The baseline completes 29 process cases with 17 injected failures and six observed leak cases. It shows zero allocator-family mismatches; these are exception-path ownership leaks, not allocator-family mismatches. The baseline also logs a JSON-GLib critical for empty JSON because it calls `json_node_copy(NULL)` before returning 400.

## Final fixed results

Final compiled `httpd-resource.cpp` SHA-256:

`edb97960d74973c410da70b7a1b5eec53034bc9ea5d45ff88b84b7efaf7301b2`

Byte-identical fixture SHA-256 in baseline and all final builds:

`98acf53e07cd45aba9a2c00da703f766922a26d71488f33728881fdbad8b87f7`

| Build | Process cases | Injected failures | Observed leaks | Result |
| --- | ---: | ---: | ---: | --- |
| Public baseline | 29 | 17 | 6 | Expected leaks proven |
| Fixed, native flags | 29 | 17 | 0 | Pass |
| Fixed, ASan + UBSan | 29 | 17 | 0 | Pass |
| Fixed, ASan + UBSan, native new/delete controls | 6 | 0 | 0 | Pass |

All fixed builds used `G_DEBUG=fatal-criticals`: empty input returned HTTP 400, without a GLib critical. Every final runtime stderr log is empty. No allocator-family mismatch or observer overflow occurred. The prior fixed builds, before the empty-body guard, remain under `preguard-*`; their attempted LSan results are preserved there. See `summary.json` for collated machine-readable evidence.

## Reproduce

Run from any working directory after sourcing the restored native environment:

```sh
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/env-http.sh
ROOT=/workspace/scratch/5b5281e79681/allocator-04019-verification/http-faults
python3 "$ROOT/build.py" baseline
python3 "$ROOT/sweep.py" "$ROOT/baseline" --expect-leaks
python3 "$ROOT/build.py" fixed
python3 "$ROOT/sweep.py" "$ROOT/fixed" --fatal-criticals
python3 "$ROOT/build.py" fixed --sanitize
ASAN_OPTIONS=alloc_dealloc_mismatch=1:detect_leaks=0:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
python3 "$ROOT/sweep.py" "$ROOT/fixed-asan-ubsan" --fatal-criticals
python3 "$ROOT/build.py" fixed --sanitize --native-new
ASAN_OPTIONS=alloc_dealloc_mismatch=1:detect_leaks=0:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
python3 "$ROOT/sweep.py" "$ROOT/fixed-asan-ubsan-native-new" --control-only --fatal-criticals
```

Per-build `commands.json` records exact argv and working directory; `source-hashes.json` records the compiled source, fixture, scripts, compile database, config, and relevant production headers. Each build retains its source and fixture snapshots. The final variants use byte-identical fixture code to the original baseline; its harmless declaration/visibility warnings are retained in the build logs. No production test or Meson file was changed by this fixture. `results.json` contains every process case, live-owner counters, outcome, and sanitizer environment. `sanitizer-diagnostics.json` preserves stderr. `environment.json` records compiler version, library versions, and the actual linked libraries.

## Limits

- LeakSanitizer was attempted with `detect_leaks=1` and failed in this execution environment with its fatal ptrace restriction. Those failures are preserved as `lsan-unavailable-*` results and diagnostics. ASan/UBSan reruns use `detect_leaks=0`; leak conclusions come from the explicit live allocation/owner counters, not a claimed LSan pass
- The fixture deterministically fails C++ allocations, not GLib's abort-on-OOM allocator or arbitrary C malloc calls
- The preserved native compile configuration uses `-fno-rtti`; UBSan does not provide RTTI-dependent vptr checking
- JSON-GLib, GTK, and GLib are real native shared libraries, not sanitizer-rebuilt libraries
- The owner wrappers observe the named call sites; this is not a process-wide audit of every GLib object
- No server is started, no socket settings change, and no GIMP process is interrupted
- This fixture does **not** execute or claim the native 17-case HTTP integration suite, GUI QA, or the PDB/image dispatch implementations
