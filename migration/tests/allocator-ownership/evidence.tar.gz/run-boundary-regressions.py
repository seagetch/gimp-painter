from pathlib import Path
import json,os,subprocess
out=Path(__file__).resolve().parent;base=out.parent/'gimp-native-restore-20261009';build=base/'build-http';repo=out.parent/'gimp-painter-port-active'
names=['painter-filter-process','painter-mypaint-resource','gimp-fill-brush','gimp-painter-smudge','painter-profile-parser','painter-profile-native','painter-paper','painter-xcf-roundtrip']
tests={t['name']:t for t in json.loads((build/'meson-info/intro-tests.json').read_text())};selected=[tests[n] for n in names];targets=[str(Path(t['cmd'][0]).relative_to(build)) for t in selected]
cmd=['ninja','-C',str(build),'-f',str(base/'http.ninja'),'-j4']+targets
(out/'boundary-regression-build-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'boundary-regression-build.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(out/'boundary-regression-build-exit.json').write_text(json.dumps({'exit_code':r.returncode})+'\n')
if r.returncode:raise SystemExit(r.returncode)
results=[]
for test in selected:
 env=dict(os.environ,**test.get('env',{}));name=test['name']
 if 'LD_LIBRARY_PATH' in test.get('env',{}):env['LD_LIBRARY_PATH']=test['env']['LD_LIBRARY_PATH']+':'+os.environ.get('LD_LIBRARY_PATH','')
 with (out/(name+'-current.log')).open('w') as log:
  r=subprocess.run(test['cmd'],cwd=test.get('workdir') or build,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=test.get('timeout',180))
 results.append({'name':name,'command':test['cmd'],'declared_environment':test.get('env',{}),'exit_code':r.returncode});(out/'boundary-regression-results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,r.returncode,flush=True)
