#!/usr/bin/env bash
set -eo pipefail
task_root=/workspace/scratch/5b5281e79681
fixture="$task_root/allocator-04019-verification/dispatcher-faults"
product="$task_root/gimp-painter-port-active/app/painter"
baseline="$task_root/allocator-04019-verification/baseline/app/painter"
source "$task_root/gimp-native-restore-20261009/env-main.sh"
set -u
mkdir -p "$fixture/bin" "$fixture/logs"
cd "$fixture"
sha256sum "$baseline/fair-dispatcher.hpp" "$product/fair-dispatcher.hpp" \
  "$product/source.hpp" "$product/boundary.hpp" "$product/gimp-painter-error.cpp" \
  dispatcher-faults.cpp run.sh > source-sha256.txt
g++ --version > logs/toolchain.txt
pkg-config --modversion glib-2.0 gobject-2.0 >> logs/toolchain.txt
read -r -a glib_flags <<< "$(pkg-config --cflags --libs glib-2.0 gobject-2.0)"
common=(-std=c++17 -O1 -g -Wall -Wextra -Werror -fno-omit-frame-pointer
  -Wl,--wrap=g_main_context_ref -Wl,--wrap=g_main_context_unref
  -Wl,--wrap=g_thread_ref -Wl,--wrap=g_thread_unref)
sanitizers=(-fsanitize=address,undefined -fno-sanitize-recover=all -no-pie)
for variant in baseline fixed; do
  if [[ "$variant" == baseline ]]; then
    header="$baseline"
    expectation=1
  else
    header="$product"
    expectation=0
  fi
  for mode in fault fault-sanitized native-sanitized; do
    extra=()
    allocator=1
    if [[ "$mode" == *sanitized ]]; then extra=("${sanitizers[@]}"); fi
    if [[ "$mode" == native-sanitized ]]; then allocator=0; fi
    output="$fixture/bin/$variant-$mode"
    g++ "${common[@]}" "${extra[@]}" -DEXPECT_BASELINE="$expectation" \
      -DFAULT_ALLOCATORS="$allocator" -I"$header" -I"$product" \
      dispatcher-faults.cpp "$product/gimp-painter-error.cpp" \
      "${glib_flags[@]}" -o "$output" > "logs/$variant-$mode-build.log" 2>&1
    # LSan cannot run under this executor's ptrace constraints. Explicit counters
    # cover scoped C++ ownership and actual GLib ref/unref calls in fault mode.
    ASAN_OPTIONS=detect_leaks=0:alloc_dealloc_mismatch=1:halt_on_error=1 \
    UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
      "$output" > "logs/$variant-$mode.log" 2>&1
    tail -n 1 "logs/$variant-$mode.log"
  done
done
sha256sum --check source-sha256.txt > logs/source-integrity.log
