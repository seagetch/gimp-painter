// Standalone regression harness. Product headers and GLib are used unmodified.
#include <fair-dispatcher.hpp>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <utility>

#ifndef EXPECT_BASELINE
#define EXPECT_BASELINE 0
#endif
#ifndef FAULT_ALLOCATORS
#define FAULT_ALLOCATORS 1
#endif

namespace probe {
struct Allocation { void *pointer; std::size_t bytes; };
[[maybe_unused]] static Allocation allocations[4096];
static bool active;
static std::size_t fail_at, attempts, failure_bytes, injected, live, live_bytes;
static unsigned context_refs, context_unrefs, thread_refs, thread_unrefs, wrong_pointer;
static GMainContext *expected_context;
static GThread *expected_thread;

[[noreturn]] static void fail (const char *message)
{
  std::fprintf (stderr, "FAIL: %s\n", message);
  std::abort ();
}
static void require (bool value, const char *message)
{ if (!value) fail (message); }

#if FAULT_ALLOCATORS
static void *allocate (std::size_t bytes, std::size_t alignment = 0)
{
  if (active && ++attempts == fail_at)
    {
      ++injected;
      failure_bytes = bytes;
      throw std::bad_alloc ();
    }
  void *pointer = nullptr;
  if (alignment)
    {
      if (posix_memalign (&pointer, alignment, bytes ? bytes : 1))
        throw std::bad_alloc ();
    }
  else
    pointer = std::malloc (bytes ? bytes : 1);
  if (!pointer) throw std::bad_alloc ();
  if (active)
    {
      std::size_t slot = 0;
      while (slot < 4096 && allocations[slot].pointer) ++slot;
      require (slot < 4096, "allocation record capacity exceeded");
      allocations[slot] = {pointer, bytes};
      ++live;
      live_bytes += bytes;
    }
  return pointer;
}
static void release (void *pointer) noexcept
{
  if (!pointer) return;
  for (auto& allocation : allocations)
    if (allocation.pointer == pointer)
      {
        --live;
        live_bytes -= allocation.bytes;
        allocation = {};
        break;
      }
  std::free (pointer);
}
#endif

struct Observation
{
  std::size_t attempts, failure_bytes, injected, live, live_bytes;
  unsigned context_refs, context_unrefs, thread_refs, thread_unrefs, wrong_pointer;
  bool threw;
};
static void begin (std::size_t ordinal, GMainContext *context, GThread *thread)
{
  require (!active && !live && !live_bytes, "prior C++ allocations remain");
  attempts = failure_bytes = injected = 0;
  context_refs = context_unrefs = thread_refs = thread_unrefs = wrong_pointer = 0;
  fail_at = ordinal;
  expected_context = context;
  expected_thread = thread;
  active = true;
}
static Observation finish (bool threw)
{
  active = false;
  return {attempts, failure_bytes, injected, live, live_bytes,
          context_refs, context_unrefs, thread_refs, thread_unrefs,
          wrong_pointer, threw};
}
} // namespace probe

#if FAULT_ALLOCATORS
void *operator new (std::size_t bytes) { return probe::allocate (bytes); }
void *operator new[] (std::size_t bytes) { return probe::allocate (bytes); }
void operator delete (void *pointer) noexcept { probe::release (pointer); }
void operator delete[] (void *pointer) noexcept { probe::release (pointer); }
void operator delete (void *pointer, std::size_t) noexcept { probe::release (pointer); }
void operator delete[] (void *pointer, std::size_t) noexcept { probe::release (pointer); }
void *operator new (std::size_t bytes, std::align_val_t alignment)
{ return probe::allocate (bytes, static_cast<std::size_t> (alignment)); }
void *operator new[] (std::size_t bytes, std::align_val_t alignment)
{ return probe::allocate (bytes, static_cast<std::size_t> (alignment)); }
void operator delete (void *pointer, std::align_val_t) noexcept { probe::release (pointer); }
void operator delete[] (void *pointer, std::align_val_t) noexcept { probe::release (pointer); }
void operator delete (void *pointer, std::size_t, std::align_val_t) noexcept { probe::release (pointer); }
void operator delete[] (void *pointer, std::size_t, std::align_val_t) noexcept { probe::release (pointer); }
void *operator new (std::size_t bytes, const std::nothrow_t&) noexcept
{ try { return probe::allocate (bytes); } catch (...) { return nullptr; } }
void *operator new[] (std::size_t bytes, const std::nothrow_t&) noexcept
{ try { return probe::allocate (bytes); } catch (...) { return nullptr; } }
void operator delete (void *pointer, const std::nothrow_t&) noexcept { probe::release (pointer); }
void operator delete[] (void *pointer, const std::nothrow_t&) noexcept { probe::release (pointer); }
void *operator new (std::size_t bytes, std::align_val_t alignment, const std::nothrow_t&) noexcept
{ try { return probe::allocate (bytes, static_cast<std::size_t> (alignment)); } catch (...) { return nullptr; } }
void *operator new[] (std::size_t bytes, std::align_val_t alignment, const std::nothrow_t&) noexcept
{ try { return probe::allocate (bytes, static_cast<std::size_t> (alignment)); } catch (...) { return nullptr; } }
void operator delete (void *pointer, std::align_val_t, const std::nothrow_t&) noexcept { probe::release (pointer); }
void operator delete[] (void *pointer, std::align_val_t, const std::nothrow_t&) noexcept { probe::release (pointer); }
#endif

// GNU ld wraps only these harness/product calls, not GLib's own internal calls.
// Every wrapper forwards to the actual GLib implementation.
extern "C" GMainContext *__real_g_main_context_ref (GMainContext *);
extern "C" void __real_g_main_context_unref (GMainContext *);
extern "C" GThread *__real_g_thread_ref (GThread *);
extern "C" void __real_g_thread_unref (GThread *);
extern "C" GMainContext *__wrap_g_main_context_ref (GMainContext *context)
{
  if (probe::active) { ++probe::context_refs; probe::wrong_pointer += context != probe::expected_context; }
  return __real_g_main_context_ref (context);
}
extern "C" void __wrap_g_main_context_unref (GMainContext *context)
{
  if (probe::active) { ++probe::context_unrefs; probe::wrong_pointer += context != probe::expected_context; }
  __real_g_main_context_unref (context);
}
extern "C" GThread *__wrap_g_thread_ref (GThread *thread)
{
  if (probe::active) { ++probe::thread_refs; probe::wrong_pointer += thread != probe::expected_thread; }
  return __real_g_thread_ref (thread);
}
extern "C" void __wrap_g_thread_unref (GThread *thread)
{
  if (probe::active) { ++probe::thread_unrefs; probe::wrong_pointer += thread != probe::expected_thread; }
  __real_g_thread_unref (thread);
}

using GimpPainter::FairDispatcher;
using probe::require;
static GThread *owner_thread;
static unsigned observations, failures, successes, expected_leak_observations;

static void drain (GMainContext *context)
{
  unsigned count = 0;
  while (g_main_context_iteration (context, false))
    require (++count < 100, "main context did not become idle");
}

static void construction (GMainContext *context)
{ FairDispatcher dispatcher (context, 0); }

static void scheduled_ticket (GMainContext *context)
{
  unsigned callbacks = 0;
  FairDispatcher dispatcher (context, 0);
  auto ticket = dispatcher.ticket ([&] { ++callbacks; return false; });
  ticket.schedule ();
  ticket.schedule (); // Scheduling an already queued ticket is idempotent.
  drain (context);
  require (callbacks == 1 && ticket.valid (), "scheduled ticket callback/lifetime");
  ticket.close ();
  require (!ticket.valid (), "closed ticket is still valid");
}

static void lifecycle (GMainContext *context)
{
  unsigned order[4] = {}, count = 0, a_count = 0;
  {
    FairDispatcher dispatcher (context, 0);
    auto a = dispatcher.ticket ([&] { order[count++] = 1; return ++a_count < 2; });
    auto b = dispatcher.ticket ([&] { order[count++] = 2; return false; });
    a.schedule (); a.schedule (); b.schedule ();
    drain (context);
    require (count == 3 && order[0] == 1 && order[1] == 2 && order[2] == 1,
             "FIFO rotation or duplicate scheduling changed");
    unsigned moved_calls = 0, replaced_calls = 0, cancelled_calls = 0;
    auto original = dispatcher.ticket ([&] { ++moved_calls; return false; });
    original.schedule ();
    FairDispatcher::Ticket moved (std::move (original));
    require (!original.valid () && moved.valid (), "ticket move construction");
    auto replaced = dispatcher.ticket ([&] { ++replaced_calls; return false; });
    replaced.schedule ();
    replaced = std::move (moved);
    require (!moved.valid () && replaced.valid (), "ticket move assignment");
    {
      auto cancelled = dispatcher.ticket ([&] { ++cancelled_calls; return false; });
      cancelled.schedule ();
    }
    drain (context);
    require (moved_calls == 1 && !replaced_calls && !cancelled_calls,
             "move replacement/destructor failed to cancel");
    replaced.close (); replaced.close ();
    require (!replaced.valid (), "idempotent close");
  }
  unsigned orphan_calls = 0;
  FairDispatcher::Ticket orphan;
  {
    FairDispatcher dispatcher (context, 0);
    orphan = dispatcher.ticket ([&] { ++orphan_calls; return false; });
    orphan.schedule ();
    require (orphan.valid (), "scheduled orphan is not valid before owner destruction");
  }
  require (!orphan.valid (), "ticket survives owner as valid");
  orphan.schedule ();
  drain (context);
  require (!orphan_calls, "destroyed owner left its source alive");
  orphan.close (); orphan.close ();
}

using Action = void (*) (GMainContext *);
static probe::Observation observe (const char *label, Action action, GMainContext *argument,
                                  GMainContext *actual_context, std::size_t ordinal,
                                  bool expected_leak)
{
  probe::begin (ordinal, actual_context, owner_thread);
  bool threw = false;
  try { action (argument); }
  catch (const std::bad_alloc&) { threw = true; }
  catch (...) { probe::active = false; probe::fail ("unexpected exception"); }
  const auto result = probe::finish (threw);
  ++observations;
  if (threw) ++failures; else ++successes;
  const int context_net = static_cast<int> (result.context_refs) - static_cast<int> (result.context_unrefs);
  const int thread_net = static_cast<int> (result.thread_refs) - static_cast<int> (result.thread_unrefs);
  std::printf ("%s fail_at=%zu attempts=%zu injected=%zu thrown=%u failed_bytes=%zu "
               "context=%u/%u thread=%u/%u cxx_live=%zu/%zu expected_leak=%u\n",
               label, ordinal, result.attempts, result.injected, threw, result.failure_bytes,
               result.context_refs, result.context_unrefs, result.thread_refs, result.thread_unrefs,
               result.live, result.live_bytes, expected_leak);
  std::fflush (stdout); // All evidence is recorded before any harness-only cleanup.
  require (!result.wrong_pointer, "wrapper observed an unexpected context/thread pointer");
  require (!result.live && !result.live_bytes, "C++ heap allocations leaked");
  require (result.injected == (threw ? 1u : 0u), "injected exception was unexpectedly swallowed");
  if (expected_leak)
    {
      require (threw && context_net == 1 && thread_net == 1,
               "baseline failed to expose the expected retained-reference leak");
      ++expected_leak_observations;
      // Test-only cleanup of exactly the observed surplus; product code is untouched.
      __real_g_main_context_unref (actual_context);
      __real_g_thread_unref (owner_thread);
    }
  else
    require (context_net == 0 && thread_net == 0, "unexpected retained-reference imbalance");
  return result;
}

static std::size_t sweep (const char *label, Action action, GMainContext *argument,
                          GMainContext *actual_context, std::size_t constructor_allocations)
{
  const auto control = observe (label, action, argument, actual_context, 0, false);
  require (!control.threw, "control failed");
#if FAULT_ALLOCATORS
  require (control.attempts > 0, "allocation interception inactive");
  if (!constructor_allocations) constructor_allocations = control.attempts;
  for (std::size_t ordinal = 1; ordinal <= control.attempts + 1; ++ordinal)
    {
      const bool leak = EXPECT_BASELINE && ordinal >= 2 && ordinal <= constructor_allocations;
      const auto result = observe (label, action, argument, actual_context, ordinal, leak);
      require (result.threw == (ordinal <= control.attempts), "sweep missed an allocation ordinal");
    }
#else
  (void) constructor_allocations;
#endif
  return control.attempts;
}

static gboolean warmed_callback (gpointer) { return G_SOURCE_REMOVE; }
static void warm (GMainContext *context)
{
  g_main_context_unref (g_main_context_ref (context));
  GSource *source = g_timeout_source_new (0);
  g_source_set_callback (source, warmed_callback, nullptr, nullptr);
  require (g_source_attach (source, context) != 0, "warm source attachment failed");
  drain (context);
  g_source_unref (source);
}

int main ()
{
  std::printf ("FairDispatcher variant=%s allocators=%s GLib=%u.%u.%u\n",
               EXPECT_BASELINE ? "baseline" : "fixed",
               FAULT_ALLOCATORS ? "scoped-global-new" : "native-new-delete",
               glib_major_version, glib_minor_version, glib_micro_version);
  auto *context = g_main_context_new ();
  auto *default_context = g_main_context_ref (g_main_context_default ());
  owner_thread = g_thread_ref (g_thread_self ());
  g_thread_unref (g_thread_ref (owner_thread));
  warm (context); warm (default_context);
  const auto constructor_allocations = sweep ("constructor-explicit", construction, context, context, 0);
  const auto default_allocations = sweep ("constructor-default", construction, nullptr, default_context, 0);
  require (constructor_allocations == default_allocations, "constructor allocation paths differ");
  sweep ("ticket-schedule", scheduled_ticket, context, context, constructor_allocations);
  observe ("ticket-lifecycle", lifecycle, context, context, 0, false);
#if FAULT_ALLOCATORS
  require (expected_leak_observations == (EXPECT_BASELINE ? 3 * (constructor_allocations - 1) : 0),
           "unexpected baseline/fixed leak observation count");
#endif
  require (!probe::live && !probe::live_bytes, "final C++ heap imbalance");
  g_thread_unref (owner_thread);
  g_main_context_unref (default_context);
  g_main_context_unref (context);
  std::printf ("PASS observations=%u failures=%u successes=%u observed_ref_leaks=%u "
               "cxx_live=%zu/%zu heap_counter=%s\n", observations, failures, successes,
               expected_leak_observations, probe::live, probe::live_bytes,
               FAULT_ALLOCATORS ? "active" : "not-used-native-allocators");
}
