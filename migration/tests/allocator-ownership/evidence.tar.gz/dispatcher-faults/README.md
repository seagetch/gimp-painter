# FairDispatcher constructor allocation-failure regression

Run on 2026-10-09 using GCC 14.2.0 and native GLib/GObject 2.84.4.

## Result

The preserved baseline leaks one retained `GMainContext` reference and one
retained `GThread` reference when either deque construction allocation fails.
The current header's reordered member declarations remove both leaks.

| Header/build | Observations | Injected failures | Successful paths | Observed ref leak cases | Final scoped C++ live blocks/bytes |
| --- | ---: | ---: | ---: | ---: | ---: |
| Baseline, fault injection | 20 | 13 | 7 | 6 | 0/0 |
| Fixed, fault injection | 20 | 13 | 7 | 0 | 0/0 |
| Baseline, ASan/UBSan fault injection | 20 | 13 | 7 | 6 | 0/0 |
| Fixed, ASan/UBSan fault injection | 20 | 13 | 7 | 0 | 0/0 |
| Baseline, ASan/UBSan native allocators | 4 | 0 | 4 | 0 | Not instrumented by the harness |
| Fixed, ASan/UBSan native allocators | 4 | 0 | 4 | 0 | Not instrumented by the harness |

Baseline `PASS` means that the expected leak was reproduced, not that the
baseline was leak-free. The six leak cases are the same two constructor failures
encountered in each of three independent scenarios: explicit-context constructor,
default-context constructor, and constructor followed by ticket scheduling.

Each constructor makes three C++ allocations on this toolchain: 144-byte State
control block, 64-byte deque map, and 512-byte deque storage. At failure ordinals
2 and 3, the baseline records `context=1/0 thread=1/0`; the fixed header records
`context=0/0 thread=0/0`. C++ storage unwinds to zero in both versions.

The ticket/scheduling scenario makes seven allocations. Failures 4 through 7
also unwind cleanly in both versions, with `context=1/1 thread=1/1` and zero
scoped C++ live storage. Controls and one ordinal beyond the final allocation
verify that the same paths complete normally.

## What is exercised

- Both builds include the actual selected `fair-dispatcher.hpp`; the baseline
  include directory takes precedence only for that header. `source.hpp`,
  `boundary.hpp`, and `gimp-painter-error.cpp` come from the active product tree
- Every direct product call to `g_main_context_ref/unref` and `g_thread_ref/unref`
  is wrapped by the linker, counted, and forwarded to the real GLib function
- GLib's internal shared-library calls are not intercepted, and GLib C allocator
  failures are not injected. Each context and the current thread are warmed
  before the scoped C++ allocation failure begins
- Each test logs its resource counters before optional test-only cleanup of the
  baseline's exactly observed retained refs. Cleanup calls real GLib directly
  outside observation; no product behavior or baseline source is patched
- Normal lifecycle coverage checks FIFO rotation, duplicate scheduling,
  Ticket move construction and assignment, cancellation of replaced/destructed
  tickets, repeated close, owner destruction with an outstanding Ticket, and
  suppression of callbacks after owner destruction

## Sanitizer interpretation

All six executables exited zero. ASan/UBSan emitted no diagnostics. The fault
injection variants override global C++ new/delete with tracked malloc/free;
these runs validate instrumented access and undefined behavior plus explicit
C++ allocation and forwarded GLib reference balances. They do **not** independently
prove native C++ new/delete pairing.

Separate native allocator variants do not define any operator new/delete and
run with `alloc_dealloc_mismatch=1`. Symbol inspection showed undefined native
`operator new(unsigned long)` / `operator delete(void*, unsigned long)`, whereas
the injection build defines its replacement operators. Native variants exercise
successful construction/scheduling and the full Ticket lifecycle without fault
injection.

LeakSanitizer was not run: the parent task already established that this executor
cannot run LSan under its ptrace restriction. All sanitizer executions explicitly
use `ASAN_OPTIONS=detect_leaks=0:alloc_dealloc_mismatch=1:halt_on_error=1` and
`UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1`. The explicit counters are scoped
ownership evidence, not a process-wide GLib leak detector. GLib itself is the
real native library, not a sanitizer-rebuilt library.

## Reproduce

```sh
bash /workspace/scratch/5b5281e79681/allocator-04019-verification/dispatcher-faults/run.sh
```

The script sources `gimp-native-restore-20261009/env-main.sh`, builds entirely
inside this fixture directory, and runs all six variants. It does not invoke
Meson, modify tracked product files, or run UI tests.

Evidence:

- `logs/baseline-fault.log` and `logs/fixed-fault.log`: complete per-ordinal data
- `logs/*-fault-sanitized.log`: ASan/UBSan per-ordinal data
- `logs/*-native-sanitized.log`: native allocator control/lifecycle results
- `logs/*-build.log`: compiler output (empty for successful warning-free builds)
- `logs/toolchain.txt`: compiler and GLib package versions
- `source-sha256.txt`: hashes captured before compiling
- `logs/source-integrity.log`: all hashes verified unchanged after the run

Selected header SHA-256 values:

- Baseline: `b776f8ab1d9739a9877991385fc3fbddef6da1dec98f0bdc09f439406a7a330c`
- Fixed: `b91633f201fb69abedafcdc337842332d9ef63e1c70c6611069af47879852c7b`

The harness and reproduction script hashes are also recorded in the manifest.
