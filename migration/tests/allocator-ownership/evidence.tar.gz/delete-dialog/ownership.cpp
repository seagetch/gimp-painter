/* SPDX-License-Identifier: GPL-3.0-or-later */
#include "config.h"
#include <gegl.h>
#include <gtk/gtk.h>
#include <glib/gstdio.h>
extern "C" {
#include "libgimpbase/gimpbase.h"
#include "libgimpconfig/gimpconfig.h"
#include "libgimpmath/gimpmath.h"
#include "libgimpwidgets/gimpwidgets.h"
#include "core/core-types.h"
#include "widgets/widgets-types.h"
#include "core/gimp.h"
#include "core/gimpcontext.h"
#include "core/gimpcontainer.h"
#include "core/gimpdatafactory.h"
#include "core/gimpbrush.h"
#include "core/gimpbrush-private.h"
#include "core/gimppattern.h"
#include "core/gimptempbuf.h"
#include "core/gimptag.h"
#include "core/gimptagged.h"
#include "core/gimptoolinfo.h"
#include "config/gimpcoreconfig.h"
#include "widgets/gimpaction.h"
#include "widgets/gimpactiongroup.h"
#include "widgets/gimpactionfactory.h"
#include "widgets/gimpdialogfactory.h"
#include "widgets/gimpdocked.h"
#include "display/display-types.h"
#include "actions/actions-types.h"
#include "actions/actions.h"
#include "dialogs/preferences-dialog.h"
#include "gimpcoreapp.h"
#include "tests.h"
#include "gimp-app-test-utils.h"
}
#include "widgets/gimppaintermybrusheditor.hpp"
#include "core/gimppaintermybrush-handle.hpp"
#include "paint/painter-mypaint-surface/gimp-painter-options.hpp"
#include "mypaintbrush-settings-data.h"
#include "painter/gimp-painter-binding.h"
#include <algorithm>
#include <cstring>
#include <string>
#include <fstream>
#include <vector>
using namespace GimpPainter;
static Gimp *gimp;
static std::string writable_directory;
static gchar *original_search;
static GtkWidget*find(GtkWidget*w,const char*name){
  if(!g_strcmp0(gtk_widget_get_name(w),name))return w;
  if(GTK_IS_CONTAINER(w)){GList*children=gtk_container_get_children(GTK_CONTAINER(w));GtkWidget*result=nullptr;for(auto*l=children;l&&!result;l=l->next)result=find(GTK_WIDGET(l->data),name);g_list_free(children);return result;}return nullptr;
}
static GtkWidget*control(GtkWidget*w,const char*name){auto*r=find(w,name);g_assert_nonnull(r);return r;}
struct Editor {
  GtkWidget*window;GimpPainterMybrushEditor*widget;ObjectRef<GimpPainterMybrushOptions>model;
  explicit Editor(bool horizontal=false,GimpContext*context=nullptr) {
    GError*error=nullptr;auto*ctx=context?context:gimp->user_context;
    auto*w=gimp_painter_mybrush_editor_new(ctx,horizontal,&error);g_assert_no_error(error);g_assert_nonnull(w);widget=GIMP_PAINTER_MYBRUSH_EDITOR(w);
    model=ObjectRef<GimpPainterMybrushOptions>::adopt(gimp_painter_mybrush_options_ref_for_context(ctx,&error));g_assert_no_error(error);
    window=gtk_window_new(GTK_WINDOW_TOPLEVEL);g_object_ref_sink(window);gtk_window_set_default_size(GTK_WINDOW(window),horizontal?900:440,700);gtk_container_add(GTK_CONTAINER(window),w);gtk_widget_show_all(window);
  }
  ~Editor(){if(window){gtk_widget_destroy(window);g_object_unref(window);}}
  GtkWidget*get(const char*name){return control(GTK_WIDGET(widget),name);}
  MyPaint::Resource snapshot(){return PainterOptionsRef::retain(model.get()).snapshot();}
  void set(const MyPaint::Resource&r){GError*e=nullptr;g_assert_true(gimp_painter_mybrush_options_set_json(model.get(),r.encode().c_str(),&e));g_assert_no_error(e);}
  std::vector<guchar>preview(){
    gint64 deadline=g_get_monotonic_time()+20*G_TIME_SPAN_SECOND;
    while(gimp_painter_mybrush_editor_preview_pending(widget)&&g_get_monotonic_time()<deadline)g_main_context_iteration(nullptr,FALSE);
    g_assert_false(gimp_painter_mybrush_editor_preview_pending(widget));auto*p=gimp_painter_mybrush_editor_ref_preview(widget);g_assert_nonnull(p);
    std::vector<guchar>pixels;for(int y=0;y<gdk_pixbuf_get_height(p);++y){auto*row=gdk_pixbuf_get_pixels(p)+y*gdk_pixbuf_get_rowstride(p);pixels.insert(pixels.end(),row,row+gdk_pixbuf_get_width(p)*4);}g_object_unref(p);return pixels;
  }
};

struct EntryObservation { GtkWidget* widget; bool finalized; };
static EntryObservation observations[8];
static unsigned observed_count;
static bool watch_entries;
extern "C" GtkWidget* __real_gtk_entry_new(void);
extern "C" GtkWidget* __wrap_gtk_entry_new(void) {
  GtkWidget* widget=__real_gtk_entry_new();
  if(watch_entries) {
    g_assert_cmpuint(observed_count,<,8);
    auto* observation=&observations[observed_count++];
    observation->widget=widget;observation->finalized=false;
    g_object_weak_ref(G_OBJECT(widget),+[](gpointer data,GObject*){
      auto* o=static_cast<EntryObservation*>(data);o->finalized=true;o->widget=nullptr;
    },observation);
  }
  return widget;
}
static GtkDialog* dialog_named(const char* title) {
  GList* windows=gtk_window_list_toplevels();GtkDialog* result=nullptr;
  for(auto* l=windows;l;l=l->next)if(GTK_IS_DIALOG(l->data)&&!g_strcmp0(gtk_window_get_title(GTK_WINDOW(l->data)),title)){
    g_assert_null(result);result=GTK_DIALOG(l->data);
  }
  g_list_free(windows);g_assert_nonnull(result);return result;
}
static void prompt_check(Editor& editor,const char* action,const char* title,const char* name,int response,bool deleting) {
  observed_count=0;watch_entries=true;
  gtk_button_clicked(GTK_BUTTON(editor.get(action)));
  watch_entries=false;
  GtkDialog* dialog=dialog_named(title);
  unsigned unparented=0,finalized_before_response=0;
  for(unsigned n=0;n<observed_count;++n)if(observations[n].finalized)++finalized_before_response;
  for(unsigned n=0;n<observed_count;++n)if(observations[n].widget&&!gtk_widget_get_parent(observations[n].widget))++unparented;
  if(name) {g_assert_cmpuint(observed_count,==,1);g_assert_nonnull(observations[0].widget);
    std::string expected=gimp_object_get_name(gimp_context_get_painter_mybrush(GIMP_CONTEXT(editor.model.get())));
    if(!g_strcmp0(action,"painter-brush-save-as"))expected+=" copy";
    g_assert_cmpstr(gtk_entry_get_text(GTK_ENTRY(observations[0].widget)),==,expected.c_str());
    gtk_entry_set_text(GTK_ENTRY(observations[0].widget),name);
  }
  gtk_dialog_response(dialog,response);
  unsigned finalized=0;
  for(unsigned n=0;n<observed_count;++n)if(observations[n].finalized)++finalized;
  unsigned leaked=observed_count-finalized;
  g_print("OWNERSHIP action=%s response=%d created=%u unparented=%u finalized_before_response=%u finalized=%u live_after_dialog=%u\n",action,response,observed_count,unparented,finalized_before_response,finalized,leaked);
  const bool baseline=!g_strcmp0(g_getenv("OWNERSHIP_EXPECT"),"baseline");
  g_assert_cmpuint(observed_count,==,deleting?(baseline?1:0):1);
  g_assert_cmpuint(leaked,==,0);
  g_assert_cmpuint(finalized_before_response,==,deleting&&baseline?1:0);
  g_assert_cmpuint(unparented,==,0);
  /* Diagnostic cleanup guard; neither real baseline nor fixed GTK leaves
   * an entry alive after the dialog response. */
  for(unsigned n=0;n<observed_count;++n)if(observations[n].widget){g_assert_true(g_object_is_floating(observations[n].widget));g_object_ref_sink(observations[n].widget);g_object_unref(observations[n].widget);}
}
static void ownership_regression() {
  gimp_set_focused_once(gimp);
  const char* root=g_getenv("OWNERSHIP_ROOT");g_assert_nonnull(root);
  writable_directory=std::string(root)+"/painter-mypaint-brushes";
  g_assert_cmpint(g_mkdir_with_parents(writable_directory.c_str(),0700),==,0);
  std::string search=writable_directory+G_SEARCHPATH_SEPARATOR_S+g_getenv("GIMP_TESTING_ABS_TOP_SRCDIR")+std::string("/data/painter-mypaint-brushes");
  g_object_set(gimp->config,"painter-mypaint-brush-path",search.c_str(),"painter-mypaint-brush-path-writable",writable_directory.c_str(),nullptr);
  gimp_data_factory_data_refresh(gimp->painter_mybrush_factory,gimp->user_context);
  auto* container=gimp_data_factory_get_container(gimp->painter_mybrush_factory);
  const int original_count=gimp_container_get_n_children(container);g_assert_cmpint(original_count,==,177);
  gimp_context_set_painter_mybrush(gimp->user_context,GIMP_PAINTER_MYBRUSH(gimp_container_get_child_by_index(container,0)));
  Editor editor;
  prompt_check(editor,"painter-brush-save-as","Save Painter Brush As","Ownership Save",GTK_RESPONSE_OK,false);
  auto selected=ObjectRef<GimpPainterMybrush>::retain(gimp_context_get_painter_mybrush(GIMP_CONTEXT(editor.model.get())));
  g_assert_cmpstr(gimp_object_get_name(selected.get()),==,"Ownership Save");
  g_assert_cmpint(gimp_container_get_n_children(container),==,original_count+1);
  prompt_check(editor,"painter-brush-rename","Rename Painter Brush","Ownership Renamed",GTK_RESPONSE_OK,false);
  g_assert_cmpstr(gimp_object_get_name(selected.get()),==,"Ownership Renamed");
  auto file=ObjectRef<GObject>::retain(G_OBJECT(gimp_data_get_file(GIMP_DATA(selected.get()))));g_assert_nonnull(file.get());g_assert_true(g_file_query_exists(G_FILE(file.get()),nullptr));
  prompt_check(editor,"painter-brush-delete","Delete Painter Brush",nullptr,GTK_RESPONSE_CANCEL,true);
  g_assert_true(g_file_query_exists(G_FILE(file.get()),nullptr));g_assert_cmpint(gimp_container_get_n_children(container),==,original_count+1);
  prompt_check(editor,"painter-brush-delete","Delete Painter Brush",nullptr,GTK_RESPONSE_OK,true);
  g_assert_false(g_file_query_exists(G_FILE(file.get()),nullptr));g_assert_cmpint(gimp_container_get_n_children(container),==,original_count);
  g_print("OWNERSHIP save_rename_delete_disk_and_factory_verified=1\n");
}
int main(int argc,char**argv){
  g_test_init(&argc,&argv,nullptr);if(!gtk_init_check(&argc,&argv))return GIMP_EXIT_TEST_SKIPPED;
  gimp_test_utils_setup_menus_path();g_setenv("GIMP_TESTING_MENUS_PATH",g_getenv("OWNERSHIP_MENU_PATH"),TRUE);gimp=gimp_init_for_gui_testing(TRUE);
  g_test_add_func("/painter-editor/dialog-entry-ownership",ownership_regression);
  g_application_run(gimp->app,0,nullptr);int result=gimp_core_app_get_exit_status(GIMP_CORE_APP(gimp->app));g_application_quit(gimp->app);g_clear_object(&gimp->app);return result;
}
