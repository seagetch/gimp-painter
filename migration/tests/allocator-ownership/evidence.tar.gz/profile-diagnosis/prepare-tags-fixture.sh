#!/bin/bash
set -euo pipefail
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/env-http.sh
cd /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/build-http
ninja -f /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/http.ninja data/tags/gimp-tags-default.xml
install -D -m 0644 data/tags/gimp-tags-default.xml /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/prefix/share/gimp/3.0/tags/gimp-tags-default.xml
sha256sum data/tags/gimp-tags-default.xml /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/prefix/share/gimp/3.0/tags/gimp-tags-default.xml
