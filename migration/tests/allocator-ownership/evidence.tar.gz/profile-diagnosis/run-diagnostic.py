from pathlib import Path
import json,os,subprocess,time,sys,hashlib
out=Path(__file__).resolve().parent
b=Path('/workspace/scratch/5b5281e79681/gimp-native-restore-20261009/build-http')
test=next(t for t in json.loads((b/'meson-info/intro-tests.json').read_text()) if t['name']=='painter-profile-native')
env=os.environ.copy()
for k,v in test['env'].items():env[k]=v+(':'+env.get(k,'') if k=='LD_LIBRARY_PATH' else '')
label=sys.argv[1]
cmd=([str(out/'painter-profile-diagnostic')] if label.startswith('diagnostic') else test['cmd'])+([] if label.endswith('full') else ['-p','/painter-profile-native/first-run-installer-retry'])
start=time.time()
with (out/(label+'.run.log')).open('w') as log:
 try:r=subprocess.run(cmd,cwd=b,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=test['timeout']);code=r.returncode
 except subprocess.TimeoutExpired:code=124
text=(out/(label+'.run.log')).read_text()
result=dict(name=label,command=cmd,declared_test_env=test['env'],returncode=code,display=env.get('DISPLAY'),elapsed_seconds=round(time.time()-start,2),binary_sha256=hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest(),tap=[l for l in text.splitlines() if l.startswith(('ok ','not ok ','1..','Bail out'))])
(out/(label+'.result.json')).write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
print(text[-9000:],flush=True)
print('PROFILE_DIAGNOSIS_RUN_COMPLETE',flush=True)
raise SystemExit(code if code>=0 else 1)
