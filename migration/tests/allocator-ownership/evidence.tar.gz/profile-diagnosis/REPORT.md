# Painter profile installer diagnosis

The original `painter-profile-native` executable passes all **9/9 cases with exit 0** on the existing cloud desktop display `:0` after supplying one required generated runtime file. No tracked production source or original test binary was changed.

## Exact cause of the original assertion

`gimp_user_install_run()` reaches `user_install_create_files()` in `app/core/gimp-user-install.c:1358–1366`. That calls `gimp_tags_user_install()`. `app/core/gimp-tags.c:114–123` parses `gimp_data_directory_file("tags", "gimp-tags-default.xml", NULL)` and returns FALSE on failure without printing the GError.

The scratch diagnostic enabled the installer's existing verbose flag and printed the configured data directory and tag-file existence. It reproduced the assertion and reported:

- Data directory: `/workspace/scratch/5b5281e79681/gimp-native-restore-20261009/prefix/share/gimp/3.0`
- `tags_exists=0`
- All migration and directory creation messages completed before the assertion

The legitimate build output `data/tags/gimp-tags-default.xml` was generated using only the explicit target in `http.ninja`, then installed at that configured scratch prefix. The generated and installed file hashes match: `e72e33728748420f6337f6f35e07baa01606859063e8fbc07d4d570f72e353a5`. See `prepare-tags-fixture.sh` and its log.

## Verification and limits

1. Original earlier run: six cases passed, the first-run installer asserted, final two cases were not run. Preserved in `../delete-dialog/painter-profile-native.*`.
2. Filtered scratch diagnostic before fixture: reproduced the assertion, exit -6.
3. Identical filtered diagnostic binary after fixture: installer case passed. Shutdown then hit `gimp_device_info_save_tool: GIMP_IS_DEVICE_INFO(info)` and exit -5. This critical is absent in the original full suite. No stack trace was collected; its root cause is not established here.
4. Original full native suite after fixture: **9/9 passed, exit 0, 1.52 seconds**. Full output and command/environment are in `original-full.run.log` and `original-full.result.json`.

The original executable SHA-256 before and after was `25b7312f3a837dfda3244174936301312176a67cdbb7ff2e41394c485d7f053d`. The full suite still emits nonfatal missing-icon and writable-data-folder configuration messages.

A byte-for-byte comparison against public HEAD `be7946decb64097c1b82f7c444481121c5515922` confirms the installer, tags implementation, original test, and tags build inputs are unchanged. This is a source comparison, not a run of a complete public-parent build. The tested original binary contains the current WIP profile error-ownership change.

## Reproduction and retained evidence

`build-diagnostic.py` recreates the scratch test-only instrumentation and records exact compiler and linker arguments in `build-commands.json`. Source, original and scratch binary, archive, generated and installed fixture hashes are in `source-hashes.json`. The diagnostic scratch binary/object/source copies were removed after hashing to keep this evidence directory small; the normal native test executable is retained unchanged.

GUI commands were run through the authorized cloud native terminal using supported per-key input. No new display/socket or security change was made. The existing Chromium tab was preserved. `run-diagnostic-desktop.sh` accepts `diagnostic-before`, `diagnostic-after`, or `original-full`; its Python runner uses the existing Meson test declaration and records outcomes.
