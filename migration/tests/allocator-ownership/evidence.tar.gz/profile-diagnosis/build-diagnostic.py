from pathlib import Path
import json,subprocess,shlex,hashlib
root=Path('/workspace/scratch/5b5281e79681')
out=Path(__file__).resolve().parent
repo=root/'gimp-painter-port-active'
b=root/'gimp-native-restore-20261009/build-http'
src=repo/'app/tests/test-painter-profile-native.cpp'
text=src.read_text()
old='auto*install=gimp_user_install_new(G_OBJECT(gimp),FALSE);g_assert_true(gimp_user_install_run(install,1));'
new='g_print("DIAGNOSTIC data_directory=%s\\n",gimp_data_directory()); auto*tags=gimp_data_directory_file("tags","gimp-tags-default.xml",nullptr); g_print("DIAGNOSTIC tags_exists=%d\\n",g_file_query_exists(tags,nullptr)); g_object_unref(tags); auto*install=gimp_user_install_new(G_OBJECT(gimp),TRUE);g_assert_true(gimp_user_install_run(install,1));'
assert text.count(old)==1
scratch=out/'test-painter-profile-diagnostic.cpp'; scratch.write_text(text.replace(old,new))
commands=[]
cc=json.loads((b/'compile_commands.json').read_text())
x=next(x for x in cc if x['file'].endswith('test-painter-profile-native.cpp'))
args=shlex.split(x['command'])
for i,arg in enumerate(args):
 if arg==x['file']:args[i]=str(scratch)
 if arg==x['output']:args[i]=str(out/'test-painter-profile-diagnostic.o')
 if arg==x['output']+'.d':args[i]=str(out/'test-painter-profile-diagnostic.o.d')
commands.append(args)
r=subprocess.run(['ninja','-f',str(b.parent/'http.ninja'),'-t','commands','app/tests/painter-profile-native'],cwd=b,capture_output=True,text=True,check=True)
link=shlex.split(r.stdout.splitlines()[-1]); link[link.index('-o')+1]=str(out/'painter-profile-diagnostic')
link=[str(out/'test-painter-profile-diagnostic.o') if a==x['output'] else a for a in link]
commands.append(link)
(out/'build-commands.json').write_text(json.dumps(dict(cwd=str(b),commands=commands),indent=2))
with (out/'build.log').open('w') as log:
 for cmd in commands:subprocess.run(cmd,cwd=b,stdout=log,stderr=subprocess.STDOUT,check=True)
paths=[src,scratch,repo/'app/core/gimppainterprofile.cpp',repo/'app/core/gimp-user-install.c',repo/'app/core/gimp-tags.c',out/'painter-profile-diagnostic',b/'app/tests/painter-profile-native',b/'app/core/libappcore.a']
(out/'source-hashes.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},indent=2))
print('Diagnostic built; production source and native binary unchanged')
