#!/bin/bash
set -e
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/env-http.sh
python3 /workspace/scratch/5b5281e79681/allocator-04019-verification/profile-diagnosis/run-diagnostic.py "$@"
