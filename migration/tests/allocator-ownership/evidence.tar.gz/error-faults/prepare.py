from pathlib import Path
import subprocess, json, shlex, hashlib
root=Path('/workspace/scratch/5b5281e79681/allocator-04019-verification/error-faults')
repo=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active')
build=Path('/workspace/scratch/5b5281e79681/gimp-native-restore-20261009/build-http')
manifest={'head':subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),'sources':{}}
files=[p.relative_to(repo) for p in (repo/'app/painter').glob('*.h*')]+[Path('app/paint/painter-native-stroking.hpp'),Path('app/painter/gimp-painter-error.cpp')]
for variant in ['baseline','fixed']:
 for rel in files:
  content=subprocess.check_output(['git','-C',str(repo),'show','HEAD:'+str(rel)]) if variant=='baseline' else (repo/rel).read_bytes()
  out=root/variant/rel
  out.parent.mkdir(parents=True,exist_ok=True)
  out.write_bytes(content)
  manifest['sources'][str(out.relative_to(root))]=hashlib.sha256(content).hexdigest()
entries=json.loads((build/'compile_commands.json').read_text())
entry=next(e for e in entries if e['file'].endswith('/gimpfillbrush.cpp'))
(root/'compile-db-entry.json').write_text(json.dumps(entry,indent=2)+'\n')
flags=[]
for token in shlex.split(entry['command'])[1:]:
 if token.startswith('-I'):
  path=Path(token[2:]); path=path if path.is_absolute() else (build/path).resolve()
  flags+=['-I'+str(path)]
 elif token.startswith('-D') or token in ['-std=c++14','-pthread','-fexceptions','-fno-rtti','-fvisibility-inlines-hidden']:
  flags.append(token)
(root/'native-flags.json').write_text(json.dumps(flags,indent=2)+'\n')
(root/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Saved',len(files),'sources for each variant at HEAD',manifest['head'])
