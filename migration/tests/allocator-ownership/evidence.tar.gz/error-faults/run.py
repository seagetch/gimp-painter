from pathlib import Path
import json,os,subprocess
root=Path(__file__).resolve().parent
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0:alloc_dealloc_mismatch=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
results=[]
for name in ['baseline-fault','fixed-fault','baseline-fault-asan','fixed-fault-asan','fixed-standard-asan','allocator-mismatch-control']:
 r=subprocess.run([str(root/name)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (root/(name+'.run.log')).write_text(r.stdout)
 expected=name=='allocator-mismatch-control'
 passed=(r.returncode!=0 and 'alloc-dealloc-mismatch (operator new vs free)' in r.stdout) if expected else r.returncode==0
 results.append({'binary':name,'exit':r.returncode,'expected_failure':expected,'passed':passed,'output':r.stdout})
 print(name,'exit',r.returncode,'expected_failure',expected,'passed',passed,flush=True)
 if not expected: print(r.stdout,flush=True)
(root/'run-results.json').write_text(json.dumps({'ASAN_OPTIONS':env['ASAN_OPTIONS'],'UBSAN_OPTIONS':env['UBSAN_OPTIONS'],'results':results},indent=2)+'\n')
raise SystemExit(not all(r['passed'] for r in results))
