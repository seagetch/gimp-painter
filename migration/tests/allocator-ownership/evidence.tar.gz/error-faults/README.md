# Native GError ownership regression

Result: PASS. The exact HEAD native_stroke_checked template leaks its GError when the std::string message copy throws; the migrated template clears the source pointer before the copy and releases the real GError during unwinding. No repository files or main build outputs were edited.

## Replay

```sh
source /workspace/scratch/5b5281e79681/gimp-native-restore-20261009/env-http.sh
python /workspace/scratch/5b5281e79681/allocator-04019-verification/error-faults/build.py
python /workspace/scratch/5b5281e79681/allocator-04019-verification/error-faults/run.py
```

The replay uses the preserved source snapshots. prepare.py documents how they were captured; do not rerun it to replay the preserved evidence. Exact compiler invocations are in build-commands.txt, with the actual gimpfillbrush.cpp compile-database record in compile-db-entry.json and normalized include/define flags in native-flags.json. Compiler/GLib/linker environment is in environment.json. All result logs are beside the binaries. run-results.json includes exit codes, expected-failure status, and complete output.

## Proven behavior

- baseline-fault and baseline-fault-asan: 29 checks each; source_null=0, freed=0, live_errors=1 after the real native template's long UTF-8 string-copy failure. The fixture validates the surviving error bytes and then explicitly frees that orphan, keeping its process clean.
- fixed-fault and fixed-fault-asan: 49 checks each; source_null=1, freed=1, live_errors=0 after the corresponding migrated template failure.
- fixed-standard-asan: 33 checks with ordinary C++ new/delete, including direct helper and real native boundary success/error/fallback ownership behavior.
- allocator-mismatch-control: intentionally exits 1 with AddressSanitizer alloc-dealloc-mismatch (operator new vs free), proving that the standard allocator's mismatch detector is active independently of the fault-injection replacement allocator.

The direct helper cases validate successful copy, throwing copy, null GError with long fallback, throwing fallback copy, empty fallback, source clearing before allocation/destruction, exactly one real free, byte-for-byte UTF-8 preservation, and zero residual tracked errors. The real native template cases validate successful operations with and without callback-produced errors, operation failure with and without errors, and allocating message-copy failure.

The entire actual painter-native-stroking.hpp is compiled unchanged. The prelude uses the native headers from gimpfillbrush.cpp; no fake Gimp structs, no copied substitute template, no unimplemented native symbols. Only native_stroke_checked is instantiated/executed. The actual snapshot of app/painter/gimp-painter-error.cpp is compiled and linked. GLib 2.84.4 creates actual GError instances through g_error_new_literal. Linker wrappers forward g_error_free and g_clear_error to the real GLib functions while maintaining explicit ownership counters. GLib internal frees from g_clear_error are accounted at that public call, since shared-library internal references are not linker-wrapped.

The failure allocator is armed only immediately before the intended string operation, fails one allocation, and asserts that its size equals strlen(message)+1 (or strlen(fallback)+1). Pointer state is captured only while the owning local remains alive: at the allocation or actual free. A pointer to native_stroke_checked's dead stack local is never dereferenced after unwinding.

## Sanitizer settings and bounds

ASAN_OPTIONS=detect_leaks=0:alloc_dealloc_mismatch=1:halt_on_error=1
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1

ASan and UBSan report no error in the five positive variants. LeakSanitizer is disabled because the parent task has already established its environment ptrace restriction; this fixture does not claim an LSan clean run. The explicit GError counters establish only ownership of the tested native errors. Custom new/delete fault variants cannot alone establish all C++ allocator-family mismatch behavior, so the standard-new/delete variant and expected-negative mismatch control are separate. This bounded fixture does not execute whole painting transactions, callback interleavings, rendering, file loading, or all 26 migrated call sites.

## Source identity

HEAD: be7946decb64097c1b82f7c444481121c5515922

- Baseline app/paint/painter-native-stroking.hpp SHA-256: 677545b28b41f6ae5124b5df29b768fd1fa05221f8f8492df665240e597ef25b
- Fixed app/paint/painter-native-stroking.hpp SHA-256: b1224ea6a84a32c6590a219e3026fd4353cc1005c0d6a626ea2f8b91ccc40a33
- Fixed app/painter/resources.hpp SHA-256: 0a337c7467ed382dc087a1fb611fa9639981ae2879fb36a0642833d787143bfa
- Fixed app/painter/gimp-painter-error.cpp SHA-256: 14bc510a2c3721894854b871402c7c95caa94d6559ab79731c7eb4ee76d83cf3
- error-faults.cpp SHA-256: b234164979ce9dd64ea67aaad80016077a4da901d635d444158e5ab835126fa6

source-manifest.json records all 62 preserved baseline/fixed source snapshots plus fixture and build-script hashes. Baseline files were read with git show HEAD:<path>; fixed files were snapshotted from the working tree before compilation.
