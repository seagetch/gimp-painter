/* Standalone regression fixture. Real production headers are snapshotted unchanged. */
#include "config.h"
#include <gdk-pixbuf/gdk-pixbuf.h>
#include <gio/gio.h>
#include <gegl.h>
#include <cairo.h>
extern "C" {
#include "libgimpbase/gimpbase.h"
#include "libgimpconfig/gimpconfig.h"
#include "libgimpcolor/gimpcolor.h"
#include "libgimpmath/gimpmath.h"
#include "paint-types.h"
#include "core/gimp.h"
#include "core/gimpbrush.h"
#include "core/gimpcontext.h"
#include "core/gimpdrawable.h"
#include "core/gimpdynamics.h"
#include "core/gimpimage.h"
#include "core/gimppickable.h"
#include "core/gimpprojection.h"
#include "core/gimpsymmetry.h"
#include "core/gimptempbuf.h"
#include "gimpfillbrush.h"
}
#include "painter/resources.hpp"
#include "paint/painter-native-stroking.hpp"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>

namespace {
const char message[] =
  u8"Native paint failed: \u65e5\u672c\u8a9e \u2014 cr\u00e8me br\u00fbl\u00e9e \U0001f58c; "
  "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
  "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
  "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
  "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
const char fallback[] =
  u8"Fallback: \u65e5\u672c\u8a9e \u2014 cr\u00e8me br\u00fbl\u00e9e \U0001f58c; "
  "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "
  "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
GError *tracked_error = nullptr;
GError **observed_source = nullptr; // Inspected only while the actual owner is alive.
unsigned live_errors = 0, frees = 0, clear_calls = 0, failures = 0, checks = 0;
bool source_null_at_free = false;
bool source_null_at_failure = false;
bool fail_next = false;
std::size_t failure_size = 0;

void check (bool ok, const char *why)
{
  ++checks;
  if (!ok) { std::fprintf (stderr, "FAIL: %s\n", why); std::abort (); }
}
void reset_tracking ()
{
  check (live_errors == 0, "previous test released all real GErrors");
  tracked_error = nullptr; observed_source = nullptr;
  frees = clear_calls = failures = 0;
  source_null_at_free = source_null_at_failure = false;
  fail_next = false; failure_size = 0;
}
GError *make_error ()
{
  check (!tracked_error && live_errors == 0, "single tracked native GError");
  tracked_error = g_error_new_literal (g_quark_from_static_string ("real-native-error-fixture"), 71, message);
  ++live_errors;
  check (tracked_error && std::strcmp (tracked_error->message, message) == 0,
         "GLib creates exact long UTF-8 error text");
  return tracked_error;
}
void record_free (GError *error)
{
  if (error == tracked_error) {
    check (live_errors == 1, "tracked GError freed exactly once");
    --live_errors; ++frees;
    source_null_at_free = observed_source && *observed_source == nullptr;
    tracked_error = nullptr;
  }
}
void verify_bytes (const char *actual, const char *expected)
{
  check (std::strcmp (actual, expected) == 0, "returned error message preserves exact bytes");
  check (g_utf8_validate (actual, -1, nullptr), "returned message remains valid UTF-8");
}
}
extern "C" void __real_g_error_free (GError *);
extern "C" void __real_g_clear_error (GError **);
extern "C" void __wrap_g_error_free (GError *error)
{
  record_free (error);
  __real_g_error_free (error);
}
extern "C" void __wrap_g_clear_error (GError **error)
{
  // GLib's internal g_error_free is not link-wrapped; observe its public clear call.
  GError *before = error ? *error : nullptr;
  ++clear_calls;
  __real_g_clear_error (error);
  if (before) record_free (before);
}

#ifndef STANDARD_NEW
void *operator new (std::size_t size)
{
  if (fail_next) {
    fail_next = false; ++failures; failure_size = size;
    source_null_at_failure = observed_source && *observed_source == nullptr;
    throw std::bad_alloc ();
  }
  if (void *p = std::malloc (size ? size : 1)) return p;
  throw std::bad_alloc ();
}
void *operator new[] (std::size_t size) { return ::operator new (size); }
void operator delete (void *p) noexcept { std::free (p); }
void operator delete[] (void *p) noexcept { std::free (p); }
void operator delete (void *p, std::size_t) noexcept { std::free (p); }
void operator delete[] (void *p, std::size_t) noexcept { std::free (p); }
void *operator new (std::size_t size, const std::nothrow_t&) noexcept
{ try { return ::operator new (size); } catch (...) { return nullptr; } }
void *operator new[] (std::size_t size, const std::nothrow_t&) noexcept
{ try { return ::operator new[] (size); } catch (...) { return nullptr; } }
void operator delete (void *p, const std::nothrow_t&) noexcept { std::free (p); }
void operator delete[] (void *p, const std::nothrow_t&) noexcept { std::free (p); }
#endif

int main ()
{
  check (std::strlen (message) > 200, "message cannot use small-string storage");
#ifdef FIXED_BOUNDARY
  reset_tracking ();
  {
    GError *error = make_error (); observed_source = &error;
    const auto text = GimpPainter::take_error_message (error, fallback);
    check (!error, "helper clears source on successful copy");
    check (live_errors == 0 && frees == 1 && source_null_at_free,
           "helper frees real GError exactly once with source already cleared");
    verify_bytes (text.c_str (), message);
    observed_source = nullptr;
  }
  reset_tracking ();
  {
    GError *error = nullptr; observed_source = &error;
    const auto text = GimpPainter::take_error_message (error, fallback);
    check (!error && live_errors == 0 && frees == 0, "null helper input remains null without free");
    verify_bytes (text.c_str (), fallback);
    const auto empty = GimpPainter::take_error_message (error, "");
    check (empty.empty (), "empty fallback stays empty");
    observed_source = nullptr;
  }
#ifndef STANDARD_NEW
  reset_tracking ();
  {
    GError *error = make_error (); observed_source = &error;
    fail_next = true;
    bool caught = false;
    try { (void) GimpPainter::take_error_message (error, fallback); }
    catch (const std::bad_alloc&) { caught = true; }
    check (caught && failures == 1 && failure_size == std::strlen (message) + 1,
           "helper fault is the allocating string copy");
    check (!error && source_null_at_failure && source_null_at_free,
           "helper source is cleared before failed allocation and destructor");
    check (live_errors == 0 && frees == 1, "helper frees GError when string copy throws");
    observed_source = nullptr;
  }
  reset_tracking ();
  {
    GError *error = nullptr; observed_source = &error;
    fail_next = true;
    bool caught = false;
    try { (void) GimpPainter::take_error_message (error, fallback); }
    catch (const std::bad_alloc&) { caught = true; }
    check (caught && failures == 1 && failure_size == std::strlen (fallback) + 1,
           "null helper fault is the allocating fallback copy");
    check (!error && source_null_at_failure && live_errors == 0 && frees == 0,
           "failed fallback copy leaves no owned error");
    observed_source = nullptr;
  }
#endif
#endif

  reset_tracking ();
  {
    bool caught = false;
    try {
      GimpPainter::native_stroke_checked ([&] (GError **error) {
        *error = make_error (); observed_source = error; return false;
      });
    } catch (const std::runtime_error& ex) { caught = true; verify_bytes (ex.what (), message); }
    observed_source = nullptr;
    check (caught && live_errors == 0 && frees == 1 && source_null_at_free,
           "real native boundary throws exact error text and releases GError");
  }
  reset_tracking ();
  {
    bool caught = false;
    try { GimpPainter::native_stroke_checked ([] (GError **) { return false; }); }
    catch (const std::runtime_error& ex) {
      caught = true; verify_bytes (ex.what (), "Owned stroke operation failed");
    }
    check (caught && live_errors == 0 && frees == 0, "native boundary uses fallback on failure without GError");
  }
  reset_tracking ();
  GimpPainter::native_stroke_checked ([] (GError **) { return true; });
  check (live_errors == 0 && frees == 0, "successful native operation without error");
  reset_tracking ();
  GimpPainter::native_stroke_checked ([] (GError **error) {
    *error = make_error (); observed_source = error; return true;
  });
  observed_source = nullptr;
  check (live_errors == 0 && frees == 1 && source_null_at_free,
         "successful native operation clears an error supplied by callback");

#ifndef STANDARD_NEW
  reset_tracking ();
  {
    GError *saved = nullptr;
    bool caught = false;
    try {
      GimpPainter::native_stroke_checked ([&] (GError **error) {
        saved = *error = make_error (); observed_source = error;
        fail_next = true; return false;
      });
    } catch (const std::bad_alloc&) { caught = true; }
    // native_stroke_checked's local is dead now: never dereference observed_source here.
    observed_source = nullptr;
    check (caught && failures == 1 && failure_size == std::strlen (message) + 1,
           "real boundary fault is the allocating string copy");
#ifdef FIXED_BOUNDARY
    check (source_null_at_failure && source_null_at_free && live_errors == 0 && frees == 1,
           "fixed native boundary clears source and frees on failed string copy");
    (void) saved;
    std::puts ("FIXED_NATIVE_COPY_FAILURE: source_null=1 freed=1 live_errors=0");
#else
    check (!source_null_at_failure && live_errors == 1 && frees == 0,
           "HEAD native boundary leaks real GError on failed string copy");
    verify_bytes (saved->message, message);
    std::puts ("BASELINE_NATIVE_COPY_FAILURE: source_null=0 freed=0 live_errors=1 (recovered below)");
    g_error_free (saved); // Recover fixture-owned evidence after proving the baseline defect.
    check (live_errors == 0 && frees == 1, "fixture cleans up demonstrated baseline orphan");
#endif
  }
#endif
  check (live_errors == 0, "no tracked GLib errors remain at process exit");
  std::printf ("PASS: %u checks; mode=%s; allocator=%s; real GLib errors balanced\n", checks,
#ifdef FIXED_BOUNDARY
    "fixed",
#else
    "HEAD baseline",
#endif
#ifdef STANDARD_NEW
    "standard C++ new/delete"
#else
    "scoped C++ string-allocation fault"
#endif
  );
}
