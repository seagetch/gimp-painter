/* Negative control only: prove the unmodified ASan allocator catches new/free. */
#include <glib.h>
int main ()
{
  int *value = new int (7);
  g_free (value); // Deliberate mismatch; expected ASan failure in this control only.
}
