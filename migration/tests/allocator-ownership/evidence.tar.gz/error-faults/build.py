from pathlib import Path
import json,shlex,subprocess
root=Path(__file__).resolve().parent
native=json.loads((root/'native-flags.json').read_text())
libs=shlex.split(subprocess.check_output(['pkg-config','--libs','gobject-2.0'],text=True))
variants=[('baseline-fault','baseline',False,False),('fixed-fault','fixed',False,False),('baseline-fault-asan','baseline',False,True),('fixed-fault-asan','fixed',False,True),('fixed-standard-asan','fixed',True,True)]
commands=[]
for name,variant,standard,asan in variants:
 cmd=['c++','-I'+str(root/variant/'app')]+native+['-O1','-g','-fno-omit-frame-pointer','-Wall','-Wextra']
 if variant=='fixed': cmd+=['-DFIXED_BOUNDARY=1']
 if standard: cmd+=['-DSTANDARD_NEW=1']
 if asan: cmd+=['-fsanitize=address,undefined']
 cmd += [str(root/'error-faults.cpp'),str(root/variant/'app/painter/gimp-painter-error.cpp'),'-Wl,--wrap=g_error_free','-Wl,--wrap=g_clear_error']+libs+['-o',str(root/name)]
 commands.append(shlex.join(cmd))
 (root/'build-commands.txt').write_text('\n'.join(commands)+'\n')
 result=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (root/(name+'.build.log')).write_text(result.stdout)
 print(name,'exit',result.returncode,flush=True)
 if result.returncode: print(result.stdout); raise SystemExit(result.returncode)
cmd=['c++']+native+['-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(root/'allocator-mismatch-control.cpp')]+libs+['-o',str(root/'allocator-mismatch-control')]
commands.append(shlex.join(cmd))
(root/'build-commands.txt').write_text('\n'.join(commands)+'\n')
result=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(root/'allocator-mismatch-control.build.log').write_text(result.stdout)
print('allocator-mismatch-control','exit',result.returncode,flush=True)
if result.returncode: print(result.stdout); raise SystemExit(result.returncode)
