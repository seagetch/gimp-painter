from pathlib import Path
import hashlib,json,subprocess
root=Path('/workspace/shared/gimp-final-link-04008')
summary=json.loads((root/'summary.json').read_text())
cpp_records=[]
for variant in ('default','http'):
 build=Path('/workspace/shared/gimp-cpp-boundary-04005/build-'+variant)
 cc=json.loads((build/'compile_commands.json').read_text())
 wanted=['app/painter/gimp-painter-binding.cpp','app/painter/binding-store.cpp','app/core/gimpclonelayer.cpp','app/core/gimpfilterlayer.cpp','app/paint/painter-mypaint/resource.cpp']
 if variant=='http':wanted.append('app/httpd/httpd.cpp')
 for source in wanted:
  entry=next(t for t in cc if t['file'].endswith('/'+source))
  obj=build/entry['output']
  assert entry['command'].startswith('c++ ') and '-std=c++14' in entry['command']
  cpp_records.append({'variant':variant,'source':source,'object':str(obj),'object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'compiler':'c++','language_standard':'c++14'})
  if source=='app/painter/gimp-painter-binding.cpp':
   debug=subprocess.check_output(['readelf','--debug-dump=info',str(obj)],text=True)
   language=next(line.strip() for line in debug.splitlines() if 'DW_AT_language' in line)
   assert 'C++14' in language
   cpp_records[-1]['dwarf_language']=language
summary['production_cpp_objects']=cpp_records
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
text='''# 04.008 Final C++ runtime link verification

Result: PASS on source commit 34983b34c7e2c45b1c69c6c13ab93c17bef6574e, 2026-10-08 UTC.

Fresh native builds completed for the real `app/gimp-3.0` and `app/gimp-console-3.0` executables in both configurations:

| Configuration | Build steps | C main | Final driver | C++ runtime | Isolated version smoke |
| --- | ---: | --- | --- | --- | --- |
| painter-http=disabled | 1,425 | cc; defined main | c++ | libstdc++.so.6 | Both exit 0, GIMP 3.0.9 |
| painter-http=enabled | 1,447 | cc; defined main | c++ | libstdc++.so.6 | Both exit 0, GIMP 3.0.9 |

The compiler is GCC/G++ 14.2.0; C++ objects use `-std=c++14`. The main source is compiled by `cc` with no explicit `-std` flag; its DWARF C11 tag is retained only as debug metadata, not as evidence that C11 was explicitly selected. Both GUI and console targets retain explicit `link_language: 'cpp'` in `app/meson.build` (lines 231 and 247). Exact generated compile and link commands are saved separately. The final links include the real C `main.c.o`, the Painter/core/paint C++ archives, and `-lstdc++`.

All four linked binaries contain the unmangled production C bridge `gimp_painter_binding_close`, `gimp_painter_error_quark`, and the C++ BindingStore implementation. Sample migrated feature symbols verified in every binary cover CloneLayer, FilterLayer, FillBrush, Smudge, brush geometry, MyBrush, and MyPaint session. The HTTP-enabled binaries additionally contain the four HTTP service symbols and `libsoup-3.0.so.0`; these are absent in the disabled binaries. Final runtime imports include C++ allocation, exception handling, and exception personality symbols. The bridge object's debug language independently confirms C++14.

For each configuration, a negative control replayed the actual console link into a separate temporary output, replacing `c++` with `cc` and removing `-lstdc++`. Both links failed with exit 1 on the real MyPaint `resource.cpp.o` reference to `std::locale::~locale()` (GLIBCXX_3.4), followed by `libstdc++.so.6: DSO missing from command line`. Neither control created an executable; production executable hashes were unchanged. This demonstrates that the final runtime dependency is necessary for actual migrated C++ objects.

The only execution smoke was `--version`. Each process received a new minimal environment, isolated GIMP/XDG directories, no inherited display or D-Bus values, `GIMP_PAINTER_HTTP_ENABLE=0`, and explicitly empty HTTP port/token/webhook-origin values. No GUI startup, HTTP listener/request, or user profile was used.

Source safety: SHA-256 before/after comparison covered 9,915 tracked files, with zero content changes and the same source HEAD. The pre-existing untracked `tools/__pycache__/` remains. No source edits, commit, or push occurred. Both builds used `-j4` and `/workspace/shared/gimp-painter-build.lock`.

Generated-source precaution: existing genuine prerequisites did not suppress Ninja's enum/PDB generator recipes. Separate verification manifests redirect only 17 source-writing custom commands per configuration to the previously prepared isolated source copy; generated outputs still go to the real configured build directory. Production `build.ninja`, source files, and every compile/link recipe remain unchanged. The source-writing generators never target the checkout.

Evidence: `summary.json` contains allowlisted target, object, symbol, runtime, smoke, negative-control, and source-integrity records. Full build logs, exact target compile/link commands, negative-link diagnostics, version output, selected build options, compiler identities, and before/after source hash manifests are retained beside this report.

Scope: native Linux debugoptimized default and HTTP-enabled configurations. This establishes final-link/runtime closure; it does not replace GUI, HTTP request, or feature-behavior acceptance tests. Historical 04.004 evidence was not counted as a fresh success.
'''
(root/'report.md').write_text(text)
files=['summary.json','report.md','default-build.log','http-build.log','default-verification.json','http-verification.json','source-hashes-before.json','source-hashes-after.json']
(root/'artifact-hashes.json').write_text(json.dumps({name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files},indent=2)+'\n')
print('Completed report.md, summary.json and artifact-hashes.json; verified',len(cpp_records),'production C++ object records')
