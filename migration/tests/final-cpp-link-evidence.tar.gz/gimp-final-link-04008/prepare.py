from pathlib import Path
import hashlib,json,re,subprocess
repo=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active')
base=Path('/workspace/shared/gimp-cpp-boundary-04005')
evidence=Path('/workspace/shared/gimp-final-link-04008')
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')
hashes={p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in tracked if (repo/p).is_file()}
(evidence/'source-hashes-before.json').write_text(json.dumps(hashes,indent=2)+'\n')
(evidence/'source-head.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True))
for variant in ('default','http'):
 build=base/('build-'+variant)
 report=json.loads((build/'prerequisites-report.json').read_text())
 protected=set(report['protected_targets'])
 manifest=(build/'build.ninja').read_text()
 substitutions=[]
 blocks=manifest.split('\n\n')
 for i,block in enumerate(blocks):
  if not block.startswith('build '):continue
  targets=block.split(': ',1)[0][6:].split()
  if not protected.intersection(targets):continue
  match=re.search(r'^ COMMAND = (.+)$',block,re.M)
  if not match:raise RuntimeError(targets)
  original=match.group(1)
  original_file=evidence/(variant+'-'+str(len(substitutions))+'.command')
  original_file.write_text(original.replace('$ ',' ').replace('$$','$'))
  command=f'/usr/bin/python3 {evidence}/safe-generator.py {variant} {original_file}'
  blocks[i]=block[:match.start(1)]+command+block[match.end(1):]
  substitutions.append({'targets':targets,'original_command':original,'replacement_command':command})
 assert len(substitutions)==len(protected),(len(substitutions),len(protected))
 (evidence/(variant+'.ninja')).write_text('\n\n'.join(blocks))
 (evidence/(variant+'-protected-generators.json')).write_text(json.dumps(substitutions,indent=2)+'\n')
print('Recorded',len(hashes),'tracked file hashes; redirected 17 protected generator recipes per configuration; compile/link recipes unchanged')
