from pathlib import Path
import datetime,hashlib,json,os,re,shlex,subprocess,sys
variant=sys.argv[1]
assert variant in ('default','http')
repo=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active')
base=Path('/workspace/shared/gimp-cpp-boundary-04005')
build=base/('build-'+variant)
ev=Path('/workspace/shared/gimp-final-link-04008')
checks=[]
def run(args,**kw):
 return subprocess.run(args,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kw).stdout
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
targets=json.loads((build/'meson-info/intro-targets.json').read_text())
cc=json.loads((build/'compile_commands.json').read_text())
common_symbols=['main','gimp_painter_binding_close','gimp_painter_error_quark','gimp_clone_layer_get_type','gimp_filter_layer_get_type','gimp_fill_brush_get_type','gimp_painter_smudge_get_type','gimp_painter_brush_geometry_transform','gimp_painter_mybrush_get_type','gimp_painter_session_get_type']
for name in ('gimp-console-3.0','gimp-3.0'):
 exe=build/'app'/name
 assert exe.is_file(),exe
 target=next(t for t in targets if t['type']=='executable' and t['name']==name)
 main_obj='app/'+name+'.p/main.c.o'
 compile_entry=next(t for t in cc if t['output']==main_obj)
 compile_args=shlex.split(compile_entry['command'])
 assert compile_args[0]=='cc' and compile_entry['file'].endswith('/app/main.c')
 dwarf=run(['readelf','--debug-dump=info',str(build/main_obj)])
 language=next(x.strip() for x in dwarf.splitlines() if 'DW_AT_language' in x)
 assert 'C11' in language or 'C99' in language or re.search(r'\(ANSI C\)',language),language
 obj_symbols=run(['nm',str(build/main_obj)])
 assert re.search(r'\bT main$',obj_symbols,re.M)
 link_line=run(['ninja','-C',str(build),'-f',str(ev/(variant+'.ninja')),'-t','commands','app/'+name]).splitlines()[-1]
 link_args=shlex.split(link_line)
 assert link_args[0]=='c++',link_args[:2]
 assert '-lstdc++' in link_args
 (ev/(variant+'-'+name+'-compile-command.txt')).write_text(compile_entry['command']+'\n')
 (ev/(variant+'-'+name+'-link-command.txt')).write_text(link_line+'\n')
 all_symbols=run(['nm','--defined-only',str(exe)])
 selected={symbol:next((line for line in all_symbols.splitlines() if line.split()[-1]==symbol),None) for symbol in common_symbols}
 assert all(selected.values()),selected
 http_symbols=['gimp_painter_httpd_get_type','gimp_painter_httpd_from_environment','gimp_painter_httpd_start','gimp_painter_httpd_stop']
 for symbol in http_symbols:
  matched=next((line for line in all_symbols.splitlines() if line.split()[-1]==symbol),None)
  assert bool(matched)==(variant=='http'),(variant,symbol,matched)
  selected[symbol]=matched
 cpp_symbols=run(['nm','-C','--defined-only',str(exe)])
 store_symbols=[x for x in cpp_symbols.splitlines() if 'GimpPainter::BindingStore::' in x and re.search(r' [TtWw] ',x) and len(x)<200]
 assert store_symbols
 dyn=run(['readelf','--dynamic',str(exe)])
 needed=re.findall(r'\(NEEDED\).*?\[(.*?)\]',dyn)
 assert 'libstdc++.so.6' in needed
 assert ('libsoup-3.0.so.0' in needed)==(variant=='http')
 runtime=run(['nm','-D',str(exe)])
 runtime_selected=[x for x in runtime.splitlines() if any(y in x for y in ['__gxx_personality_v0','__cxa_throw','_Znwm@','_ZdlPvm@'])]
 assert any('__gxx_personality_v0' in x for x in runtime_selected)
 isolation=ev/(variant+'-'+name+'-isolated')
 isolation.mkdir(exist_ok=True)
 for folder in ('config','cache','data','runtime','profile'): (isolation/folder).mkdir(exist_ok=True)
 (isolation/'runtime').chmod(0o700)
 libraries=[build/p for p in ('libgimpbase','libgimpcolor','libgimpconfig','libgimpmath','libgimpmodule','libgimpthumb','libgimpwidgets')]
 if variant=='http':libraries.append(Path('/workspace/shared/gimp-http-deps-04005/root/usr/lib/x86_64-linux-gnu'))
 libraries.append(Path('/workspace/shared/gimp-build-deps-04005/root/usr/lib/x86_64-linux-gnu'))
 # A new environment excludes all inherited settings, tokens, display and D-Bus addresses.
 # The four optional HTTP start settings are explicitly cleared as an additional guard.
 smoke_env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','LD_LIBRARY_PATH':':'.join(map(str,libraries)),
  'GIMP3_DIRECTORY':str(isolation/'profile'),'XDG_CONFIG_HOME':str(isolation/'config'),
  'XDG_CACHE_HOME':str(isolation/'cache'),'XDG_DATA_HOME':str(isolation/'data'),'XDG_RUNTIME_DIR':str(isolation/'runtime'),
  'GIMP_PAINTER_HTTP_ENABLE':'0','GIMP_PAINTER_HTTP_PORT':'','GIMP_PAINTER_HTTP_TOKEN':'','GIMP_PAINTER_HTTP_WEBHOOK_ORIGIN':''}
 smoke=subprocess.run([str(exe),'--version'],env=smoke_env,cwd=isolation,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
 (ev/(variant+'-'+name+'-version.log')).write_text(smoke.stdout+smoke.stderr)
 assert smoke.returncode==0,(name,smoke.returncode,smoke.stderr)
 assert 'GNU Image Manipulation Program version' in smoke.stdout,smoke.stdout
 record={'variant':variant,'name':name,'executable':str(exe),'executable_sha256':sha(exe),
  'main_source':compile_entry['file'],'main_source_sha256':sha(repo/'app/main.c'),'main_object':main_obj,
  'main_object_sha256':sha(build/main_obj),'main_compile_driver':compile_args[0],'main_dwarf_language':language,
  'main_symbol':'T main','link_driver':link_args[0],'link_runtime_argument':'-lstdc++',
  'needed_libraries':needed,'production_symbols':selected,'cpp_binding_symbols':store_symbols[:8],
  'runtime_symbols':runtime_selected,'smoke':{'arguments':['--version'],'returncode':smoke.returncode,'stdout':smoke.stdout.strip(),
  'stderr':smoke.stderr.strip(),'isolation_directory':str(isolation),'http_start_settings_cleared':True,'inherited_environment_discarded':True}}
 # On the real console link, removing both the C++ driver and explicit runtime must fail.
 if name=='gimp-console-3.0':
  negative=link_args.copy();negative[0]='cc';negative.remove('-lstdc++')
  negative_output=ev/(variant+'-console-no-cpp-runtime')
  negative[negative.index('-o')+1]=str(negative_output)
  (ev/(variant+'-negative-command.json')).write_text(json.dumps(negative,indent=2)+'\n')
  with (ev/(variant+'-negative-link.log')).open('w') as log:
   control=subprocess.run(negative,cwd=build,stdout=log,stderr=subprocess.STDOUT)
  negative_text=(ev/(variant+'-negative-link.log')).read_text()
  errors=[x for x in negative_text.splitlines() if any(y in x for y in ('undefined reference','DSO missing from command line','error:'))]
  assert control.returncode!=0 and errors,(control.returncode,negative_text[-3000:])
  assert any('std::' in x or '__gxx_personality' in x or 'operator new' in x or 'GLIBCXX' in x or 'CXXABI' in x for x in errors),errors[:5]
  # The control executable is intentionally never executed; it is separate from production.
  record['negative_control']={'driver':'cc','removed_runtime_argument':'-lstdc++','output':str(negative_output),'returncode':control.returncode,
   'executable_created':negative_output.exists(),'representative_errors':errors[:12],'production_hash_unchanged':sha(exe)==record['executable_sha256']}
  assert record['negative_control']['production_hash_unchanged']
 checks.append(record)
 print(variant,name,'C main / C++ link / production symbols / isolated --version PASS',flush=True)
(ev/(variant+'-verification.json')).write_text(json.dumps({'verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks},indent=2)+'\n')
