from pathlib import Path
import hashlib,json,shlex,subprocess
repo=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active')
ev=Path('/workspace/shared/gimp-final-link-04008')
scope=json.loads((ev/'source-scope-draft.json').read_text())
paths=sorted({p for duty in scope['duties'] for p in duty['current_paths']})
assert len(paths)==40 and len(scope['duties'])==25
records=[];commands={};archive_cache={}
for variant in ('default','http'):
 build=Path('/workspace/shared/gimp-cpp-boundary-04005/build-'+variant)
 cc=json.loads((build/'compile_commands.json').read_text())
 intro=json.loads((build/'meson-info/intro-targets.json').read_text())
 links={name:shlex.split((ev/(variant+'-'+name+'-link-command.txt')).read_text()) for name in ('gimp-3.0','gimp-console-3.0')}
 commands[variant]=[]
 for path in paths:
  file=repo/path
  digest=hashlib.sha256(file.read_bytes()).hexdigest()
  duties=[duty for duty in scope['duties'] if path in duty['current_paths']]
  assert all(duty['current_path_sha256'][path]==digest for duty in duties)
  record={'variant':variant,'path':path,'source_sha256':digest,'work_ids':[d['work_id'] for d in duties]}
  if path.endswith('meson.build'):
   record['kind']='configuration'
   defined=[t for t in intro if t['defined_in']==str(file)]
   if path=='app/meson.build':
    record['configured_final_targets']=[{'name':t['name'],'filename':t['filename'][0],
     'compile_drivers':[s['compiler'] for s in t['target_sources'] if 'compiler' in s],
     'link_drivers':[s['linker'] for s in t['target_sources'] if 'linker' in s]} for t in defined if t['name'] in links]
    assert len(record['configured_final_targets'])==2
   else:
    generator=next(t for t in defined if t['type']=='custom')
    outputs=[Path(p) for p in generator['filename']]
    assert all(p.exists() for p in outputs)
    obj='app/paint/painter-mypaint/libpainter-mypaint.a.p/resource.cpp.o'
    deps=subprocess.check_output(['ninja','-C',str(build),'-t','deps',obj],text=True)
    relative=[str(p.relative_to(build)) for p in outputs]
    assert all(p in deps for p in relative) and '(VALID)' in deps
    record['configured_generator']={'name':generator['name'],'outputs':relative,'output_sha256':{str(p.relative_to(build)):hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs}}
    record['observed_dependency_consumer']={'object':obj,'dependency_log_status':'VALID','observed_outputs':relative,'archive':'app/paint/painter-mypaint/libpainter-mypaint.a','final_targets':['gimp-3.0','gimp-console-3.0']}
   records.append(record);continue
  record['kind']='translation-unit'
  entries=[entry for entry in cc if (Path(entry['directory'])/entry['file']).resolve()==file]
  if variant=='default' and path.startswith('app/httpd/'):
   assert not entries,path
   record['status']='excluded by painter-http=disabled'
   records.append(record);continue
  matches=[]
  for entry in entries:
   output=entry['output'];archive=output.split('.a.p/',1)[0]+'.a' if '.a.p/' in output else None
   member_targets=[name for name,args in links.items() if output in args or (archive and archive in args)]
   if not member_targets:continue
   obj=build/output
   assert obj.exists(),obj
   args=shlex.split(entry['command'])
   compiler=args[0];std=[arg for arg in args if arg.startswith('-std=')]
   assert compiler==('c++' if path.endswith('.cpp') else 'cc'),(path,compiler)
   membership={'output':output,'object_sha256':hashlib.sha256(obj.read_bytes()).hexdigest(),'compile_driver':compiler,'explicit_standard_flags':std,'final_link_input_targets':member_targets}
   if archive:
    archive_path=build/archive
    if str(archive_path) not in archive_cache:
     archive_cache[str(archive_path)]=subprocess.check_output(['ar','t',str(archive_path)],text=True).splitlines()
    assert str(obj) in archive_cache[str(archive_path)],(archive,output)
    membership['archive']=archive
    membership['archive_member_verified']=True
   else:membership['direct_final_link_object']=True
   matches.append(membership)
   commands[variant].append({'source':path,'directory':entry['directory'],'output':entry['output'],'command':entry['command']})
  assert matches,path
  record['status']='compiler/object/archive-or-direct-final-input membership verified'
  record['memberships']=matches
  records.append(record)
report={'criterion_scope':'Source registration and archive/direct-input membership only; does not claim every archive member is retained, runtime feature registration, or feature behavior completeness.',
 'source_head':scope['source_parent'],'scope_draft_sha256':hashlib.sha256((ev/'source-scope-draft.json').read_bytes()).hexdigest(),
 'duty_count':25,'unique_current_paths':40,'configuration_count':2,'records':records,
 'duties':[{'work_id':d['work_id'],'source_id':d['source_id'],'current_paths':d['current_paths']} for d in scope['duties']]}
(ev/'counterpart-membership.json').write_text(json.dumps(report,indent=2)+'\n')
for variant,entries in commands.items():(ev/(variant+'-counterpart-compiler-entries.json')).write_text(json.dumps(entries,indent=2)+'\n')
print('Verified 40 counterpart paths over both configurations, binding all 25 duties; 5 HTTP paths explicitly excluded in default')
print('Exact selected compiler entries:',{v:len(e) for v,e in commands.items()})
