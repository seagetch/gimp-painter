#ifndef __RESOURCE_screenshot_icons_H__
#define __RESOURCE_screenshot_icons_H__

#include <gio/gio.h>

G_BEGIN_DECLS

G_GNUC_INTERNAL GResource *screenshot_icons_get_resource (void);

G_END_DECLS

#endif
