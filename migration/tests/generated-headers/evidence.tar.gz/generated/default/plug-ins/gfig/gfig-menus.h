#ifndef __RESOURCE_gfig_menus_H__
#define __RESOURCE_gfig_menus_H__

#include <gio/gio.h>

G_BEGIN_DECLS

G_GNUC_INTERNAL GResource *gfig_menus_get_resource (void);

G_END_DECLS

#endif
