#ifndef __RESOURCE_lighting_icon_images_H__
#define __RESOURCE_lighting_icon_images_H__

#include <gio/gio.h>

G_BEGIN_DECLS

G_GNUC_INTERNAL GResource *lighting_icon_images_get_resource (void);

G_END_DECLS

#endif
