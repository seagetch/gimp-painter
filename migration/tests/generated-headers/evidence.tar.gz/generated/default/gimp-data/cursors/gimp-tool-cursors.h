#ifndef __RESOURCE_gimp_tool_cursors_H__
#define __RESOURCE_gimp_tool_cursors_H__

#include <gio/gio.h>

G_BEGIN_DECLS

G_GNUC_INTERNAL GResource *gimp_tool_cursors_get_resource (void);

G_END_DECLS

#endif
