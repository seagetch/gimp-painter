struct Huffnode
{
  signed short   left;
  signed short   right;
  unsigned short value  : 13;
  unsigned short leaf   :  1;
  unsigned short makeup :  1;
};
#include "plug-ins/file-bmp/huffman.h"
#include "plug-ins/file-bmp/huffman.h"
