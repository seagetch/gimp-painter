#include <glib.h>
#include "app/dialogs/welcome-dialog-data.h"
#include "app/dialogs/welcome-dialog-data.c"
