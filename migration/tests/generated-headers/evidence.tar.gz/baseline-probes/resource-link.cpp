#include "gimp-data/cursors/gimp-tool-cursors.h"
#include "gimp-data/cursors/gimp-tool-cursors.h"
GResource *(*probe)(void) = gimp_tool_cursors_get_resource;
