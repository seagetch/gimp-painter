#include <glib-object.h>
typedef struct _GimpPDB GimpPDB;
#include "app/pdb/internal-procs.h"
#include "app/pdb/internal-procs.h"
void (*probe)(GimpPDB*) = internal_procs_init;
