#ifndef __RESOURCE_ifs_menus_H__
#define __RESOURCE_ifs_menus_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *ifs_menus_get_resource (void);
#endif
