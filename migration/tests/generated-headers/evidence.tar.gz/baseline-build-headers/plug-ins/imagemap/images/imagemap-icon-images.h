#ifndef __RESOURCE_imagemap_icon_scalable_images_H__
#define __RESOURCE_imagemap_icon_scalable_images_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *imagemap_icon_scalable_images_get_resource (void);
#endif
