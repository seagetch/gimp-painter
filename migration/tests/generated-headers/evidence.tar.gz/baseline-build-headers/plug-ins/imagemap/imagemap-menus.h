#ifndef __RESOURCE_imagemap_menus_H__
#define __RESOURCE_imagemap_menus_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *imagemap_menus_get_resource (void);
#endif
