#ifndef __RESOURCE_gfig_icon_scalable_images_H__
#define __RESOURCE_gfig_icon_scalable_images_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *gfig_icon_scalable_images_get_resource (void);
#endif
