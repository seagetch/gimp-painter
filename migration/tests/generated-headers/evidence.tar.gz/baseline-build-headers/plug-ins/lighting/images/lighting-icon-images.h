#ifndef __RESOURCE_lighting_icon_images_H__
#define __RESOURCE_lighting_icon_images_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *lighting_icon_images_get_resource (void);
#endif
