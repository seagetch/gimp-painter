
/* NOTE: This file is auto-generated from authors.xml, do not edit it. */

static const gchar * const creators[] =
{
  "Spencer Kimball",
  "Peter Mattis",
  NULL
};

static const gchar * const maintainers[] =
{
  "Michael Natterer",
  "Jehan",
  NULL
};

static const gchar * const authors[] =
{
  "Spencer Kimball",
  "Peter Mattis",
  "Michael Natterer",
  "Jehan",
  "Jacob Boerema",
  "Simon Budig",
  "Shubham Daule",
  "Tobias Ellinghaus",
  "Ell",
  "Idriss Fekir",
  "Niels De Graef",
  "Stanislav Grinkov",
  "Povilas Kanapickas",
  "Øyvind Kolås",
  "Lloyd Konneker",
  "Bruno Lopes",
  "lillolollo",
  "Nikc M.",
  "Thomas Manni",
  "Daniel Novomeský",
  "Lukas Oberhuber",
  "Yoshio Ono",
  "Akkana Peck",
  "Liam Quin",
  "Oleksii Samorukov",
  "Michael Schumacher",
  "Elad Shahar",
  "Jernej Simončič",
  "Elle Stone",
  "Massimo Valentini",
  "woob",
  "Timm Bäder",
  "Daniel P. Berrange",
  "João S. O. Bueno",
  "Kevin Cozens",
  "Jeremiah Darais",
  "Alexia Death",
  "Marek Dvoroznak",
  "Gil Eliyahu",
  "Dirk Farin",
  "Richard Gitschlag",
  "Saul Goode",
  "Cameron Gregory",
  "Julien Hardelin",
  "Michael Henning",
  "Éric Hoffman",
  "HJ Imbens",
  "Hartmut Kuhse",
  "Adrian Likins",
  "Mikael Magnusson",
  "Pascal Massimino",
  "Johannes Matschke",
  "Robert McHardy",
  "Richard McLean",
  "Jörn Meier",
  "Simon Müller",
  "Lionel N.",
  "Nathan Osman",
  "Juan Palacios",
  "Ville Pätsi",
  "Félix Piédallu",
  "John Ralls",
  "Debarshi Ray",
  "Kristian Rietveld",
  "shark0r",
  "Mukund Sivaraman",
  "Jakub Steiner",
  "Tobias Stoeckmann",
  "Benoit Touchette",
  "Rupert Weber",
  "Mihail Zenkov",
  NULL
};

static const gchar * const artists[] =
{
  "Patrick David",
  "Aryeom Han",
  "Denis Rangelov",
  "Sevenix",
  "Alexia Death",
  "Philipp Haegi",
  "Ville Pätsi",
  "Klaus Staedtler",
  "Jakub Steiner",
  NULL
};

static const gchar * const documenters[] =
{
  "Jacob Boerema",
  "Patrick David",
  "Niels De Graef",
  "Lloyd Konneker",
  "Akkana Peck",
  "Alexandre Prokoudine",
  "Julien Hardelin",
  NULL
};
