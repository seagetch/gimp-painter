#ifndef __GIT_VERSION_H__
#define __GIT_VERSION_H__

#define GIMP_GIT_VERSION          "efe844e"
#define GIMP_GIT_VERSION_ABBREV   "efe844e"
#define GIMP_GIT_LAST_COMMIT_YEAR "2026"

#endif /* __GIT_VERSION_H__ */
