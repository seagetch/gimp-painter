#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/libgimpwidgets/gimpwidgetsmarshal.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/libgimpwidgets/gimpwidgetsmarshal.h"
auto volatile marshal_probe_0 = &_gimp_widgets_marshal_BOOLEAN__POINTER;
auto volatile marshal_probe_1 = &_gimp_widgets_marshal_VOID__BOXED_BOXED;
auto volatile marshal_probe_2 = &_gimp_widgets_marshal_VOID__DOUBLE_DOUBLE;
auto volatile marshal_probe_3 = &_gimp_widgets_marshal_VOID__ENUM_BOOLEAN;
auto volatile marshal_probe_4 = &_gimp_widgets_marshal_VOID__INT_INT;
auto volatile marshal_probe_5 = &_gimp_widgets_marshal_VOID__OBJECT_INT;
auto volatile marshal_probe_6 = &_gimp_widgets_marshal_VOID__STRING_FLAGS;
auto volatile marshal_probe_7 = &_gimp_widgets_marshal_VOID__STRING_INT;
int main() { return 0; }
