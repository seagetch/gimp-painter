#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/app/widgets/stamp-widgets-enums.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/app/widgets/stamp-widgets-enums.h"
