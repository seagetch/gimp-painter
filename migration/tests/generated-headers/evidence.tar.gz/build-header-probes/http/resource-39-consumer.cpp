#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/screenshot/screenshot-icons.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/screenshot/screenshot-icons.h"
auto volatile resource_getter = &screenshot_icons_get_resource;
int main() { GResource *resource = screenshot_icons_get_resource(); return resource == nullptr; }
