#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/gfig/gfig-menus.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/gfig/gfig-menus.h"
