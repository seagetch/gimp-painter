#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/imagemap/imagemap-menus.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/imagemap/imagemap-menus.h"
auto volatile resource_getter = &imagemap_menus_get_resource;
int main() { GResource *resource = imagemap_menus_get_resource(); return resource == nullptr; }
