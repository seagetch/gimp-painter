#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/build-header-probes/http/welcome-missing-c-linkage.h"
#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/build-header-probes/http/welcome-missing-c-linkage.h"
#include <type_traits>
#include <cassert>
// Redeclare the actual API with C language linkage after the
// direct includes; this rejects missing header C linkage even
// when a compiler leaves global variable names unmangled.
extern "C" const gint gimp_welcome_dialog_n_items;
extern "C" const gchar *gimp_welcome_dialog_items[];
extern "C" const gchar *gimp_welcome_dialog_demos[];
extern "C" const gint gimp_welcome_dialog_intro_n_paragraphs;
extern "C" const gchar *gimp_welcome_dialog_intro[];
auto volatile probe_0 = &gimp_welcome_dialog_n_items;
auto volatile probe_1 = &gimp_welcome_dialog_items;
auto volatile probe_2 = &gimp_welcome_dialog_demos;
auto volatile probe_3 = &gimp_welcome_dialog_intro_n_paragraphs;
auto volatile probe_4 = &gimp_welcome_dialog_intro;
static_assert(std::is_same<decltype(gimp_welcome_dialog_n_items), const gint>::value, "count must be const gint");
static_assert(std::is_same<decltype(gimp_welcome_dialog_intro_n_paragraphs), const gint>::value, "count must be const gint");
int main() { assert(gimp_welcome_dialog_n_items >= 0); assert(gimp_welcome_dialog_intro_n_paragraphs >= 0); return 0; }
