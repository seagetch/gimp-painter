#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/lighting/images/lighting-icon-images.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/lighting/images/lighting-icon-images.h"
auto volatile resource_getter = &lighting_icon_images_get_resource;
int main() { GResource *resource = lighting_icon_images_get_resource(); return resource == nullptr; }
