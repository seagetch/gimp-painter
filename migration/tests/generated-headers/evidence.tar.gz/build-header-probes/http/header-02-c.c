#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/app/core/stamp-core-enums.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/app/core/stamp-core-enums.h"
