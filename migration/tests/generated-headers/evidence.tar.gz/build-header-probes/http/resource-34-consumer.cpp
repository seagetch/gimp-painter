#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/ifs-compose/ifs-menus.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/plug-ins/ifs-compose/ifs-menus.h"
auto volatile resource_getter = &ifs_menus_get_resource;
int main() { GResource *resource = ifs_menus_get_resource(); return resource == nullptr; }
