#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/app/gui/gimpdbusservice-generated.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/app/gui/gimpdbusservice-generated.h"
auto volatile dbus_probe_0 = &gimp_dbus_service_ui_get_type;
auto volatile dbus_probe_1 = &gimp_dbus_service_ui_interface_info;
auto volatile dbus_probe_2 = &gimp_dbus_service_ui_skeleton_new;
int main() { if (!gimp_dbus_service_ui_get_type() || !gimp_dbus_service_ui_interface_info()) return 1; GimpDBusServiceUI *p = gimp_dbus_service_ui_skeleton_new(); if (!p) return 2; g_object_unref(p); return 0; }
