#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/gimp-data/icons/Default/gimp-core-pixbufs.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-http/gimp-data/icons/Default/gimp-core-pixbufs.h"
auto volatile resource_getter = &gimp_core_pixbufs_get_resource;
int main() { GResource *resource = gimp_core_pixbufs_get_resource(); return resource == nullptr; }
