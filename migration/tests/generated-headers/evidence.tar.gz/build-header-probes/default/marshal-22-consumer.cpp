#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/libgimp/gimpuimarshal.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/libgimp/gimpuimarshal.h"
auto volatile marshal_probe_0 = &_gimpui_marshal_VOID__POINTER_BOOLEAN;
auto volatile marshal_probe_1 = &_gimpui_marshal_VOID__STRING_BOOLEAN;
int main() { return 0; }
