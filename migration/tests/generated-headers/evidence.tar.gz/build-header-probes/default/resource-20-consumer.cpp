#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/gimp-data/icons/Default/gimp-icon-pixbufs.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/gimp-data/icons/Default/gimp-icon-pixbufs.h"
auto volatile resource_getter = &gimp_icon_pixbufs_get_resource;
int main() { GResource *resource = gimp_icon_pixbufs_get_resource(); return resource == nullptr; }
