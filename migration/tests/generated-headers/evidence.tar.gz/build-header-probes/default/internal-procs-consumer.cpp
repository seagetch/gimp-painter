#include <glib-object.h>
#include "pdb-types.h"
#include "/workspace/scratch/5b5281e79681/gimp-painter-port-active/app/pdb/internal-procs.h"
#include "/workspace/scratch/5b5281e79681/gimp-painter-port-active/app/pdb/internal-procs.h"

auto volatile probe_0 = &internal_procs_init;
