#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/plug-ins/gfig/gfig-menus.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/plug-ins/gfig/gfig-menus.h"
auto volatile resource_getter = &gfig_menus_get_resource;
int main() { GResource *resource = gfig_menus_get_resource(); return resource == nullptr; }
