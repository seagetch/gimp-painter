#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/app/plug-in/stamp-plug-in-enums.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/app/plug-in/stamp-plug-in-enums.h"
