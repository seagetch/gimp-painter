#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/app/gegl/stamp-gimp-gegl-enums.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/app/gegl/stamp-gimp-gegl-enums.h"
