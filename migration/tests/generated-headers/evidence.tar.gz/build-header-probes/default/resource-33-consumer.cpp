#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/plug-ins/gfig/images/gfig-icon-images.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/plug-ins/gfig/images/gfig-icon-images.h"
auto volatile resource_getter = &gfig_icon_scalable_images_get_resource;
int main() { GResource *resource = gfig_icon_scalable_images_get_resource(); return resource == nullptr; }
