struct Huffnode
{
  signed short   left;
  signed short   right;
  unsigned short value  : 13;
  unsigned short leaf   :  1;
  unsigned short makeup :  1;
};
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/plug-ins/file-bmp/huffman.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/plug-ins/file-bmp/huffman.h"
