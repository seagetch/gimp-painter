#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/gimp-data/cursors/gimp-color-picker-cursors.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/gimp-data/cursors/gimp-color-picker-cursors.h"
auto volatile resource_getter = &gimp_color_picker_cursors_get_resource;
int main() { GResource *resource = gimp_color_picker_cursors_get_resource(); return resource == nullptr; }
