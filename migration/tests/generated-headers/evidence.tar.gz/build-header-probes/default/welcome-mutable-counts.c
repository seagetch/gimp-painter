#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/build-header-probes/default/welcome-mutable-counts.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/app/dialogs/welcome-dialog-data.c"
