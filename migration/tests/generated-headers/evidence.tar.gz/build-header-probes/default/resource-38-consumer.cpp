#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/plug-ins/pagecurl/pagecurl-icons.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/plug-ins/pagecurl/pagecurl-icons.h"
auto volatile resource_getter = &pagecurl_icons_get_resource;
int main() { GResource *resource = pagecurl_icons_get_resource(); return resource == nullptr; }
