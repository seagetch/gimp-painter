#include <glib-object.h>
#define __GIMP_BASE_H_INSIDE__
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/libgimpbase/gimpversion.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/libgimpbase/gimpversion.h"
