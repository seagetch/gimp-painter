#include <glib.h>
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/app/dialogs/authors.h"
#include "/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/app/dialogs/authors.h"
