#!/usr/bin/env python3
"""Read-only build-output verification for GIMP migration 04.017.

Source the native environment first. This runner never invokes Meson/Ninja and
never writes to either the repository or build directory. All compiler outputs,
the generated consumers, and their exact commands remain under --output.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def token_hash(text):
    return hashlib.sha256(text.encode()).hexdigest()


def strip_comments(text):
    # Keep string and character literals intact while dropping C comments.
    return re.sub(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|/\*.*?\*/|//[^\n]*',
                  lambda m: ' ' if m[0].startswith(('/*', '//')) else m[0],
                  text, flags=re.S)


def wrapper_normalized(text):
    """Remove only standalone include guards, include lines and C-linkage lines.

    Real macro definitions with values and all declaration/data tokens survive.
    A const-count correction is accounted for separately by the caller.
    """
    text = strip_comments(text)
    guard_names = set(re.findall(r'^\s*#ifndef\s+(\w+)\s*$', text, re.M))
    lines = []
    for line in text.splitlines():
        s = line.strip()
        if s in ('G_BEGIN_DECLS', 'G_END_DECLS', '#endif'):
            continue
        if re.match(r'#\s*include\b', s) or re.match(r'#ifndef\s+', s):
            continue
        if any(re.fullmatch(r'#define\s+' + re.escape(g), s) for g in guard_names):
            continue
        lines.append(line)
    # Tokenize instead of erasing whitespace inside string literals.
    tokens = re.findall(r'"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|[A-Za-z_]\w*|\d+(?:\.\d+)?|\S', '\n'.join(lines))
    return '\n'.join(tokens)


class Runner:
    def __init__(self, args):
        self.repo = args.repo.resolve()
        self.build = args.build.resolve()
        self.out = args.output.resolve()
        self.out.mkdir(parents=True, exist_ok=True)
        self.baseline = args.baseline.resolve() if args.baseline else None
        self.db = json.loads((self.build / 'compile_commands.json').read_text())
        self.targets = json.loads((self.build / 'meson-info/intro-targets.json').read_text())
        self.scope = json.loads((self.repo / 'migration/inventory/generated-c-header-scope.json').read_text())
        self.commands = []
        self.headers = []
        self.abi = []
        self.comparisons = []
        self.runtime = []
        self.controls = []
        self.failures = []
        self.inputs = {}
        self.cc = self.compiler(self.find_row('app/pdb/internal-procs.c'))
        self.cxx = self.compiler(self.find_row('app/paint/painter-brush-settings/tests/test-data.cpp'))
        self.report = {'task': '04.017', 'repo': str(self.repo), 'build': str(self.build),
                       'output': str(self.out), 'headers': self.headers, 'abi': self.abi,
                       'runtime': self.runtime, 'comparisons': self.comparisons,
                       'negative_controls': self.controls,
                       'commands': self.commands, 'failures': self.failures,
                       'limitations': ['No full application build is attempted.',
                           'internal_procs_init is verified by a relocatable link against its real C provider; other application dependencies remain unresolved.',
                           'Definition-only MyPaint headers have internal-linkage data and no external C ABI; the repository real C11/C++14 metadata tests are compiled and run.',
                           'Optional help-browser/help-menus.h is inactive and is not claimed built by this runner.']}

    def fail(self, message):
        self.failures.append(message)

    def compiler(self, row):
        argv = row.get('arguments') or shlex.split(row['command'])
        # The native database starts with the real compiler, without wrappers.
        resolved = shutil.which(argv[0])
        if not resolved:
            raise RuntimeError(f'Compiler is unavailable: {argv[0]}')
        return resolved

    def find_row(self, suffix):
        matches = [r for r in self.db if r['file'].endswith(suffix)]
        if not matches:
            raise RuntimeError(f'No native compile command for {suffix}')
        return matches[0]

    def flags(self, row):
        # Retain native include paths, definitions, threading and PIC. Omit C-only
        # diagnostic flags and output/dependency options for the C++ consumers.
        words = row.get('arguments') or shlex.split(row['command'])
        result = []
        i = 1
        while i < len(words):
            w = words[i]
            if w in ('-I', '-isystem', '-iquote', '-D', '-U', '-include', '-imacros'):
                result.extend(words[i:i+2]); i += 2; continue
            if w.startswith(('-I', '-D', '-U')) or w in ('-pthread', '-fPIC', '-fno-common'):
                result.append(w)
            i += 1
        return result

    def run(self, name, argv, cwd=None, expect_failure=False):
        argv = [str(a) for a in argv]
        result = subprocess.run(argv, cwd=cwd or self.build, capture_output=True, text=True)
        log = self.out / f'{name}.log'
        log.write_text(result.stdout + result.stderr)
        row = {'name': name, 'argv': argv, 'cwd': str(cwd or self.build),
               'exit_code': result.returncode, 'expected': 'nonzero' if expect_failure else 0,
               'log': str(log)}
        self.commands.append(row)
        if (expect_failure and result.returncode == 0) or (not expect_failure and result.returncode != 0):
            self.fail(f'{name}: unexpected command exit {result.returncode}; see {log}')
        return result

    def remember(self, path):
        self.inputs[str(path)] = sha(path)

    def classify(self, header):
        text = (self.build / header).read_text()
        if not strip_comments(text).strip():
            return 'comment-only-stamp', '', self.find_row('app/pdb/internal-procs.c') if header.startswith(('app/', 'pdb/')) else self.find_row('libgimp/gimp.c')
        if header == 'plug-ins/file-bmp/huffman.h':
            bmp = self.repo / 'plug-ins/file-bmp/bmp-load.c'
            self.remember(bmp)
            struct = re.search(r'struct Huffnode\s*\{.*?\n\};', bmp.read_text(), re.S)
            if not struct:
                raise RuntimeError('Exact bmp-load.c struct Huffnode prerequisite not found')
            return 'definition-only-huffman', struct[0] + '\n', self.find_row('plug-ins/file-bmp/bmp-load.c')
        if header == 'app/dialogs/authors.h':
            return 'definition-only-authors', '#include <glib.h>\n', self.find_row('app/dialogs/about-dialog.c')
        if header == 'app/widgets/gimplanguagestore-data.h':
            return 'definition-only-languages', '#include <glib.h>\n', self.find_row('app/widgets/gimplanguagestore.c')
        if 'painter-brush-settings/' in header:
            return 'definition-only-mypaint', '', self.find_row('app/paint/painter-brush-settings/tests/test-data.c')
        if header == 'libgimpbase/gimpversion.h':
            return 'configured-version-macros', '#include <glib-object.h>\n#define __GIMP_BASE_H_INSIDE__\n', self.find_row('libgimp/gimp.c')
        if 'get_resource' in text:
            return 'resource-c-api', '', self.find_row(header[:-2] + '.c')
        if header.endswith('marshal.h'):
            return 'marshaller-c-api', '', self.find_row(header[:-2] + '.c')
        if header == 'app/gui/gimpdbusservice-generated.h':
            return 'gdbus-c-api', '', self.find_row(header[:-2] + '.c')
        if header == 'app/dialogs/welcome-dialog-data.h':
            return 'welcome-c-api', '#include <glib.h>\n', self.find_row(header[:-2] + '.c')
        if header in ('config.h', 'git-version.h'):
            return 'configured-macros', '', self.find_row('app/pdb/internal-procs.c')
        raise RuntimeError(f'Unclassified generated header: {header}')

    def compile_consumer(self, name, header, prelude, row, lang, body=''):
        source = self.out / f'{name}.{lang}'
        source.write_text(prelude + f'#include "{header}"\n' * 2 + body)
        obj = self.out / f'{name}.o'
        cc, std = (self.cc, 'c11') if lang == 'c' else (self.cxx, 'c++14')
        result = self.run(name, [cc, f'-std={std}', '-Werror', *self.flags(row),
                               '-c', source, '-o', obj])
        return obj, result.returncode == 0

    def verify_headers(self):
        generated = sorted({str(Path(p).relative_to(self.build))
                            for t in self.targets for p in t['filename'] if p.endswith('.h')})
        if len(generated) != self.scope['active_native_custom_header_count']:
            self.fail(f'Custom header count {len(generated)} differs from expected {self.scope["active_native_custom_header_count"]}')
        expected = generated + ['config.h', 'libgimpbase/gimpversion.h']
        self.report['custom_header_count'] = len(generated)
        self.report['configured_header_count'] = 2
        self.report['inactive_optional_headers'] = self.scope['inactive_optional_headers']
        for number, header in enumerate(expected):
            path = self.build / header
            if not path.is_file():
                self.fail(f'Missing actual generated output: {path}')
                continue
            self.remember(path)
            kind, prelude, row = self.classify(header)
            results = {}
            for lang in ('c', 'cpp'):
                name = f'header-{number:02d}-{lang}'
                _, passed = self.compile_consumer(name, path, prelude, row, lang)
                results[lang] = {'command': name, 'passed': passed}
            self.headers.append({'path': header, 'sha256': sha(path), 'kind': kind,
                                 'context_source': row['file'], 'prerequisite': prelude,
                                 'double_include': results,
                                 'abi_note': 'No declarations or symbols' if kind == 'comment-only-stamp' else None})
            self.compare(header)

    def compare(self, header):
        old = self.baseline / header if self.baseline else None
        if not old or not old.exists():
            return
        new = self.build / header
        self.remember(old)
        a, b = old.read_text(), new.read_text()
        change = None
        if header == 'app/dialogs/welcome-dialog-data.h':
            # This is the intentional interface fix, not generated content loss.
            a = re.sub(r'extern\s+gint(\s+gimp_welcome_dialog_(?:n_items|intro_n_paragraphs))', r'extern const gint\1', a)
            change = 'Expected correction: both exported count declarations are const gint'
        elif header == 'app/widgets/gimplanguagestore-data.h':
            a = re.sub(r'(?m)^(\s*)gchar \*(code|name);$', r'\1const gchar *\2;', a)
            change = 'Expected correction: GimpLanguageDef code/name fields point to const gchar; every table value remains unchanged'
        normalized_a, normalized_b = wrapper_normalized(a), wrapper_normalized(b)
        equal = normalized_a == normalized_b
        self.comparisons.append({'path': header, 'baseline_sha256': sha(old),
                                 'current_sha256': sha(new), 'byte_identical': old.read_bytes() == new.read_bytes(),
                                 'wrapper_normalized_baseline_sha256': token_hash(normalized_a),
                                 'wrapper_normalized_current_sha256': token_hash(normalized_b),
                                 'wrapper_normalized_equal': equal, 'expected_interface_change': change})
        if not equal and header != 'git-version.h':
            self.fail(f'Unexpected baseline content/declaration difference: {header}')

    def provider(self, name, source):
        row = self.find_row(source)
        path = (Path(row['directory']) / row['file']).resolve()
        self.remember(path)
        words = list(row.get('arguments') or shlex.split(row['command']))
        argv = [self.compiler(row)]
        i = 1
        while i < len(words):
            w = words[i]
            if w in ('-o', '-MF', '-MQ', '-MT'):
                i += 2; continue
            if w in ('-MD', '-MMD', '-MP') or w.startswith('-std='):
                i += 1; continue
            argv.append(w); i += 1
        obj = self.out / f'{name}-provider.o'
        argv += ['-std=c11', '-o', obj]
        result = self.run(f'{name}-provider', argv, row['directory'])
        return obj, row, result.returncode == 0, path

    def symbols(self, name, path, undefined=False):
        args = ['nm', '-u' if undefined else '--defined-only', '-g', path]
        result = self.run(name, args)
        return {line.split()[-1] for line in result.stdout.splitlines() if line.split()}

    def link_abi(self, name, header, source, prelude, symbols, body=None, execute=False):
        provider, row, provider_ok, provider_source = self.provider(name, source)
        headerpath = self.repo / header if header.startswith('app/pdb/') else self.build / header
        self.remember(headerpath)
        if body is None:
            body = '\n' + '\n'.join(f'auto volatile probe_{i} = &{symbol};' for i, symbol in enumerate(symbols)) + '\n'
        consumer, consumer_ok = self.compile_consumer(name + '-consumer', headerpath, prelude, row, 'cpp', body)
        case = {'name': name, 'header': header, 'header_sha256': sha(headerpath),
                'provider_source': str(provider_source), 'provider_sha256': sha(provider_source),
                'provider_context': row['file'], 'symbols': symbols,
                'provider_c11': provider_ok, 'consumer_cpp14': consumer_ok,
                'link': 'executable' if execute else 'relocatable'}
        self.abi.append(case)
        if not (provider_ok and consumer_ok):
            return
        unresolved = self.symbols(name + '-consumer-unresolved', consumer, True)
        provided = self.symbols(name + '-provider-defined', provider)
        case['consumer_required_symbols'] = sorted(unresolved)
        case['provider_defined_symbols'] = sorted(provided)
        # Each named C symbol must be required under its unmangled spelling and
        # supplied by the actual generated C translation unit.
        for symbol in symbols:
            if symbol not in unresolved or symbol not in provided:
                self.fail(f'{name}: C spelling {symbol} absent from consumer references or provider definitions')
        if execute:
            exe = self.out / name
            libs = shlex.split(self.run(name + '-glib-libs', ['pkg-config', '--libs', 'gio-2.0', 'gobject-2.0', 'glib-2.0']).stdout)
            linked = self.run(name + '-link', [self.cxx, consumer, provider, *libs, '-o', exe])
            case['linked'] = linked.returncode == 0
            if linked.returncode == 0:
                case['executed'] = self.run(name + '-run', [exe]).returncode == 0
        else:
            combined = self.out / f'{name}-linked.o'
            linked = self.run(name + '-link', [self.cxx, '-r', consumer, provider, '-o', combined])
            case['linked'] = linked.returncode == 0
            if linked.returncode == 0:
                remaining = self.symbols(name + '-remaining-unresolved', combined, True)
                case['remaining_unresolved_symbols'] = sorted(remaining)
                case['tested_symbols_resolved'] = not set(symbols).intersection(remaining)
                if not case['tested_symbols_resolved']:
                    self.fail(f'{name}: tested C provider symbols remain unresolved')

    def verify_abi(self):
        self.link_abi('internal-procs', 'app/pdb/internal-procs.h', 'app/pdb/internal-procs.c',
                      '#include <glib-object.h>\n#include "pdb-types.h"\n', ['internal_procs_init'])
        welcome = ['gimp_welcome_dialog_n_items', 'gimp_welcome_dialog_items',
                   'gimp_welcome_dialog_demos', 'gimp_welcome_dialog_intro_n_paragraphs',
                   'gimp_welcome_dialog_intro']
        # Global address references exercise all five C data symbols, while the
        # static_asserts reject the old writable-count declarations in C++.
        body = '#include <type_traits>\n#include <cassert>\n'
        body += ('// Redeclare the actual API with C language linkage after the\n'
                 '// direct includes; this rejects missing header C linkage even\n'
                 '// when a compiler leaves global variable names unmangled.\n'
                 'extern "C" const gint gimp_welcome_dialog_n_items;\n'
                 'extern "C" const gchar *gimp_welcome_dialog_items[];\n'
                 'extern "C" const gchar *gimp_welcome_dialog_demos[];\n'
                 'extern "C" const gint gimp_welcome_dialog_intro_n_paragraphs;\n'
                 'extern "C" const gchar *gimp_welcome_dialog_intro[];\n')
        body += '\n'.join(f'auto volatile probe_{i} = &{s};' for i, s in enumerate(welcome)) + '\n'
        for s in (welcome[0], welcome[3]):
            body += f'static_assert(std::is_same<decltype({s}), const gint>::value, "count must be const gint");\n'
        body += 'int main() { assert(gimp_welcome_dialog_n_items >= 0); assert(gimp_welcome_dialog_intro_n_paragraphs >= 0); return 0; }\n'
        self.link_abi('welcome', 'app/dialogs/welcome-dialog-data.h', 'app/dialogs/welcome-dialog-data.c', '', welcome, body, True)
        # Force the direct C declaration and real definition into one translation
        # unit too, so qualifiers are checked by C rather than symbol matching.
        row = self.find_row('app/dialogs/welcome-dialog-data.c')
        src = self.out / 'welcome-c-qualifiers.c'
        src.write_text('#include "app/dialogs/welcome-dialog-data.h"\n#include "app/dialogs/welcome-dialog-data.c"\n')
        self.run('welcome-c-qualifiers', [self.cc, '-std=c11', '-Werror', *self.flags(row), '-c', src, '-o', self.out / 'welcome-c-qualifiers.o'])
        headertext = (self.build / 'app/dialogs/welcome-dialog-data.h').read_text()
        bad_linkage = self.out / 'welcome-missing-c-linkage.h'
        bad_linkage.write_text(re.sub(r'(?m)^G_(?:BEGIN|END)_DECLS\s*$', '', headertext))
        source = self.out / 'welcome-missing-c-linkage.cpp'
        source.write_text(f'#include "{bad_linkage}"\n' * 2 + body)
        result = self.run('welcome-missing-c-linkage-control', [self.cxx, '-std=c++14', '-Werror', *self.flags(row), '-c', source, '-o', self.out / 'bad-linkage.o'], expect_failure=True)
        self.controls.append({'name': 'welcome-missing-c-linkage', 'rejected': result.returncode != 0,
                              'change': 'Remove only G_BEGIN_DECLS/G_END_DECLS from final header; C-linkage redeclarations must conflict'})
        bad_const = self.out / 'welcome-mutable-counts.h'
        bad_const.write_text(re.sub(r'extern const gint', 'extern gint', headertext))
        source = self.out / 'welcome-mutable-counts.c'
        source.write_text(f'#include "{bad_const}"\n#include "{self.build / "app/dialogs/welcome-dialog-data.c"}"\n')
        result = self.run('welcome-mutable-counts-control', [self.cc, '-std=c11', '-Werror', *self.flags(row), '-c', source, '-o', self.out / 'bad-const.o'], expect_failure=True)
        self.controls.append({'name': 'welcome-mutable-counts', 'rejected': result.returncode != 0,
                              'change': 'Remove only const from two count declarations; actual C provider definitions must conflict'})
        for number, item in enumerate(self.headers):
            header = item['path']
            if item['kind'] == 'resource-c-api':
                text = (self.build / header).read_text()
                symbols = re.findall(r'\b(\w+_get_resource)\s*\(', text)
                if len(symbols) != 1:
                    self.fail(f'Expected exactly one resource getter in {header}')
                    continue
                symbol = symbols[0]
                body = f'auto volatile resource_getter = &{symbol};\nint main() {{ GResource *resource = {symbol}(); return resource == nullptr; }}\n'
                self.link_abi(f'resource-{number:02d}', header, header[:-2] + '.c', '', symbols, body, True)
            elif item['kind'] == 'marshaller-c-api':
                text = (self.build / header).read_text()
                symbols = sorted(set(re.findall(r'void\s+(\w+)\s*\(', text)))
                body = '\n'.join(f'auto volatile marshal_probe_{i} = &{s};' for i, s in enumerate(symbols)) + '\n'
                body += 'int main() { return 0; }\n'
                self.link_abi(f'marshal-{number:02d}', header, header[:-2] + '.c', '', symbols, body, True)
            elif item['kind'] == 'gdbus-c-api':
                symbols = ['gimp_dbus_service_ui_get_type', 'gimp_dbus_service_ui_interface_info',
                           'gimp_dbus_service_ui_skeleton_new']
                body = '\n'.join(f'auto volatile dbus_probe_{i} = &{s};' for i, s in enumerate(symbols)) + '\n'
                body += 'int main() { if (!gimp_dbus_service_ui_get_type() || !gimp_dbus_service_ui_interface_info()) return 1; GimpDBusServiceUI *p = gimp_dbus_service_ui_skeleton_new(); if (!p) return 2; g_object_unref(p); return 0; }\n'
                self.link_abi('gdbus', header, header[:-2] + '.c', '', symbols, body, True)

    def verify_mypaint(self):
        for lang, suffix, cc, std in [('c', 'c', self.cc, 'c11'), ('cpp', 'cpp', self.cxx, 'c++14')]:
            relative = f'app/paint/painter-brush-settings/tests/test-data.{suffix}'
            row = self.find_row(relative)
            source = self.repo / relative
            self.remember(source)
            self.remember(source.with_name('test-data.h'))
            exe = self.out / f'mypaint-metadata-{lang}'
            result = self.run(f'mypaint-metadata-{lang}-compile', [cc, f'-std={std}', '-Werror', *self.flags(row), source, '-o', exe])
            case = {'name': f'mypaint-metadata-{lang}', 'real_test_source': str(source),
                    'source_sha256': sha(source), 'compiled': result.returncode == 0}
            if result.returncode == 0:
                case['executed'] = self.run(f'mypaint-metadata-{lang}-run', [exe]).returncode == 0
            self.runtime.append(case)

    def finish(self):
        changed = [p for p, digest in self.inputs.items() if not Path(p).is_file() or sha(p) != digest]
        if changed:
            self.fail('Inputs changed during verification: ' + ', '.join(changed))
        self.report.update({'status': 'passed' if not self.failures else 'failed',
                            'input_sha256': self.inputs, 'inputs_stable': not changed,
                            'compile_commands_sha256': sha(self.build / 'compile_commands.json'),
                            'script_sha256': sha(__file__),
                            'compiler_c': self.cc, 'compiler_cpp': self.cxx,
                            'command_count': len(self.commands)})
        (self.out / 'report.json').write_text(json.dumps(self.report, indent=2) + '\n')
        print(json.dumps({'status': self.report['status'], 'headers': len(self.headers),
                          'double_include_compiles': sum(len(h['double_include']) for h in self.headers),
                          'abi_cases': len(self.abi), 'runtime_tests': len(self.runtime),
                          'failures': self.failures, 'report': str(self.out / 'report.json')}, indent=2))
        return 1 if self.failures else 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', required=True, type=Path)
    p.add_argument('--build', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--baseline', type=Path)
    args = p.parse_args()
    runner = Runner(args)
    for name, tool in [('compiler-c', runner.cc), ('compiler-cpp', runner.cxx)]:
        runner.run(name, [tool, '--version'])
    try:
        runner.verify_headers()
        runner.verify_abi()
        runner.verify_mypaint()
    except Exception as error:
        runner.fail(f'{type(error).__name__}: {error}')
    return runner.finish()


if __name__ == '__main__':
    sys.exit(main())
