from pathlib import Path
import hashlib,json,shlex,subprocess
R=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active');B=R.parent/'gimp-native-restore-20261008-evening/build-default';O=R.parent/'generated-header-04017-verification/baseline-probes';O.mkdir(exist_ok=True)
flags=shlex.split(subprocess.check_output(['pkg-config','--cflags','glib-2.0','gobject-2.0','gio-2.0'],text=True))
huff=(R/'plug-ins/file-bmp/bmp-load.c').read_text();start=huff.index('struct Huffnode\n');huff=huff[start:huff.index('};',start)+2]
rows=[]
def run(name,argv,expected):
 result=subprocess.run([str(x) for x in argv],capture_output=True,text=True);(O/(name+'.log')).write_text(result.stdout+result.stderr)
 row={'name':name,'command':[str(x) for x in argv],'exit_code':result.returncode,'expected':expected,'log':name+'.log'};rows.append(row);return result
for header,prelude in [('app/dialogs/authors.h','#include <glib.h>\n'),('app/widgets/gimplanguagestore-data.h','#include <glib.h>\n'),('plug-ins/file-bmp/huffman.h',huff+'\n')]:
 for lang,cc,std in [('c','gcc','c11'),('cpp','g++','c++14')]:
  name=Path(header).stem+'-'+lang;source=O/(name+'.'+lang);source.write_text(prelude+('#include "'+header+'"\n')*2)
  result=run(name,[cc,'-std='+std,'-Werror',*flags,'-I'+str(B),'-c',source,'-o',O/(name+'.o')],'duplicate include must currently fail')
  assert result.returncode!=0,name
header=B/'app/dialogs/welcome-dialog-data.h';source=O/'welcome-definitions.c';source.write_text('#include <glib.h>\n#include "app/dialogs/welcome-dialog-data.h"\n#include "app/dialogs/welcome-dialog-data.c"\n')
assert run('welcome-count-qualifiers',['gcc','-std=c11','-Werror',*flags,'-I'+str(B),'-I'+str(R),'-c',source,'-o',O/'welcome.o'],'header declarations currently conflict with real generated definitions').returncode!=0
source=O/'internal-link.cpp';source.write_text('#include <glib-object.h>\ntypedef struct _GimpPDB GimpPDB;\n#include "app/pdb/internal-procs.h"\n#include "app/pdb/internal-procs.h"\nvoid (*probe)(GimpPDB*) = internal_procs_init;\n')
assert run('internal-cpp-compile',['g++','-std=c++14','-Werror',*flags,'-I'+str(R),'-c',source,'-o',O/'internal-cpp.o'],'compiles but declares wrong linkage').returncode==0
provider=B/'app/pdb/libappinternalprocs.a.p/internal-procs.c.o';assert provider.exists()
assert run('internal-partial-link',['g++','-r',O/'internal-cpp.o',provider,'-o',O/'internal-linked.o'],'real C provider included in partial link').returncode==0
result=run('internal-unresolved',['nm','-u',O/'internal-linked.o'],'C++ mangled internal_procs_init remains unresolved despite actual C provider')
assert '_Z19internal_procs_init' in result.stdout,result.stdout
source=O/'resource-link.cpp';header=B/'gimp-data/cursors/gimp-tool-cursors.h';source.write_text('#include "gimp-data/cursors/gimp-tool-cursors.h"\n#include "gimp-data/cursors/gimp-tool-cursors.h"\nGResource *(*probe)(void) = gimp_tool_cursors_get_resource;\n')
assert run('resource-cpp-compile',['g++','-std=c++14','-Werror',*flags,'-I'+str(B),'-c',source,'-o',O/'resource-cpp.o'],'compiles but declares wrong C linkage').returncode==0
result=run('resource-unresolved',['nm','-u',O/'resource-cpp.o'],'resource getter declaration is C++ mangled')
assert '_Z30gimp_tool_cursors_get_resourcev' in result.stdout or '_Z29gimp_tool_cursors_get_resourcev' in result.stdout,result.stdout
(O/'report.json').write_text(json.dumps({'status':'all expected pre-fix defects reproduced','cases':rows,'source_sha256':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'pdb/app.pl',R/'app/pdb/internal-procs.h',R/'tools/generate-welcome-dialog-data.py',R/'app/dialogs/authors.xsl',R/'tools/gen-languages.c',R/'plug-ins/file-bmp/generate-huffman.c']}},indent=2)+'\n')
print('Reproduced six duplicate-include failures, welcome qualifier mismatch and both missing-C-linkage families')
