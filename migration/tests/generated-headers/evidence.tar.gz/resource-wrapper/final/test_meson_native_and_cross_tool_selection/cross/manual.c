#include <gio/gio.h>

#if defined (__ELF__) && ( __GNUC__ > 2 || (__GNUC__ == 2 && __GNUC_MINOR__ >= 6))
# define SECTION __attribute__ ((section (".gresource.manual"), aligned (sizeof(void *) > 8 ? sizeof(void *) : 8)))
#else
# define SECTION
#endif

static const SECTION union { const guint8 data[193]; const double alignment; void * const ptr;}  manual_resource_data = {
  "\107\126\141\162\151\141\156\164\000\000\000\000\000\000\000\000"
  "\030\000\000\000\164\000\000\000\000\000\000\050\003\000\000\000"
  "\000\000\000\000\001\000\000\000\002\000\000\000\012\107\063\052"
  "\002\000\000\000\164\000\000\000\010\000\114\000\174\000\000\000"
  "\200\000\000\000\002\225\323\321\000\000\000\000\200\000\000\000"
  "\013\000\166\000\220\000\000\000\271\000\000\000\324\265\002\000"
  "\377\377\377\377\271\000\000\000\001\000\114\000\274\000\000\000"
  "\300\000\000\000\146\151\170\164\165\162\145\057\001\000\000\000"
  "\160\141\171\154\157\141\144\056\164\170\164\000\000\000\000\000"
  "\031\000\000\000\000\000\000\000\122\145\163\157\165\162\143\145"
  "\040\154\151\156\153\141\147\145\040\146\151\170\164\165\162\145"
  "\012\000\000\050\165\165\141\171\051\057\000\000\000\000\000\000"
  "" };

static GStaticResource static_resource = { manual_resource_data.data, sizeof (manual_resource_data.data) - 1 /* nul terminator */, NULL, NULL, NULL };

G_GNUC_INTERNAL
GResource *manual_get_resource (void);
GResource *manual_get_resource (void)
{
  return g_static_resource_get_resource (&static_resource);
}

G_GNUC_INTERNAL
void manual_unregister_resource (void);
void manual_unregister_resource (void)
{
  g_static_resource_fini (&static_resource);
}

G_GNUC_INTERNAL
void manual_register_resource (void);
void manual_register_resource (void)
{
  g_static_resource_init (&static_resource);
}
