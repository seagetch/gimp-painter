#ifndef __RESOURCE_manual_H__
#define __RESOURCE_manual_H__

#include <gio/gio.h>

G_BEGIN_DECLS

G_GNUC_INTERNAL GResource *manual_get_resource (void);

G_GNUC_INTERNAL void manual_register_resource (void);
G_GNUC_INTERNAL void manual_unregister_resource (void);


G_END_DECLS

#endif
