#include "fixture.h"
#include "fixture.h"
GResource *(*get_resource)(void) = &fixture_get_resource;
