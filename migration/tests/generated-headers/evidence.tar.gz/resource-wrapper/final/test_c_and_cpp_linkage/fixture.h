#ifndef __RESOURCE_fixture_H__
#define __RESOURCE_fixture_H__

#include <gio/gio.h>

G_BEGIN_DECLS

extern GResource *fixture_get_resource (void);

extern void fixture_register_resource (void);
extern void fixture_unregister_resource (void);


G_END_DECLS

#endif
