#include "fixture.h"
#include "fixture.h"
int main() { auto get = &fixture_get_resource; auto reg = &fixture_register_resource; auto unreg = &fixture_unregister_resource; reg(); auto resource = get(); unreg(); return resource ? 0 : 1; }
