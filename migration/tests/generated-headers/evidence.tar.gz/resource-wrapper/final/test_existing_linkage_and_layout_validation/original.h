#ifndef __RESOURCE_fixture_H__
#define __RESOURCE_fixture_H__

#include <gio/gio.h>

extern GResource *fixture_get_resource (void);
#endif
