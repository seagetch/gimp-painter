Do not modify a stale output
