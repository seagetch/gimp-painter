#!/usr/bin/env python3
"""Isolated imagemap parser header probes; does not run a Meson/Ninja build."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/scratch/5b5281e79681/gimp-painter-port-active')
NATIVE=Path('/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening')
KINDS=('cern','csim','ncsa')
COMMANDS=json.loads((NATIVE/'build-default/compile_commands.json').read_text())
parser=argparse.ArgumentParser()
parser.add_argument('stage',choices=('baseline','after'))
args=parser.parse_args()
STAGE=args.stage
records=[]


def run(argv,cwd,label,success=True):
    result=subprocess.run([str(a) for a in argv],cwd=cwd,text=True,capture_output=True)
    folder=ROOT/STAGE/'logs';folder.mkdir(parents=True,exist_ok=True)
    (folder/(label+'.log')).write_text(result.stdout+result.stderr)
    records.append({'label':label,'argv':[str(a) for a in argv], 'cwd':str(cwd),
                    'returncode':result.returncode,'expected_success':success})
    (ROOT/STAGE/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    if (result.returncode==0)!=success:
        raise RuntimeError(f'{label}: unexpected exit {result.returncode}\n{result.stdout}{result.stderr}')
    return result


def source_flags(kind):
    entry=next(e for e in COMMANDS if e['file'].endswith(f'imap_{kind}_parse.c'))
    argv=shlex.split(entry['command']); clean=[]; skip=False
    for arg in argv:
        if skip: skip=False; continue
        if arg in ('-o','-MF','-MQ'):
            skip=True; continue
        if arg in ('-MD','-c',entry['file']): continue
        clean.append(arg)
    return clean,Path(entry['directory'])


if STAGE=='after':
    for flavor in ('fallback','generated'):
        folder=ROOT/STAGE/flavor;folder.mkdir(parents=True,exist_ok=True)
        for kind in KINDS:
            for suffix in (('.y','_parse.h','_parse.c') if flavor=='fallback' else ('.y',)):
                shutil.copyfile(REPO/'plug-ins/imagemap'/f'imap_{kind}{suffix}',folder/f'imap_{kind}{suffix}')
            if flavor=='generated':
                run([sys.executable,REPO/'tools/meson-bison.py',f'imap_{kind}_parse.h',ROOT/'tooling/root/usr/bin/bison',
                     '--yacc','-d','--name-prefix',kind+'_','--output',f'imap_{kind}_parse.c',
                     '--defines='+f'imap_{kind}_parse.h',f'imap_{kind}.y'],folder,f'generate-{kind}')

checks=[]
for flavor in ('fallback','generated'):
    folder=ROOT/STAGE/flavor
    for kind in KINDS:
        for debug in (0,1):
            label=f'{flavor}-{kind}-debug{debug}'
            out=folder/f'{kind}-debug{debug}';out.mkdir(exist_ok=True)
            header=folder/f'imap_{kind}_parse.h'
            first='IMG' if kind=='csim' else 'RECTANGLE'
            base=f'''#include "{header}"
#include "{header}"
#include <stddef.h>
int (*probe_parse)(void) = {kind}_parse;
YYSTYPE *probe_lval = &{kind}_lval;
#if YYDEBUG
int *probe_debug = &{kind}_debug;
#endif
int probe(void)
{{
  {kind}_lval.val = {first};
#if YYDEBUG
  {kind}_debug = 0;
#endif
  return {kind}_parse();
}}
'''
            asserts=f'''ASSERT(sizeof(((YYSTYPE *)0)->val) == sizeof(int), "int value");
ASSERT(sizeof(((YYSTYPE *)0)->value) == sizeof(double), "double value");
ASSERT(sizeof(((YYSTYPE *)0)->id) == sizeof(char *), "string value");
ASSERT(offsetof(YYSTYPE, val) == 0, "val union offset");
ASSERT(offsetof(YYSTYPE, value) == 0, "value union offset");
ASSERT(offsetof(YYSTYPE, id) == 0, "id union offset");
ASSERT({first} == 258, "first user token");
'''
            for lang,compiler,std,assertion in [('c','cc','c11','_Static_assert'),('cpp','c++','c++11','static_assert')]:
                src=out/f'consumer.{lang}'
                src.write_text(base+f'#define ASSERT {assertion}\n'+asserts)
                run([compiler,'-std='+std,'-Wall','-Wextra','-Werror','-DYYDEBUG='+str(debug),'-c',src,'-o',out/(lang+'.o')],REPO,label+'-'+lang+'-double-include')
            linkage=out/'linkage.cpp'
            linkage.write_text(f'''#include "{header}"
#include "{header}"
extern "C" {{
  int {kind}_parse(void);
  extern YYSTYPE {kind}_lval;
#if YYDEBUG
  extern int {kind}_debug;
#endif
}}
''')
            run(['c++','-std=c++11','-Wall','-Wextra','-Werror','-DYYDEBUG='+str(debug),'-fsyntax-only',linkage],REPO,label+'-explicit-c-linkage',success=(STAGE=='after'))
            flags,builddir=source_flags(kind)
            run(flags+['-DYYDEBUG='+str(debug),'-c',folder/f'imap_{kind}_parse.c','-o',out/'parser.o'],builddir,label+'-real-parser-c-object')
            run(['c++','-r',out/'cpp.o',out/'parser.o','-o',out/'linked.o'],REPO,label+'-partial-link')
            undefined=run(['nm','-u',out/'linked.o'],REPO,label+'-undefined-symbols').stdout
            target_unresolved=[line for line in undefined.splitlines() if any(f'{kind}_{s}' in line for s in ('parse','lval','debug'))]
            assert bool(target_unresolved)==(STAGE=='baseline'), (label,target_unresolved)
            checks.append({'header':str(header),'debug':debug,'c_double_include':True,
                           'cpp_double_include':True,'explicit_c_linkage':STAGE=='after',
                           'real_parser_compiled':True,'partial_link_target_unresolved':target_unresolved})

report={'stage':STAGE,'compiler':run(['cc','--version'],REPO,'compiler-version').stdout.splitlines()[0],
        'checks':checks,'note':'Partial links deliberately retain unrelated application/lexer references; no parser execution or full app build is claimed.'}
if STAGE=='after':
    integrity=[]
    for kind in KINDS:
        for flavor in ('fallback','generated'):
            for suffix in ('.y','_parse.c'):
                before=ROOT/'baseline'/flavor/f'imap_{kind}{suffix}'
                after=ROOT/'after'/flavor/f'imap_{kind}{suffix}'
                assert before.read_bytes()==after.read_bytes(),str(after)
                integrity.append({'file':str(after),'byte_identical_to_baseline':True,
                                  'sha256':hashlib.sha256(after.read_bytes()).hexdigest()})
            before=(ROOT/'baseline'/flavor/f'imap_{kind}_parse.h').read_text()
            after=(ROOT/'after'/flavor/f'imap_{kind}_parse.h').read_text()
            pattern=r'\b([A-Z][A-Z_0-9]+)\s*=\s*(-?\d+)'
            assert re.findall(pattern,before)==re.findall(pattern,after)
            union=r'\bunion YYSTYPE\s*\{(.*?)\n\}'
            assert re.search(union,before,re.S).group(1)==re.search(union,after,re.S).group(1)
    report['integrity']=integrity
(ROOT/STAGE/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'stage':STAGE,'cases':len(checks),'commands':len(records),'pass':True}))
