/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_CSIM_IMAP_CSIM_PARSE_H_INCLUDED
# define YY_CSIM_IMAP_CSIM_PARSE_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int csim_debug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    IMG = 258,                     /* IMG  */
    SRC = 259,                     /* SRC  */
    WIDTH = 260,                   /* WIDTH  */
    HEIGHT = 261,                  /* HEIGHT  */
    BORDER = 262,                  /* BORDER  */
    USEMAP = 263,                  /* USEMAP  */
    START_MAP = 264,               /* START_MAP  */
    END_MAP = 265,                 /* END_MAP  */
    NAME = 266,                    /* NAME  */
    AREA = 267,                    /* AREA  */
    SHAPE = 268,                   /* SHAPE  */
    COORDS = 269,                  /* COORDS  */
    ALT = 270,                     /* ALT  */
    HREF = 271,                    /* HREF  */
    NOHREF = 272,                  /* NOHREF  */
    TARGET = 273,                  /* TARGET  */
    ONMOUSEOVER = 274,             /* ONMOUSEOVER  */
    ONMOUSEOUT = 275,              /* ONMOUSEOUT  */
    ONFOCUS = 276,                 /* ONFOCUS  */
    ONBLUR = 277,                  /* ONBLUR  */
    ONCLICK = 278,                 /* ONCLICK  */
    ACCESSKEY = 279,               /* ACCESSKEY  */
    TABINDEX = 280,                /* TABINDEX  */
    AUTHOR = 281,                  /* AUTHOR  */
    DESCRIPTION = 282,             /* DESCRIPTION  */
    BEGIN_COMMENT = 283,           /* BEGIN_COMMENT  */
    END_COMMENT = 284,             /* END_COMMENT  */
    FLOAT = 285,                   /* FLOAT  */
    STRING = 286                   /* STRING  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define IMG 258
#define SRC 259
#define WIDTH 260
#define HEIGHT 261
#define BORDER 262
#define USEMAP 263
#define START_MAP 264
#define END_MAP 265
#define NAME 266
#define AREA 267
#define SHAPE 268
#define COORDS 269
#define ALT 270
#define HREF 271
#define NOHREF 272
#define TARGET 273
#define ONMOUSEOVER 274
#define ONMOUSEOUT 275
#define ONFOCUS 276
#define ONBLUR 277
#define ONCLICK 278
#define ACCESSKEY 279
#define TABINDEX 280
#define AUTHOR 281
#define DESCRIPTION 282
#define BEGIN_COMMENT 283
#define END_COMMENT 284
#define FLOAT 285
#define STRING 286

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 49 "imap_csim.y"

  int val;
  double value;
  char *id;

#line 135 "imap_csim_parse.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE csim_lval;


int csim_parse (void);


#ifdef __cplusplus
}
#endif

#endif /* !YY_CSIM_IMAP_CSIM_PARSE_H_INCLUDED  */
