#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/after/generated/imap_cern_parse.h"
#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/after/generated/imap_cern_parse.h"
extern "C" {
  int cern_parse(void);
  extern YYSTYPE cern_lval;
#if YYDEBUG
  extern int cern_debug;
#endif
}
