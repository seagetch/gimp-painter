#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/after/fallback/imap_csim_parse.h"
#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/after/fallback/imap_csim_parse.h"
extern "C" {
  int csim_parse(void);
  extern YYSTYPE csim_lval;
#if YYDEBUG
  extern int csim_debug;
#endif
}
