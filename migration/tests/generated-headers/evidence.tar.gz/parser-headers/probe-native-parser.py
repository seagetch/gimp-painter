import json,shlex,subprocess
from pathlib import Path
root=Path('/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers')
commands=json.loads(Path('/workspace/scratch/5b5281e79681/gimp-native-restore-20261008-evening/build-default/compile_commands.json').read_text())
for kind in ('cern','csim','ncsa'):
 entry=next(e for e in commands if e['file'].endswith(f'imap_{kind}_parse.c'))
 argv=shlex.split(entry['command']); clean=[]; skip=False
 for arg in argv:
  if skip: skip=False; continue
  if arg in ('-o','-MF','-MQ'):
   skip=True; continue
  if arg != '-MD': clean.append(arg)
 clean+=['-o',str(root/f'native-{kind}.o')]
 result=subprocess.run(clean,cwd=entry['directory'],text=True,capture_output=True)
 (root/f'native-{kind}.log').write_text(result.stdout+result.stderr)
 (root/f'native-{kind}.command.json').write_text(json.dumps({'argv':clean,'cwd':entry['directory'],'returncode':result.returncode},indent=2))
 print(kind,result.returncode,(result.stdout+result.stderr)[:1500])
