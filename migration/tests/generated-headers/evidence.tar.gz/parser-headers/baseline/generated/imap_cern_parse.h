/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_CERN_IMAP_CERN_PARSE_H_INCLUDED
# define YY_CERN_IMAP_CERN_PARSE_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int cern_debug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    RECTANGLE = 258,               /* RECTANGLE  */
    POLYGON = 259,                 /* POLYGON  */
    CIRCLE = 260,                  /* CIRCLE  */
    DEFAULT = 261,                 /* DEFAULT  */
    AUTHOR = 262,                  /* AUTHOR  */
    DESCRIPTION = 263,             /* DESCRIPTION  */
    BEGIN_COMMENT = 264,           /* BEGIN_COMMENT  */
    FLOAT = 265,                   /* FLOAT  */
    COMMENT = 266,                 /* COMMENT  */
    LINK = 267                     /* LINK  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define RECTANGLE 258
#define POLYGON 259
#define CIRCLE 260
#define DEFAULT 261
#define AUTHOR 262
#define DESCRIPTION 263
#define BEGIN_COMMENT 264
#define FLOAT 265
#define COMMENT 266
#define LINK 267

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 46 "imap_cern.y"

   int val;
   double value;
   char *id;

#line 97 "imap_cern_parse.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE cern_lval;


int cern_parse (void);


#endif /* !YY_CERN_IMAP_CERN_PARSE_H_INCLUDED  */
