#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/baseline/generated/imap_ncsa_parse.h"
#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/baseline/generated/imap_ncsa_parse.h"
extern "C" {
  int ncsa_parse(void);
  extern YYSTYPE ncsa_lval;
#if YYDEBUG
  extern int ncsa_debug;
#endif
}
