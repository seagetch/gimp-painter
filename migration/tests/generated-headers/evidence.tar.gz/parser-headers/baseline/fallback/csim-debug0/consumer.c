#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/baseline/fallback/imap_csim_parse.h"
#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/baseline/fallback/imap_csim_parse.h"
#include <stddef.h>
int (*probe_parse)(void) = csim_parse;
YYSTYPE *probe_lval = &csim_lval;
#if YYDEBUG
int *probe_debug = &csim_debug;
#endif
int probe(void)
{
  csim_lval.val = IMG;
#if YYDEBUG
  csim_debug = 0;
#endif
  return csim_parse();
}
#define ASSERT _Static_assert
ASSERT(sizeof(((YYSTYPE *)0)->val) == sizeof(int), "int value");
ASSERT(sizeof(((YYSTYPE *)0)->value) == sizeof(double), "double value");
ASSERT(sizeof(((YYSTYPE *)0)->id) == sizeof(char *), "string value");
ASSERT(offsetof(YYSTYPE, val) == 0, "val union offset");
ASSERT(offsetof(YYSTYPE, value) == 0, "value union offset");
ASSERT(offsetof(YYSTYPE, id) == 0, "id union offset");
ASSERT(IMG == 258, "first user token");
