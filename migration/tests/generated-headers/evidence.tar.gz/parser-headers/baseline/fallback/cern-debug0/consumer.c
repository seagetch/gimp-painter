#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/baseline/fallback/imap_cern_parse.h"
#include "/workspace/scratch/5b5281e79681/generated-header-04017-verification/parser-headers/baseline/fallback/imap_cern_parse.h"
#include <stddef.h>
int (*probe_parse)(void) = cern_parse;
YYSTYPE *probe_lval = &cern_lval;
#if YYDEBUG
int *probe_debug = &cern_debug;
#endif
int probe(void)
{
  cern_lval.val = RECTANGLE;
#if YYDEBUG
  cern_debug = 0;
#endif
  return cern_parse();
}
#define ASSERT _Static_assert
ASSERT(sizeof(((YYSTYPE *)0)->val) == sizeof(int), "int value");
ASSERT(sizeof(((YYSTYPE *)0)->value) == sizeof(double), "double value");
ASSERT(sizeof(((YYSTYPE *)0)->id) == sizeof(char *), "string value");
ASSERT(offsetof(YYSTYPE, val) == 0, "val union offset");
ASSERT(offsetof(YYSTYPE, value) == 0, "value union offset");
ASSERT(offsetof(YYSTYPE, id) == 0, "id union offset");
ASSERT(RECTANGLE == 258, "first user token");
