import json, os, time
from pathlib import Path
target = Path(os.environ['GIMP_STARTUP_OUTPUT'])
gui = os.environ['GIMP_STARTUP_GUI'] == '1'
assert Gimp.get_pdb().lookup_procedure('plug-in-blinds') is not None
assert Gimp.get_pdb().lookup_procedure('plug-in-painter-small-tiles') is not None
assert Gimp.get_pdb().lookup_procedure('plug-in-painter-retinex') is not None
assert Gimp.get_pdb().lookup_procedure('plug-in-painter-convmatrix') is not None
resources = {kind: len(getter('')) for kind, getter in (
    ('brushes', Gimp.brushes_get_list), ('patterns', Gimp.patterns_get_list),
    ('gradients', Gimp.gradients_get_list), ('palettes', Gimp.palettes_get_list))}
assert all(resources.values()), resources
image = Gimp.Image.new(64, 64, Gimp.ImageBaseType.RGB)
layer = Gimp.Layer.new(image, 'installed startup', 64, 64,
                      Gimp.ImageType.RGBA_IMAGE, 100.0, Gimp.LayerMode.NORMAL)
assert image.insert_layer(layer, None, 0)
assert Gimp.context_set_foreground(Gegl.Color.new('rgb(1.0,0.0,0.0)'))
assert layer.edit_fill(Gimp.FillType.FOREGROUND)
destination = Gio.File.new_for_path(str(target/'startup.xcf'))
assert Gimp.file_save(Gimp.RunMode.NONINTERACTIVE, image, destination, None)
image.delete()
reopened = Gimp.file_load(Gimp.RunMode.NONINTERACTIVE, destination)
assert reopened and len(reopened.get_layers()) == 1
assert reopened.get_layers()[0].get_name() == 'installed startup'
display = Gimp.Display.new(reopened) if gui else None
if gui:
    assert display is not None
    Gimp.displays_flush()
(target/'batch-ready.json').write_text(json.dumps(dict(resources=resources, gui=gui)))
deadline = time.monotonic() + 30
while not (target/'observer-ready').exists():
    assert time.monotonic() < deadline, 'Startup observer did not acknowledge'
    time.sleep(0.02)
if not gui:
    reopened.delete()
print('INSTALLED_NORMAL_RESTORE_SAVE_REOPEN_OK')
