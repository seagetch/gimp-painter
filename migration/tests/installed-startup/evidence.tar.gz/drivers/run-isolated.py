#!/usr/bin/python3
import argparse,json,os,shutil,subprocess,sys
from pathlib import Path
BASE=Path('/workspace/scratch/5b5281e79681/installed-04016-verification')
REPO=BASE.parent/'gimp-painter-port-active'
NATIVE=BASE.parent/'gimp-native-restore-20261008'
p=argparse.ArgumentParser();p.add_argument('variant',choices=['default','http']);p.add_argument('name');p.add_argument('--gui',action='store_true');p.add_argument('--user-resources',action='store_true');p.add_argument('--existing-display',action='store_true');p.add_argument('--filter',action='store_true');a=p.parse_args()
package=BASE/('package-'+a.variant);recipe=package/'recipe';out=BASE/('isolated-'+a.variant);out.mkdir(exist_ok=True)
if a.gui and not a.existing_display:
    args=[str(NATIVE/'deps/root/usr/bin/xvfb-run'),'-a','--server-args=-screen 0 1024x768x24 -nolisten tcp',sys.executable,str(Path(__file__).resolve()),*sys.argv[1:],'--existing-display']
    raise SystemExit(subprocess.call(args))
shutil.copy2(REPO/'tools/check_installed_startup.py',recipe/'tools/check_installed_startup.py')
command=['bwrap','--ro-bind','/usr','/usr','--symlink','usr/bin','/bin','--symlink','usr/lib','/lib','--symlink','usr/lib64','/lib64','--ro-bind','/etc','/etc','--dev','/dev','--proc','/proc','--tmpfs','/tmp','--ro-bind',str(package/'gimp-painter-linux-x86_64'),'/runtime 日本語','--ro-bind',str(recipe),'/recipe','--bind',str(out),'/test','--chdir','/test','--clearenv','--setenv','PATH','/usr/bin:/bin']
if a.gui:
    command += ['--ro-bind','/tmp/.X11-unix','/tmp/.X11-unix','--ro-bind',os.environ['XAUTHORITY'],'/run/test-xauthority','--setenv','DISPLAY',os.environ['DISPLAY'],'--setenv','XAUTHORITY','/run/test-xauthority']
if a.filter:
    command += ['/usr/bin/python3','-B','/recipe/tools/check_installed_filter.py','--bundle','/runtime 日本語','--output','/test/'+a.name]
else:
    command += ['/usr/bin/python3','-B','/recipe/tools/check_installed_startup.py','--bundle','/runtime 日本語','--output','/test/'+a.name,'--forbid','/workspace','--forbid',str(REPO),'--forbid',str(NATIVE)]
    if a.gui: command += ['--gui','--gui-observation','/test/'+a.name+'-observation.json']
    if a.user_resources:command += ['--user-resources']
(BASE/(a.variant+'-'+a.name+'-command.json')).write_text(json.dumps({'command':command,'source_sha':subprocess.check_output(['git','-C',str(REPO),'rev-parse','HEAD'],text=True).strip()},indent=2)+'\n')
raise SystemExit(subprocess.call(command))
