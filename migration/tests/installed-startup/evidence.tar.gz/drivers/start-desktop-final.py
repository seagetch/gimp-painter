import json,subprocess
from pathlib import Path
base=Path('/workspace/scratch/5b5281e79681/installed-04016-verification')
with (base/'gui-final-default.log').open('w') as log:
 result=subprocess.run(['/usr/bin/python3','-B',str(base/'run-isolated.py'),'default','gui-final','--gui','--user-resources','--existing-display'],stdout=log,stderr=subprocess.STDOUT)
(base/'gui-final-default-exit.json').write_text(json.dumps({'exit_code':result.returncode})+'\n')
