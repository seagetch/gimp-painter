export GIMP_DEPS_DIRECTORY=/workspace/scratch/5b5281e79681/gimp-native-restore-20261008/deps
source tools/linux-debian13-env.sh
PYTHONDONTWRITEBYTECODE=1 python3 migration/tests/test_linux_runtime_package.py -v
