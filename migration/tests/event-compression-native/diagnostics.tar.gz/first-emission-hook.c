#define main frozen_perspective_main
#include "test-painter-perspective-events.c"
#undef main
static guint seen[32], n_seen;
static gboolean observe(GSignalInvocationHint *hint,guint n,const GValue *v,gpointer data)
{
 GdkEvent *e;guint32 time;
 if(g_value_get_object(&v[0])!=G_OBJECT(shell->canvas))return TRUE;
 e=g_value_get_boxed(&v[1]);time=gdk_event_get_time(e);
 if(time>=10000&&time<10032){g_assert_cmpuint(n_seen,<,32);seen[n_seen++]=time-10000;}
 return TRUE;
}
static void enqueue(GdkEventType type,guint id,GdkDevice *dev,guint state)
{
 GdkEvent *e=gdk_event_new(type);gdouble x,y;
 gimp_display_shell_transform_xy_f(shell,90+id*4,90+id*3,&x,&y);
 e->any.window=g_object_ref(gtk_widget_get_window(shell->canvas));e->any.send_event=TRUE;
 gdk_event_set_device(e,dev);gdk_event_set_source_device(e,dev);
 if(type==GDK_MOTION_NOTIFY){e->motion.time=10000+id;e->motion.x=x;e->motion.y=y;e->motion.state=state;}
 else if(type==GDK_BUTTON_RELEASE){e->button.time=10000+id;e->button.x=x;e->button.y=y;e->button.state=state;e->button.button=1;}
 else if(type==GDK_KEY_PRESS){e->key.time=10000+id;e->key.keyval=GDK_KEY_Shift_L;e->key.state=state;}
 else {e->crossing.time=10000+id;e->crossing.x=x;e->crossing.y=y;e->crossing.state=state;e->crossing.mode=GDK_CROSSING_NORMAL;e->crossing.detail=GDK_NOTIFY_NONLINEAR;e->crossing.focus=TRUE;}
 /* gdk_event_put copies. This fixture owns and frees only its input copy. */
 gdk_event_put(e);gdk_event_free(e);
}
static void queued_terminals(void)
{
 GdkEventType boundaries[]={GDK_BUTTON_RELEASE,GDK_KEY_PRESS,GDK_LEAVE_NOTIFY};
 for(guint k=0;k<G_N_ELEMENTS(boundaries);k++){
  create_image();gimp_test_run_mainloop_until_idle();n_seen=0;
  guint signal=g_signal_lookup("event",GTK_TYPE_WIDGET);gulong hook=g_signal_add_emission_hook(signal,0,observe,NULL,NULL);
  send_event(GDK_BUTTON_PRESS,0,80,80,0);g_assert_cmpuint(presses,==,1);
  enqueue(GDK_MOTION_NOTIFY,1,device,GDK_BUTTON1_MASK);enqueue(GDK_MOTION_NOTIFY,2,device,GDK_BUTTON1_MASK);
  enqueue(boundaries[k],3,device,GDK_BUTTON1_MASK);
  enqueue(GDK_MOTION_NOTIFY,4,device,k?GDK_BUTTON1_MASK:0);
  if(k)enqueue(GDK_BUTTON_RELEASE,5,device,GDK_BUTTON1_MASK);
  gimp_test_run_mainloop_until_idle();
  g_assert_cmpuint(n_seen,==,k?5:4);for(guint i=0;i<n_seen;i++)g_assert_cmpuint(seen[i],==,i+1);
  g_assert_cmpuint(releases,==,1);g_assert_cmpuint(n_motion,>,0);g_assert_null(shell->grab_seat);
  g_signal_remove_emission_hook(signal,hook);close_image();
 }
}
static void exact_reset(void)
{
 create_image();GdkWindow*w=gtk_widget_get_window(shell->canvas);
 gimp_tool_control_set_motion_mode(active()->control,GIMP_MOTION_MODE_EXACT);
 send_event(GDK_BUTTON_PRESS,0,80,80,0);g_assert_false(gdk_window_get_event_compression(w));
 send_event(GDK_BUTTON_RELEASE,GDK_BUTTON1_MASK,90,90,0);g_assert_true(gdk_window_get_event_compression(w));
 send_event(GDK_BUTTON_PRESS,0,80,80,0);g_assert_false(gdk_window_get_event_compression(w));
 send_event(GDK_BUTTON_RELEASE,GDK_BUTTON1_MASK|GDK_BUTTON3_MASK,90,90,0);g_assert_true(gdk_window_get_event_compression(w));
 send_event(GDK_BUTTON_PRESS,0,80,80,0);g_assert_false(gdk_window_get_event_compression(w));
 gimp_context_set_tool(gimp_get_user_context(gimp),gimp_get_tool_info(gimp,"gimp-move-tool"));
 g_assert_true(gdk_window_get_event_compression(w));close_image();
}
int main(int argc,char**argv)
{
 g_test_init(&argc,&argv,NULL);if(!gtk_init_check(&argc,&argv))return GIMP_EXIT_TEST_SKIPPED;
 gimp_test_utils_setup_menus_path();gimp=gimp_init_for_gui_testing(TRUE);
 g_test_add_func("/event-order/queued-terminals",queued_terminals);g_test_add_func("/event-order/exact-reset",exact_reset);
 g_application_run(gimp->app,0,NULL);gint r=gimp_core_app_get_exit_status(GIMP_CORE_APP(gimp->app));g_application_quit(G_APPLICATION(gimp->app));g_clear_object(&gimp->app);return r;
}
