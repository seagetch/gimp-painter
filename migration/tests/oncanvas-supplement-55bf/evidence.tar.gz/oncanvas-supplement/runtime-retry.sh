#!/bin/bash
set -euo pipefail
source /workspace/shared/gimp-clean-aggregate/env.sh
P=/tmp/exact55-oncanvas-supplement
export TMPDIR=/tmp HOME="$P/profile/home" XDG_CONFIG_HOME="$P/profile/config" XDG_CACHE_HOME="$P/profile/cache" XDG_DATA_HOME="$P/profile/data" XDG_STATE_HOME="$P/profile/state" XDG_RUNTIME_DIR="$P/profile/runtime"
mkdir -p "$HOME" "$XDG_CONFIG_HOME" "$XDG_CACHE_HOME" "$XDG_DATA_HOME" "$XDG_STATE_HOME" "$XDG_RUNTIME_DIR";chmod700="$XDG_RUNTIME_DIR";chmod 700 "$XDG_RUNTIME_DIR"
export LD_LIBRARY_PATH=$(find /workspace/shared/gimp-clean-aggregate/build -maxdepth 1 -type d -name 'libgimp*' -printf '%p:')${LD_LIBRARY_PATH:-}
python3 "$P/runtime-retry.py"
