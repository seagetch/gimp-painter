import pathlib,json,hashlib,subprocess,shlex,os,fcntl,re,time,shutil,tarfile
P=pathlib.Path(__file__).resolve().parent;A=pathlib.Path('/workspace/shared/gimp-clean-aggregate');B=A/'build';S=A/'source';E=A/'exact-55bfa5f1f72f33fb5a2f10b1f7a319bd773b0e94';O=P/'proof';O.mkdir(exist_ok=True)
lock=open(A/'build.lock','w');fcntl.flock(lock,fcntl.LOCK_EX)
print('lock acquired',flush=True)
source=json.loads((E/'prebuild-tracked-source-sha256.json').read_text())
def hashes(paths):return {str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(paths)}
def source_seal():
 changed=[n for n,h in source.items() if hashlib.sha256(os.fsencode(os.readlink(S/n))if(S/n).is_symlink()else(S/n).read_bytes()).hexdigest()!=h];assert not changed,changed
source_seal();owned=json.loads((P/'source-pins.json').read_text())
for name,pin in owned['files'].items():
 assert source[name]==pin['base_sha256'];assert hashlib.sha256((P/name).read_bytes()).hexdigest()==pin['candidate_sha256']
 old=(S/name).read_text().splitlines();new=iter((P/name).read_text().splitlines());assert all(any(x==line for x in new)for line in old),name
commands=json.loads((B/'compile_commands.json').read_text());jobs=[('painter-smudge-ui','test-painter-smudge-ui.cpp',26),('painter-save-continuation','test-painter-save-continuation.cpp',13),('painter-mypaint-tool','test-painter-mypaint-tool.cpp',27)];records=[];inputs=set()
for target,file,count in jobs:
 row=next(r for r in commands if r['file'].endswith('/'+file));cmd=shlex.split(row['command']);out=O/(target+'.o')
 for flag in ['-o','-MQ']:cmd[cmd.index(flag)+1]=str(out)
 cmd[cmd.index('-MF')+1]=str(out)+'.d';cmd[cmd.index('-c')+1]=str(P/'app/tests'/file)
 link=shlex.split(subprocess.check_output(['ninja','-t','commands','app/tests/'+target],cwd=B,text=True).splitlines()[-1]);link[link.index('-o')+1]=str(O/target);link[link.index(row['output'])]=str(out)
 for arg in link:
  x=pathlib.Path(arg);x=x if x.is_absolute() else B/x
  if not x.is_file() or x==out:continue
  inputs.add(x)
  if x.suffix=='.a' and x.read_bytes()[:8]==b'!<thin>\n':
   for n in subprocess.check_output(['ar','t',str(x)],cwd=B,text=True).splitlines():
    m=pathlib.Path(n);m=m if m.is_absolute()else B/m;assert m.is_file(),m;inputs.add(m)
 records.append({'target':target,'compile':cmd,'link':link,'cases':count})
inputs_before=json.loads((O/'link-inputs-before.json').read_text()); actual=hashes(inputs); print('input-set-difference', sorted(set(actual)-set(inputs_before)), sorted(set(inputs_before)-set(actual)), flush=True); assert all(actual.get(n)==h for n,h in inputs_before.items()); inputs={pathlib.Path(n) for n in inputs_before}; assert hashes(inputs)==inputs_before
# Runtime-only retry: compiled3 fixtures and unchanged geometry executable already sealed.
for job in records:assert (O/job['target']).is_file()
assert (O/'paint-geometry-tool').is_file()
assert hashes(inputs)==inputs_before;source_seal()
(O/'postlink-seal.json').write_text(json.dumps({'linked_inputs':len(inputs),'unchanged':True,'committed_sources':len(source),'base_commit':owned['base_commit'],'only_test_overlay':owned['files']},indent=2)+'\n')
# Original fixture build tree remains readonly; output profiles are private.
privatebuild=P/'runtime-build';(privatebuild/'app/tests/gimpdir-output').mkdir(parents=True,exist_ok=True)
for name in ['icons','themes','plug-ins']:
 if (B/name).exists() and not(privatebuild/name).exists():(privatebuild/name).symlink_to(B/name)
env=dict(os.environ,GIMP_TESTING_ABS_TOP_SRCDIR=str(S),GIMP_TESTING_ABS_TOP_BUILDDIR=str(privatebuild),GIMP_TESTING_PLUGINDIRS=str(B/'plug-ins/common'),UI_TEST='yes',GIMP_TEST_ONCANVAS_SCREENSHOTS=str(O/'screenshots'),GIMP_TEST_CONFLICT_SCREENSHOTS=str(O/'geometry-screenshots'))
(O/'screenshots').mkdir(exist_ok=True);(O/'geometry-screenshots').mkdir(exist_ok=True)
# Wrapper launches each case with genuine authenticated portrait server; no environment-only enable claim.
results=[]
for target,count in [(j[0],j[2])for j in jobs]+[('paint-geometry-tool',8)]:
 caseenv=dict(env)
 if target=='painter-save-continuation':caseenv['GSETTINGS_BACKEND']='memory'
 command=['python3',str(S/'tools/run-painter-xvfb.py'),str(O/target)];start=time.time();r=subprocess.run(command,env=caseenv,cwd=B,capture_output=True,text=True,timeout=180)
 row={'target':target,'command':command,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'duration':time.time()-start,'ok_tap_cases':len(re.findall(r'^ok \d+',r.stdout,re.M))};results.append(row);(O/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(target,r.returncode,row['ok_tap_cases'],flush=True)
 assert r.returncode==0 and row['ok_tap_cases']==count,(target,r.returncode,row['ok_tap_cases'])
source_seal();assert hashes(inputs)==inputs_before
(O/'final-seal.json').write_text(json.dumps({'committed_sources':len(source),'linked_inputs':len(inputs),'unchanged':True,'cases':sum(r['ok_tap_cases']for r in results),'production_commit':owned['base_commit'],'test_only_overlay':True},indent=2)+'\n')
fcntl.flock(lock,fcntl.LOCK_UN);print('RELEASED',flush=True)
