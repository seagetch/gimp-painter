# Defined extreme-coefficient old PDB observation

This separate 2026-10-04 capture leaves the original 304-case convolution archive
unchanged. It uses the same restored GIMP-painter 2.8.23, source commit
`afa43fae3e920210146abed514f136fd49f671b5`, and original convolution plug-in binary.
The source/binary hashes and actual command are in `capture-report.json`.

Two real noninteractive `plug-in-convmatrix` calls use Gray and RGB 3x3 images.
Each input byte is `(x+y+channel)%2`. The 25-element matrix has only its center
set to `3e38`; divisor is `3e38`, offset is zero, all five channel flags are one,
alpha-alg is zero, and border mode is EXTEND. Both calls returned SUCCESS (3).
The observed intermediate shadow and final output are byte-for-byte identical
to their 0/1 inputs. The report embeds all observed bytes, and `fixtures.json`
also indexes native tile data in the 45-byte deduplicated `pixels.bin`.

The old plug-in casts coefficient and divisor to the same finite float value.
Actual sample multiplication, accumulation and division remain finite for this
input. A coefficient-times-255 worst-case estimate overflows float, so rejecting
the request solely on that estimate excludes a defined old operation. This
capture does not claim that arbitrary source values with these parameters are
safe or defined.

`tools/capture_legacy_convolution_extreme.py` reproduces the capture using the
existing observation harness. Its only harness adaptation, `input-pattern.patch`,
changes synthetic source generation to 0/1 values. The old plug-in and original
convolution/merge implementations are unchanged. Observation hooks and compressed
build commands/logs are preserved. Source the legacy build environment before
running the script; choose a new output directory for a fresh observation.
