# Pinned old convolution runtime evidence

Captured 2026-10-04 from seagetch/gimp-painter commit
`afa43fae3e920210146abed514f136fd49f671b5` using the real installed 2.8.23
application libraries and unmodified `convolution-matrix` executable. The source
is preserved exactly as `pinned-convolution-matrix.c`. This is runtime evidence,
not a reimplementation used as its own oracle.

`capture-report.json` records the source, instrumented harness, original
application/plug-in binaries, commands and artifact hashes. `restoration-report.json`
records the separate fresh reference build, pinned babl/GEGL sources, verified
560-archive Debian dependency lock, existing compatibility patches, compiler
hashes and build/test results. No new compatibility or rendering patch was needed.
The known original GEGL simple-test failure remains recorded; a successful
convolution capture does not claim that unrelated dependency suite passed.

`fixtures.json` indexes deduplicated byte buffers in `pixels.bin` with byte
offsets, lengths and SHA-256 hashes. All pixels are native old TileManager bytes,
with no PNG conversion. For each case, `source` is the synthetic lower/source
layer; `input` is the direct-PDB initial buffer; `start1` is the actual FilterLayer
input; `merge1-input`, `merge1-shadow`, `merge1-mask`, and `merge1-output` surround
the real old shadow merge. `output` is the final layer. Only the initial ROI is
valid kernel output in a partial-ROI shadow; bytes outside it must not be treated
as defined convolution results. `initial_roi` contains selected,x1,y1,x2,y2;
`merge_bounds` columns are named in the manifest. The five channel selectors are
gray, red, green, blue, alpha. Matrix doubles retain PDB x*5+y ordering.

The normal corpus has 304 cases: 292 direct PDB invocations, including eight
expected execution errors for dimensions below 3, and 12 actual FilterLayer
runs. It covers RGB/RGBA/Gray/GrayA; 3x3, 4x4 and 9x8 scenes; all three requested
borders; asymmetric and signed/fractional coefficients; divisor/offset and float
cast/rounding; channel masks; all-zero alpha; hard/soft/offset selections; and
hard/soft final-selection changes at genuine plug-in progress callbacks.
FilterLayer scenes are 53x41, within a single old projection tile.

Measured quirks: all 114 alpha-alg=0/1 pairs have identical final output because
old NONINTERACTIVE `check_config` disables weighting. All 88 non-alpha border
pairs match because the same function forces EXTEND for RGB and Gray.
The PDB has 11 arguments and no autoset argument; positive/zero/negative-normalized
cases pass the divisor and offset a UI autoset operation would calculate.
This does not claim a GUI/autoset interaction test. `signature.tsv` records the
registered old parameter and value types. An independent fresh-profile repeat
matched all 304 final outputs (`repeat-report.json`).

Observation hooks count real FilterLayer starts/ends, record tile buffers and
apply explicitly requested selection edits at a real progress callback. They do
not change the old plug-in, convolution formula, projection or merge arithmetic.
The separate source/harness is `migration/tests/legacy-convolution-capture.c`;
reproduce with `source /workspace/shared/gimp-legacy-build/env.sh` followed by
`python3 tools/capture_legacy_convolution.py --capture --output /new/empty/path`.
Use the tool's source/prefix/work options when rebuilding elsewhere.

## Negative and limited ROI evidence

`diagnostics/summary.json` is separate from the normal compatibility corpus.
For a right-edge partial ROI with CLEAR, all three repeated calls per GrayA/RGBA
returned success but produced different final bytes. The original row getter
logged 36 bounds assertions. These are undefined/nondeterministic results, not
valid goldens to emulate. One-row bottom-right selections returned stable final
selected pixels across three repeats, while the source still writes an
uninitialized preceding shadow row outside the ROI. No whole-shadow determinism
or expanded-selection correctness is claimed for that case. Diagnostic reports'
`passed` means the observation harness captured the calls successfully, not that
the legacy algorithm behaved correctly.

The gzip logs preserve normal startup GValue warnings and diagnostic assertions.
The sealed archive and member manifest preserve every normal and diagnostic case
without adding the local extracted directory to version control.
