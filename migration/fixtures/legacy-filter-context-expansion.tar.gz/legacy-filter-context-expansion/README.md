# Genuine old expanding-selection phase evidence

This is a new old-runtime integration prerequisite, not accepted GIMP 3 native integration.
The immutable source commit remains afa43fae3e920210146abed514f136fd49f671b5.
The three actual old FilterLayer scenes start with a hard 21x57 selection ROI
(x=21..42, y=3..60) inside a 63x63 RGBA layer. At the actual incoming old PDB
progress request 0.70175438596491224, the harness changes selection to:

- running-k1: larger hard rectangle (1..62, 1..62)
- running-k2: globally empty selection (unrestricted final merge)
- running-k3: soft nonzero selection across the interior

Each scene completes its original job without a restart, then receives one
unchanged-byte source notification for an exactly one-job rerun. The actual
pre-merge shadow, original drawable, final local coverage and resulting drawable
are captured, as are operation-start input and real PDB progress events.
All 2,772 pixels outside the initial write ROI have zero shadow bytes. Expanded
final merge changes alpha in 2,208 / 2,426 / 2,038 outside-ROI pixels; the same-input
rerun differs by 10,813 / 11,956 / 10,422 bytes respectively.

Source audit: app/core/gimpdrawable-shadow.c creates tile_manager_new with no
validate callback. app/base/tile-manager.c:339-355 zero-fills invalid tiles in
that case. Both shadow read/write handlers in app/plug-in/gimpplugin-message.c
register cleanup_add_shadow, and app/plug-in/gimpplugin-cleanup.c:335-344 frees
those shadow tiles on ordinary plug-in cleanup. The source hashes are recorded.
Reading the pre-merge shadow through native tiles may validate unwritten tiles;
the native final expanded merge would validate the same zero-filled tiles.

capture-report.json is the authoritative execution/source/hash record.
capture-harness.c and capture-script.py match its recorded source hashes exactly;
the latter records this restored workspace's absolute locations. Observation hooks
are identical in purpose to the accepted scalar corpus. No transformed expected
pixels are supplied by a replacement formula. Original files remain off-tree.
