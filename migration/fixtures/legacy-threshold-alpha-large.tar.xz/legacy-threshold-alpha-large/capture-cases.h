typedef struct { const char *id; gint width, height, components, image_width, image_height, offset_x, offset_y, threshold, live, selection, final_selection, active_components, final_components, lock_alpha, final_lock, zero_alpha, rerun, writer, phase, idle_selection, idle_components, idle_lock; } CaptureCase;
static const CaptureCase capture_cases[] = {
  {"live-c1-1031x1021-t127-s1-f0-a3-l0-spill-unchanged", 1031, 1021, 1, 1039, 1029, 3, 2, 127, 1, 1, 0, 3, -1, 0, -1, 0, 2, 0, 2, -1, -1, -1},
  {"live-c3-1031x1021-t127-s1-f2-a15-l0-spill-unchanged", 1031, 1021, 3, 1039, 1029, 3, 2, 127, 1, 1, 2, 15, -1, 0, -1, 0, 2, 0, 2, -1, -1, -1},
};
