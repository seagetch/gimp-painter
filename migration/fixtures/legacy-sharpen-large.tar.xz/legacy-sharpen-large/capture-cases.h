typedef struct { const char *id; gint width, height, components, image_width, image_height, offset_x, offset_y, percent, live, selection, final_selection, active_components, final_components, lock_alpha, final_lock, zero_alpha, rerun, writer; } CaptureCase;
static const CaptureCase capture_cases[] = {
  {"live-c2-1031x1021-p50-s1-f0-a3-l0-spill", 1031, 1021, 2, 1039, 1029, 3, 2, 50, 1, 1, 0, 3, -1, 0, -1, 0, 1, 0},
  {"live-c4-1031x1021-p50-s1-f2-a15-l0-spill", 1031, 1021, 4, 1039, 1029, 3, 2, 50, 1, 1, 2, 15, -1, 0, -1, 0, 1, 0},
};
