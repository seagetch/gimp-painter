# Genuine old FilterLayer context corpus

Produced by `tools/capture_legacy_filter_context.py` from pinned old source
`afa43fae3e920210146abed514f136fd49f671b5`, using actual old Blinds and native
shadow merge. See `capture-report.json` for complete source/executable hashes,
commands, verified fixture coverage and observed context changes.

`merges.tsv` columns: id, width, height, channels, active-byte bit mask, globally
empty selection. Each id has input, shadow, effective local mask, and output raw
files. `bounds.tsv` records drawable dimensions/offsets, global emptiness and
native global/local bounds. `events.tsv` records actual starts, completions,
idle checks and incoming PDB progress mutation checkpoints.

The 280 native cases cross every component bit mask with four selection modes.
`s0` is globally empty/unrestricted; `s1` hard; `s2` soft; `s3` globally selected
outside the drawable. `l0` has no alpha lock; `l1` has target alpha lock; `l2`
sets the ancestor native field as a deliberately synthetic source-rule probe,
because the old group setter rejects alpha lock. See the contract for this limit.

The twelve live scenes use `k1` hard selection, `k2` soft selection, `k3` red
only, `k4` alpha only, `k5` target alpha lock, and `k6` background. Idle context
changes start no new job and leave the settled cache identical. Running edits
occur at an actual PDB progress request after the plug-in pixel calculation and
before final shadow merge. Each scene then receives one unchanged-byte lower
source update to establish phase-dependent rerun behavior.

`capture-harness.c` and `capture-script.py` are exact copies whose hashes match
the report. `observation-hooks.patch` contains every old-source instrumentation
change. The installed old application and transformation source are unchanged.
This corpus does not claim current GIMP 3 integration or responsiveness acceptance.
