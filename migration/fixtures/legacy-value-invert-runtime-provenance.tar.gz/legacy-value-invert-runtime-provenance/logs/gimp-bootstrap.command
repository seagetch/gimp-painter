env NOCONFIGURE=1 ./autogen.sh --disable-gtk-doc 
