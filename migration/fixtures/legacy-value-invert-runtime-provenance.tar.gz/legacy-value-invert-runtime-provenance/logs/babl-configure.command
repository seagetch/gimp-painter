./configure --prefix=/workspace/shared/gimp-legacy-value-invert/build/prefix --disable-docs 
