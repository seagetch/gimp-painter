make -C tests/simple check -j4 
