/workspace/shared/gimp-legacy-value-invert/build/prefix/bin/gimp-2.8 --version 
