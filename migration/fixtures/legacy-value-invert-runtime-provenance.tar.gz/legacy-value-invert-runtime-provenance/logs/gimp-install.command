make -j4 install 
