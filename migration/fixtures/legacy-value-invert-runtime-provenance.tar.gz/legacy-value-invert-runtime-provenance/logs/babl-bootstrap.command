autoreconf --force --install --verbose 
