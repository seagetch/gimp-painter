; Actual pinned legacy Blinds PDB byte capture.

(let* ((image (car (gimp-file-load RUN-NONINTERACTIVE "/workspace/scratch/5b5281e79681/gimp-painter/migration/fixtures/legacy-blinds-package-smoke/input-RGBA-4096x4096.png" "/workspace/scratch/5b5281e79681/gimp-painter/migration/fixtures/legacy-blinds-package-smoke/input-RGBA-4096x4096.png"))) (layer (car (gimp-image-get-active-layer image))))
 (file-png-save2 RUN-NONINTERACTIVE image layer "/workspace/scratch/5b5281e79681/gimp-painter/migration/fixtures/legacy-blinds-package-smoke/loaded-RGBA-4096x4096.png" "/workspace/scratch/5b5281e79681/gimp-painter/migration/fixtures/legacy-blinds-package-smoke/loaded-RGBA-4096x4096.png" 0 9 0 0 0 0 0 0 1)
 (gimp-message "BLINDS_INPUT_LOADED=RGBA-4096x4096") (gimp-image-delete image))

(let* ((image (car (gimp-file-load RUN-NONINTERACTIVE "/workspace/scratch/5b5281e79681/gimp-painter/migration/fixtures/legacy-blinds-package-smoke/input-RGBA-4096x4096.png" "/workspace/scratch/5b5281e79681/gimp-painter/migration/fixtures/legacy-blinds-package-smoke/input-RGBA-4096x4096.png"))) (layer (car (gimp-image-get-active-layer image))))
 (gimp-context-set-background '(31 121 217))
 (gimp-message "BLINDS_CASE_START=RGBA-4096x4096-a67-s7-o1-t1")
 (plug-in-blinds RUN-NONINTERACTIVE image layer 67 7 1 1)
 (gimp-message "BLINDS_PDB_DONE=RGBA-4096x4096-a67-s7-o1-t1")
 (file-png-save2 RUN-NONINTERACTIVE image layer "/workspace/scratch/5b5281e79681/gimp-painter/migration/fixtures/legacy-blinds-package-smoke/RGBA-4096x4096-a67-s7-o1-t1.png" "/workspace/scratch/5b5281e79681/gimp-painter/migration/fixtures/legacy-blinds-package-smoke/RGBA-4096x4096-a67-s7-o1-t1.png" 0 9 0 0 0 0 0 0 1)
 (gimp-message "BLINDS_CASE_DONE=RGBA-4096x4096-a67-s7-o1-t1") (gimp-image-delete image))
