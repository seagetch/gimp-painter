typedef struct { const char *id; gint width, height, components, image_width, image_height, offset_x, offset_y, live, selection, final_selection, active_components, final_components, lock_alpha, final_lock, zero_alpha, rerun, writer, phase, idle_selection, idle_components, idle_lock, grouped, seeded; } CaptureCase;
static const CaptureCase capture_cases[] = {
  {"projection-c3-top-positive-fresh", 17, 13, 3, 13, 11, 3, 2, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 0, 0},
  {"projection-c3-top-positive-seeded", 17, 13, 3, 13, 11, 3, 2, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 0, 1},
  {"projection-c3-top-negative-fresh", 17, 13, 3, 13, 11, -4, -3, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 0, 0},
  {"projection-c3-top-negative-seeded", 17, 13, 3, 13, 11, -4, -3, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 0, 1},
  {"projection-c3-group-positive-fresh", 17, 13, 3, 13, 11, 3, 2, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 1, 0},
  {"projection-c3-group-positive-seeded", 17, 13, 3, 13, 11, 3, 2, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 1, 1},
  {"projection-c3-group-negative-fresh", 17, 13, 3, 13, 11, -4, -3, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 1, 0},
  {"projection-c3-group-negative-seeded", 17, 13, 3, 13, 11, -4, -3, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 1, 1},
  {"projection-c4-top-positive-fresh", 17, 13, 4, 13, 11, 3, 2, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 0, 0},
  {"projection-c4-top-positive-seeded", 17, 13, 4, 13, 11, 3, 2, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 0, 1},
  {"projection-c4-top-negative-fresh", 17, 13, 4, 13, 11, -4, -3, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 0, 0},
  {"projection-c4-top-negative-seeded", 17, 13, 4, 13, 11, -4, -3, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 0, 1},
  {"projection-c4-group-positive-fresh", 17, 13, 4, 13, 11, 3, 2, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 1, 0},
  {"projection-c4-group-positive-seeded", 17, 13, 4, 13, 11, 3, 2, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 1, 1},
  {"projection-c4-group-negative-fresh", 17, 13, 4, 13, 11, -4, -3, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 1, 0},
  {"projection-c4-group-negative-seeded", 17, 13, 4, 13, 11, -4, -3, 1, 0, -1, 15, -1, 0, -1, 0, 0, 0, 0, -1, -1, -1, 1, 1},
};
