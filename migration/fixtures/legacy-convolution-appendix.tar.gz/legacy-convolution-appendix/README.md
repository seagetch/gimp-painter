# Additional defined old PDB boundaries

Six genuine calls to the original pinned GIMP-painter 2.8.23 convolution plug-in,
recorded separately from the unchanged 304-case corpus and extreme-center probe.
All use native Gray or RGB 3x3 pixels with byte `(x+y+channel)%2`, which equals
`(pixel_index+channel)%2` at width 3. All returned SUCCESS (3); the capture report
embeds every observed input, intermediate shadow and final byte.

Four calls have center coefficient=divisor=3e38 and offset zero. The harness
appends a twelfth value after constructing the registered eleven arguments:
G_TYPE_INT value 4242 or G_TYPE_STRING value `ignored-old-convolution-sentinel`.
Both values are ignored by the original handler, and both Gray/RGB outputs
remain exactly equal to input. The original core transmits args->n_values;
the original handler explicitly accepts nparams==11 or12 and reads only the
first eleven. `input-pattern.patch` preserves the exact harness adaptation;
`argument-contract.json` records the relevant pristine source hashes.

Two further calls have an all-zero matrix, divisor 1, offset2147483500.0 and the
normal eleven arguments. The offset narrows to float2147483520, within the
defined int conversion range. All shadow and final output bytes are255.
A conservative cutoff at2147483000 would reject these valid observed calls.

This is bounded evidence for these inputs and sentinel types, not a claim that
all arbitrary trailing types or all extreme numeric values are safe. There is
no GUI test or formula-generated oracle. Existing observation-only hooks copy
old native tile buffers; all original plug-in, conversion and merge code stays
unchanged. The 72-byte pixels.bin and fixtures.json preserve the exact bytes.
Reproduce with tools/capture_legacy_convolution_appendix.py after sourcing the
restored legacy env.sh; choose a fresh output path.
